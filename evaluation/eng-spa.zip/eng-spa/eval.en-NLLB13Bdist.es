Los AM galeses se preocupan por "parecer muppets"
Hay consternación entre algunos AM por una sugerencia de que su título debería cambiar a MWPs (Miembro del Parlamento de Gales).
Ha surgido debido a los planes para cambiar el nombre de la asamblea al Parlamento de Gales.
Los AM de todo el espectro político están preocupados de que pueda invitar al ridículo.
Un laborista AM dijo que su grupo estaba preocupado "que rima con Twp y Pwp".
Para los lectores fuera de Gales: en galés twp significa tonto y pwp significa caca.
Un AM de Plaid dijo que el grupo en su conjunto no estaba "feliz" y ha sugerido alternativas.
Un conservador galés dijo que su grupo estaba "de mente abierta" sobre el cambio de nombre, pero señaló que era un corto salto verbal de MWP a Muppet.
En este contexto, la letra w galés se pronuncia de manera similar a la pronunciación inglesa de Yorkshire de la letra u.
La Comisión de la Asamblea, que actualmente está redactando una legislación para introducir los cambios de nombre, dijo: "La decisión final sobre cualquier descriptor de cómo se llaman a los miembros de la Asamblea será, por supuesto, un asunto para los propios miembros".
La Ley de Gobierno de Gales de 2017 dio a la asamblea galesa el poder de cambiar su nombre.
En junio, la Comisión publicó los resultados de una consulta pública sobre las propuestas que encontraron un amplio apoyo para llamar a la asamblea un Parlamento galés.
En cuanto al título de los AM, la Comisión favoreció a los miembros del Parlamento galés o WMP, pero la opción MWP recibió el mayor apoyo en una consulta pública.
Al parecer, los AM están sugiriendo opciones alternativas, pero la lucha por llegar a un consenso podría ser un dolor de cabeza para la presidenta, Elin Jones, quien se espera que presente un proyecto de ley sobre los cambios en unas semanas.
La legislación sobre las reformas incluirá otros cambios en el funcionamiento de la Asamblea, incluidas las normas sobre la inhabilitación de los AM y el diseño del sistema de comités.
Los AM obtendrán la votación final sobre la cuestión de cómo deberían llamarse cuando debatan la legislación.
Los macedonios acuden a las urnas para el referéndum sobre el cambio de nombre del país
Los votantes votarán el domingo si cambian el nombre de su país a "República de Macedonia del Norte".
La votación popular fue organizada en un intento de resolver una disputa de décadas con la vecina Grecia, que tiene su propia provincia llamada Macedonia.
Atenas ha insistido durante mucho tiempo en que el nombre de su vecino del norte representa una reclamación sobre su territorio y se ha opuesto repetidamente a sus ofertas de membresía en la UE y la OTAN.
El presidente macedonio Gjorge Ivanov, un opositor al plebiscito sobre el cambio de nombre, ha dicho que ignorará la votación.
Sin embargo, los partidarios del referéndum, incluido el primer ministro Zoran Zaev, argumentan que el cambio de nombre es simplemente el precio a pagar para unirse a la UE y la OTAN.
Las campanas de San Martín caen en silencio mientras las iglesias de Harlem luchan
"Históricamente, los ancianos con los que he hablado dicen que había un bar y una iglesia en cada esquina", dijo el Sr. Adams.
"Hoy, no hay ninguna de las dos".
Dijo que la desaparición de las barras era comprensible.
"La gente socializa de una manera diferente" hoy en día, dijo.
"Los bares ya no son salones de barrio donde la gente va regularmente".
En cuanto a las iglesias, le preocupa que el dinero de la venta de activos no dure tanto como los líderes esperan, "y tarde o temprano volverán a donde comenzaron".
Las iglesias, agregó, podrían ser reemplazadas por edificios de apartamentos con condominios llenos del tipo de personas que no ayudarán a los santuarios restantes del vecindario.
"La abrumadora mayoría de las personas que compran condominios en estos edificios serán blancos,Dijo, "y por lo tanto acelerará el día en que estas iglesias cierren por completo porque es poco probable que la mayoría de estas personas que se mudan a estos condominios se conviertan en miembros de estas iglesias".
Ambas iglesias fueron construidas por congregaciones blancas antes de que Harlem se convirtiera en una metrópolis negra: Metropolitan Community en 1870, St. Martin's una década después.
La congregación metodista blanca original se mudó en la década de 1930.
Una congregación negra que había estado adorando cerca se hizo con la propiedad del edificio.
St. Martin's fue tomada por una congregación negra bajo el reverendo John Howard Johnson, quien lideró un boicot de los minoristas en la calle 125, una calle principal para ir de compras en Harlem, que se resistieron a contratar o promover a los negros.
Un incendio en 1939 dejó el edificio gravemente dañado, pero cuando los feligreses del padre Johnson hicieron planes para reconstruirlo, encargaron el carillón.
El reverendo David Johnson, hijo del padre Johnson y su sucesor en St. Martin's, orgullosamente llamó al carillón "las campanas de los pobres".
El experto que tocó el carillón en julio lo llamó otra cosa: "Un tesoro cultural" y "un instrumento histórico insustituible".
La experta, Tiffany Ng, de la Universidad de Michigan, también señaló que fue el primer carillón del mundo tocado por un músico negro, Dionisio A. Lind, quien se mudó al carillón más grande de la Iglesia de Riverside hace 18 años.
El Sr. Merriweather dijo que St. Martin no lo reemplazó.
Lo que ha ocurrido en San Martín en los últimos meses ha sido una complicada historia de arquitectos y contratistas, algunos traídos por los líderes laicos de la iglesia, otros por la diócesis episcopal.
La sacristía, el órgano de gobierno de la parroquia, - escribió la diócesis en julio con preocupaciones de que la diócesis "buscara pasar los costos" a la sacristía, a pesar de que la sacristía no había participado en la contratación de los arquitectos y contratistas que la diócesis envió.
Algunos feligreses se quejaron de la falta de transparencia por parte de la diócesis.
Un tiburón hiere a un niño de 13 años en una inmersión de langosta en California
Un tiburón atacó e hirió a un niño de 13 años el sábado mientras buceaba en busca de langosta en California en el primer día de la temporada de langosta, dijeron las autoridades.
El ataque ocurrió justo antes de las 7 a.m. cerca de Beacon's Beach en Encinitas.
Chad Hammel dijo a KSWB-TV en San Diego que había estado buceando con amigos durante aproximadamente media hora el sábado por la mañana cuando escuchó al niño gritar pidiendo ayuda y luego remó con un grupo para ayudarlo a sacarlo del agua.
Hammel dijo que al principio pensó que era solo la emoción de atrapar una langosta, pero luego "se dio cuenta de que estaba gritando: 'Me mordieron!
¡Me han mordido!'
Toda su clavícula estaba abierta", Hammel dijo que se dio cuenta una vez que llegó al niño.
Le grité a todos que salieran del agua: "¡Hay un tiburón en el agua!" Hammel añadió.
El niño fue trasladado en avión al Hospital de Niños Rady en San Diego donde está en estado crítico.
Se desconocía la especie de tiburón responsable del ataque.
El capitán de socorristas Larry Giles dijo en una conferencia de prensa que un tiburón había sido visto en el área unas semanas antes, pero se determinó que no era una especie peligrosa de tiburón.
Giles agregó que la víctima sufrió lesiones traumáticas en la parte superior del torso.
Las autoridades cerraron el acceso a la playa desde Ponto Beach en Casablad hasta Swami's en Ecinitas durante 48 horas por motivos de investigación y seguridad.
Giles señaló que hay más de 135 especies de tiburones en la zona, pero la mayoría no se consideran peligrosas.
Los planes de Sainsbury's empujan hacia el mercado de belleza del Reino Unido
Sainsbury's se está enfrentando a Boots, Superdrug y Debenhams con pasillos de belleza al estilo de tiendas por departamentos con asistentes especializados.
Como parte de un impulso sustancial en el mercado de belleza de 2.800 millones de libras del Reino Unido, que continúa creciendo mientras las ventas de moda y artículos para el hogar caen, los pasillos de belleza más grandes serán probados en 11 tiendas en todo el país y llevados a más tiendas el próximo año si resulta un éxito.
La inversión en belleza se produce a medida que los supermercados buscan maneras de usar el espacio de los estantes una vez demandados para televisores, microondas y artículos para el hogar.
Sainsbury's dijo que duplicaría el tamaño de su oferta de belleza a hasta 3,000 productos, incluidas marcas como Revlon, Essie, Tweezerman y Dr. PawPaw por primera vez.
Las gamas existentes de L'Oreal, Maybelline y Burt's Bees también obtendrán más espacio con áreas de marca similares a las que se encuentran en tiendas como Boots.
El supermercado también está relanzando su gama de maquillaje Boutique para que la mayoría de los productos sean amigables con los veganos, algo cada vez más demandado por los compradores más jóvenes.
Además, el minorista de perfumes Fragrance Shop probará concesiones en dos tiendas de Sainsbury's, la primera de las cuales abrió en Croydon, sur de Londres, la semana pasada mientras que una segunda abrirá en Selly Oak, Birmingham, a finales de este año.
Las compras en línea y el cambio hacia la compra diaria de pequeñas cantidades de alimentos en las tiendas locales significan que los supermercados tienen que hacer más para persuadir a la gente a visitar.
Mike Coupe, el director ejecutivo de Sainsbury's, ha dicho que los puntos de venta se parecerán cada vez más a tiendas por departamentos a medida que la cadena de supermercados intenta luchar contra los discounters Aldi y Lidl con más servicios y no alimentos.
Sainsbury's ha estado poniendo puntos de venta de Argos en cientos de tiendas y también ha introducido una serie de hábitats desde que compró ambas cadenas hace dos años, lo que dice que ha reforzado las ventas de comestibles y ha hecho que las adquisiciones sean más rentables.
El intento anterior del supermercado de renovar sus departamentos de belleza y farmacia terminó en fracaso.
Sainsbury's probó una empresa conjunta con Boots a principios de la década de 2000, pero el vínculo terminó después de una disputa sobre cómo dividir los ingresos de las tiendas de la farmacia en sus supermercados.
La nueva estrategia se produce después de que Sainsbury's vendiera su negocio de farmacia de 281 tiendas a Celesio, el propietario de la cadena de farmacias Lloyds, por 125 millones de libras, hace tres años.
Dijo que Lloyds jugaría un papel en el plan, agregando una gama extendida de marcas de cuidado de la piel de lujo, incluidas La Roche-Posay y Vichy en cuatro tiendas.
Paul Mills-Hicks, director comercial de Sainsbury's, dijo: "Hemos transformado el aspecto y la sensación de nuestros pasillos de belleza para mejorar el ambiente para nuestros clientes.
También hemos invertido en colegas especialmente entrenados que estarán disponibles para ofrecer consejos.
Nuestra gama de marcas está diseñada para satisfacer todas las necesidades y el entorno atractivo y las ubicaciones convenientes significan que ahora somos un destino de belleza atractivo que desafía la vieja forma de comprar".
Peter Jones 'furioso' después de que Holly Willoughby se retirara de un acuerdo de 11 millones de libras
La estrella de Dragons Den, Peter Jones, se fue furiosa después de que la presentadora de televisión Holly Willoughby se retirara de un acuerdo de 11 millones de libras con su negocio de marcas de estilo de vida para centrarse en sus nuevos contratos con Marks and Spencer e ITV.
Willoughby no tiene tiempo para su marca de ropa para el hogar y accesorios Truly.
El negocio de la pareja había sido comparado con la marca Goop de Gwyneth Paltrow.
La presentadora de esta mañana, de 37 años, tomó a Instagram para anunciar que se va.
Holly Willoughby ha dejado furiosa a la estrella de Dragons' Den Peter Jones retirándose de su lucrativo negocio de marcas de estilo de vida en el último minuto para centrarse en sus nuevos contratos con Marks & Spencer e ITV.
Las fuentes dicen que Jones estaba "furioso" cuando la chica de oro de la TV admitió durante una tensa reunión el martes en la sede de su imperio de negocios en Marlow, Buckinghamshire, que sus nuevos acuerdos, valorados en hasta £1.5 millones, significaban que ya no tenía tiempo suficiente para dedicarse a su marca de ropa para el hogar y accesorios Truly.
El negocio había sido comparado con la marca Goop de Gwyneth Paltrow y se suponía que duplicaría la fortuna estimada de 11 millones de libras de Willoughby.
Mientras Willoughby, de 37 años, se dirigía a Instagram para anunciar que se iba de Truly, Jones salió de Gran Bretaña para dirigirse a una de sus casas de vacaciones.
Una fuente dijo: "Truly era de lejos la prioridad de Holly.
Iba a ser su futuro a largo plazo que la vería a través de las próximas dos décadas.
Su decisión de retirarse dejó a todos los involucrados absolutamente atónitos.
Nadie podía creer lo que estaba sucediendo el martes, estaba tan cerca del lanzamiento.
Hay un almacén lleno de mercancías en el cuartel general de Marlow que están listas para ser vendidas".
Los expertos creen que la salida del presentador de esta mañana, que se encuentra entre las estrellas más rentables de Gran Bretaña, podría costarle a la empresa millones debido a la fuerte inversión en productos que van desde cojines y velas hasta ropa y ropa para el hogar, y el potencial de más retrasos en su lanzamiento.
Y podría significar el final de una larga amistad.
La madre de tres hijos Willoughby y su esposo Dan Baldwin han estado cerca de Jones y su esposa Tara Capp durante diez años.
Willoughby creó Truly con Capp en 2016 y Jones, de 52 años, se unió como presidente en marzo.
Las parejas van de vacaciones juntas y Jones tiene una participación del 40% en la empresa de producción de televisión de Baldwin.
Willoughby se convertirá en un embajador de la marca para M & S y reemplazará a Ant McPartlin como anfitrión de I'm A Celebrity de ITV.
Una fuente cercana a Jones dijo anoche "No vamos a comentar sobre sus asuntos de negocios".
Hablamos duro y luego nos enamoramos.
Bromeó sobre las críticas que recibiría de los medios de comunicación por hacer un comentario que algunos considerarían "no presidencial" y por ser tan positivo sobre el líder norcoreano.
¿Por qué el presidente Trump ha renunciado tanto?
Trump dijo en su voz falsa de "anchor de noticias".
"No he renunciado a nada".
Señaló que Kim está interesado en una segunda reunión después de que su reunión inicial en Singapur en junio fue aclamada por Trump como un gran paso hacia la desnuclearización de Corea del Norte.
Pero las negociaciones de desnuclearización se han estancado.
Más de tres meses después de la cumbre de junio en Singapur, el principal diplomático de Corea del Norte, Ri Yong Ho, dijo a los líderes mundiales en la Asamblea General de la ONU el sábado que el Norte no ve una "respuesta correspondiente" de Estados Unidos a los primeros movimientos de desarme de Corea del Norte.
En cambio, señaló, los EE.UU. continúan las sanciones destinadas a mantener la presión.
Trump tuvo una visión mucho más optimista en su discurso de mitin.
"Estamos muy bien con Corea del Norte", dijo.
"Ibamos a la guerra con Corea del Norte.
Millones de personas habrían muerto.
Ahora tenemos una gran relación".
Dijo que sus esfuerzos para mejorar las relaciones con Kim han traído resultados positivos: poner fin a las pruebas de cohetes, ayudar a liberar rehenes y devolver los restos de los soldados estadounidenses a casa.
Y defendió su inusual enfoque al hablar de las relaciones con Kim.
"Es muy fácil ser presidente, pero en lugar de tener a 10.000 personas afuera tratando de entrar en esta arena llena, tendríamos a unas 200 personas de pie justo allí", dijo Trump, señalando a la multitud directamente delante de él.
Un tsunami y un terremoto devastaron una isla en Indonesia y mataron a cientos de personas
A raíz del terremoto de Lombok, por ejemplo, se dijo a las organizaciones no gubernamentales extranjeras que no eran necesarias.
Aunque más del 10 por ciento de la población de Lombok había sido desplazada, no se declaró desastre nacional, un requisito previo para catalizar la ayuda internacional.
"En muchos casos, desafortunadamente, han dejado muy claro que no están solicitando asistencia internacional, por lo que es un poco difícil", dijo la Sra. Sumbung.
Si bien Save the Children está reuniendo un equipo para viajar a Palu, todavía no está seguro si el personal extranjero puede trabajar en el terreno.
El Sr. Sutopo, portavoz de la agencia nacional de desastres, dijo que los funcionarios indonesios estaban evaluando la situación en Palu para ver si se permitiría a las agencias internacionales contribuir al esfuerzo de ayuda.
Dado el temblor de la tierra que Indonesia sufre constantemente, el país sigue siendo lamentablemente poco preparado para la ira de la naturaleza.
Aunque se han construido refugios para tsunamis en Aceh, no son una vista común en otras costas.
La aparente falta de una sirena de advertencia de tsunami en Palu, a pesar de que una advertencia había estado en vigor, probablemente ha contribuido a la pérdida de vidas.
En los mejores momentos, viajar entre las muchas islas de Indonesia es un desafío.
Los desastres naturales complican aún más la logística.
Un barco hospitalario que había estado estacionado en Lombok para tratar a las víctimas del terremoto se dirige a Palu, pero tardará al menos tres días en llegar al lugar de la nueva calamidad.
El presidente Joko Widodo hizo de la mejora de la infraestructura en ruinas de Indonesia una pieza central de su campaña electoral, y ha gastado dinero en carreteras y ferrocarriles.
Pero la escasez de fondos ha afectado a la administración del Sr. Joko mientras se enfrenta a la reelección el próximo año.
El Sr. Joko también se enfrenta a la presión de las persistentes tensiones sectarias en Indonesia, donde los miembros de la mayoría musulmana han adoptado una forma más conservadora de fe.
Más de 1.000 personas murieron y decenas de miles fueron desplazadas de sus hogares cuando bandas cristianas y musulmanas lucharon en las calles, usando machetes, arcos y flechas y otras armas brutales.
Ver: Daniel Sturridge del Liverpool se sumerge en el empate profundo contra el Chelsea
Daniel Sturridge salvó a Liverpool de una derrota en la Premier League ante el Chelsea con un gol en el minuto 89 el sábado en Stamford Bridge en Londres.
Sturridge recibió un pase de Xherdan Shaqiri mientras estaba a unos 30 metros de la portería del Chelsea con su equipo rezagado 1-0.
Él golpeó la pelota a su izquierda antes de recoger un tiro hacia el poste lejano.
El intento navegó muy por encima de la caja mientras se desplazaba hacia la esquina superior derecha de la red.
El balón finalmente cayó sobre un Kepa Arrizabalaga saltando y cayó en la red.
"Simplemente estaba tratando de entrar en esa posición, de conseguir el balón y jugadores como Shaq siempre lo juegan hacia adelante tanto como sea posible, así que solo traté de crearme tanto tiempo como fuera posible", dijo Sturridge a LiverpoolFC.com.
"Vi a Kante venir y tomé un toque y no lo pensé demasiado y sólo tomé el tiro".
Chelsea lideraba 1-0 en el descanso después de conseguir un gol en el minuto 25 de la estrella belga Eden Hazard.
El delantero de los Blues hizo un pase a Mateo Kovacic en esa jugada, antes de girar cerca del centro del campo y correr hacia la mitad de Liverpool.
Kovacic hizo un rápido pase en el centro del campo.
Luego disparó una hermosa pelota a través, llevando a Hazard a la caja.
Hazard superó a la defensa y terminó en la red con un tiro con el pie izquierdo más allá de Alisson Becker de Liverpool.
El Liverpool enfrenta al Nápoles en la fase de grupos de la Liga de Campeones a las 3 p.m. del miércoles en el Estadio San Paolo de Nápoles, Italia.
Chelsea enfrenta a Videoton en la UEFA Europa League el jueves a las 3 p.m. en Londres.
El número de muertos por el tsunami de Indonesia sube a 832
El número de muertos en el terremoto y el tsunami de Indonesia ha aumentado a 832, dijo la agencia de desastres del país el domingo por la mañana.
Se informó que muchas personas quedaron atrapadas entre los escombros de edificios derribados en el terremoto de magnitud 7,5 que golpeó el viernes y provocó olas de hasta 6 metros de altura, dijo el portavoz de la agencia Sutopo Purwo Nugroho en una conferencia de prensa.
La ciudad de Palu, que tiene más de 380.000 habitantes, estaba llena de escombros de edificios derrumbados.
La policía detiene a un hombre, de 32 años, bajo sospecha de asesinato después de que una mujer es apuñalada hasta la muerte.
Se ha iniciado una investigación de asesinato después de que el cuerpo de una mujer fue encontrado en Birkenhead, Merseyside esta mañana.
El hombre de 44 años fue encontrado a las 7.55 am con puñaladas en Grayson Mews en John Street, con un hombre de 32 años arrestado por sospecha de asesinato.
La policía ha instado a las personas en el área que vieron o escucharon algo a presentarse.
El detective inspector Brian O'Hagan dijo: "La investigación está en las primeras etapas, pero apelaría a cualquier persona que estuviera en las cercanías de John Street en Birkenhead que haya visto o escuchado algo sospechoso para que se ponga en contacto con nosotros.
También hago un llamamiento a cualquiera, especialmente a los taxistas que puedan haber capturado algo en las imágenes de la cámara de control, para que se pongan en contacto con nosotros ya que pueden tener información que es vital para nuestra investigación".
Un portavoz de la policía ha confirmado que la mujer cuyo cuerpo fue encontrado es local de Birkenhead y fue encontrada dentro de una propiedad.
Esta tarde amigos que creen conocer a la mujer han llegado a la escena para hacer preguntas sobre dónde la encontraron esta mañana.
Las investigaciones continúan ya que la policía ha dicho que están en el proceso de informar a los familiares más cercanos de la víctima.
Un taxista que vive en Grayson Mews acaba de intentar volver a su apartamento pero la policía le dice que a nadie se le permite entrar o salir del edificio.
Se quedó sin palabras cuando descubrió lo que había sucedido.
A los residentes ahora se les dice que pasarán horas hasta que se les permita volver.
Un oficial de policía fue escuchado diciendo a un hombre que la zona entera ahora está siendo tratada como una escena de crimen.
Una mujer apareció en la escena llorando.
Ella sigue repitiendo 'es tan horrible'.
A las 2 de la tarde dos furgonetas de policía estaban dentro del cordón con otra furgoneta justo afuera.
Varios oficiales estaban dentro del cordón vigilando el bloque de pisos.
A cualquier persona con información se le pide que envíe un DM a @MerPolCC, llame al 101 o contacte a Crimestoppers anónimamente al 0800 555 111 citando el registro 247 del 30 de septiembre.
La estatua del Parlamento de Cromwell se convierte en el último monumento conmemorativo golpeado por la reescritura de la historia
Su destierro sería una justicia poética por la destrucción de tantos artefactos culturales y religiosos de Inglaterra por parte de sus seguidores puritanos fanáticos.
Pero la Sociedad Cromwell describió la sugerencia del Sr. Crick como "tontería" y "intento de reescribir la historia".
John Goldsmith, presidente de la Sociedad Cromwell, dijo: "En el debate actual sobre la eliminación de estatuas era inevitable que la figura de Oliver Cromwell fuera del Palacio de Westminster se convirtiera en un blanco.
La iconoclasia de las guerras civiles inglesas no fue ordenada ni llevada a cabo por Cromwell.
Tal vez el mal Cromwell sería sacrificado por las acciones de su antepasado Thomas en el siglo anterior.
La magnífica representación de Sir William Hamo Thorneycroft de Cromwell es evidencia de la opinión del siglo XIX y parte de la historiografía de una figura que muchos creen que todavía vale la pena celebrar.
El Sr. Goldsmith dijo a The Sunday Telegraph: "Cromwell es considerado por muchos, tal vez más a finales del siglo XIX que hoy, como un defensor del parlamento contra la presión externa, en su caso, por supuesto, la monarquía.
Si esa es una representación totalmente exacta es objeto de continuo debate histórico.
Lo que es cierto es que el conflicto de mediados del siglo XVII ha dado forma al desarrollo posterior de nuestra nación, y Cromwell es una figura individual reconocible que representa un lado de esa división.
Sus logros como Lord Protector también merecen ser celebrados y conmemorados".
El cerdo asesino mató a un granjero chino
Un agricultor fue atacado y asesinado por un cerdo en un mercado en el suroeste de China, según informes de los medios locales.
El hombre, identificado solo por su apellido "Yuan", fue encontrado muerto con una arteria cortada, cubierto de sangre cerca de un establo en el mercado de Liupanshui en la provincia de Guizhou, informó el domingo el South China Morning Post.
Un criador de cerdos se prepara para inyectar vacunas en cerdos en una granja de cerdos el 30 de mayo de 2005 en Xining, provincia de Qinghai, China.
Según los informes, viajó con su primo desde la vecina provincia de Yunnan el miércoles para vender 15 cerdos en el mercado.
A la mañana siguiente, su primo lo encontró muerto, y descubrió una puerta abierta a un establo de cerdos vecino.
Dijo que en el establo había un gran cerdo macho con sangre en la boca.
Un examen forense confirmó que el cerdo de 550 libras había matado al granjero, según el informe.
"Las piernas de mi primo estaban ensangrentadas y mutiladas", dijo el primo, conocido por su apellido "Wu", según lo citado por el Guiyang Evening News.
Las imágenes de las cámaras de seguridad muestran a Yuan entrando al mercado a las 4.40 de la mañana del jueves para alimentar a sus cerdos.
Su cuerpo fue encontrado una hora después.
El animal que mató al hombre no pertenecía a Yuan ni a su primo.
Un gerente del mercado dijo al Evening News que el cerdo había sido encerrado para evitar que atacara a alguien más, mientras la policía recogía pruebas en el lugar.
Según los informes, la familia de Yuan y las autoridades del mercado están negociando una compensación por su muerte.
Aunque es raro, se han registrado casos de cerdos que atacan a humanos antes.
En 2016, un cerdo atacó a una mujer y su esposo en su granja en Massachusetts, dejando al hombre con heridas graves.
Diez años antes, un cerdo de 650 libras pegó a un granjero galés a su tractor hasta que su esposa asustó al animal.
Después de que un granjero de Oregon fue comido por sus cerdos en 2012, un granjero de Manitoba le dijo a CBC News que los cerdos normalmente no son agresivos, pero el sabor de la sangre puede actuar como un "gatillo".
"Sólo están jugando.
Son punzantes, muy curiosos... no quieren hacerte daño.
Usted sólo tiene que pagarles la cantidad adecuada de respeto", dijo.
Los restos del huracán Rosa traerán fuertes lluvias generalizadas al suroeste de EE.UU.
Como se predijo, el huracán Rosa se está debilitando mientras se mueve sobre las aguas más frías de la costa norte de México.
Sin embargo, Rosa traerá lluvias de inundación a través del norte de México y el suroeste de los EE.UU. en los próximos días.
Rosa tenía vientos de 85 mph, un huracán de categoría 1, a las 5 a.m. El domingo, hora del este, y estaba ubicado a 385 millas al suroeste de Punta Eugenia, México.
Se espera que Rosa se mueva hacia el norte el domingo.
Mientras tanto, Como Rosa se acerca a la península de Baja California el lunes como una tormenta tropical comenzará a empujar humedad tropical profunda hacia el norte en el suroeste de los EE.UU.
Rosa traerá hasta 10 pulgadas de lluvia en partes de México el lunes.
Luego, la humedad tropical interactuando con el canal que se aproxima creará fuertes lluvias en el suroeste en los próximos días.
A nivel local, de 1 a 4 pulgadas de lluvia causarán peligrosas inundaciones repentinas, flujos de escombros y posibles deslizamientos de tierra en el desierto.
La humedad tropical profunda hará que las precipitaciones se acerquen a 2 a 3 pulgadas por hora en algunos lugares, especialmente en partes del sur de Nevada y Arizona.
Se espera hasta 2 a 4 pulgadas de lluvia en partes del suroeste, especialmente en gran parte de Arizona.
Las inundaciones repentinas son posibles con condiciones que se deterioran rápidamente debido a la naturaleza dispersa de la lluvia tropical.
Sería extremadamente poco aconsejable aventurarse en el desierto a pie con la amenaza de lluvias tropicales.
Las fuertes lluvias podrían hacer que los cañones se conviertan en ríos furiosos y las tormentas eléctricas traerán ráfagas locales de viento y soplado de polvo.
El estrecho que se aproxima traerá algunas fuertes lluvias a partes de la costa del sur de California.
Las precipitaciones totales de más de media pulgada son posibles, lo que podría causar flujos de escombros menores y carreteras resbaladizas.
Esta sería la primera lluvia de la región de su temporada de lluvias.
Algunas lluvias tropicales dispersas comenzarán a acercarse a Arizona el domingo por la noche y el lunes temprano, antes de que la lluvia se extienda más tarde el lunes y el martes.
Las fuertes lluvias se extenderán a las cuatro esquinas el martes y durarán hasta el miércoles.
Octubre puede ver algunos cambios de temperatura intensos a través de los EE.UU. a medida que el Ártico se enfría, pero los trópicos siguen siendo bastante cálidos.
A veces esto conduce a cambios dramáticos en la temperatura a corta distancia.
Hay un gran ejemplo de dramáticas diferencias de temperatura en el centro de Estados Unidos el domingo.
Hay una diferencia de temperatura de casi 20 grados entre Kansas City, Missouri, y Omaha, Nebraska, y entre San Luis y Des Moines, Iowa.
Durante los próximos días, el prolongado calor del verano tratará de reconstruirse y expandirse de nuevo.
Se espera que gran parte del centro y el este de los Estados Unidos vean un comienzo cálido de octubre con temperaturas de 80 desde las llanuras del sur hasta partes del noreste.
La ciudad de Nueva York podría alcanzar los 80 grados el martes, que sería aproximadamente 10 grados por encima del promedio.
Nuestro pronóstico climático a largo plazo indica grandes posibilidades de temperaturas por encima del promedio para el este de EE.UU. hasta la primera mitad de octubre.
Más de 20 millones de personas vieron la audiencia de Brett Kavanaugh
Más de 20 millones de personas vieron el impresionante testimonio del jueves del candidato a la Corte Suprema Brett Kavanaugh y la mujer que lo acusó de una agresión sexual que supuestamente ocurrió en la década de 1980, Christine Blasey Ford, en seis cadenas de televisión.
Mientras tanto, el estancamiento político continuó, con las emisoras interrumpiendo la programación regular para el giro de última hora del viernes: un acuerdo diseñado por el senador de Arizona Jeff Flake para que el FBI lleve a cabo una investigación de una semana de los cargos.
Ford le dijo al Comité Judicial del Senado que está 100 por ciento segura de que Kavanaugh la manoseó borracha y trató de quitarse la ropa en una fiesta de la escuela secundaria.
Kavanaugh, en un testimonio apasionado, dijo que está 100% seguro de que no sucedió.
Es probable que más de los 20,4 millones de personas reportadas por Nielsen el viernes lo vieron.
La compañía estaba contando la audiencia promedio en CBS, ABC, NBC, CNN, Fox News Channel y MSNBC.
Las cifras no estaban inmediatamente disponibles para otras cadenas que lo mostraron, incluyendo PBS, C-SPAN y Fox Business Network.
Y Nielsen por lo general tiene algún problema para medir a la gente que mira en las oficinas.
Para ponerlo en perspectiva, ese es un tamaño de audiencia similar al de un partido de fútbol de playoffs o los Premios de la Academia.
Fox News Channel, cuyos presentadores de opinión han apoyado firmemente el nombramiento de Kavanaugh, lideró a todas las redes con un promedio de 5.69 millones de espectadores durante la audiencia de todo el día, dijo Nielsen.
ABC fue el segundo con 3,26 millones de espectadores.
CBS tenía 3,1 millones, NBC tenía 2,94 millones, MSNBC tenía 2,89 millones y CNN tenía 2,52 millones, dijo Nielsen.
El interés siguió siendo alto después de la audiencia.
Flake fue la figura central en el drama del viernes.
Después de que la oficina del republicano moderado emitiera una declaración de que votaría a favor de Kavanaugh, fue capturado en las cámaras de CNN y CBS el viernes por la mañana siendo gritado por los manifestantes mientras intentaba subir en un ascensor a una audiencia del Comité Judicial.
Estuvo de pie con los ojos hacia abajo durante varios minutos mientras era reprendido, televisado en vivo por CNN.
"Estoy aquí delante de ustedes", dijo una mujer.
"¿Crees que está diciendo la verdad al país?
Le dijeron: "Tienes poder cuando tantas mujeres son impotentes".
Flake dijo que su oficina había emitido una declaración y dijo, antes de que el ascensor cerrara, que tendría más que decir en la audiencia del comité.
Las redes de cable y transmisión estaban cubriendo en vivo horas más tarde, cuando el Comité Judicial debía votar para adelantar la nominación de Kavanaugh al pleno del Senado para una votación.
Pero Flake dijo que solo lo haría con el entendimiento de que el FBI investigaría las acusaciones contra el candidato para la próxima semana, lo que la minoría demócrata ha estado instando.
Flake fue convencido en parte por conversaciones con su amigo, el senador demócrata Chris Coons.
Después de una conversación con Coons y varios senadores después, Flake tomó su decisión.
La elección de Flake tenía poder, porque era evidente que los republicanos no tendrían los votos para aprobar a Kavanaugh sin la investigación.
El presidente Trump ha abierto una investigación del FBI sobre las acusaciones contra Kavanaugh.
La primera ministra británica May acusa a sus críticos de "jugar a la política" por el Brexit
La primera ministra Theresa May acusó a los críticos de sus planes de abandonar la Unión Europea de "jugar a la política" con el futuro de Gran Bretaña y socavar el interés nacional en una entrevista con el periódico Sunday Times.
La primera ministra de Gran Bretaña, Theresa May, llega a la Conferencia del Partido Conservador en Birmingham, Gran Bretaña, el 29 de septiembre de 2018.
En otra entrevista junto a la de ella en la portada del periódico, su ex ministro de Relaciones Exteriores Boris Johnson presionó su ataque a su llamado plan Chequers para el Brexit, diciendo que una propuesta de que Gran Bretaña y la UE deberían cobrar los aranceles de cada uno era "totalmente absurda".
Wayde Sims tiroteo: la policía detiene al sospechoso Dyteon Simpson en la muerte del jugador de LSU
La policía ha arrestado a un sospechoso en el fatal tiroteo de Wayde Sims, un jugador de baloncesto de 20 años en LSU.
Dyteon Simpson, de 20 años, ha sido arrestado y encarcelado por un cargo de asesinato en segundo grado, dijo el Departamento de Policía de Baton Rouge.
Las autoridades publicaron un video de la confrontación entre Sims y Simpson, y la policía dijo que Sims perdió sus gafas durante la pelea.
La policía recuperó las gafas de la escena y dijo que encontraron el ADN de Simpson en ellas, CBS afiliado WAFB informa.
Después de interrogar a Simpson, la policía dijo que admitió haber matado a tiros a Wayde.
Su fianza se ha fijado en $350,000, informa el Abogado.
La oficina del médico forense de East Baton Rouge dio a conocer un informe preliminar el viernes, diciendo que la causa de la muerte es una herida de bala en la cabeza en el cuello.
El departamento le da crédito al grupo de trabajo de la Policía Estatal de Luisiana, el laboratorio de crímenes de la Policía Estatal, la Policía de la Universidad del Sur y los ciudadanos de la zona por ayudar en la investigación que condujo al arresto.
El director atlético de LSU Joe Alleva agradeció a la policía del área por su "diligencia y búsqueda de la justicia".
Sims tenía 20 años.
El delantero de 6 pies y 6 pulgadas creció en Baton Rouge, donde su padre, Wayne, también jugó baloncesto para LSU.
Promedió 5.6 puntos y 2.6 rebotes por juego la temporada pasada.
El viernes por la mañana, el entrenador de baloncesto de LSU, Will Wade, dijo que el equipo está "devastado" y "en shock" por la muerte de Wayde.
"Esto es lo que te preocupa todo el tiempo", dijo Wade.
El volcán arroja cenizas sobre la Ciudad de México
La ceniza que arroja el volcán Popocatépetl ha llegado a los barrios del sur de la capital de México.
El Centro Nacional para la Prevención de Desastres advirtió el sábado a los mexicanos que se mantuvieran alejados del volcán después de que la actividad aumentó en el cráter y registró 183 emisiones de gas y cenizas en 24 horas.
El centro estaba monitoreando múltiples ruidos y temblores.
Las imágenes en las redes sociales mostraron capas delgadas de revestimiento de ceniza en los parabrisas de los automóviles en barrios de la Ciudad de México como Xochimilco.
Los geofísicos han notado un aumento de actividad en el volcán que se encuentra a 72 kilómetros al sureste de la capital desde que un terremoto de magnitud 7.1 sacudió el centro de México en septiembre de 2017.
El volcán conocido como "Don Goyo" ha estado activo desde 1994.
La policía choca con los separatistas catalanes antes del aniversario del voto de independencia
Seis personas fueron arrestadas en Barcelona el sábado después de que manifestantes independentistas se enfrentaran con la policía antidisturbios, y mientras miles se unieron a manifestaciones rivales para conmemorar el primer aniversario del voto polarizador de Cataluña sobre la secesión.
Un grupo de pro-separatistas enmascarados detenidos por la policía antidisturbios los arrojó huevos y pintura en polvo, creando nubes oscuras de polvo en calles que normalmente estarían llenas de turistas.
También estallaron peleas más tarde en el día con la policía usando sus bastones para contener los combates.
Durante varias horas, grupos independentistas que coreaban "No olvidar, no perdonar" se enfrentaron a manifestantes unionistas que gritaban: "Viva España".
Catorce personas recibieron tratamiento por heridas leves recibidas en las protestas, informó la prensa local.
Las tensiones siguen siendo altas en la región independentista un año después del referéndum del 1 de octubre considerado ilegal por Madrid pero celebrado por los catalanes separatistas.
Los votantes optaron abrumadoramente por ser independientes, aunque la participación fue baja con los que se oponían a la secesión boicoteando en gran medida la votación.
Según las autoridades catalanas, casi 1000 personas resultaron heridas el año pasado después de que la policía intentó detener la votación en los centros de votación de toda la región en violentos enfrentamientos.
Los grupos pro-independencia habían acampado durante la noche del viernes para evitar una manifestación en apoyo de la policía nacional.
La manifestación continuó pero se vio obligada a tomar una ruta diferente.
Narcis Termes, de 68 años, un electricista que asistió a la protesta separatista con su esposa, dijo que ya no tenía esperanzas sobre las perspectivas de la independencia de Cataluña.
"El año pasado vivimos uno de nuestros mejores momentos.
Vi a mis padres llorar de alegría por poder votar pero ahora estamos atrapados", dijo.
A pesar de haber logrado una victoria vital aunque estrecha en las elecciones regionales del pasado diciembre, Los partidos independentistas catalanes han luchado por mantener el impulso este año con muchos de sus líderes más conocidos en el exilio autoimpuesto o en detención a la espera de juicio por su papel en la organización del referéndum y la posterior declaración de independencia.
Joan Puig, un mecánico de 42 años que grababa la protesta en apoyo a la policía en su teléfono, dijo que el conflicto había sido avivado por políticos de ambos lados.
"Se está poniendo cada vez más tenso", dijo.
El sábado, Oriol Junqueras, uno de los nueve líderes catalanes en prisión preventiva desde finales del año pasado, anunció que se postulará a las elecciones al Parlamento Europeo del próximo año.
"Ponerse como candidato a las elecciones europeas es la mejor manera de denunciar la regresión en los valores democráticos y la represión que hemos visto por parte del gobierno español", dijo.
Londonderry: hombres arrestados después de que una casa fuera atropellada por un coche
Tres hombres, de 33, 34 y 39 años, han sido arrestados después de que un automóvil chocara repetidamente contra una casa en Londonderry.
El incidente se desarrolló en Ballynagard Crescent el jueves alrededor de las 19:30 BST.
El inspector Bob Blemmings dijo que los daños fueron causados a las puertas y al propio edificio.
Una ballesta también puede haber sido disparada contra el coche en algún momento.
La huelga de Menga le da a Livingston una victoria por 1-0 sobre los Rangers.
El primer gol de Dolly Menga para Livingston aseguró la victoria
El ascenso de Livingston sorprendió a los Rangers al entregar a Steven Gerrard a su segunda derrota en 18 juegos como gerente del club de Ibrox.
La huelga de Dolly Menga resultó ser la diferencia ya que el equipo de Gary Holt se movió al nivel de Hibernian en el segundo.
El equipo de Gerrard permanece sin una victoria fuera de casa en la Premier League esta temporada y se enfrentará a los líderes Hearts, a los que faltan ocho puntos, el próximo domingo.
Antes de eso, los Rangers recibirán al Rapid Vienna en la Liga Europa el jueves.
Livingston, mientras tanto, amplía su racha invicta en la división a seis juegos, con el entrenador en jefe Holt todavía probando la derrota desde que reemplazó a Kenny Miler el mes pasado.
Livingston pierde sus oportunidades contra los visitantes.
El equipo de Holt debería haber estado por delante mucho antes de marcar, con su franqueza causando a los Rangers todo tipo de problemas.
Scott Robinson rompió pero arrastró su esfuerzo a través de la cara de la meta, luego Alan Lithgow sólo pudo dirigir su esfuerzo a lo largo después de deslizarse para encontrar el cabezal de Craig Halkett a través de la meta.
Los anfitriones estaban contentos de dejar que los Rangers jugaran delante de ellos, sabiendo que podrían molestar a los visitantes en piezas fijas.
Y así fue como llegó el objetivo crucial.
Los Rangers concedieron un tiro libre y Livingston trabajó una apertura, Declan Gallagher y Robinson se combinaron para establecer a Menga, quien tomó un toque y anotó desde el centro de la caja.
En esa etapa, los Rangers habían dominado la posesión pero habían encontrado la defensa de casa impenetrable y el portero Liam Kelly estaba en gran parte tranquilo,
Ese patrón continuó en la segunda mitad, aunque Alfredo Morelos forzó una salva de Kelly.
Scott Pittman fue rechazado por los pies del portero de los Rangers Allan McGregor y Lithgow disparó desde otro set de Livingston.
Los cruces llegaron continuamente a la caja de Livingston y fueron continuamente eliminados, mientras que dos reclamos de penaltis - después del desafío de Halkett contra el sustituto Glenn Middleton, y uno para el balonmano - fueron rechazados.
"Fenomenal" desde Livingston - análisis
Alasdair Lamont de la BBC Escocia en el Tony Macaroni Arena
Una actuación fenomenal y un resultado para Livingston.
Para un hombre, eran excelentes, continuando superando las expectativas en esta trayectoria ascendente.
Su estilo de juego y el personal apenas han cambiado desde su regreso a la primera división, pero el gran crédito tiene que ir a Holt por la forma en que ha galvanizado al equipo desde su llegada.
Tenía tantos héroes.
El capitán Halkett era inmenso, reuniendo una defensa magníficamente organizada, mientras que Menga mantuvo a Connor Goldson y Joe Worrall alerta todo el tiempo.
Sin embargo, a los Rangers les faltaba la inspiración.
Aunque a veces han sido buenos bajo Gerrard, no han cumplido con esos estándares.
A su última pelota le faltaba - sólo una vez abrieron el lado de casa - y es una especie de llamada de atención para los Rangers, que se encuentran en el centro de la tabla.
Erdogan recibe una recepción mixta en Colonia
Había sonrisas y cielos azules el sábado (29 de septiembre) cuando los líderes de Turquía y Alemania se reunieron para el desayuno en Berlín.
Es el último día de la polémica visita del presidente Erdogan a Alemania, cuyo objetivo es reparar las relaciones entre los aliados de la OTAN.
Se han enfrentado por temas como los derechos humanos, la libertad de prensa y la adhesión de Turquía a la UE.
Erdogan luego se dirigió a Colonia para abrir una nueva mezquita gigante.
La ciudad es el hogar de la mayor población turca fuera de Turquía.
La policía citó razones de seguridad para impedir que una multitud de 25.000 personas se reuniera frente a la mezquita, pero muchos partidarios salieron cerca para ver a su presidente.
Cientos de manifestantes anti-Erdogan - muchos de ellos kurdos - también hicieron oír sus voces, condenando tanto las políticas de Erdogan como la decisión del gobierno alemán de darle la bienvenida al país.
Las protestas de duelo reflejan la división de un visitante aclamado como un héroe por algunos turcos alemanes y vilipendiado como un autocrata por otros.
Deptford accidente de carretera: ciclista muere en colisión con el coche
Un ciclista ha muerto en una colisión con un automóvil en Londres.
El accidente ocurrió cerca de la intersección de Bestwood Street y Evelyn Street, una carretera concurrida en Deptford, en el sureste de la ciudad, alrededor de las 10:15 BST.
El conductor del coche se detuvo y los paramédicos asistieron, pero el hombre murió en el lugar.
El accidente se produce meses después de que otro ciclista muriera en un accidente de tránsito en Childers Street, a una milla de distancia del accidente del sábado.
La Policía Metropolitana dijo que los oficiales estaban trabajando para identificar al hombre e informar a su pariente más cercano.
Los cierres de carreteras y desvíos de autobuses están en su lugar y se ha aconsejado a los automovilistas que eviten el área.
Prisión de Long Lartin: Seis oficiales heridos en el desorden
Seis oficiales de prisión resultaron heridos en un disturbio en una prisión de hombres de alta seguridad, dijo la Oficina de Prisiones.
El desorden estalló en el HMP Long Lartin en Worcestershire alrededor de las 09:30 BST el domingo y continúa.
Los oficiales especializados en "Tornado" han sido traídos para lidiar con el disturbio, que involucra a ocho reclusos y está contenido en un ala.
Los oficiales fueron tratados por lesiones faciales leves en la escena.
Un portavoz del Servicio Penitenciario dijo: "Se ha desplegado personal de prisión especialmente capacitado para hacer frente a un incidente en curso en el HMP Long Lartin.
Seis miembros del personal han sido tratados por heridas.
No toleramos la violencia en nuestras prisiones, y estamos claros de que los responsables serán remitidos a la policía y podrían pasar más tiempo tras las rejas".
HMP Long Lartin tiene más de 500 prisioneros, incluyendo algunos de los delincuentes más peligrosos del país.
En junio se informó que el gobernador de la prisión recibió tratamiento hospitalario después de haber sido atacado por un prisionero.
Y en octubre del año pasado agentes antidisturbios fueron llamados a la prisión para hacer frente a un grave disturbio en el que el personal fue atacado con pelotas de billar.
El huracán Rosa amenaza Phoenix, Las Vegas, Salt Lake City con inundaciones repentinas (las zonas secas pueden beneficiarse)
Es raro que una depresión tropical golpee Arizona, pero eso es exactamente lo que es probable que suceda a principios de la próxima semana, cuando el huracán Rosa deje sus huellas de energía en el desierto suroeste, generando riesgos de inundaciones repentinas.
El Servicio Meteorológico Nacional ya ha emitido alertas de inundaciones repentinas para el lunes y el martes para el oeste de Arizona en el sur y el este de Nevada, el sureste de California y Utah, incluidas las ciudades de Phoenix, Flagstaff, Las Vegas y Salt Lake City.
Se espera que Rosa tome un camino directo sobre Phoenix el martes, acercándose tarde el lunes con lluvia.
El Servicio Meteorológico Nacional en Phoenix señaló en un tuit que sólo "diez ciclones tropicales han mantenido el estado de tormenta tropical o depresión dentro de 200 millas de Phoenix desde 1950!
Katrina (1967) fue un huracán a menos de 40 millas de la frontera de Arizona".
Los últimos modelos del Centro Nacional de Huracanes predicen de 2 a 4 pulgadas de lluvia, con cantidades aisladas de hasta 6 pulgadas en el borde de Mogollon de Arizona.
Otras áreas del desierto suroeste, incluyendo las Rocosas centrales y la Gran Cuenca, probablemente obtendrán de 1 a 2 pulgadas, con totales aisladas de hasta 4 pulgadas posibles.
Para aquellos que están fuera del riesgo de inundaciones repentinas, la lluvia de Rosa puede ser una bendición ya que la región está afectada por la sequía.
Aunque las inundaciones son una preocupación muy grave, es probable que algunas de estas lluvias sean beneficiosas ya que el suroeste está experimentando actualmente condiciones de sequía.
Según el U.S. Drought Monitor, poco más del 40 por ciento de Arizona está experimentando al menos una sequía extrema, la segunda categoría más alta", informó weather.com.
Primero, la trayectoria del huracán Rosa conduce a la tierra a través de la península de Baja California de México.
Rosa, todavía en la fuerza del huracán el domingo por la mañana con vientos máximos de 85 millas por hora, está a 385 millas al sur de Punta Eugenia, México y se mueve hacia el norte a 12 millas por hora.
La tormenta se encuentra con aguas más frías en el Pacífico y por lo tanto se está apagando.
Por lo tanto, se espera que toque tierra en México con fuerza de tormenta tropical en la tarde o noche del lunes.
Las lluvias en partes de México podrían ser fuertes, lo que plantea un riesgo significativo de inundaciones.
"Se esperan precipitaciones totales de 3 a 6 pulgadas desde Baja California hasta el noroeste de Sonora, con hasta 10 pulgadas posibles", informó weather.com.
Rosa luego seguirá hacia el norte a través de México como una tormenta tropical antes de llegar a la frontera de Arizona en las primeras horas de la mañana del martes como una depresión tropical, que luego seguirá a través de Arizona y en el sur de Utah a última hora de la noche del martes.
"El principal peligro que se espera de Rosa o de sus restos es lluvias muy fuertes en Baja California, el noroeste de Sonora y el desierto suroeste de Estados Unidos", dijo el Centro Nacional de Huracanes.
Se espera que estas lluvias produzcan inundaciones repentinas que amenazan la vida y flujos de escombros en los desiertos, y deslizamientos de tierra en terrenos montañosos.
Ataque de Midsomer Norton: cuatro arrestos por intento de asesinato
Tres adolescentes y un hombre de 20 años han sido arrestados bajo sospecha de intento de asesinato después de que un joven de 16 años fue encontrado con heridas de puñalada en Somerset.
El adolescente fue encontrado herido en el área de Excelsior Terrace de Midsomer Norton, alrededor de las 04:00 BST el sábado.
Fue llevado al hospital donde permanece en una condición "estable".
Un joven de 17 años, dos de 18 años y un hombre de 20 años fueron arrestados durante la noche en el área de Radstock, dijo la policía de Avon y Somerset.
Los oficiales han pedido a cualquiera que tenga alguna grabación de teléfono móvil de lo que sucedió que se presente.
Trump dice que Kavanaugh 'sufría, la mezquindad, la ira' del Partido Demócrata
"Un voto por el juez Kavanaugh es un voto para rechazar las tácticas despiadadas y escandalosas del Partido Demócrata", dijo Trump en un mitin en Wheeling, Virginia Occidental.
Trump dijo que Kavanaugh ha "sufrido la mezquindad, la ira" del Partido Demócrata a lo largo de su proceso de nominación.
Kavanaugh testificó ante el Congreso el jueves, negando enérgica y emocionalmente una acusación de Christine Blasey Ford de que la agredió sexualmente hace décadas cuando eran adolescentes.
Ford también testificó en la audiencia sobre su acusación.
El presidente dijo el sábado que el "pueblo estadounidense vio el brillo y la calidad y el coraje" de Kavanaugh ese día.
"Un voto para confirmar al juez Kavanaugh es un voto para confirmar a una de las mentes jurídicas más consumadas de nuestro tiempo, un jurista con un excelente historial de servicio público", dijo a la multitud de partidarios de Virginia Occidental.
El Presidente se refirió indirectamente a la nominación de Kavanaugh mientras hablaba de la importancia de la participación republicana en las elecciones de mitad de período.
"A cinco semanas de una de las elecciones más importantes de nuestras vidas.
No estoy corriendo, pero realmente estoy corriendo", dijo.
"Es por eso que estoy en todas partes luchando por grandes candidatos".
Trump argumentó que los demócratas están en una misión de "resistir y obstruir".
Se espera que la primera votación de procedimiento clave en el Senado sobre la nominación de Kavanaugh tenga lugar a más tardar el viernes, dijo a CNN un asistente de alto rango del liderazgo republicano.
Cientos de muertos por terremoto y tsunami en Indonesia, con un número cada vez mayor de muertos
Al menos 384 personas murieron, muchas arrastradas cuando olas gigantes golpearon las playas, cuando un gran terremoto y tsunami azotaron la isla indonesia de Sulawesi, dijeron las autoridades el sábado.
Cientos de personas se habían reunido para un festival en la playa de la ciudad de Palu el viernes cuando olas de hasta seis metros (18 pies) de altura golpearon la costa al atardecer, arrasando a muchos hasta la muerte y destruyendo todo en su camino.
El tsunami siguió a un terremoto de magnitud 7.5.
"Cuando la amenaza de tsunami surgió ayer, la gente todavía estaba haciendo sus actividades en la playa y no corrió de inmediato y se convirtieron en víctimas", dijo Sutopo Purwo Nugroho, el portavoz de la agencia de mitigación de desastres de Indonesia BNPB en una sesión informativa en Yakarta.
"El tsunami no vino por sí mismo, arrastró automóviles, troncos, casas, golpeó todo en tierra", dijo Nugroho, y agregó que el tsunami había viajado a través del mar abierto a velocidades de 800 kilómetros por hora antes de golpear la costa.
Algunas personas treparon a los árboles para escapar del tsunami y sobrevivieron, dijo.
Alrededor de 16.700 personas fueron evacuadas a 24 centros en Palu.
Las fotografías aéreas publicadas por la agencia de desastres mostraron muchos edificios y tiendas destruidos, puentes retorcidos y derrumbados y una mezquita rodeada de agua.
Las réplicas continuaron sacudiendo la ciudad costera el sábado.
La serie de terremotos se sintió en un área con 2,4 millones de habitantes.
La Agencia de Indonesia para la Evaluación y Aplicación de la Tecnología (BPPT) dijo en un comunicado que la energía liberada por el terremoto masivo del viernes era alrededor de 200 veces la potencia de la bomba atómica lanzada sobre Hiroshima en la Segunda Guerra Mundial.
La geografía de la ciudad, que se encuentra al final de una bahía larga y estrecha, podría haber aumentado el tamaño del tsunami, dijo.
Nugroho describió los daños como "extensivos" y dijo que miles de casas, hospitales, centros comerciales y hoteles se habían derrumbado.
Los cuerpos de algunas víctimas fueron encontrados atrapados bajo los escombros de edificios derrumbados, dijo, y agregó que 540 personas resultaron heridas y 29 desaparecidas.
Nugroho dijo que las bajas y el daño podrían ser mayores a lo largo de la costa a 300 km al norte de Palu, un área llamada Donggala, que está más cerca del epicentro del terremoto.
Las comunicaciones "estaban totalmente paralizadas sin información" de Donggala, dijo Nugroho.
Hay más de 300.000 personas viviendo allí", dijo la Cruz Roja en un comunicado, y agregó que su personal y voluntarios se dirigían a las áreas afectadas.
"Esto ya es una tragedia, pero podría ser mucho peor", decía.
La agencia el sábado fue ampliamente criticada por no informar que un tsunami había golpeado Palu, aunque los funcionarios dijeron que las olas habían llegado dentro del tiempo en que se emitió la advertencia.
En imágenes aficionadas compartidas en las redes sociales se puede escuchar a un hombre en el piso superior de un edificio gritando advertencias frenéticas del tsunami que se aproxima a las personas en la calle de abajo.
En cuestión de minutos, una muralla de agua se derrumba contra la orilla, arrastrando edificios y automóviles.
Reuters no pudo confirmar de inmediato la autenticidad de las imágenes.
El terremoto y el tsunami causaron un gran corte de energía que cortó las comunicaciones alrededor de Palu haciendo difícil para las autoridades coordinar los esfuerzos de rescate.
El ejército ha comenzado a enviar aviones de carga con ayuda desde Yakarta y otras ciudades, dijeron las autoridades, pero los evacuados todavía necesitan alimentos y otras necesidades básicas.
El aeropuerto de la ciudad se ha reabierto solo para los esfuerzos de socorro y permanecerá cerrado hasta octubre.
El presidente Joko Widodo estaba programado para visitar los centros de evacuación en Palu el domingo.
El número de víctimas del tsunami en Indonesia se eleva a más de 800.
Es muy malo.
Mientras que el personal de World Vision de Donggala ha llegado a salvo a la ciudad de Palu, donde los empleados se están refugiando en refugios de lona instalados en el patio de su oficina, pasaron por escenas de devastación en el camino, dijo el Sr. Doseba.
"Me dijeron que vieron muchas casas destruidas", dijo.
Es muy malo.
Incluso cuando los grupos de ayuda comenzaron los sombríos movimientos de arranque de los engranajes de socorro de desastres, algunos se quejaron de que los trabajadores de ayuda extranjeros con profunda experiencia estaban siendo impedidos de viajar a Palu.
Según las regulaciones indonesias, los fondos, suministros y personal del extranjero solo pueden comenzar a fluir si el sitio de una calamidad es declarado zona nacional de desastre.
Eso no ha sucedido todavía.
"Todavía es un desastre a nivel provincial", dijo Aulia Arriani, portavoz de la Cruz Roja de Indonesia.
"Una vez que el gobierno dice, 'OK, este es un desastre nacional', podemos abrirnos a la asistencia internacional, pero aún no hay estatus".
A medida que la segunda noche cayó sobre Palu después del terremoto y el tsunami del viernes, los amigos y familiares de los desaparecidos mantenían la esperanza de que sus seres queridos fueran los milagros que levaduran las tristes historias de los desastres naturales.
El sábado, un niño fue sacado de una alcantarilla.
El domingo, los rescatistas liberaron a una mujer que había estado atrapada bajo los escombros durante dos días con el cuerpo de su madre a su lado.
Gendon Subandono, el entrenador del equipo nacional de parapente de Indonesia, había entrenado a dos de los parapentistas desaparecidos para los Juegos Asiáticos, que concluyeron a principios de este mes en Indonesia.
Otros de los atrapados en el Hotel Roa Roa, incluido el Sr. Mandagi, eran sus estudiantes.
"Como estudiante de último año en el campo del parapente, tengo mi propia carga emocional", dijo.
El Sr. Gendon relató cómo, en las horas posteriores a la noticia del derrumbe del Hotel Roa Roa que circuló entre la comunidad del parapente, había enviado desesperadamente mensajes de WhatsApp a los competidores de Palu, que participaban en el festival de la playa.
Sus mensajes, sin embargo, sólo resultaron en una marca de verificación gris, en lugar de un par de cheques azules.
"Creo que eso significa que los mensajes no fueron entregados", dijo.
Los ladrones se llevaron $26,750 durante el reabastecimiento del cajero automático en Newport en el Levee
Los ladrones el viernes por la mañana robaron $26,750 a un trabajador de Brink llenando un cajero automático en Newport on the Levee, según un comunicado de prensa del Departamento de Policía de Newport.
El conductor del coche había estado vaciando un cajero automático en el complejo de entretenimiento y preparándose para entregar más dinero, Det. Dennis McCarthy escribió en el comunicado.
Mientras estaba ocupado, otro hombre "corrió por detrás del empleado del Brink" y robó una bolsa de dinero destinada a la entrega.
Los testigos vieron a varios sospechosos huyendo de la escena, según el comunicado, pero la policía no especificó el número involucrado en el incidente.
Cualquiera que tenga información sobre sus identidades debe comunicarse con la policía de Newport al 859-292-3680.
Kanye West: el rapero cambia su nombre a Ye
El rapero Kanye West está cambiando su nombre a Ye.
Anunciando el cambio en Twitter el sábado, escribió: "El ser conocido formalmente como Kanye West".
West, de 41 años, ha sido apodado Ye durante algún tiempo y usó el apodo como el título de su octavo álbum, que fue lanzado en junio.
El cambio se produce antes de su aparición en Saturday Night Live, donde se espera que lance su nuevo álbum Yandhi.
Reemplaza a la cantante Ariana Grande en el programa que canceló por "razones emocionales", dijo el creador del programa.
Además de ser una abreviatura de su actual nombre profesional, West ha dicho previamente que la palabra tiene un significado religioso para él.
"Creo que 'yo' es la palabra más usada en la Biblia, y en la Biblia significa 'usted'", dijo West a principios de este año, al hablar del título de su álbum con el presentador de radio Big Boy.
"Así que yo soy tú, yo soy nosotros, somos nosotros.
Pasó de Kanye, que significa el único, a sólo Ye, siendo un reflejo de lo bueno, lo malo, lo confuso, de todo.
El álbum es más un reflejo de lo que somos".
Es uno de varios raperos famosos que cambiaron su nombre.
Sean Combs ha sido conocido como Puff Daddy, P. Diddy o Diddy, pero este año anunció su preferencia por los nombres Love y Brother Love.
Un ex colaborador de West, JAY-Z, también se ha conformado con o sin guión y mayúsculas.
El AMLO de México promete no usar el ejército contra civiles
El presidente electo de México, Andrés Manuel López Obrador, ha prometido nunca usar la fuerza militar contra civiles mientras el país se acerca al 50 aniversario de una sangrienta represalia contra estudiantes.
López Obrador prometió el sábado en Tlatelolco Plaza "nunca usar el ejército para reprimir al pueblo mexicano".
Las tropas dispararon contra una manifestación pacífica en la plaza el 2 de octubre de 1968, matando hasta 300 personas en un momento en que los movimientos estudiantiles de izquierda estaban echando raíces en toda América Latina.
López Obrador se ha comprometido a apoyar a los jóvenes mexicanos dando subsidios mensuales a los que estudian y abriendo más universidades públicas gratuitas.
Ha dicho que el desempleo y la falta de oportunidades educativas atraen a los jóvenes a las pandillas criminales.
EE.UU. debería duplicar el financiamiento de la IA
A medida que China se vuelve más activa en inteligencia artificial, Estados Unidos debería duplicar la cantidad que gasta en investigación en el campo, dice el inversor y practicante de IA Kai-Fu Lee, que ha trabajado para Google, Microsoft y Apple.
Los comentarios se producen después de que varias partes del gobierno de los EE.UU. hayan hecho anuncios de IA, incluso cuando los EE.UU. en general carecen de una estrategia formal de IA.
Mientras tanto, China presentó su plan el año pasado: apunta a ser el número uno en innovación de IA para 2030.
"Duplicar el presupuesto de investigación de IA sería un buen comienzo, dado que todos los demás países están mucho más atrás que Estados Unidos, y estamos buscando el próximo avance en IA", dijo Lee.
Doblar la financiación podría duplicar las posibilidades de que el próximo gran logro de IA se haga en los EE.UU., dijo Lee a CNBC en una entrevista esta semana.
Lee, cuyo libro "Superpoderes de IA: China, Silicon Valley y el Nuevo Orden Mundial" fue publicado este mes por Houghton Mifflin Harcourt, es CEO de Sinovation Ventures, que ha invertido en una de las compañías de IA más prominentes de China, Face++.
En la década de 1980 en la Universidad Carnegie Mellon trabajó en un sistema de IA que superó al jugador estadounidense de Othello de más alto rango, y más tarde fue ejecutivo en Microsoft Research y presidente de la sucursal china de Google.
Lee reconoció concursos de tecnología del gobierno de EE.UU. anteriores como el Desafío de Robótica de la Agencia de Proyectos de Investigación Avanzada de Defensa y preguntó cuándo sería el próximo, con el fin de ayudar a identificar a los próximos visionarios.
Los investigadores en los EE.UU. a menudo tienen que trabajar duro para ganar subvenciones del gobierno, dijo Lee.
"No es China la que está quitando a los líderes académicos; son las corporaciones", dijo Lee.
Facebook, Google y otras compañías tecnológicas han contratado luminarias de universidades para trabajar en IA en los últimos años.
Lee dijo que los cambios en la política de inmigración también podrían ayudar a los EE.UU. a reforzar sus esfuerzos de IA.
"Creo que las tarjetas verdes deberían ofrecerse automáticamente a los doctores en IA", dijo.
El Consejo de Estado de China emitió su Plan de Desarrollo de Inteligencia Artificial de Próxima Generación en julio de 2017.
La Fundación Nacional de Ciencias Naturales de China proporciona fondos a las personas en las instituciones académicas de manera similar a la forma en que la Fundación Nacional de Ciencias y otras organizaciones gubernamentales distribuyen dinero a los investigadores estadounidenses, Pero la calidad del trabajo académico es más baja en China, dijo Lee.
A principios de este año, el Departamento de Defensa de Estados Unidos estableció un Centro Conjunto de Inteligencia Artificial, que está destinado a involucrar a socios de la industria y el mundo académico, y la Casa Blanca anunció la formación de un Comité Selecto de Inteligencia Artificial.
Y este mes DARPA anunció una inversión de $2 mil millones en una iniciativa llamada AI Next.
En cuanto a la NSF, actualmente invierte más de $ 100 millones por año en investigación de IA.
Mientras tanto, la legislación estadounidense que buscaba crear una Comisión Nacional de Seguridad sobre Inteligencia Artificial no ha visto acción en meses.
Los macedonios votan en referéndum si cambian el nombre del país
El pueblo de Macedonia votó en un referéndum el domingo sobre si cambiar su nombre a "República de Macedonia del Norte", una medida que resolvería una disputa de décadas con Grecia que había bloqueado sus ofertas de membresía en la Unión Europea y la OTAN.
Grecia, que tiene una provincia llamada Macedonia, sostiene que el nombre de su vecino del norte representa una reclamación sobre su territorio y ha vetado su entrada en la OTAN y la UE.
Los dos gobiernos llegaron a un acuerdo en junio basado en el nuevo nombre propuesto, pero los opositores nacionalistas argumentan que el cambio socavaría la identidad étnica de la población de mayoría eslava de Macedonia.
El presidente Gjorge Ivanov ha dicho que no votará en el referéndum y una campaña de boicot ha generado dudas sobre si la participación alcanzará el mínimo del 50 por ciento requerido para que el referéndum sea válido.
La pregunta en la boleta del referéndum decía: "¿Está usted a favor de la adhesión a la OTAN y a la UE con la aceptación del acuerdo con Grecia?"
Los partidarios del cambio de nombre, incluido el primer ministro Zoran Zaev, argumentan que es un precio que vale la pena pagar para buscar la admisión en organismos como la UE y la OTAN para Macedonia, uno de los países que emergerán del colapso de Yugoslavia.
"Vine hoy a votar por el futuro del país, por los jóvenes de Macedonia para que puedan vivir libremente bajo el paraguas de la Unión Europea porque significa vidas más seguras para todos nosotros", dijo Olivera Georgijevska, de 79 años, en Skopje.
Aunque no es legalmente vinculante, suficientes miembros del Parlamento han dicho que respetarán el resultado de la votación para que sea decisivo.
El cambio de nombre requeriría una mayoría de dos tercios en el parlamento.
La comisión electoral estatal dijo que no había informes de irregularidades a la 1 p.m.
Sin embargo, la participación fue de sólo el 16 por ciento, en comparación con el 34 por ciento en las últimas elecciones parlamentarias de 2016 cuando el 66 por ciento de los votantes registrados emitieron su voto.
"Vine a votar por mis hijos, nuestro lugar está en Europa", dijo Gjose Tanevski, de 62 años, un votante en la capital, Skopje.
El primer ministro de Macedonia, Zoran Zaev, su esposa Zorica y su hijo Dushko dieron su voto para el referéndum en Macedonia sobre el cambio de nombre del país que abriría el camino para que se una a la OTAN y a la Unión Europea en Strumica, Macedonia, el 30 de septiembre de 2018.
Frente al parlamento en Skopje, Vladimir Kavardarkov, de 54 años, estaba preparando un pequeño escenario y levantando sillas frente a las tiendas de campaña de los que boicotearán el referéndum.
"Estamos a favor de la OTAN y la UE, pero queremos unirnos con la cabeza en alto, no a través de la puerta de servicio", dijo Kavadarkov.
"Somos un país pobre, pero tenemos dignidad.
Si no quieren tomarnos como Macedonia, podemos recurrir a otros como China y Rusia y convertirnos en parte de la integración euroasiática".
El primer ministro Zaev dice que la adhesión a la OTAN traerá una inversión muy necesaria a Macedonia, que tiene una tasa de desempleo de más del 20 por ciento.
"Creo que la gran mayoría estará a favor porque más del 80 por ciento de nuestros ciudadanos están a favor de la UE y la OTAN", dijo Zaev después de emitir su voto.
Dijo que un resultado de "sí" sería "la confirmación de nuestro futuro".
Una encuesta publicada el lunes pasado por el Instituto de Investigación Política de Macedonia dijo que entre el 30 y el 43 por ciento de los votantes participarían en el referéndum, por debajo de la participación requerida.
Otra encuesta, realizada por Telma TV de Macedonia, encontró que el 57 por ciento de los encuestados planean votar el domingo.
De ellos, el 70 por ciento dijo que votaría sí.
Para que el referéndum tenga éxito la participación debe ser del 50 por ciento más un voto.
Un fracaso en el referéndum representaría el primer golpe serio a la política del gobierno prooccidental desde que asumió el poder en mayo del año pasado.
Ver: Sergio Aguero del Manchester City navega a través de toda la defensa de Brighton para el gol
Sergio Aguero y Raheem Sterling despacharon a la defensa de Brighton en la victoria 2-0 del Manchester City el sábado en el Etihad Stadium de Manchester, Inglaterra.
Aguero hizo que pareciera ridículamente fácil en su puntaje en el minuto 65.
El delantero argentino recibió un pase en el centro del campo al comienzo de la secuencia.
Corrió entre tres defensores de Brighton, antes de cortar en el campo abierto.
Aguero se encontró entonces rodeado por cuatro camisetas verdes.
Empujó alrededor de un defensor antes de superar a varios más en el borde de la caja de Brighton.
Luego empujó un pase a su izquierda, encontrando a Sterling.
El delantero inglés usó su primer toque en la caja para devolver el balón a Aguero, quien usó su bota derecha para vencer al portero de Brighton Mathew Ryan con un tiro en el lado derecho de la red.
"Aguero está luchando con algunos problemas en sus pies", dijo el gerente del City, Pep Guardiola, a los periodistas.
"Hablamos de él jugando 55, 60 minutos.
Eso fue lo que pasó.
Tuvimos suerte de que anotara un gol en ese momento".
Pero fue Sterling quien dio a los Sky Blues la ventaja inicial en la pelea de la Premier League.
Ese gol llegó en el minuto 29.
Aguero recibió el balón profundamente en el territorio de Brighton en esa jugada.
Envió una hermosa bola a través del flanco izquierdo a Leroy Sane.
Sane hizo algunos toques antes de llevar a Sterling hacia el poste lejano.
El delantero de los azules del cielo golpeó la pelota en la red justo antes de deslizarse fuera de los límites.
El City lucha contra Hoffenheim en el partido de grupos de la Liga de Campeones a las 12:55 p.m. del martes en el Rhein-Neckar-Arena en Sinsheim, Alemania.
Scherzer quiere jugar al spoiler contra los Rockies.
Con los Nacionales eliminados de la contienda de playoffs, no había mucha razón para forzar otro comienzo.
Pero el siempre competitivo Scherzer espera tomar el montículo el domingo contra los Rockies de Colorado, pero sólo si todavía hay implicaciones en los playoffs para los Rockies, que tienen una ventaja de un juego sobre los Dodgers de Los Ángeles en la Liga Nacional Oeste.
Los Rockies se aseguraron al menos un lugar de comodín con una victoria de 5-2 sobre los Nacionales el viernes por la noche, pero todavía buscan asegurar su primer título de división.
"Aunque estamos jugando por nada, al menos podemos jugar sabiendo que la atmósfera aquí en Denver con la multitud y el otro equipo jugaría probablemente al más alto nivel de cualquier punto al que me enfrente este año.
¿Por qué no querría competir en eso?"
Los Nacionales aún no han anunciado un titular para el domingo, pero se dice que están inclinados a dejar que Scherzer lance en tal situación.
Scherzer, que sería su 34o titular, lanzó una sesión de bullpen el jueves y lanzaría en su descanso normal el domingo.
El derecho de Washington tiene marca de 18-7 con efectividad de 2.53 y 300 ponches en 220 2/3 entradas esta temporada.
Manifestaciones de Trump en Virginia Occidental
El Presidente se refirió indirectamente a la situación que rodea a su elegido para la Corte Suprema, Brett Kavanaugh, mientras hablaba de la importancia de la participación republicana en las elecciones de mitad de período.
"Todo lo que hemos hecho está en juego en noviembre.
A cinco semanas de una de las elecciones más importantes de nuestras vidas.
Este es uno de los grandes, grandes -- no estoy corriendo pero realmente estoy corriendo es por eso que estoy en todo el lugar luchando por grandes candidatos", dijo.
Trump continuó: "Ven este horrible, horrible grupo radical de demócratas, lo ven sucediendo ahora mismo.
Y están decididos a recuperar el poder usando cualquier medio necesario, ves la mezquindad, la maldad.
No les importa a quién lastimen, a quién tengan que atropellar para obtener poder y control, eso es lo que quieren es poder y control, no se lo vamos a dar".
Los demócratas, dijo, están en una misión de "resistir y obstruir".
"Y se ve que en los últimos cuatro días", dijo, llamando a los demócratas "enojados y malvados y desagradables y falsos".
Se refirió al Comité Judicial del Senado clasificando a la senadora demócrata Dianne Feinstein por su nombre, que recibió fuertes abucheos de la audiencia.
¿Recuerdas su respuesta?
¿Ha filtrado usted el documento?
Uh, uh, qué.
No, uh no, espero uno - que fue muy mal lenguaje corporal - el peor lenguaje corporal que he visto. "
El Partido Laborista ya no es una iglesia amplia.
Es intolerante con los que dicen lo que piensan.
Cuando los activistas de Momentum en mi partido local votaron a favor de censurarme, no fue una sorpresa.
Después de todo, soy el último en una línea de diputados laboristas a los que se les dice que no somos bienvenidos, todo por decir lo que pensamos.
Mi colega parlamentaria Joan Ryan recibió un trato similar porque se opuso decididamente al antisemitismo.
En mi caso, la moción de censura me criticó por no estar de acuerdo con Jeremy Corbyn.
Sobre la importancia de una política económica responsable, sobre la seguridad nacional, sobre Europa, cuestiones irónicamente similares en las que Jeremy no estaba de acuerdo con los líderes anteriores.
El anuncio para la reunión de trabajo de Nottingham East el viernes declaró que "queremos que las reuniones sean inclusivas y productivas".
Durante la mayor parte de mis ocho años como diputado laborista local, las reuniones del Comité General del viernes por la noche han sido exactamente eso.
Lamentablemente, hoy en día, no es el tono de muchas reuniones y la promesa de una política "más amable y amable" ha sido olvidada hace mucho tiempo si, de hecho, alguna vez comenzó.
Se ha vuelto cada vez más evidente que los puntos de vista diferentes no son tolerados en el Partido Laborista y cada opinión es juzgada por si es aceptable para la dirección del partido.
Esto comenzó poco después de que Jeremy se convirtiera en líder, Como colegas con los que antes había pensado que compartía una visión política similar, comenzaron a esperar que hiciera un giro en U y tomara posiciones con las que de otra manera nunca habría estado de acuerdo, ya sea sobre la seguridad nacional o el mercado único de la UE.
Cada vez que hablo en público - y no importa realmente lo que diga - hay una tirada de abusos en las redes sociales pidiendo la deselección, denunciando la política del centro, diciéndome que no debería estar en el Partido Laborista.
Y esa no es sólo mi experiencia.
De hecho, sé que soy más afortunado que algunos de mis colegas, ya que los comentarios dirigidos a mí tienden a ser políticos.
Estoy asombrado por la profesionalidad y la determinación de esos colegas que se enfrentan a un torrente de abusos sexistas o racistas todos los días, pero nunca se escapan.
Uno de los aspectos más decepcionantes de esta era política es cómo los niveles de abuso se han normalizado.
Jeremy Corbyn afirmó la semana pasada que el Partido Laborista debería fomentar una cultura de tolerancia.
La realidad es que ya no somos una iglesia tan amplia y con cada moción de "desconfianza" o cambio en las reglas de selección el partido se vuelve más estrecho.
He recibido muchos consejos en los últimos dos años instándome a mantener la cabeza baja, no ser tan vocal y entonces estaría "bien".
Pero eso no es por lo que vine a la política.
Desde que me uní al Partido Laborista hace 32 años como estudiante de escuela, provocado por la negligencia del gobierno de Thatcher que había dejado literalmente caer mi aula de la escuela primaria, he tratado de defender mejores servicios públicos para aquellos que más los necesitan, ya sea como concejal local o ministro del gobierno.
Nunca he ocultado mi política, incluso en las últimas elecciones.
Nadie en Nottingham East podría haber estado de ninguna manera confundido acerca de mis posiciones políticas y áreas de desacuerdo con el liderazgo actual.
A los que promovieron la moción el viernes, Todo lo que quiero decir es que cuando el país está arando hacia un Brexit que perjudicará a los hogares, empresas y nuestros servicios públicos, no entiendo el deseo de perder tiempo y energía en mi lealtad al líder del Partido Laborista.
Pero realmente el único mensaje que tengo no es a Nottingham Momentum, es a mis electores, ya sean miembros laboristas o no: Estoy orgulloso de servirlos y prometo que ninguna cantidad de amenazas de deselección o conveniencia política me impedirá actuar en lo que creo que son los mejores intereses de todos ustedes.
Chris Leslie es diputado por Nottingham Este
Ayr 38-17 Melrose: invicto Ayr es el primero
Dos intentos tardíos pueden haber distorsionado un poco el resultado final, pero no hay duda de que Ayr merecía triunfar en este maravillosamente entretenido partido del día.
Ahora encabezan la tabla, el único equipo invicto de los diez.
Al final, fue su defensa superior, tanto como su mejor toma de riesgos, lo que llevó al equipo local y el entrenador Peter Murchie tenía todo el derecho de estar satisfecho.
"Hemos sido probados en nuestros juegos hasta ahora, y todavía estamos invictos, así que tengo que estar feliz", dijo.
Robyn Christie, de Melrose, dijo: "Crédito a Ayr, ellos se arriesgaron mejor que nosotros".
El intento de Grant Anderson en el minuto 14, convertido por Frazier Climo, puso a Ayr delante, pero, una tarjeta amarilla para el capitán de Escocia Rory Hughes, liberada para el juego por los Warriors, permitió que Melrose hiciera que los números dijeran y Jason Baggot tomó un intento no convertido.
Climo extendió la ventaja de Ayr con un penalti, antes, justo en el medio tiempo, anotó y luego convirtió un intento en solitario para hacerlo 17-5 a Ayr en el descanso.
Pero Melrose comenzó bien la segunda mitad y el intento de Patrick Anderson, convertido por Baggot, redujo el margen de maniobra a cinco puntos.
Luego hubo un largo retraso por una lesión grave de Ruaridh Knott, quien fue sacado en camilla, y desde el reinicio, Ayr avanzó aún más a través de un intento de Stafford McDowall, convertido por Climo.
El capitán interino de Ayr, Blair Macpherson, recibió una tarjeta amarilla, y de nuevo, Melrose hizo que el hombre extra pagara con un intento no convertido de Bruce Colvine, al final de un período de feroz presión.
El equipo local regresó, sin embargo, y cuando Struan Hutchinson recibió una tarjeta amarilla por abordar a Climo sin el balón, desde la línea de penalti, MacPherson aterrizó en la parte posterior del maul de Ayr que avanzaba.
Climo se convirtió, como lo hizo de nuevo casi desde el reinicio, después de que Kyle Rowe recogió la patada de caja de David Armstrong y envió al flanqueador Gregor Henry para el quinto intento del equipo local.
Aún así, la estrella del juego parece preparada para una nueva carrera en la industria de la restauración.
La estrella de "Still Game" Ford Kieran parece listo para pasar a la industria de la hospitalidad después de que se descubrió que ha sido nombrado director de una compañía de restaurantes con licencia.
El actor de 56 años interpreta a Jack Jarvis en el popular programa de la BBC, que escribe y protagoniza junto a su compañero de comedia Greg Hemphill.
El dúo ha anunciado que la próxima novena temporada será la última de la serie, y parece que Kiernan está planeando una vida después de Craiglang.
Según los registros oficiales, es el director de Adriftmorn Limited.
El actor se negó a comentar sobre la historia, aunque una fuente del Scottish Sun insinuó que Kiernan estaba buscando involucrarse en el "próspero comercio de restaurantes" de Glasgow.
'El mar es nuestro': Bolivia sin litoral espera que el tribunal vuelva a abrir el camino al Pacífico
Los marineros patrullan un cuartel general naval en La Paz.
Los edificios públicos ondean una bandera azul océano.
Las bases navales desde el lago Titicaca hasta el Amazonas llevan el lema: "El mar es nuestro por derecho.
Recuperarlo es un deber".
En toda Bolivia sin litoral, el recuerdo de una costa que Chile perdió en un sangriento conflicto de recursos en el siglo XIX sigue vivo, al igual que el anhelo de navegar por el Océano Pacífico una vez más.
Esas esperanzas son tal vez las más altas en décadas, ya que Bolivia espera un fallo de la Corte Internacional de Justicia el 1 de octubre después de cinco años de deliberaciones.
"Bolivia tiene el impulso, un espíritu de unidad y serenidad, y por supuesto está esperando con una visión positiva el resultado", dijo Roberto Calzadilla, un diplomático boliviano.
Muchos bolivianos verán el fallo de la Corte Internacional de Justicia en grandes pantallas en todo el país, con la esperanza de que el tribunal de La Haya decida a favor de la afirmación de Bolivia de que - después de décadas de discusiones agitadas - Chile está obligado a negociar la concesión a Bolivia de una salida soberana al mar.
Evo Morales, el carismático presidente indígena de Bolivia, que enfrenta una polémica batalla por la reelección el próximo año, también tiene mucho que depender del fallo del lunes.
"Estamos muy cerca de regresar al Océano Pacífico", prometió a finales de agosto.
Pero algunos analistas creen que es poco probable que la corte decida a favor de Bolivia, y eso cambiaría poco si lo hiciera.
El organismo de la ONU con sede en los Países Bajos no tiene poder para otorgar territorio chileno, y ha estipulado que no determinará el resultado de posibles conversaciones.
El hecho de que el fallo de la CIJ llegue solo seis meses después de que se escucharan los argumentos finales indica que el caso "no fue complicado", dijo Paz Zárate, experta chilena en derecho internacional.
Y lejos de promover la causa de Bolivia, los últimos cuatro años pueden haberla hecho retroceder.
"El tema del acceso al mar ha sido secuestrado por la actual administración boliviana", dijo Zárate.
La retórica beligerante de Morales ha socavado cualquier buena voluntad chilena residual, sugirió.
Bolivia y Chile continuarán en algún momento las conversaciones, pero será extremadamente difícil mantener conversaciones después de esto.
Los dos países no han intercambiado embajadores desde 1962.
El expresidente Eduardo Rodríguez Veltzé, representante de Bolivia en La Haya, rechazó la idea de que la decisión de la corte fuera inusualmente rápida.
El lunes traerá a Bolivia "una oportunidad extraordinaria para abrir una nueva era de relaciones con Chile" y una oportunidad para "poner fin a 139 años de desacuerdos con beneficios mutuos", dijo.
Calzadilla también negó que Morales - todavía uno de los presidentes más populares de América Latina - estuviera usando el tema marítimo como una muleta política.
"Bolivia nunca renunciará a su derecho a tener acceso al Océano Pacífico", agregó.
"El fallo es una oportunidad para ver que necesitamos superar el pasado".
Corea del Norte dice que el desarme nuclear no vendrá a menos que pueda confiar en EE.UU.
El ministro de Relaciones Exteriores de Corea del Norte, Ri Yong Ho, dice que su nación nunca desarmará sus armas nucleares primero si no puede confiar en Washington.
Ri hablaba el sábado en la Asamblea General de las Naciones Unidas.
Pidió a los Estados Unidos que cumplan con las promesas hechas durante una cumbre en Singapur entre los líderes de los rivales.
Sus comentarios vienen como EE.UU. El secretario de Estado Mike Pompeo parece estar a punto de reiniciar la diplomacia nuclear estancada más de tres meses después de Singapur con Kim Jong Un de Corea del Norte.
Ri dice que es un "sueño" que las continuas sanciones y la objeción de Estados Unidos a una declaración que ponga fin a la Guerra de Corea alguna vez harán que el Norte se arrodille.
Washington es cauteloso de estar de acuerdo con la declaración sin que Pyongyang primero haga movimientos significativos de desarme.
Tanto Kim como el presidente estadounidense Donald Trump quieren una segunda cumbre.
Pero hay un escepticismo generalizado de que Pyongyang sea serio al renunciar a un arsenal que el país probablemente ve como la única manera de garantizar su seguridad.
Pompeo planea visitar Pyongyang el próximo mes para prepararse para una segunda cumbre Kim-Trump.
Los desfiles de moda de París revelan la última línea de sombreros masivos en camino a una calle alta cerca de ti.
Si quieres ampliar tu colección de sombreros o bloquear completamente el sol entonces no busques más.
Los diseñadores Valentino y Thom Browne dieron a conocer una serie de extravagantes sombreros de gran tamaño para su colección SS19 en la pasarela que deslumbró el conjunto de estilo en la Semana de la Moda de París.
Sombreros muy poco prácticos han barrido Instagram este verano y estos diseñadores han enviado sus creaciones llamativas por la pasarela.
La pieza más destacada de Valentino era un sombrero beige con un borde ancho en forma de pluma que inundaba las cabezas de las modelos.
Otros accesorios de gran tamaño incluían sandías adornadas con joyas, un sombrero mágico e incluso una piña, pero no están diseñados para mantener la cabeza caliente.
Thom Browne también reveló una selección de máscaras extrañas y justo a tiempo para Halloween.
Muchas de las coloridas máscaras tenían los labios cosidos y se parecían más a Hannibal Lecter que a la alta costura.
Una creación se parecía a un equipo de buceo con buzo y gafas, mientras que otra parecía un cono de helado derretido.
Y si continúas con la enorme declaración de moda... estás de suerte.
Los observadores de la moda predicen que los enormes gorros podrían estar haciendo su camino a las calles más altas cerca de usted.
Los sombreros de gran tamaño vienen calientes en los talones de 'La Bomba', el sombrero de paja con un borde de dos pies de ancho que se ha visto en todo el mundo de Rihanna a Emily Ratajkowski.
La etiqueta de culto detrás del sombrero altamente poco práctico que se esparció en las redes sociales envió otra gran creación por la pasarela: una bolsa de arena de paja casi tan grande como la modelo vestida con traje de baño que la llevaba.
La bolsa de rafia naranja quemada, recortada con flecos de rafia y rematada con un mango de cuero blanco, fue la pieza destacada en la colección La Riviera SS19 de Jacquemus en la Semana de la Moda de París.
El estilista de celebridades Luke Armitage dijo a FEMAIL: "Espero ver grandes sombreros y bolsos de playa llegar a la calle principal para el próximo verano, ya que el diseñador ha tenido un impacto tan grande que sería difícil ignorar la demanda de los accesorios de gran tamaño".
John Edward: Habilidades lingüísticas esenciales para los ciudadanos del mundo
Las escuelas independientes de Escocia mantienen un historial de excelencia académica. y esto ha continuado en 2018 con otro conjunto de resultados de exámenes sobresalientes, que solo se ve reforzado por el éxito individual y colectivo en deportes, arte, música y otros esfuerzos comunitarios.
Con más de 30.000 alumnos en toda Escocia, estas escuelas, representadas por el Consejo Escocés de Escuelas Independientes (SCIS), se esfuerzan por ofrecer el mejor nivel de servicio a sus alumnos y padres.
Las escuelas independientes tienen como objetivo preparar a sus alumnos para la educación superior y superior, su carrera elegida y su lugar como ciudadanos del mundo.
Como sector educativo que puede diseñar e implementar un plan de estudios escolar a medida, estamos viendo que las lenguas modernas continúan siendo una asignatura popular y deseada dentro de las escuelas.
Nelson Mandela dijo: "Si le hablas a un hombre en un idioma que entiende, eso le va a la cabeza.
Si le hablas en su propio idioma eso llega a su corazón".
Este es un poderoso recordatorio de que no podemos confiar solo en el inglés cuando queremos construir relaciones y confianza con personas de otros países.
A partir de los resultados de los exámenes recientes de este año, podemos ver que las lenguas encabezan las tablas de liga con las tasas de aprobación más altas dentro de las escuelas independientes.
Un total del 68 por ciento de los alumnos que estudiaron idiomas extranjeros obtuvieron un grado superior A.
Los datos, recopilados de las 74 escuelas miembros del SCIS, mostraron que el 72 por ciento de los estudiantes obtuvieron un grado superior A en mandarín, mientras que el 72 por ciento de los que estudiaban alemán, el 69 por ciento de los que estudiaban francés y el 63 por ciento de los que estudiaban español también obtuvieron un A.
Esto demuestra que las escuelas independientes en Escocia están apoyando las lenguas extranjeras como habilidades vitales que los niños y jóvenes necesitarán sin duda alguna en el futuro.
En la actualidad, las lenguas, como asignatura de elección, se mantienen al mismo nivel que las materias STEM (ciencia, tecnología, ingeniería y matemáticas) en los planes de estudios de las escuelas independientes y en otros lugares.
Una encuesta realizada por la Comisión de Empleo y Habilidades del Reino Unido en 2014 encontró que de las razones que los empleadores dieron por tener dificultades para cubrir vacantes, el 17 por ciento se atribuyeron a una escasez de habilidades lingüísticas.
Por lo tanto, cada vez más, las competencias lingüísticas son imprescindibles para preparar a los jóvenes para sus futuras carreras.
Con más oportunidades de empleo que requieren idiomas, estas competencias son esenciales en un mundo globalizado.
Independientemente de la carrera que alguien elija, si han aprendido un segundo idioma, tendrán una ventaja real en el futuro teniendo una habilidad para toda la vida como esta.
Ser capaz de comunicarse directamente con personas de países extranjeros pondrá automáticamente a una persona multilingüe por delante de la competencia.
Según una encuesta de YouGov de más de 4.000 adultos del Reino Unido en 2013, el 75 por ciento no podía hablar un idioma extranjero lo suficientemente bien como para mantener una conversación y el francés era el único idioma hablado por un porcentaje de dos dígitos, el 15 por ciento.
Es por eso que invertir en la enseñanza de idiomas ahora es importante para los niños de hoy.
Tener varios idiomas, especialmente los de las economías en desarrollo, equipará a los niños con una mejor oportunidad de encontrar un empleo significativo.
Dentro de Escocia, cada escuela será diferente en los idiomas que enseñan.
Algunas escuelas se centrarán en las lenguas modernas más clásicas, mientras que otras enseñarán idiomas que se consideran más importantes para el Reino Unido cuando se mira hacia el futuro en 2020, como el mandarín o el japonés.
Cualquiera que sea el interés de su hijo, siempre habrá una serie de idiomas para elegir dentro de las escuelas independientes, con personal docente que es especialista en esta área.
Las escuelas independientes escocesas se dedican a proporcionar un entorno de aprendizaje que prepare a los niños y les brinde las habilidades necesarias para tener éxito, sea cual sea el futuro.
No se puede negar en este momento, en un entorno empresarial global, que las lenguas siguen siendo de vital importancia para el futuro del país, por lo que esto debe reflejarse en la educación.
De hecho, las lenguas modernas deberían considerarse realmente "habilidades de comunicación internacional".
Las escuelas independientes seguirán ofreciendo esta opción, diversidad y excelencia a los jóvenes de Escocia.
Hay que hacerlo bien.
John Edward es director del Consejo Escocés de Escuelas Independientes
LeBron hará su debut con los Lakers el domingo en San Diego.
La espera casi ha terminado para los aficionados que buscan ver a LeBron James hacer su debut para los Lakers de Los Ángeles.
El entrenador de los Lakers, Luke Walton, ha anunciado que James jugará el domingo en el primer partido de pretemporada contra los Denver Nuggets en San Diego.
Pero cuántos minutos jugará aún no se ha determinado.
"Será más de uno y menos de 48", dijo Walton en el sitio web oficial de los Lakers.
El reportero de los Lakers Mike Trudell tuiteó que James probablemente jugará minutos limitados.
Después del entrenamiento a principios de esta semana, a James se le preguntó acerca de sus planes para los seis juegos del calendario de pretemporada de los Lakers.
"No necesito juegos de pretemporada en esta etapa de mi carrera para prepararme", dijo.
El rally de Trump en Virginia Occidental tiempo, canal de YouTube
El presidente Donald Trump comienza una oleada de mítines de campaña esta noche en Wheeling, Virginia Occidental.
Es el primero de los cinco mítines programados de Trump en la próxima semana, incluyendo paradas en lugares amistosos incluyendo Tennessee y Mississippi.
Con la votación de confirmación en espera para su elección para llenar la vacante de la Corte Suprema, Trump apunta a generar apoyo para las próximas elecciones de medio término ya que los republicanos corren el riesgo de perder el control del Congreso cuando se emiten los votos en noviembre.
¿A qué hora es el mitin de Trump en Virginia Occidental esta noche y cómo lo ves en línea?
El mitin de Trump en Wheeling, Virginia Occidental está programado para las 7 p.m. Esta noche, sábado 29 de septiembre de 2018.
Puedes ver el mitin de Trump en Virginia Occidental en línea a continuación a través de la transmisión en vivo en YouTube.
Es probable que Trump se dirija a las audiencias de esta semana para el candidato a la Corte Suprema Brett Kavanaugh, que se puso tenso por las acusaciones de mala conducta sexual con una votación de confirmación del Senado esperada en espera de hasta una semana mientras el FBI investiga.
Pero el objetivo principal de esta oleada de mítines es ayudar a los republicanos que se enfrentan a las elecciones de noviembre a ganar algo de impulso.
Por lo tanto, la campaña del presidente Trump dijo que estos cinco mítines en la próxima semana tienen como objetivo "energizar a los voluntarios y partidarios mientras los republicanos intentan proteger y expandir las mayorías que tienen en el Senado y la Cámara de Representantes", según Reuters.
"El control del Congreso es tan crítico para su agenda que el presidente viajará a tantos estados como sea posible mientras nos dirigimos a la ocupada temporada de campaña", dijo a Reuters un portavoz de la campaña de Trump que se negó a ser identificado.
Programado para el Wesbanco Arena en Wheeling, el mitin de esta noche podría traer simpatizantes de "Ohio y Pensilvania y atraer la cobertura de los medios de Pittsburgh", según el West Virginia Metro News.
El sábado será la segunda vez en el último mes que Trump visita Virginia Occidental, el estado que ganó por más de 40 puntos porcentuales en 2016.
Trump está tratando de ayudar al candidato republicano al Senado de Virginia Occidental, Patrick Morrisey, que está rezagado en las encuestas.
"No es una buena señal para Morrisey que el presidente tenga que venir a tratar de darle un impulso en las encuestas", dijo Simon Haeder, un politólogo de la Universidad de Virginia Occidental, según Reuters.
Ryder Cup 2018: Equipo de EE.UU. muestra estómago para luchar para mantener vivas las esperanzas en camino a los singles del domingo
Después de tres sesiones unilaterales, los cuartos del sábado por la tarde podrían haber sido lo que necesitaba esta Ryder Cup.
El péndulo oscilante del impulso es un concepto deportivo completamente inventado pero en el que los jugadores realmente creen, y nunca más que en competiciones como estas.
Entonces, ¿dónde dirían que está el impulso ahora?
"Tenían una ventaja de seis puntos y ahora son cuatro, así que estamos llevando eso como un poco de impulso supongo", dijo Jordan Spieth mientras caminaba por el día.
Europa tiene la ventaja, por supuesto, de cuatro puntos de ventaja con doce más en juego.
Los estadounidenses, como dice Spieth, sienten que tienen un poco de viento en sus velas y tienen mucho que animar, no menos importante la forma de Spieth y Justin Thomas que jugaron juntos todo el día y cada uno cuenta con tres puntos de cuatro.
Spieth ha sido letal desde el tee hasta el green y está dando el ejemplo.
Esos gritos guturales de celebración se hicieron más fuertes a medida que su ronda continuaba, hundiendo un putt crucial para tomar el cuarto partido cuando él y Thomas habían estado dos abajo después de dos.
Su putt que les ganó el partido en el 15 fue recibido con un grito similar, el tipo que te dice que cree que el equipo estadounidense no está fuera de esto.
"Realmente sólo tienes que profundizar y preocuparte por tu propio partido", dijo Spieth.
Es todo lo que cada uno de estos jugadores tiene ahora.
18 hoyos para hacer una marca.
Los únicos jugadores con más puntos que Spieth y Thomas en los últimos dos días son Francesco Molinari y Tommy Fleetwood, la historia indiscutible de la Ryder Cup.
La extraña pero adorable pareja de Europa son cuatro de cuatro y no pueden equivocarse.
"Moliwood" fueron la única pareja que no disparó un bogey el sábado por la tarde, pero también evitaron los bogey el sábado por la mañana, el viernes por la tarde y las nueve de la parte trasera el viernes por la mañana.
Esa carrera, y la forma en que su energía parece fluir tanto hacia y desde esta ruidosa multitud cements que son los jugadores para vencer el domingo, y no habría un jugador más popular para sellar una posible victoria europea mientras el sol se pone sobre Le Golf National que Fleetwood o Molinari.
Preferiblemente ambos simultáneamente en agujeros diferentes.
Sin embargo, todavía es prematuro hablar de la gloria europea.
Bubba Watson y Webb Simpson hicieron un trabajo corto de Sergio García, el héroe de cuatro bolas de la mañana, cuando fue emparejado con Alex Noren.
Un bogey y dos dobles en el nueve delantero cavaron al español y al sueco en un agujero del que nunca llegaron a salir.
El domingo, sin embargo, no hay nadie que te ayude a salir de tu agujero.
Las cuatro bolas y cuartos son tan fascinantes de ver de cerca debido a las interacciones entre parejas, los consejos que dan, los consejos que no y la forma en que una estrategia puede cambiar en un instante.
Europa ha jugado mejor como equipo hasta ahora y toman una ventaja significativa en el último día pero esta sesión de cuartos también mostró que el equipo de EE.UU. tiene el estómago para la lucha que algunos, especialmente Estados Unidos, habían estado dudando.
Europa tiene una ventaja de 10-6 en el último día de la Ryder Cup
Europa tomará una ventaja saludable en el último día de la Copa Ryder después de salir de los partidos de cuatro bolas y cuartos del sábado con una ventaja de 10-6 sobre los Estados Unidos.
El inspirado dúo Tommy Fleetwood y Francesco Molinari lideraron la carga con dos victorias sobre un luchador Tiger Woods para llevar su cuenta hasta ahora en Le Golf National a cuatro puntos.
El equipo europeo de Thomas Bjorn, intentando retener el trofeo que perdieron en Hazeltine hace dos años, dominó a un equipo estadounidense que falló en los cuatro bolas de la mañana, tomando la serie 3-1.
Los EE.UU. ofrecieron más resistencia en los cuartos, ganando dos partidos, pero no pudieron comer en el déficit.
El equipo de Jim Furyk necesita ocho puntos de los 12 partidos de domingo para retener el trofeo.
Fleetwood es el primer novato europeo en ganar cuatro puntos seguidos mientras que él y Molinari, apodado "Molliwood" después de un sensacional fin de semana son sólo la segunda pareja en ganar cuatro puntos de sus primeros cuatro partidos en la historia de la Ryder Cup.
Después de haber aplastado a Woods y Patrick Reed en las cuatro bolas, luego jugaron magníficamente para vencer a un desinflado Woods y al novato estadounidense Bryson Dechambeau por un 5 y 4 aún más enfático.
Woods, que se arrastró a través de dos partidos el sábado, mostró explosiones ocasionales de brillantez pero ahora ha perdido 19 de sus 29 partidos en cuatro bolas y cuartos y siete seguidos.
Justin Rose, descansado para las cuatro bolas de la mañana, regresó con su compañero Henrik Stenson en los cuartos para derrotar 2 y 1 a Dustin Johnson y Brooks Koepka - clasificados uno y tres en el mundo.
Europa no lo tenía todo a su manera aunque en un día agradable y ventoso al suroeste de París.
El tricampeón de Grand Slam Jordan Spieth y Justin Thomas establecieron el punto de referencia para los estadounidenses con dos puntos el sábado.
Obtuvieron una dura victoria de 2 y 1 sobre los españoles Jon Rahm e Ian Poulter en los cuatro balones y regresaron más tarde para vencer a Poulter y Rory McIlroy 4 y 3 en los cuartos después de haber perdido los dos hoyos iniciales.
Solo dos veces en la historia de la Ryder Cup un equipo ha regresado de un déficit de cuatro puntos al entrar en los singles, aunque como titulares el equipo de Furyk solo necesita empatar para retener el trofeo.
Después de ser el segundo mejor durante dos días, sin embargo, un contraataque del domingo parece que será más allá de ellos.
Corea del Norte dice que 'de ninguna manera' se desarmará unilateralmente sin confianza.
El ministro de Relaciones Exteriores de Corea del Norte dijo a las Naciones Unidas el sábado que las continuas sanciones estaban profundizando su desconfianza en Estados Unidos y que no había manera de que el país renunciara a sus armas nucleares unilateralmente en tales circunstancias.
Ri Yong Ho dijo a la Asamblea General anual del organismo mundial que Corea del Norte había tomado "medidas de buena voluntad significativas" en el último año, Por ejemplo, detener las pruebas nucleares y de misiles, desmantelar el sitio de pruebas nucleares y prometer no proliferar armas nucleares y tecnología nuclear.
"Sin embargo, no vemos ninguna respuesta correspondiente de los EE.UU"., dijo.
"Sin ninguna confianza en los EE.UU. no habrá confianza en nuestra seguridad nacional y en tales circunstancias no hay manera de que nos desarmaremos unilateralmente primero".
Mientras Ri repitió las conocidas quejas norcoreanas sobre la resistencia de Washington a un enfoque "faseal" de desnuclearización bajo el cual Corea del Norte sería recompensada a medida que tomara pasos graduales, Su declaración pareció significativa en el sentido de que no rechazó de inmediato la desnuclearización unilateral como lo ha hecho Pyongyang en el pasado.
Ri se refirió a una declaración conjunta emitida por Kim Jong Un y Donald Trump en la primera cumbre entre un presidente estadounidense en funciones y un líder norcoreano en Singapur el 12 de junio. cuando Kim se comprometió a trabajar hacia la "desnuclearización de la península coreana" mientras que Trump prometió garantías de seguridad de Corea del Norte.
Corea del Norte ha estado buscando un final formal a la Guerra de Corea de 1950-53, pero Estados Unidos ha dicho que Pyongyang debe renunciar primero a sus armas nucleares.
Washington también se ha resistido a los llamados para relajar las duras sanciones internacionales a Corea del Norte.
"Estados Unidos insiste en la "desnuclearización primero" y aumenta el nivel de presión mediante sanciones para lograr su propósito de manera coercitiva, e incluso se opone a la "declaración del fin de la guerra", dijo Ri.
"La percepción de que las sanciones pueden ponernos de rodillas es un sueño de las personas que no saben nada de nosotros.
Pero el problema es que las continuas sanciones están profundizando nuestra desconfianza".
Ri no mencionó los planes para una segunda cumbre entre Kim y Trump que el líder estadounidense destacó en las Naciones Unidas a principios de semana.
En cambio, el ministro destacó tres reuniones entre Kim y el líder surcoreano Moon Jae-in en los últimos cinco meses y agregó: "Si la parte en este asunto de la desnuclearización fuera Corea del Sur y no Estados Unidos, la desnuclearización de la península coreana no habría llegado a tal punto muerto".
Aun así, el tono del discurso de Ri fue dramáticamente diferente al del año pasado, cuando dijo a la Asamblea General de la ONU que apuntar al continente estadounidense con los cohetes de Corea del Norte era inevitable después de que el "Sr. Presidente Malvado" Trump llamara a Kim un "hombre cohete" en una misión suicida.
Este año en las Naciones Unidas, Trump, quien el año pasado amenazó con "destruir totalmente" a Corea del Norte, elogió a Kim por su coraje en tomar medidas para desarmarse, pero dijo que aún queda mucho trabajo por hacer y que las sanciones deben permanecer vigentes hasta que Corea del Norte desnuclearice.
El miércoles, Trump dijo que no tenía un marco de tiempo para esto, diciendo: "Si toma dos años, tres años o cinco meses, no importa".
China y Rusia argumentan que el Consejo de Seguridad de la ONU debería recompensar a Pyongyang por las medidas tomadas.
Sin embargo, el secretario de Estado de Estados Unidos, Mike Pompeo, dijo el jueves al Consejo de Seguridad de la ONU que: "La aplicación de las sanciones del Consejo de Seguridad debe continuar vigorosamente y sin falta hasta que logremos la desnuclearización completa, final y verificada".
El Consejo de Seguridad ha aumentado por unanimidad las sanciones a Corea del Norte desde 2006 en un intento de sofocar la financiación para los programas de misiles nucleares y balísticos de Pyongyang.
Pompeo se reunió con Ri al margen de la Asamblea General de la ONU y dijo después que volvería a visitar Pyongyang el próximo mes para prepararse para una segunda cumbre.
Pompeo ha visitado Corea del Norte tres veces este año, pero su último viaje no fue bien.
Salió de Pyongyang en julio diciendo que se había logrado progreso, solo para que Corea del Norte lo denunciara en cuestión de horas por hacer "demandas de gángster".
Corea del Norte se comprometió en una reunión con Moon este mes a desmantelar un sitio de misiles y también un complejo nuclear si Estados Unidos tomaba "medidas correspondientes".
Dijo que Kim le había dicho que las "medidas correspondientes" que estaba buscando eran las garantías de seguridad que Trump prometió en Singapur y los avances hacia la normalización de las relaciones con Washington.
Los estudiantes de Harvard toman un curso sobre cómo descansar lo suficiente
Un nuevo curso en la Universidad de Harvard este año ha conseguido que todos sus estudiantes de pregrado duerman más en un intento de combatir la creciente cultura machista de estudiar a través de "noches largas" alimentadas con cafeína.
Un académico descubrió que los estudiantes de la universidad número uno del mundo a menudo no tienen ni idea de lo básico sobre cómo cuidar de sí mismos.
Charles Czeisler, profesor de medicina del sueño en la Facultad de Medicina de Harvard y especialista en el Hospital Brigham and Women, diseñó el curso, que cree que es el primero de su tipo en los Estados Unidos.
Se inspiró para comenzar el curso después de dar una charla sobre el impacto que la privación del sueño tenía en el aprendizaje.
'Al final de la misma una muchacha se me acercó y me dijo: '¿Por qué me dicen esto sólo ahora, en mi último año?'
Dijo que nadie le había dicho nunca sobre la importancia del sueño, lo que me sorprendió", dijo a The Telegraph.
El curso, lanzado por primera vez este año, explica a los estudiantes lo esencial de cómo los buenos hábitos de sueño ayudan al rendimiento académico y atlético, así como a mejorar su bienestar general.
Paul Barreira, profesor de psiquiatría en la Escuela de Medicina de Harvard y director ejecutivo de los servicios de salud de la universidad, dijo que la universidad decidió introducir el curso después de encontrar que los estudiantes estaban seriamente privados de sueño durante la semana.
El curso de una hora de duración incluye una serie de tareas interactivas.
En una sección hay una imagen de una habitación del dormitorio, donde los estudiantes hacen clic en tazas de café, cortinas, zapatillas y libros para ser informados sobre los efectos de la cafeína y la luz y cómo el rendimiento deportivo se ve afectado por la falta de sueño, y la importancia de una rutina de la hora de acostarse.
En otra sección, se les dice a los participantes cómo la privación de sueño a largo plazo puede aumentar los riesgos de ataques cardíacos, accidentes cerebrovasculares, depresión y cáncer.
Un mapa del campus, con iconos interactivos, anima a los participantes a pensar en su rutina diaria.
Sabemos que no cambiará el comportamiento de los estudiantes al instante.
Pero creemos que tienen derecho a saberlo, al igual que usted tiene derecho a saber los efectos para la salud de elegir fumar cigarrillos", añadió el profesor Czeisler.
La cultura del orgullo de 'trabar toda la noche' todavía existe, dijo, y agregó que la tecnología moderna y la presión cada vez mayor sobre los estudiantes significaban que la privación del sueño era un problema creciente.
Asegurarse de dormir lo suficiente, de buena calidad, debería ser el 'arma secreta' de un estudiante para combatir el estrés, el agotamiento y la ansiedad, dijo, incluso para evitar aumentar de peso, ya que la privación del sueño pone el cerebro en modo de hambre, haciéndolos constantemente hambrientos.
Raymond So, un californiano de 19 años que estudia química y biología física, ayudó al profesor Czeisler a diseñar el curso, después de haber asistido a una de sus clases el año pasado durante su primer año en Harvard.
Dijo que el curso le había abierto los ojos e inspirado a impulsar un curso en todo el campus.
El próximo paso, espera, es pedir a todos los estudiantes de posgrado que completen un programa de estudios similar antes de unirse a la institución competitiva.
El profesor Czeisler recomendó que los estudiantes deberían considerar la posibilidad de establecer una alarma para la hora de irse a la cama, Además, debe tener en cuenta los efectos nocivos de la "luz azul" emitida por las pantallas electrónicas y la iluminación LED, que puede alterar su ritmo circadiano y provocar problemas para conciliar el sueño.
Livingston 1-0 Rangers: el gol de Menga derriba a los hombres de Gerrard
Los Rangers sufrieron otro ataque de tristeza en la jornada de ausencia cuando la huelga de Dolly Menga envió al equipo desarticulado de Steven Gerrard a una derrota por 1-0 en Livingston.
El equipo de Ibrox buscaba registrar su primera victoria en la carretera desde el triunfo 4-1 de febrero en St Johnstone, Pero el equipo de Gary Holt le infligió la segunda derrota a Gerrard en 18 juegos como entrenador para dejar a su equipo a ocho puntos de distancia de los líderes de Ladbrokes Hearts.
Menga golpeó siete minutos antes del descanso y una alineación de los Rangers corta de inspiración nunca pareció nivelación.
Mientras que los Rangers ahora caen al sexto lugar, Livingston sube al tercero y sólo detrás de Hibernian en diferencia de goles.
Y podría haber más problemas en la tienda para los Rangers después de que el jugador de línea Calum Spence tuvo que ser tratado por una herida en la cabeza después de que aparentemente un objeto fue lanzado desde el extremo alejado.
Gerrard hizo ocho cambios en el equipo que pasó por delante de Ayr en las semifinales de la Copa Betfred.
Holt, por otro lado, fue con el mismo Livi 11 que le quitó un punto a Hearts la semana pasada y habría estado encantado con la forma en que su equipo bien entrenado asfixiaba a sus oponentes a cada paso.
Los Rangers pudieron haber dominado la posesión pero Livingston hizo más con el balón que tenían.
Debían haber marcado solo dos minutos después cuando el primer saque de Menga envió a Scott Pittman a través del gol de Allan McGregor pero el mediocampista tiró de su gran oportunidad.
Un tiro libre profundo de Keaghan Jacobs encontró al capitán Craig Halkett pero su compañero defensivo Alan Lithgow sólo pudo apuñalar en el poste trasero.
Los Rangers tomaron el control pero parecía haber más esperanza que fe sobre su juego en el último tercio.
Alfredo Morelos sin duda sintió que debería haber tenido una penalización en el cuarto de hora cuando él y Steven Lawless chocaron pero el árbitro Steven Thomson rechazó las apelaciones del colombiano.
Los Rangers lograron sólo dos tiros en la meta en la primera mitad pero el ex portero de Ibrox Liam Kelly apenas se preocupó por el gol de cabeza de Lassana Coulibaly y un golpe de Ovie Ejaria.
Si bien la apertura de Livi en el minuto 34 pudo haber estado en contra del juego, nadie puede negar que se lo merecían solo por su injerto.
Nuevamente los Rangers no lograron hacer frente a un set-piece profundo de Jacobs.
Scott Arfield no reaccionó cuando Declan Gallagher lanzó el balón a Scott Robinson, quien mantuvo su calma para elegir a Menga para un final simple.
Gerrard actuó en el descanso cuando cambió a Coulibaly por Ryan Kent y el cambio casi tuvo un impacto inmediato ya que el extremo marcó en Morelos pero el impresionante Kelly corrió desde su línea al bloqueo.
Pero Livingston continuó empujando a los visitantes a jugar exactamente el tipo de juego que disfrutan, con Lithgow y Halkett barriendo pelota larga tras pelota larga.
El equipo de Holt podría haber extendido su ventaja en las etapas finales pero McGregor se levantó bien para negar a Jacobs antes de que Lithgow se dirigiera desde la esquina.
El sustituto de los Rangers Glenn Middleton tuvo otro reclamo tardío para un penal cuando se enredó con Jacobs pero nuevamente Thomson miró hacia otro lado.
El inventor del contador Geiger
Y ahora una página de nuestro "Almanaque del domingo por la mañana": 30 de septiembre de 1882, hace 136 años en este día, y contando... el día en que el futuro físico Johannes Wilhelm "Hans" Geiger nació en Alemania.
Geiger desarrolló un método para detectar y medir la radiactividad, un invento que finalmente condujo al dispositivo conocido como el Contador Geiger.
Un pilar de la ciencia desde entonces, el Contador Geiger también se convirtió en un pilar de la cultura pop, como en la película de 1950 "Bells of Coronado", protagonizada por los científicos vaqueros Roy Rogers y Dale Evans:
Hombre: "¿Qué demonios es eso?"
Rogers: "Es un Contador Geiger, usado para localizar minerales radiactivos, como el uranio.
Cuando se ponen estos auriculares, se pueden escuchar los efectos de los átomos emitidos por la radioactividad en los minerales".
Evans: "¡Ahora sí que está estallando!"
"Hans" Geiger murió en 1945, pocos días antes de cumplir 63 años.
Pero el invento que lleva su nombre vive.
Una nueva vacuna contra el cáncer puede enseñar al sistema inmunológico a "ver" las células malignas
Una nueva vacuna contra el cáncer puede enseñar al sistema inmunológico a "ver" las células malignas y matarlas
La vacuna enseña al sistema inmunológico a reconocer las células malignas como parte del tratamiento
El método consiste en extraer las células inmunes de un paciente, alterándolas en el laboratorio
Entonces pueden "ver" una proteína común a muchos cánceres y luego inyectarse de nuevo
Una vacuna de ensayo está mostrando resultados prometedores en pacientes con una variedad de cánceres.
Una mujer tratada con la vacuna, que enseña al sistema inmunológico a reconocer las células malignas, vio desaparecer su cáncer de ovario durante más de 18 meses.
El método consiste en extraer las células inmunes de un paciente, modificarlas en el laboratorio para que puedan "ver" una proteína común a muchos cánceres llamada HER2, y luego inyectar de nuevo las células.
El profesor Jay Berzofsky, del Instituto Nacional del Cáncer de Estados Unidos en Bethesda, Maryland, dijo: "Nuestros resultados sugieren que tenemos una vacuna muy prometedora".
HER2 "impulsa el crecimiento de varios tipos de cáncer", incluidos los cánceres de mama, ovario, pulmón y colorrectal, explicó el profesor Berzofsky.
Un enfoque similar de extraer células inmunes de los pacientes y "enseñarles" a atacar las células cancerosas ha funcionado en el tratamiento de un tipo de leucemia.
Kanye West se embarcó en una diatriba pro-Trump, usando un sombrero MAGA, después de su aparición en SNL.
No salió bien
Kanye West fue abucheado en el estudio durante un Saturday Night Live después de una actuación en la que elogió al presidente de los Estados Unidos, Donald Trump, y dijo que se postularía para el cargo en 2020.
Después de interpretar su tercera canción de la noche, llamada Ghost Town en la que llevaba una gorra Make America Great, lanzó un discurso en contra de los demócratas y reiteró su apoyo a Trump.
"Muchas veces hablo con una persona blanca y me dicen: "¿Cómo te puede gustar Trump, es racista?"
Bueno, si me preocupara por el racismo me habría mudado de América hace mucho tiempo", dijo.
SNL comenzó el programa con un sketch protagonizado por Matt Damon en el que la estrella de Hollywood se burló del testimonio de Brett Kavanaugh ante el Comité Judicial del Senado sobre las denuncias de agresión sexual hechas por Christine Blasey Ford.
Aunque no se transmitió, el comediante Chris Rock subió las imágenes del discurso de West a las redes sociales.
No está claro si Rock estaba tratando de burlarse de West con la publicación.
Además, West se había quejado a la audiencia de que tenía dificultades entre bastidores con su sombrero.
"Me intimidaban entre bastidores.
Dijeron: "No salgas con ese sombrero".
¡Me han intimidado!
Y luego dicen que estoy en un lugar hundido", dijo, según el Washington Examiner.
West continuó: "¿Quieres ver el lugar hundido?" diciendo que él "se pondría mi capa de Superman, porque esto significa que no puedes decirme qué hacer. ¿Quieres que el mundo avance?
Prueba el amor".
Sus comentarios provocaron abucheos por lo menos dos veces de la audiencia y los miembros del elenco de SNL parecían avergonzados, informó Variety, con una persona allí diciendo a la publicación: "Todo el estudio se quedó en silencio".
West había sido contratado como un reemplazo tardío para la cantante Ariana Grande, cuyo ex novio, el rapero Mac Miller había muerto hace unos días.
West desconcertó a muchos con una interpretación de la canción I Love it, vestida como una botella Perrier.
West obtuvo el apoyo de la jefa del grupo conservador TPUSA, Candace Turner, quien tuiteó: "A uno de los espíritus más valientes: GRACIAS por Ponerse de pie ante la turba".
Pero la presentadora de programas de entrevistas Karen Hunter tuiteó que West simplemente estaba "siendo quien es y eso es absolutamente maravilloso".
"Pero elegí NO recompensar a alguien (comprando su música o ropa o apoyando su "arte") que creo que está abrazando y vomitando una ideología que es dañina para mi comunidad.
Él es libre.
Nosotros también", añadió.
Antes del show, el rapero anunció en Twitter que había cambiado su nombre, diciendo que ahora era "el ser formalmente conocido como Kanye West".
No es el primer artista en cambiar su nombre y sigue los pasos de Diddy, también conocido como Puff Daddy, Puffy y P Diddy.
Su compañero rapero, Snoop Dogg ha tenido el nombre de Snoop Lion y por supuesto la leyenda de la música fallecido Prince, cambió su nombre a un símbolo y luego el artista anteriormente conocido como Prince.
Acusación de intento de asesinato por apuñalamiento en un restaurante de Belfast.
Un hombre de 45 años ha sido acusado de intento de asesinato después de que un hombre fue apuñalado en un restaurante en el este de Belfast el viernes.
El incidente ocurrió en Ballyhackamore, dijo la policía.
Se espera que el acusado comparezca ante el Tribunal de Magistrados de Belfast el lunes.
Los cargos serán revisados por el Ministerio Público.
La estrella de Juego de Tronos , Kit Harington , ataca la masculinidad tóxica .
Kit Harington es conocido por su papel como Jon Snow en la violenta serie de fantasía medieval de HBO Juego de Tronos.
Pero el actor, de 31 años, ha atacado el estereotipo del héroe machista, diciendo que esos papeles en la pantalla significan que los niños jóvenes a menudo sienten que tienen que ser duros para ser respetados.
Hablando con The Sunday Times Culture, Kit dijo que cree que "algo salió mal" y cuestionó cómo abordar el problema de la masculinidad tóxica en la era #MeToo.
Kit, quien recientemente se casó con su coestrella de Juego de Tronos Rose Leslie, también de 31 años, admitió que se siente "bastante fuerte" acerca de abordar el tema.
'Siento personalmente, muy fuertemente, en este momento - ¿dónde hemos ido mal con la masculinidad?', dijo.
¿Qué hemos estado enseñando a los hombres cuando crecen, en términos del problema que vemos ahora?
Kit cree que la televisión puede ser en parte responsable del aumento de la masculinidad tóxica gracias a sus personajes muy masculinos.
Él continuó: '¿Qué es innato y qué se enseña?
¿Qué se enseña en la televisión, y en las calles, que hace que los niños jóvenes sientan que tienen que ser este cierto lado de ser un hombre?
Creo que esa es realmente una de las grandes preguntas de nuestro tiempo: ¿cómo cambiamos eso?
Porque claramente algo ha salido mal para los jóvenes.'
En la entrevista también admitió que no estaría haciendo ninguna precuela o secuela de Game of Thrones cuando la serie llegue a su fin el próximo verano, diciendo que está "terminado con los campos de batalla y los caballos".
A partir de noviembre Kit protagonizará un renacimiento de True West de Sam Shepard que es la historia de un productor de cine y su hermano, que es un ladrón.
El actor reveló recientemente que considera que conocer a su esposa Rose es lo mejor que ha salido de Juego de Tronos.
"Conocí a mi esposa en este programa, así que de esa manera me dio mi futura familia, y mi vida a partir de ahora", dijo.
Rose interpretó a Ygritte, el interés amoroso del personaje de Kit, Jon Snow, en la serie de fantasía ganadora del premio Emmy.
La pareja se casó en junio de 2018 en el terreno de la propiedad familiar de Leslie en Escocia.
VIH/SIDA: China reporta un aumento del 14% en nuevos casos
China ha anunciado un aumento del 14% en el número de sus ciudadanos que viven con el VIH y el SIDA.
Más de 820.000 personas están afectadas en el país, dicen los funcionarios de salud.
Alrededor de 40,000 nuevos casos fueron reportados solo en el segundo trimestre de 2018.
La gran mayoría de los nuevos casos se transmitieron por vía sexual, lo que marca un cambio con respecto al pasado.
Tradicionalmente, el VIH se propagaba rápidamente en algunas partes de China como resultado de las transfusiones de sangre infectada.
Pero el número de personas que contraen el VIH de esta manera se ha reducido a casi cero, dijeron funcionarios de salud chinos en una conferencia en la provincia de Yunnan.
Sin embargo, año tras año, el número de personas que viven con el VIH y el SIDA en China ha aumentado en 100.000 personas.
La transmisión del VIH a través del sexo es un problema agudo en la comunidad LGBT de China.
La homosexualidad fue despenalizada en China en 1997, pero se dice que la discriminación contra las personas LGBT es abundante.
Debido a los valores conservadores del país, los estudios han estimado que el 70-90% de los hombres que tienen relaciones sexuales con hombres eventualmente se casarán con mujeres.
Muchas de las transmisiones de las enfermedades provienen de protecciones sexuales inadecuadas en estas relaciones.
Desde 2003, el gobierno de China ha prometido el acceso universal a medicamentos contra el VIH como parte de un esfuerzo para abordar el problema.
Maxine Waters niega que el personal haya filtrado datos de senadores republicanos, denuncia "mentiras peligrosas" y "teorías de conspiración"
La representante estadounidense Maxine Waters denunció el sábado las acusaciones de que un miembro de su personal había publicado la información personal de tres senadores republicanos en las páginas de Wikipedia de los legisladores.
El Demócrata de Los Ángeles afirmó que las afirmaciones estaban siendo comercializadas por expertos y sitios web de "extrema derecha".
"Mentiras, mentiras y mentiras más despreciables", dijo Waters en un comunicado en Twitter.
La información divulgada supuestamente incluía las direcciones de domicilio y números de teléfono de los senadores estadounidenses. Lindsey Graham de Carolina del Sur, y Mike Lee y Orrin Hatch, ambos de Utah.
La información apareció en línea el jueves, publicada por una persona desconocida en el Capitolio durante la audiencia de un panel del Senado sobre las acusaciones de mala conducta sexual contra el candidato a la Corte Suprema Brett Kavanaugh.
La filtración se produjo después de que los tres senadores interrogaran a Kavanaugh.
Sitios conservadores como Gateway Pundit y RedState informaron que la dirección IP que identifica la fuente de las publicaciones estaba asociada con la oficina de Waters y publicaron la información de un miembro del personal de Waters, informó el Hill.
"Esta acusación infundada es completamente falsa y una mentira absoluta", continuó Waters.
"El miembro de mi personal - cuya identidad, información personal y seguridad han sido comprometidas como resultado de estas acusaciones fraudulentas y falsas - no fue de ninguna manera responsable de la filtración de esta información.
Esta acusación infundada es completamente falsa y una mentira absoluta".
La declaración de Waters atrajo rápidamente críticas en línea, incluido el ex secretario de prensa de la Casa Blanca Ari Fleischer.
"Esta negación está enojada", escribió Fleischer.
"Esto sugiere que no tiene el temperamento para ser miembro del Congreso.
Cuando alguien es acusado de algo que no hizo, no debe estar enojado.
No deben ser desafiantes.
No deben cuestionar los motivos del acusador.
Deben estar tranquilos y serenos".
Fleischer parecía comparar la reacción de Waters con las críticas de los demócratas al juez Kavanaugh, quien fue acusado por los críticos de parecer demasiado enojado durante la audiencia del jueves.
Omar Navarro, un candidato republicano que se postula para derrocar a Waters en las elecciones de mitad de período, también expresó sus pensamientos en Twitter.
"Gran si es cierto", tuiteó.
En su declaración, Waters dijo que su oficina había alertado "a las autoridades apropiadas y a las entidades encargadas de hacer cumplir la ley de estas reclamaciones fraudulentas.
"Nos aseguraremos de que los perpetradores sean revelados", continuó, "y que sean responsabilizados legalmente por todas sus acciones que son destructivas y peligrosas para cualquiera y todos los miembros de mi personal".
Johnny English Strikes Again reseña - Rowan Atkinson espionaje parodia de bajo poder
Es tradicional ahora buscar significados de Brexit en cualquier nueva película con una inclinación británica y eso parece aplicable a este renacimiento de la franquicia de parodia de acción-comedia Johnny English - que comenzó en 2003 con Johnny English y volvió a la vida en 2011 con Johnny English Reborn.
¿Será la auto-satira de la lengua en la mejilla sobre el tema de lo obviamente basura que somos la nueva oportunidad de exportación de la nación?
En cualquier caso, el incompetente Johnny English con ojos de pop, cara de goma ha tenido su licencia para estropear las cosas renovada por segunda vez - ese nombre de su señal más que cualquier otra cosa que él es una amplia creación cómica diseñada para los territorios de cine no de habla inglesa.
Él es, por supuesto, el tonto agente secreto que a pesar de sus extrañas pretensiones de glamour de batido tiene un poco de Clouseau, una pizca del Sr. Bean y una pizca de ese tipo contribuyendo con una sola nota a la melodía del tema de los Carros de Fuego en la ceremonia de apertura de los Juegos Olímpicos de Londres 2012.
También está basado originalmente en el viajero y hombre internacional de misterio Atkinson que una vez interpretó en los ahora olvidados anuncios de TV de Barclaycard, dejando caos a su paso.
Hay uno o dos buenos momentos en esta última salida de JE.
Me encantó que Johnny English se acercara a un helicóptero mientras vestía una armadura medieval y las palas del rotor golpeaban brevemente su casco.
El don de Atkinson para la comedia física está en exhibición, pero el humor se siente bastante débil y extrañamente superfluo, especialmente cuando las marcas de películas "serias" como 007 y la propia Misión Imposible ahora ofrecen con confianza la comedia como ingrediente.
El humor se siente como si estuviera dirigido a niños en lugar de adultos, y para mí las desventuras locas de Johnny English no son tan inventivas y enfocadas como los chistes de películas mudas de Atkinson en el personaje de Bean.
La premisa de actualidad es que Gran Bretaña está en serios problemas.
Un hacker cibernético se ha infiltrado en la red de espías supersecreta de Gran Bretaña, revelando las identidades de todos los agentes británicos en el campo, para consternación del agente de guardia, un papel lamentablemente pequeño para Kevin Eldon.
Es la última gota para un primer ministro que es una figura pomposa y asediada, que ya sufre un colapso completo de la impopularidad política: Emma Thompson hace todo lo posible con este personaje cuasi-Teresa-May pero no hay mucho en el guión con lo que trabajar.
Sus asesores de inteligencia le informan que como cada espía activo ha sido comprometido, tendrá que sacar a alguien de su retiro.
Y eso significa torpe Johnny Inglés mismo, ahora empleado como maestro de escuela en algún establecimiento de lujo, pero dando lecciones off-the-record en cómo ser un agente encubierto: algunas buenas bromas aquí, como Inglés ofrece una Escuela de Rock-tipo academia de espionaje.
English es llevado de regreso a Whitehall para una sesión informativa de emergencia y se reúne con su antiguo compañero Bough, interpretado nuevamente por Ben Miller.
Bough es ahora un hombre casado, casado con un comandante de submarino, un papel de palos de hockey en el que Vicki Pepperdine está un poco borracha.
Así que el Batman y Robin de hacer cosas terriblemente mal en el Servicio Secreto de Su Majestad están de vuelta en acción, encontrándose con la hermosa femme fatale de Olga Kurylenko, Ophelia Bulletova.
Mientras tanto, el primer ministro está cayendo peligrosamente bajo el hechizo del carismático multimillonario tecnológico que afirma que puede resolver los problemas informáticos de Gran Bretaña: el siniestro Jason Volta, interpretado por Jake Lacy.
English y Bough comienzan su odisea de extravagancias: disfrazados de camareros, incendian un restaurante francés. Crean caos contrabandeándose a bordo del lujoso yate de Volta; y English desencadena pura anarquía mientras intenta usar un auricular de Realidad Virtual para familiarizarse con el interior de la casa de Volta.
Todas las paradas ciertamente se han retirado para esa última secuencia, pero tan amable y ruidosa como es, hay un poco de televisión infantil sobre todo el asunto.
Algo muy moderado.
Y como con las otras películas de Johnny English no pude dejar de pensar: ¿no puede la industria cinematográfica británica darle a Rowan Atkinson un papel que realmente haga justicia a su talento?
El Partido Laborista niega que esté ideando un plan para que los británicos trabajen cuatro días a la semana pero sean pagados por cinco días
El Partido Laborista de Jeremy Corbyn está considerando un plan radical que verá a los británicos trabajando cuatro días a la semana, pero siendo pagados por cinco.
Según los informes, el partido quiere que los jefes de las empresas pasen los ahorros obtenidos a través de la revolución de la inteligencia artificial (IA) a los trabajadores dándoles un día extra de descanso.
Se vería a los empleados disfrutar de un fin de semana de tres días - pero todavía llevar a casa el mismo salario.
Las fuentes dijeron que la idea encajaría con la agenda económica del partido y sus planes para inclinar el país a favor de los trabajadores.
El cambio a una semana de cuatro días ha sido respaldado por el Congreso de Sindicatos como una forma para que los trabajadores se aprovechen de la cambiante economía.
Una fuente de alto rango del Partido Laborista dijo a The Sunday Times: "Se espera que se anuncie una revisión de la política antes de fin de año.
"No sucederá de la noche a la mañana, pero una semana laboral de cuatro días es una aspiración que encaja con el enfoque del partido para reequilibrar la economía a favor de los trabajadores, así como con la estrategia industrial general del partido".
El Partido Laborista no sería el primero en respaldar tal idea, con el Partido Verde prometiendo una semana laboral de cuatro días durante su campaña electoral general de 2017.
Sin embargo, la aspiración no está siendo respaldada actualmente por el Partido Laborista en su conjunto.
Un portavoz del Partido Laborista dijo: "Una semana laboral de cuatro días no es política del partido y no está siendo considerada por el partido".
El canciller en la sombra John McDonnell utilizó la conferencia laborista de la semana pasada para concretar su visión de una revolución socialista en la economía.
El Sr. McDonnell dijo que estaba decidido a recuperar el poder de los "directores sin rostro" y "beneficiarios" de las empresas de servicios públicos.
Los planes del canciller en la sombra también significan que los actuales accionistas de las compañías de agua pueden no recuperar toda su participación, ya que un gobierno laborista podría hacer "deducciones" sobre la base de presuntas irregularidades.
También confirmó los planes para poner a los trabajadores en los consejos de administración de las empresas y crear Fondos de Propiedad Inclusiva para entregar el 10 por ciento de la equidad de las empresas del sector privado a los empleados, que pueden recibir dividendos anuales de hasta £ 500.
Lindsey Graham, John Kennedy le dijeron a "60 Minutes" si la investigación del FBI sobre Kavanaugh podría cambiar su opinión
La investigación del FBI sobre las acusaciones contra el juez Brett Kavanaugh ha retrasado una votación final sobre su nominación a la Corte Suprema por al menos una semana, y plantea la pregunta de si los hallazgos de la oficina podrían influir en cualquier senador republicano para retirar su apoyo.
En una entrevista emitida el domingo, el corresponsal de "60 Minutes" Scott Pelley le preguntó a los republicanos Sen. John Kennedy y Lindsey Graham si el FBI podría desenterrar algo que los llevaría a cambiar de opinión.
Kennedy parecía más abierto que su colega de Carolina del Sur.
"Quiero decir, por supuesto", dijo Kennedy.
"Dije al ir a la audiencia, dije, he hablado con el juez Kavanaugh.
Lo llamé después de que esto sucediera, esa acusación salió, le dije, '¿Lo hiciste?'
Él era decidido, decidido, inequívoco".
El voto de Graham, sin embargo, parece estar grabado en piedra.
"He tomado una decisión sobre Brett Kavanaugh y se necesitaría una acusación dinámica", dijo.
"Dr. Ford, no sé qué pasó, pero sé esto: Brett lo negó enérgicamente", agregó Graham, refiriéndose a Christine Blasey Ford.
"Y todos los que ella nombra no pudieron verificarlo.
Tiene 36 años.
No veo nada nuevo cambiando".
¿Qué es el Festival del Ciudadano Global y ha hecho algo para disminuir la pobreza?
Este sábado Nueva York acogerá el Global Citizen Festival, un evento musical anual que tiene una alineación muy impresionante de estrellas actuando y una misión igualmente impresionante: acabar con la pobreza mundial.
Ahora en su séptimo año, el Global Citizen Festival verá a decenas de miles de personas acudir al Great Lawn de Central Park no solo para disfrutar de actos como Janet Jackson, Cardi B y Shawn Mendes, sino también para crear conciencia sobre el verdadero objetivo del evento de acabar con la pobreza extrema para 2030.
El Global Citizen Festival, que se declaró en 2012, es una extensión del Global Poverty Project, un grupo internacional de defensa que espera acabar con la pobreza aumentando el número de personas que luchan activamente contra ella.
Para recibir una entrada gratuita para el evento (a menos que esté dispuesto a pagar una entrada VIP), Los asistentes a los conciertos tenían que completar una serie de tareas, o "acciones" como el voluntariado, enviar un correo electrónico a un líder mundial, hacer una llamada telefónica o cualquier otra forma significativa para ayudar a crear conciencia de su objetivo de erradicar la pobreza.
Pero ¿qué tan exitoso ha sido Global Citizen con 12 años restantes para alcanzar su objetivo?
¿Es la idea de recompensar a la gente con un concierto gratis una forma genuina de persuadir a la gente a exigir un llamado a la acción, o simplemente otro caso del llamado "clicktivismo" - la gente siente que están haciendo una verdadera diferencia al firmar una petición en línea o enviar un tweet?
Desde 2011, Global Citizen dice que ha registrado más de 19 millones de "acciones" de sus partidarios, presionando por una serie de objetivos diferentes.
Dice que estas acciones han ayudado a estimular a los líderes mundiales a anunciar compromisos y políticas equivalentes a más de 37 mil millones de dólares que afectarán la vida de más de 2.25 mil millones de personas para 2030.
A principios de 2018, el grupo citó 390 compromisos y anuncios derivados de sus acciones, de los cuales al menos $ 10 mil millones ya se han desembolsado o recaudado fondos.
El grupo estima que los fondos garantizados han tenido hasta ahora un impacto directo en casi 649 millones de personas en todo el mundo.
Algunos de los compromisos clave incluyen El poder de la nutrición, una asociación con sede en el Reino Unido de inversionistas y implementadores comprometidos a "ayudar a los niños a desarrollar todo su potencial", prometiendo proporcionar a Ruanda 35 millones de dólares para ayudar a acabar con la malnutrición en el país después de recibir más de 4.700 tuits de Global Citizens.
"Con el apoyo del gobierno del Reino Unido, los donantes, los gobiernos nacionales y los ciudadanos globales como ustedes, podemos hacer de la injusticia social de la desnutrición una nota a pie de página en la historia", dijo la embajadora de The Power of Nutrition Tracey Ullman a la multitud durante un concierto en vivo en Londres en abril de 2018.
El grupo también dijo que después de más de 5,El gobierno anunció la financiación de un proyecto, el Poder de la Nutrición, que alcanzará a 5 millones de mujeres y niños con intervenciones nutricionales.
En respuesta a una de las preguntas frecuentes en su sitio web preguntando "¿qué te hace pensar que podemos acabar con la pobreza extrema?"
Global Citizen respondió: "Será un camino largo y difícil - a veces caeremos y fallaremos.
Pero, como los grandes movimientos de derechos civiles y anti-apartheid que tenemos ante nosotros, tendremos éxito, porque somos más poderosos juntos.
Janet Jackson, The Weeknd, Shawn Mendes, Cardi B, Janelle Monáe se encuentran entre algunos de los artistas que actuarán en el evento de este año en Nueva York, que será presentado por Deborra-Lee Furness y Hugh Jackman.
EE.UU. podría usar la Armada para "bloqueo" para obstaculizar las exportaciones de energía de Rusia - Secretario del Interior
Washington puede "si es necesario" recurrir a su Armada para evitar que la energía rusa llegue a los mercados, incluido Oriente Medio, ha revelado el Secretario del Interior de Estados Unidos, Ryan Zinke, según lo citado por Washington Examiner.
Zinke alegó que el compromiso de Rusia en Siria - en particular, donde está operando a invitación del gobierno legítimo - es un pretexto para explorar nuevos mercados de energía.
"Creo que la razón por la que están en Oriente Medio es porque quieren negociar energía al igual que lo hacen en Europa del Este, el vientre sur de Europa", ha dicho.
Y, según el funcionario, hay maneras y medios para abordarlo.
"Estados Unidos tiene esa capacidad, con nuestra Armada, para asegurarse de que las rutas marítimas estén abiertas, y, si es necesario, para bloquear, para asegurarse de que su energía no vaya al mercado", dijo.
Zinke se dirigió a los asistentes del evento organizado por la Alianza de Energía del Consumidor, un grupo sin fines de lucro que se presenta a sí mismo como la "voz del consumidor de energía" en los Estados Unidos.
Fue a comparar los enfoques de Washington para tratar con Rusia e Irán, señalando que son efectivamente los mismos.
"La opción económica para Irán y Rusia es, más o menos, aprovechar y reemplazar los combustibles", dijo, al tiempo que se refirió a Rusia como un "ponie de un solo truco" con una economía dependiente de los combustibles fósiles.
Las declaraciones se producen cuando el gobierno de Trump ha estado en una misión para impulsar la exportación de su gas natural licuado a Europa, reemplazando a Rusia, la opción mucho más barata para los consumidores europeos.
Para ese efecto, los funcionarios de la administración Trump, incluido el propio presidente de los Estados Unidos, Donald Trump, intentan persuadir a Alemania para que se retire del "inapropiado" proyecto del oleoducto Nord Stream 2, que según Trump, convirtió a Berlín en el "cautivo" de Moscú.
Moscú ha subrayado en repetidas ocasiones que el gasoducto Nord Stream 2 de 11 mil millones de dólares, que duplicará la capacidad del gasoducto existente a 110 mil millones de metros cúbicos, es un proyecto puramente económico.
El Kremlin sostiene que la ferviente oposición de Washington al proyecto es simplemente impulsada por razones económicas y es un ejemplo de competencia desleal.
"Creo que compartimos la opinión de que la energía no puede ser una herramienta para ejercer presión y que los consumidores deben poder elegir a los proveedores", dijo el ministro de Energía ruso, Aleksandr Novak, tras una reunión con el secretario de Energía de Estados Unidos, Rick Perry, en Moscú en septiembre.
La postura de Estados Unidos ha provocado una reacción violenta de Alemania, que ha reafirmado su compromiso con el proyecto.
La principal organización alemana de la industria, la Federación de Industrias Alemanas (BDI), ha pedido a Estados Unidos que se mantenga alejado de la política energética de la UE y de los acuerdos bilaterales entre Berlín y Moscú.
"Tengo un gran problema cuando un tercer estado interfiere en nuestro suministro de energía", dijo Dieter Kempf, jefe de la Federación de Industrias Alemanas (BDI) tras una reciente reunión entre la canciller alemana Angela Merkel y el presidente ruso Vladimir Putin.
Elizabeth Warren pondrá "una mirada dura" a su candidatura a la presidencia en 2020, dice el senador de Massachusetts
La senadora de Massachusetts, Elizabeth Warren, dijo el sábado que tomaría "una mirada dura" a postularse para presidente después de las elecciones de mitad de período.
Durante un ayuntamiento en Holyoke, Massachusetts, Warren confirmó que consideraría postularse.
"Es hora de que las mujeres vayan a Washington y arreglen nuestro gobierno roto y eso incluye a una mujer en la cima", dijo, según The Hill.
"Después del 6 de noviembre, echaré un vistazo a mi candidatura a la presidencia".
Warren pesó en el presidente Donald Trump durante el ayuntamiento, diciendo que él estaba "tomando este condado en la dirección equivocada.
"Estoy preocupada hasta los huesos por lo que Donald Trump está haciendo a nuestra democracia", dijo.
Warren ha sido abierta en sus críticas a Trump y su candidato a la Corte Suprema Brett Kavanaugh.
En un tuit el viernes, Warren dijo "por supuesto que necesitamos una investigación del FBI antes de votar".
Una encuesta publicada el jueves, sin embargo, mostró que la mayoría de los propios electores de Warren no piensan que debería postularse en 2020.
Cincuenta y ocho por ciento de los votantes "probables" de Massachusetts dijeron que el senador no debería postularse, según la encuesta del Centro de Investigación Política de la Universidad de Suffolk/Boston Globe.
El treinta y dos por ciento apoyó tal carrera.
La encuesta mostró más apoyo a una candidatura del ex gobernador Deval Patrick, con un 38 por ciento apoyando una posible candidatura y un 48 por ciento en contra.
Otros nombres demócratas de alto perfil discutidos con respecto a una posible candidatura para 2020 incluyen al ex vicepresidente Joe Biden y al senador de Vermont Bernie Sanders.
Biden dijo que decidiría oficialmente para enero, informó Associated Press.
Sarah Palin cita el trastorno de estrés postraumático de Track Palin en el mitin de Donald Trump
Track Palin, de 26 años, pasó un año en Irak después de alistarse en septiembre.
Fue arrestado y acusado de un incidente de violencia doméstica el lunes por la noche.
"Lo que mi propio hijo está pasando, lo que está pasando al regresar, puedo relacionarme con otras familias que sienten las ramificaciones del TEPT y algunas de las heridas con las que nuestros soldados regresan", dijo a la audiencia en un mitin por Donald Trump en Tulsa, Oklahoma.
Palin llamó a su arresto "el elefante en la habitación" y dijo de su hijo y otros veteranos de guerra, "vuelven un poco diferentes, vuelven endurecidos, vuelven preguntándose si existe ese respeto por lo que sus compañeros soldados y aviadores, y todos los demás miembros del ejército, han dado al país".
Fue arrestado el lunes en Wasilla, Alaska, y acusado de agresión por violencia doméstica contra una mujer, interferir con un informe de violencia doméstica y posesión de un arma mientras estaba intoxicado, según Dan Bennett, portavoz del Departamento de Policía de Wasilla.
18 estados, D.C. apoyan el desafío a la nueva política de asilo
Dieciocho estados y el Distrito de Columbia están apoyando un desafío legal a una nueva política de Estados Unidos que niega asilo a las víctimas que huyen de pandillas o violencia doméstica.
Representantes de los 18 estados y el distrito presentaron un informe de amigos de la corte el viernes en Washington para apoyar a un solicitante de asilo que desafía la política, informó NBC News.
El nombre completo del demandante en el caso Grace v. La demanda de Sessions que la Unión Americana de Libertades Civiles presentó en agosto contra la política federal no ha sido revelada.
Dijo que su compañero "y sus hijos, miembros violentos de la pandilla", la abusaron, pero los funcionarios estadounidenses negaron su solicitud de asilo el 20 de julio.
Fue detenida en Texas.
Los abogados de los estados que apoyan a Grace describieron a El Salvador, Honduras y Guatemala, que producen un gran número de solicitantes de asilo en Estados Unidos, como naciones que enfrentan problemas generalizados con pandillas y violencia doméstica.
La nueva política de asilo de Estados Unidos revocó una decisión de 2014 de la Junta de Apelaciones de Inmigrantes que permitía a los inmigrantes indocumentados que huían de la violencia doméstica solicitar asilo.
El fiscal general del Distrito de Columbia, Karl Racine, dijo en un comunicado el viernes que la nueva política "ignora décadas de ley estatal, federal e internacional".
"La ley federal requiere que todas las solicitudes de asilo sean juzgadas sobre los hechos y circunstancias particulares de la reclamación, y tal prohibición viola ese principio", dijo el informe del amigo de la corte.
Los abogados argumentaron además en el informe que la política de negar la entrada a los inmigrantes perjudica a la economía de Estados Unidos, diciendo que son más propensos a convertirse en empresarios y "proporcionar mano de obra necesaria".
El fiscal general Jeff Sessions ordenó a los jueces de inmigración que ya no concedieran asilo a las víctimas que huyen del abuso doméstico y la violencia de pandillas en junio.
"El asilo está disponible para aquellos que abandonan su país de origen debido a la persecución o el miedo debido a su raza, religión, nacionalidad o pertenencia a un grupo social o opinión política particular", dijo Sessions en su anuncio del 11 de junio de la política.
El asilo nunca fue pensado para aliviar todos los problemas, incluso todos los problemas graves, que las personas enfrentan todos los días en todo el mundo.
Los esfuerzos de rescate desesperados en Palu mientras el número de muertos se duplica en la carrera por encontrar sobrevivientes
Para los supervivientes, la situación era cada vez más grave.
"Me siento muy tensa", dijo Risa Kusuma, una madre de 35 años, al consolar a su bebé con fiebre en un centro de evacuación en la devastada ciudad de Palu.
"Cada minuto una ambulancia trae cuerpos.
El agua limpia es escasa".
Los residentes fueron vistos regresando a sus casas destruidas, recogiendo las pertenencias inundadas, tratando de salvar todo lo que pudieran encontrar.
Cientos de personas resultaron heridas y los hospitales, dañados por el terremoto de magnitud 7,5, quedaron abrumados.
Algunos de los heridos, incluido Dwi Haris, que sufrió una fractura de espalda y hombro, descansaron fuera del Hospital del Ejército de Palu, donde los pacientes estaban siendo tratados al aire libre debido a las fuertes réplicas continuas.
Sus ojos se llenaron de lágrimas cuando relató cómo sintió el violento terremoto que sacudió el quinto piso de la habitación del hotel que compartía con su esposa e hija.
"No había tiempo para salvarnos.
Estaba apretado en las ruinas del muro, creo", dijo Haris a Associated Press, y agregó que su familia estaba en la ciudad para una boda.
"Escuché a mi esposa gritar pidiendo ayuda, pero luego hubo silencio.
No sé qué le pasó a ella y a mi hijo.
Espero que estén a salvo".
El embajador de EE.UU. acusa a China de 'bullying' con 'anuncios de propaganda'
Una semana después de que un periódico oficial chino publicara un anuncio de cuatro páginas en un diario estadounidense promocionando los beneficios mutuos del comercio entre Estados Unidos y China, el embajador de Estados Unidos en China acusó a Beijing de usar la prensa estadounidense para difundir propaganda.
El presidente de Estados Unidos, Donald Trump, el miércoles pasado se refirió al suplemento pagado del China Daily en el Des Moines Register - el periódico más vendido del estado de Iowa - después de acusar a China de tratar de interferir en las elecciones del 6 de noviembre en el Congreso de Estados Unidos, Un cargo que China niega.
La acusación de Trump de que Pekín estaba tratando de interferir en las elecciones estadounidenses marcó lo que funcionarios estadounidenses dijeron a Reuters era una nueva fase en una campaña creciente de Washington para presionar a China.
Si bien es normal que los gobiernos extranjeros coloquen anuncios para promover el comercio, Beijing y Washington están actualmente encerrados en una escalada de una guerra comercial que los ha visto nivelar rondas de aranceles sobre las importaciones del otro.
Los aranceles de represalia de China al principio de la guerra comercial fueron diseñados para golpear a los exportadores en estados como Iowa que apoyaban al Partido Republicano de Trump, dijeron expertos chinos y estadounidenses.
Terry Branstad, embajador de Estados Unidos en China y ex gobernador de Iowa, un importante exportador de productos agrícolas a China, dijo que Pekín había perjudicado a trabajadores, agricultores y empresas estadounidenses.
China, escribió Branstad en un artículo de opinión en el Des Moines Register del domingo, "ahora está duplicando esa intimidación publicando anuncios de propaganda en nuestra propia prensa libre".
"Al difundir su propaganda, el gobierno de China se está aprovechando de la preciada tradición estadounidense de libertad de expresión y de prensa al colocar un anuncio pagado en el Registro de Des Moines", escribió Branstad.
"En contraste, en el quiosco de periódicos abajo de la calle aquí en Beijing, encontrará voces disidentes limitadas y no verá ningún reflejo verdadero de las opiniones dispares que el pueblo chino puede tener sobre la trayectoria económica preocupante de China, dado que los medios están bajo el firme control del Partido Comunista Chino", escribió.
Añadió que "uno de los periódicos más prominentes de China evadió la oferta de publicar" su artículo, aunque no dijo en qué periódico.
Los republicanos alejan a las mujeres votantes antes de las elecciones de mitad de período con Kavanaugh debacle, los analistas advierten
A medida que muchos republicanos de alto rango están de pie y defienden al candidato a la Corte Suprema Brett Kavanaugh frente a varias acusaciones de agresión sexual, los analistas han advertido que verán una reacción violenta, particularmente de las mujeres, durante las próximas elecciones de mitad de período.
Las emociones en torno a esto han sido extremadamente altas, y la mayoría de los republicanos ya están registrados mostrando que querían seguir adelante con una votación.
Esas cosas no se pueden revertir", dijo Grant Reeher, profesor de ciencias políticas en la Escuela Maxwell de la Universidad de Syracuse, a The Hill para un artículo publicado el sábado.
Reeher dijo que duda que el impulso de última hora del senador Jeff Flake (R-Arizona) para una investigación del FBI sea suficiente para aplacar a los votantes enojados.
"Las mujeres no van a olvidar lo que pasó ayer, no lo van a olvidar mañana y no en noviembre,Karine Jean-Pierre, asesora principal y portavoz nacional del grupo progresista MoveOn dijo el viernes, según el periódico de Washington, DC.
El viernes por la mañana, Los manifestantes corearon "¡Noviembre está llegando!" mientras manifestaban en el pasillo del Senado mientras los republicanos que controlan el Comité Judicial optaban por avanzar con el nombramiento de Kavanaugh a pesar del testimonio de la doctora Christine Blasey Ford, informó Mic.
"El entusiasmo y la motivación democráticos van a estar fuera de la carta", dijo Stu Rothenberg, un analista político no partidista, al sitio de noticias.
"La gente dice que ya ha sido alta; eso es cierto.
Pero podría ser mayor, particularmente entre las votantes femeninas en los suburbios y los votantes más jóvenes, de 18 a 29 años, que aunque no les gusta el presidente, a menudo no votan".
Incluso antes del testimonio público de Ford detallando sus acusaciones de agresión sexual contra el candidato a la Corte Suprema, los analistas sugirieron que podría seguir una reacción violenta si los republicanos avanzaban con la confirmación.
"Esto se ha convertido en un desastre para el Partido Republicano", dijo Michael Steele, ex presidente del Comité Nacional Republicano, a principios de la semana pasada, según NBC News.
"No se trata de la votación del comité o la votación final o si Kavanaugh es puesto en el banquillo, También se trata de la forma en que los republicanos han manejado esto y cómo la han tratado", señaló Guy Cecil, director de Priorities USA, un grupo que ayuda a elegir a los demócratas, al canal de noticias.
Sin embargo, los estadounidenses parecen estar algo divididos sobre a quién creer a raíz de los testimonios de Ford y Kavanaugh, con un poco más de lado con este último.
Una nueva encuesta de YouGov muestra que el 41 por ciento de los encuestados definitivamente o probablemente creyeron el testimonio de Ford, mientras que el 35 por ciento dijo que definitivamente o probablemente creyeron a Kavanaugh.
Además, el 38 por ciento dijo que pensaba que Kavanaugh probablemente o definitivamente mintió durante su testimonio, mientras que solo el 30 por ciento dijo lo mismo sobre Ford.
Después de la presión de Flake, el FBI está actualmente investigando las acusaciones presentadas por Ford, así como al menos otra acusadora, Deborah Ramírez, informó The Guardian.
Ford testificó ante el Comité Judicial del Senado bajo juramento la semana pasada que Kavanaugh la agredió borracho a la edad de 17 años.
Ramírez alega que el candidato a la Corte Suprema le expuso sus genitales mientras asistían a una fiesta durante su tiempo estudiando en Yale en la década de 1980.
El inventor de la World Wide Web planea iniciar un nuevo Internet para competir con Google y Facebook
Tim Berners-Lee, el inventor de la World Wide Web, está lanzando una startup que busca competir con Facebook, Amazon y Google.
El último proyecto de la leyenda de la tecnología, Inrupt, es una compañía que se basa en la plataforma de código abierto de Berners-Lee, Solid.
Solid permite a los usuarios elegir dónde se almacenan sus datos y a qué personas se les permite acceder a qué información.
En una entrevista exclusiva con Fast Company, Berners-Lee bromeó diciendo que la intención detrás de Inrupt es "dominación mundial".
"Tenemos que hacerlo ahora", dijo de la puesta en marcha.
"Es un momento histórico".
La aplicación utiliza la tecnología de Solid para permitir a las personas crear su propia "tienda de datos en línea personal" o un POD.
Puede contener listas de contactos, listas de tareas pendientes, calendario, biblioteca de música y otras herramientas personales y profesionales.
Es como si Google Drive, Microsoft Outlook, Slack y Spotify estuvieran todos disponibles en un mismo navegador y todo al mismo tiempo.
Lo único de la tienda de datos personales en línea es que depende completamente del usuario quién puede acceder a qué tipo de información.
La compañía lo llama "empoderamiento personal a través de datos".
La idea de Inrupt, según el CEO de la compañía, John Bruce, es que la compañía traiga recursos, procesos y habilidades apropiadas para ayudar a que Solid esté disponible para todos.
La compañía actualmente consta de Berners-Lee, Bruce, una plataforma de seguridad comprada por IBM, algunos desarrolladores contratados para trabajar en el proyecto y una comunidad de codificadores voluntarios.
A partir de esta semana, los desarrolladores de tecnología de todo el mundo podrían crear sus propias aplicaciones descentralizadas utilizando las herramientas disponibles en el sitio web de Inrupt.
Berners-Lee dijo que él y su equipo no están hablando con "Facebook y Google sobre si introducir o no un cambio completo en el que todos sus modelos de negocio sean completamente cambiados de la noche a la mañana.
"No les estamos pidiendo permiso".
En una publicación en Medium publicada el sábado, Berners-Lee escribió que la "misión de Inrupt es proporcionar energía comercial y un ecosistema para ayudar a proteger la integridad y la calidad de la nueva web construida sobre Solid".
En 1994, Berners-Lee transformó Internet cuando estableció el Consorcio de la World Wide Web en el Instituto de Tecnología de Massachusetts.
En los últimos meses, Berners-Lee ha sido una voz influyente en el debate sobre la neutralidad de la red.
Incluso mientras lanza Inrupt, Berners-Lee seguirá siendo el fundador y director del World Wide Web Consortium, la Web Foundation y el Open Data Institute.
"Soy increíblemente optimista para esta próxima era de la web", añadió Berners-Lee.
Bernard Vann: Clérigo de la Cruz Victoria de la Primera Guerra Mundial celebrado
El único clérigo de la Iglesia de Inglaterra que ganó una Cruz de Victoria durante la Primera Guerra Mundial como combatiente ha sido celebrado en su ciudad natal 100 años después.
El Teniente Coronel el Reverendo Bernard Vann ganó el premio el 29 de septiembre de 1918 en el ataque en Bellenglise y Lehaucourt.
Sin embargo, fue asesinado por un francotirador cuatro días después y nunca supo que había ganado el más alto honor militar británico.
Una piedra conmemorativa fue inaugurada por sus dos nietos en un desfile en Rushden, Northamptonshire, el sábado.
Uno de sus nietos, Michael Vann, dijo que era "brillantemente simbólico" que la piedra se revelara exactamente 100 años después de la hazaña galardonada de su abuelo.
Según el London Gazette, el 29 de septiembre de 1918, el teniente coronel Vann condujo a su batallón a través del Canal de Saint-Quentin "a través de una niebla muy espesa y bajo un fuerte fuego de armas de campo y ametralladoras".
Más tarde se dirigió a la línea de fuego y con la "mayor galantería" condujo la línea hacia adelante antes de lanzar una pistola de campo con una sola mano y noqueó a tres del destacamento.
El teniente coronel Vann fue asesinado por un francotirador alemán el 4 de octubre de 1918 - poco más de un mes antes de que terminara la guerra.
Michael Vann, de 72 años, dijo que las acciones de su abuelo fueron "algo que sé que nunca podría cumplir, pero algo que es humillante".
Él y su hermano el Dr. James Vann también colocaron una corona después del desfile, que fue dirigido por la Banda Imperial de la Juventud de Brentwood.
Michael Vann dijo que "se sentía muy honrado de desempeñar un papel en el desfile" y agregó que "el valor de un verdadero héroe se está demostrando con el apoyo que dará mucha gente".
Los aficionados a las artes marciales se quedaron despiertos toda la noche para ver Bellator 206, en su lugar obtuvieron a Peppa Pig.
Imagínese esto, se ha quedado despierto toda la noche para ver el lleno de Bellator 206 sólo para ser negado a ver el evento principal.
El proyecto de ley de San José contenía 13 peleas, incluyendo seis en la tarjeta principal y se mostraba en vivo durante toda la noche en el Reino Unido en el Canal 5.
A las 6 de la mañana, justo cuando Gegard Mousasi y Rory MacDonald se preparaban para enfrentarse, los espectadores en el Reino Unido quedaron atónitos cuando la cobertura cambió a Peppa Pig.
Algunos no quedaron impresionados después de haber permanecido despiertos hasta las primeras horas especialmente para la pelea.
Un fan en Twitter describió el cambio al dibujo animado infantil como "una especie de broma enfermiza".
"La regulación del gobierno es que a las 6 a.m. ese contenido no era adecuado por lo que tuvieron que cambiar a la programación infantil", dijo Dave Schwartz, vicepresidente senior de marketing y comunicación de Bellator, cuando se le preguntó sobre la transmisión.
"Peppa el cerdo, sí".
El presidente de la compañía Bellator, Scott Coker, dijo que van a trabajar en su programación para incluir a los espectadores del Reino Unido en el futuro.
"Creo que cuando pienso en la repetición, creo que probablemente podemos resolverlo", dijo Coker.
"Pero son las seis de la mañana un domingo allí y no podremos resolver esto hasta el domingo a nuestra hora, el lunes a la de ellos.
Pero estamos trabajando en ello.
Créeme, cuando cambió había un montón de mensajes de texto yendo y viniendo y no todos eran amistosos.
Estábamos tratando de arreglarlo, pensamos que era un fallo técnico.
Pero no lo fue, fue un asunto gubernamental.
Te puedo prometer que la próxima vez no va a suceder.
Vamos a mantenerlo a cinco peleas en lugar de seis - como lo hacemos normalmente - y tratamos de entregar demasiado para los aficionados y simplemente pasamos.
Es una situación desafortunada".
Discos de Desert Island: Tom Daley se sentía 'inferior' con respecto a la sexualidad
El buzo olímpico Tom Daley dice que creció sintiéndose inferior a todos debido a su sexualidad, pero eso le dio la motivación para convertirse en un éxito.
El joven de 24 años dijo que no se dio cuenta hasta que fue a la escuela secundaria de que "no todo el mundo es como yo".
Hablando en la primera Radio 4 Desert Island Discs presentada por Lauren Laverne, dijo que habló sobre los derechos de los homosexuales para dar a otros "esperanza".
También dijo que convertirse en padre le hizo preocuparse menos por ganar los Juegos Olímpicos.
La presentadora habitual del programa de larga duración, Kirsty Young, se ha tomado varios meses de descanso debido a la enfermedad.
Apareciendo como un náufrago en el primer programa de Laverne, Daley dijo que se sentía "menos" que todos los demás al crecer porque "no era socialmente aceptable gustarle a niños y niñas".
Él dijo: "Hasta el día de hoy, esos sentimientos de inferioridad y de sentirme diferente han sido las verdaderas cosas que me han dado el poder y la fuerza para poder triunfar".
Quería demostrar que era "algo", dijo, para que no decepcionara a todos cuando finalmente se enteraran de su sexualidad.
El dos veces medallista de bronce olímpico se ha convertido en un activista LGBT de alto perfil y utilizó su aparición en los Juegos de la Commonwealth de este año en Australia para apelar a más países para despenalizar la homosexualidad.
Dijo que habló porque se sentía afortunado de poder vivir abiertamente sin ramificaciones y quería dar a otros "esperanza".
El tres veces campeón del mundo dijo que enamorarse de un hombre - el cineasta estadounidense Dustin Lance Black, a quien conoció en 2013 - "me sorprendió".
Daley se casó con el ganador del Oscar, que es 20 años mayor que él, el año pasado, pero dijo que la diferencia de edad nunca había sido un problema.
"Cuando uno pasa por tanto a una edad tan joven" - fue a sus primeros Juegos Olímpicos a los 14 años y su padre murió de cáncer tres años más tarde - dijo que era difícil encontrar a alguien de su misma edad que hubiera experimentado altibajos similares.
La pareja se convirtió en padres en junio, con un hijo llamado Robert Ray Black-Daley, y Daley dijo que su "perspectiva completa" había cambiado.
"Si me hubieran preguntado el año pasado, todo era sobre 'Necesito ganar una medalla de oro'", dijo.
"Sabes qué, hay cosas más importantes que las medallas de oro olímpicas.
Mi medalla de oro olímpica es Robbie".
Su hijo lleva el mismo nombre que su padre Robert, quien murió en 2011 a los 40 años después de ser diagnosticado con cáncer cerebral.
Daley dijo que su padre no aceptaba que iba a morir y una de las últimas cosas que les preguntó fue si tenían sus boletos para Londres 2012 - ya que él quería estar en la primera fila.
"No podía decirle 'no vas a estar por aquí para ser el padre de la primera fila'", dijo.
"Le estaba sosteniendo la mano cuando dejó de respirar y no fue hasta que realmente dejó de respirar y estaba muerto que finalmente reconocí que no era invencible", dijo.
Al año siguiente, Daley compitió en los Juegos Olímpicos de 2012 y ganó el bronce.
"Simplemente sabía que esto era lo que había soñado toda mi vida: bucear frente a un público local en los Juegos Olímpicos, no había mejor sensación", dijo.
También inspiró su primera elección de canción - Proud de Heather Small - que había resonado con él en la preparación para los Juegos Olímpicos y todavía le daba piel de gallina.
Desert Island Discs está en BBC Radio 4 el domingo a las 11:15 BST.
Mickelson, fuera de forma, sentado en el banquillo del Ryder Cup el sábado.
El estadounidense Phil Mickelson establecerá un récord el domingo cuando juegue su 47o partido de la Ryder Cup, pero tendrá que cambiar su forma para evitar que sea un hito infeliz.
Mickelson, jugando en el evento bienal por un récord de 12 veces, fue sentado en el banquillo por el capitán Jim Furyk para los cuatro balones y cuartos del sábado.
En lugar de estar en el centro de la acción, como ha sido tan a menudo para los Estados Unidos, el cinco veces ganador de las Grandes Ligas dividió su día entre ser una animadora y trabajar en su juego en el campo con la esperanza de rectificar lo que le aflige.
Nunca el más recto de los pilotos, incluso en el apogeo de su carrera, el de 48 años no es un ajuste ideal para el estrecho campo Le Golf National, donde el largo camino áspero regularmente castiga los tiros erróneos.
Y si el recorrido por sí solo no es lo suficientemente desalentador, Mickelson, en el noveno partido del domingo, se enfrenta al verdadero campeón del Abierto Británico Francesco Molinari, quien se ha unido con el novato Tommy Fleetwood para ganar sus cuatro partidos esta semana.
Si los estadounidenses, con cuatro puntos de ventaja desde el comienzo de los 12 partidos individuales, comienzan con un comienzo caliente, el partido de Mickelson podría ser absolutamente crucial.
Furyk expresó confianza en su hombre, no que pudiera decir mucho más.
"Comprendió completamente el papel que tenía hoy, me dio una palmadita en la espalda y me abrazó y dijo que estaría listo mañana", dijo Furyk.
"Tiene mucha confianza en sí mismo.
Es miembro del Salón de la Fama y ha añadido mucho a estos equipos en el pasado, y esta semana.
Probablemente no lo imaginé jugando dos partidos.
Imaginé más, pero así es como funcionó y así pensamos que teníamos que ir.
Quiere estar ahí afuera, como todos los demás".
Mickelson superará el récord de Nick Faldo para la mayor cantidad de partidos de la Ryder Cup jugados el domingo.
Podría marcar el final de una carrera en la Ryder Cup que nunca ha alcanzado las alturas de su récord individual.
Mickelson tiene 18 victorias, 20 derrotas y siete medias, aunque Furyk dijo que su presencia trajo algo intangible al equipo.
"Es gracioso, es sarcástico, ingenioso, le gusta burlarse de la gente, y es un gran tipo para tener en la sala de equipo", explicó.
"Creo que los jugadores más jóvenes se divirtieron probándolo también esta semana, lo cual fue divertido de ver.
Él provee mucho más que un simple juego".
El capitán de Europa, Thomas Bjorn, sabe que la gran ventaja puede desaparecer pronto.
Thomas Bjorn, el capitán europeo, sabe por experiencia que una ventaja considerable en el último día de la Ryder Cup puede convertirse fácilmente en un viaje incómodo.
El danés hizo su debut en el partido de 1997 en Valderrama, donde un equipo capitaneado por Seve Ballesteros mantuvo una ventaja de cinco puntos sobre los estadounidenses, pero apenas cruzó la línea de meta con sus narices delante por el más estrecho de los márgenes, ganando 141⁄2-131⁄2.
"Sigues recordándote que teníamos una gran ventaja en Valderrama; Tuvimos una gran ventaja en Brookline, donde perdimos, y en Valderrama, donde ganamos, pero apenas", dijo Bjorn, en la foto, después de ver a la Clase de 2018 ganar 5-3 tanto el viernes como ayer para liderar 10-6 en Le Golf National.
Así que la historia me mostrará a mí y a todos en ese equipo que esto no ha terminado.
Mañana te aburrirás.
Sal y haz lo correcto.
Esto no terminará hasta que tengas los puntos en el tablero.
Tenemos un objetivo, y es tratar de ganar este trofeo, y ahí es donde el enfoque permanece.
Lo he dicho todo el tiempo, me concentro en los 12 jugadores que están en nuestro lado, pero somos muy conscientes de lo que está del otro lado: los mejores jugadores del mundo".
Encantado de cómo se han desempeñado sus jugadores en un campo de golf difícil, Bjorn añadió: "Nunca me adelantaría en esto.
Mañana es una bestia diferente.
Mañana son las actuaciones individuales que se presentan, y eso es otra cosa que hacer.
Es genial estar ahí fuera con un compañero cuando las cosas van bien, pero cuando estás ahí fuera individualmente, entonces estás probado al máximo de tu capacidad como golfista.
Ese es el mensaje que tienes que transmitir a los jugadores, es sacar lo mejor de ti mismo mañana.
Ahora, dejas atrás a tu pareja y él tiene que ir y sacar lo mejor de sí mismo, también".
En contraste con Bjorn, el número opuesto Jim Furyk buscará que sus jugadores se desempeñen mejor individualmente que como socios, las excepciones son Jordan Spieth y Justin Thomas, que recogieron tres puntos de cuatro.
El propio Furyk ha estado en ambos extremos de esos grandes cambios de los últimos días, habiendo sido parte del equipo ganador en Brookline antes de terminar como un perdedor cuando Europa logró el "Milagro en Medina".
"Recuerdo cada maldita palabra", dijo en respuesta a la pregunta de cómo Ben Crenshaw, el capitán en 1999, había reunido a sus jugadores en el último día.
"Tenemos 12 partidos importantes mañana, pero te gustaría salir a ese comienzo rápido como lo viste en Brookline, como lo viste en Medina.
Cuando ese impulso va en una dirección, pone mucha presión en los fósforos del medio.
Establecimos nuestra alineación en consecuencia y ponemos a los chicos en la moda que sentimos como, ya sabes, estamos tratando de hacer algo de magia mañana. "
Thomas ha recibido la tarea de tratar de liderar la lucha y se enfrenta a Rory McIlroy en el primer partido, con Paul Casey, Justin Rose, Jon Rahm, Tommy Fleetwood e Ian Poulter los otros europeos en la mitad superior del orden.
"Estuve con este grupo de chicos en este orden porque creo que cubre todo el camino", dijo Bjorn de sus selecciones de solteros.
El nuevo buque de guerra de Alemania se pospone una vez más.
La fragata más nueva de la Armada alemana debería haber sido puesta en servicio en 2014 para reemplazar a los antiguos buques de guerra de la era de la Guerra Fría, pero no estará allí hasta al menos el próximo año debido a sistemas defectuosos y costos de bola de nieve, informaron los medios locales.
La puesta en servicio del "Rheinland-Pfalz", el buque principal de las nuevas fragatas de clase Baden-Württemberg, ahora se ha pospuesto hasta la primera mitad de 2019, según el periódico Die Zeit citando a un portavoz militar.
El buque debería haberse unido a la Armada en 2014, pero los problemáticos problemas posteriores a la entrega afectaron el destino del ambicioso proyecto.
Los cuatro buques de la clase Baden-Württemberg que la Armada ordenó en 2007 vendrán como reemplazo de las viejas fragatas de la clase Bremen.
Se entiende que contarán con un poderoso cañón, una serie de misiles antiaéreos y antiaéreos, así como algunas tecnologías sigilosas, como radar reducido, infrarrojos y firmas acústicas.
Otras características importantes incluyen períodos de mantenimiento más largos: debería ser posible desplegar las fragatas más nuevas hasta durante dos años fuera de los puertos de origen.
Sin embargo, los continuos retrasos significan que los buques de guerra de última generación - que se dice que permiten a Alemania proyectar poder en el extranjero - ya estarán obsoletos cuando entren en servicio, señala Die Zeit.
La desgraciada fragata F125 fue noticia el año pasado, cuando la Armada alemana se negó oficialmente a ponerla en servicio y la devolvió al astillero Blohm & Voss en Hamburgo.
Esta fue la primera vez que la Armada devolvió un barco a un constructor naval después de la entrega.
Poco se sabía sobre las razones detrás del regreso, pero los medios alemanes citaron una serie de "defectos de software y hardware" cruciales que hicieron que el buque de guerra fuera inútil si se desplegara en una misión de combate.
Las deficiencias de software fueron particularmente importantes ya que los buques de la clase Baden-Württemberg serán operados por una tripulación de unos 120 marineros, solo la mitad de la mano de obra en las antiguas fragatas de la clase Bremen.
Además, surgió que el buque es dramáticamente de sobrepeso lo que reduce su rendimiento y limita la capacidad de la Armada para añadir futuras mejoras.
Se cree que el "Rheinland-Pfalz" de 7.000 toneladas pesaba el doble que los barcos de clase similar utilizados por los alemanes en la Segunda Guerra Mundial.
Además del hardware defectuoso, el precio de todo el proyecto - incluyendo la capacitación de la tripulación - también se está convirtiendo en un problema.
Se dice que ha alcanzado los asombrosos 3,1 mil millones de euros (3,6 mil millones de dólares), frente a los 2,2 mil millones iniciales.
Los problemas que afectan a las fragatas más nuevas se vuelven especialmente importantes a la luz de las recientes advertencias de que el poder naval de Alemania se está reduciendo.
A principios de este año, Hans-Peter Bartels, jefe del comité de defensa del parlamento alemán, reconoció que la Armada en realidad "se está quedando sin buques capaces de desplegar".
El funcionario dijo que el problema se ha convertido en una bola de nieve con el tiempo, porque los barcos viejos fueron desmantelados pero no se proporcionaron buques de reemplazo.
Lamentó que ninguna de las fragatas de la clase Baden-Wuerttemberg pudieran unirse a la Armada.
El National Trust escucha la vida secreta de los murciélagos
Una nueva investigación que se está llevando a cabo en una finca de las tierras altas de Escocia tiene como objetivo revelar cómo los murciélagos utilizan el paisaje en su búsqueda de alimento.
Se espera que los hallazgos arrojen nueva luz sobre el comportamiento de estos únicos mamíferos voladores y ayuden a orientar futuras actividades de conservación.
El estudio realizado por científicos del National Trust for Scotland seguirá a las pipistrellas comunes y soprano, así como a los murciélagos de orejas largas marrones y Daubenton en Inverewe Gardens en Wester Ross.
Se colocarán grabadores especiales en lugares clave alrededor de la propiedad para rastrear las actividades de los murciélagos durante toda la temporada.
El personal y los voluntarios del NHS también llevarán a cabo encuestas móviles utilizando detectores portátiles.
El análisis de sonido experto de todas las grabaciones determinará la frecuencia de las llamadas de los murciélagos y qué especies están haciendo qué.
A continuación, se elaborará un mapa de hábitats y un informe para obtener una imagen detallada a escala de paisaje de su comportamiento.
Rob Dewar, asesor de conservación de la naturaleza del NTS, espera que los resultados revelen qué áreas de hábitat son más importantes para los murciélagos y cómo las utilizan cada una de las especies.
Esta información ayudará a determinar los beneficios del trabajo de gestión del hábitat, como la creación de praderas y la mejor manera de mantener los bosques para los murciélagos y otras especies asociadas.
Las poblaciones de murciélagos en Escocia y en todo el Reino Unido han disminuido considerablemente durante el siglo pasado.
Están amenazadas por los trabajos de construcción y desarrollo que afectan a sus madrigueras y a la pérdida de su hábitat.
Las turbinas eólicas y la iluminación también pueden suponer un riesgo, al igual que el papel de mosca y algunos tratamientos químicos de los materiales de construcción, así como los ataques de gatos domésticos.
Los murciélagos no son ciegos.
Sin embargo, debido a sus hábitos nocturnos de caza sus oídos son más útiles que sus ojos cuando se trata de atrapar presas.
Utilizan una sofisticada técnica de eco-localización para identificar insectos y obstáculos en su trayectoria de vuelo.
El NTS, que es responsable del cuidado de más de 270 edificios históricos, 38 jardines importantes y 76.000 hectáreas de tierra en todo el país, toma muy en serio a los murciélagos.
Cuenta con diez expertos capacitados, que llevan a cabo regularmente encuestas, inspecciones de pajares y, a veces, rescates.
La organización incluso ha creado la primera y única reserva dedicada de murciélagos de Escocia en la finca Threave en Dumfries y Galloway, que alberga a ocho de las diez especies de murciélagos de Escocia.
El gerente de la finca David Thompson dice que la finca es el territorio ideal para ellos.
"Aquí en Threave tenemos un gran área para los murciélagos", dijo.
"Tenemos los edificios viejos, muchos árboles veteranos y todo el buen hábitat.
Pero todavía hay mucho que no se sabe sobre los murciélagos, por lo que el trabajo que hacemos aquí y en otras propiedades nos ayudará a comprender más sobre lo que necesitan para prosperar".
Destaca la importancia de comprobar si hay murciélagos antes de realizar el mantenimiento dentro de las propiedades, ya que es posible que la destrucción involuntaria de un solo nido de maternidad pueda matar hasta 400 hembras y crías, posiblemente aniquilando a toda una población local.
Los murciélagos están protegidos y es ilegal matarlos, acosarlos o molestarlos o destruir sus nidos.
Elisabeth Ferrell, oficial escocesa del Bat Conservation Trust, ha alentado al público a ayudar.
Ella dijo: "Todavía tenemos mucho que aprender sobre nuestros murciélagos y para muchas de nuestras especies simplemente no sabemos cómo van sus poblaciones".
Ronaldo rechaza las acusaciones de violación mientras los abogados intentan demandar a la revista alemana
Cristiano Ronaldo ha calificado las acusaciones de violación contra él como "noticias falsas", diciendo que la gente "quiere promocionarse" usando su nombre.
Sus abogados están listos para demandar a la revista alemana Der Spiegel, que publicó las acusaciones.
El delantero de Portugal y Juventus ha sido acusado de violar a una mujer estadounidense, llamada Kathryn Mayorga, en una habitación de hotel de Las Vegas en 2009.
Se alega que luego le pagó 375.000 dólares para que guardara silencio sobre el incidente, informó Der Spiegel el viernes.
Hablando en un video en vivo de Instagram a sus 142 millones de seguidores horas después de que se informaran las afirmaciones, Ronaldo, de 33 años, criticó los informes como "noticias falsas".
"No, no, no, no, no.
Lo que dijeron hoy, noticias falsas", dice el cinco veces ganador del Balón de Oro a la cámara.
"Quieren promocionarse usando mi nombre.
Eso es normal.
Quieren ser famosos para decir mi nombre, pero es parte del trabajo.
Soy un hombre feliz y todo está bien", añadió el jugador, sonriendo.
Los abogados de Ronaldo se están preparando para demandar a Der Spiegel por las acusaciones, que han llamado "un informe inadmisible de sospechas en el área de la privacidad", según Reuters.
El abogado Christian Schertz dijo que el jugador buscaría una indemnización por "daños morales en una cantidad correspondiente a la gravedad de la infracción, que es probablemente una de las violaciones más graves de los derechos personales en los últimos años".
Se dice que el presunto incidente tuvo lugar en junio de 2009 en una suite del Palms Hotel and Casino en Las Vegas.
Después de reunirse en un club nocturno, Ronaldo y Mayorga supuestamente regresaron a la habitación del jugador, donde supuestamente la violó por vía anal, según documentos presentados en el Tribunal de Distrito del Condado de Clark en Nevada.
Mayorga afirma que Ronaldo cayó de rodillas después del supuesto incidente y le dijo que era "99 por ciento" un "buen tipo" defraudado por el "uno por ciento".
Los documentos afirman que Ronaldo confirmó que la pareja tuvo relaciones sexuales, pero que fue consensual.
Mayorga también afirma que fue a la policía y se hizo fotografiar sus heridas en un hospital, pero más tarde aceptó un acuerdo extrajudicial porque se sentía "aterrorizada por las represalias" y estaba preocupada por "ser humillada públicamente".
La mujer de 34 años dice que ahora está tratando de anular el acuerdo ya que continúa traumatizada por el supuesto incidente.
Ronaldo estaba a punto de unirse al Real Madrid desde el Manchester United en el momento del presunto ataque, y este verano se trasladó al gigante italiano Juve en un acuerdo de 100 millones de euros.
Brexit: Reino Unido 'arrepentiría para siempre' la pérdida de fabricantes de automóviles
El Reino Unido "se arrepentiría para siempre" si perdiera su estatus como líder mundial en la fabricación de automóviles después del Brexit, dijo el Secretario de Negocios Greg Clark.
Además, agregó que era "preocupante" que Toyota UK le hubiera dicho a la BBC que si Gran Bretaña abandonaba la UE sin un acuerdo suspendería temporalmente la producción en su fábrica de Burnaston, cerca de Derby.
"Necesitamos un trato", dijo el Sr. Clark.
El fabricante japonés de automóviles dijo que el impacto de los retrasos en la frontera en caso de un Brexit sin acuerdo podría costar empleos.
La planta de Burnaston, que fabrica los Auris y Avensis de Toyota, produjo el año pasado casi 150.000 automóviles, de los cuales el 90% fueron exportados al resto de la Unión Europea.
"Mi opinión es que si Gran Bretaña sale de la UE a finales de marzo veremos que la producción se detiene en nuestra fábrica", dijo Marvin Cooke, director gerente de Toyota en Burnaston.
Otros fabricantes de automóviles del Reino Unido han expresado temores de abandonar la UE sin un acuerdo sobre cómo funcionará el comercio transfronterizo, incluidos Honda, BMW y Jaguar Land Rover.
BMW, por ejemplo, dice que cerrará su planta Mini en Oxford por un mes después del Brexit.
Las principales preocupaciones se relacionan con lo que los fabricantes de automóviles dicen que son los riesgos de la cadena de suministro en caso de un Brexit sin acuerdo.
La línea de producción de Toyota se ejecuta sobre una base de "justo a tiempo", con piezas que llegan cada 37 minutos de proveedores tanto en el Reino Unido como en la UE para automóviles hechos a pedido.
Si el Reino Unido abandona la UE sin un acuerdo el 29 de marzo, podría haber interrupciones en la frontera que, según la industria, podrían conducir a retrasos y escasez de piezas.
Sería imposible para Toyota mantener más de un día de inventario en su planta de Derbyshire, dijo la compañía, y por lo tanto la producción se detendría.
El Sr. Clark dijo que el plan Chequers de Theresa May para las futuras relaciones con la UE está "calibrado con precisión para evitar esos controles en la frontera".
"Necesitamos hacer un trato. Queremos tener el mejor acuerdo que permita, como he dicho, no sólo disfrutar del éxito actual, sino también aprovechar esta oportunidad", dijo en el programa Today de la BBC Radio 4.
"La evidencia no sólo de Toyota sino de otros fabricantes es que necesitamos absolutamente ser capaces de continuar lo que ha sido un conjunto de cadenas de suministro de gran éxito".
Toyota no pudo decir cuánto tiempo se detendría la producción, pero a largo plazo, advirtió que los costos adicionales reducirían la competitividad de la planta y eventualmente costarían empleos.
Peter Tsouvallaris, que ha trabajado en Burnaston durante 24 años y es el coordinador del sindicato Unite en la planta, dijo que sus miembros están cada vez más preocupados: "Según mi experiencia, una vez que estos trabajos se van, nunca vuelven.
Un portavoz del gobierno dijo: "Hemos presentado un plan preciso y creíble para nuestra futura relación con la UE".
La reunión de Trump con Rosenstein puede retrasarse de nuevo, dice la Casa Blanca
La reunión de alto riesgo de Donald Trump con el fiscal general adjunto Rod Rosenstein podría "retrasarse otra semana" mientras continúa la pelea por el candidato a la Corte Suprema Brett Kavanaugh, dijo la Casa Blanca el domingo.
Rosenstein supervisa el trabajo del asesor especial Robert Mueller, que está investigando la interferencia rusa en las elecciones, los vínculos entre los asesores de Trump y Rusia y la posible obstrucción de la justicia por parte del presidente.
Si Trump despedirá o no al fiscal general adjunto, y por lo tanto pondrá en peligro la independencia de Mueller, ha alimentado chismes en Washington durante meses.
A principios de este mes, el New York Times informó que Rosenstein discutió el uso de un cable para grabar conversaciones con Trump y la posibilidad de destituir al presidente a través de la 25a enmienda.
Rosenstein negó el informe.
Pero el lunes pasado fue a la Casa Blanca, en medio de informes de que estaba a punto de renunciar.
En cambio, una reunión con Trump, que estaba entonces en las Naciones Unidas en Nueva York, fue anunciada para el jueves.
Trump dijo que "prefiere no" despedir a Rosenstein, pero luego la reunión se retrasó para evitar un choque con la audiencia del comité judicial del Senado en la que Kavanaugh y una de las mujeres que lo han acusado de mala conducta sexual, la doctora Christine Blasey Ford, testificaron.
El viernes, Trump ordenó una investigación de una semana del FBI de las acusaciones contra Kavanaugh, retrasando aún más la votación completa del Senado.
La secretaria de prensa de Trump, Sarah Sanders, apareció en Fox News el domingo.
Cuando se le preguntó sobre la reunión de Rosenstein, dijo: "No se ha fijado una fecha para eso, podría ser esta semana, podría ver que posponer otra semana dado todo lo demás que está sucediendo con la corte suprema.
Pero veremos y siempre me gusta mantener a la prensa al día".
Algunos periodistas cuestionarían esa afirmación: Sanders no ha celebrado una rueda de prensa en la Casa Blanca desde el 10 de septiembre.
El presentador Chris Wallace preguntó por qué.
Sanders dijo que la escasez de reuniones informativas no se debió a un disgusto por los reporteros de televisión "grandstand", aunque ella dijo: "No voy a estar en desacuerdo con el hecho de que ellos se destaquen".
Luego sugirió que el contacto directo entre Trump y la prensa aumentará.
"El presidente hace más sesiones de preguntas y respuestas que cualquier presidente antes de él", dijo, y agregó sin citar evidencia: "Hemos mirado esos números".
Las reuniones informativas todavía ocurrirán, dijo Sanders, pero "si la prensa tiene la oportunidad de hacer preguntas al presidente de los Estados Unidos directamente, eso es infinitamente mejor que hablar conmigo.
Intentamos hacer eso mucho y nos han visto hacer eso mucho en las últimas semanas y eso va a tomar el lugar de una rueda de prensa cuando se puede hablar con el presidente de los Estados Unidos".
Trump responde regularmente a preguntas cuando sale de la Casa Blanca o participa en sesiones abiertas o conferencias de prensa con dignatarios visitantes.
Las conferencias de prensa en solitario son raras.
En Nueva York esta semana el presidente tal vez demostró por qué, haciendo una aparición libre y a veces extraña ante los reporteros reunidos.
El secretario de Salud escribe a los trabajadores de la UE en el NHS de Escocia sobre los temores del Brexit
El Secretario de Salud ha escrito al personal de la UE que trabaja en el NHS de Escocia para expresar la gratitud del país y desear que permanezcan después del Brexit.
Jeane Freeman MSP envió una carta con menos de seis meses hasta que el Reino Unido se retire de la UE.
El Gobierno escocés ya se ha comprometido a cubrir el coste de las solicitudes de estatus de residente permanente para los ciudadanos de la UE que trabajan en sus servicios públicos descentralizados.
En su carta, la Sra. Freeman escribió: "Durante el verano, las negociaciones entre el Reino Unido y la UE sobre la retirada han continuado, con vistas a las decisiones esperadas este otoño.
Pero el Gobierno del Reino Unido también ha intensificado sus preparativos para un posible escenario sin acuerdo.
Sé que este debe ser un momento muy inquietante para todos ustedes.
Por eso quise reiterar ahora cuánto valoro la contribución de cada miembro del personal, independientemente de su nacionalidad.
Los colegas de toda la UE, y más allá, aportan una valiosa experiencia y habilidades que fortalecen y mejoran el trabajo del servicio de salud, y benefician a los pacientes y a las comunidades a las que servimos.
Escocia es absolutamente su hogar y queremos que se quede aquí".
Christion Abercrombie se somete a una cirugía de emergencia después de sufrir una lesión en la cabeza
El linebacker de los Tigres del estado de Tennessee, Christion Abercrombie, se sometió a una cirugía de emergencia después de sufrir una lesión en la cabeza en la derrota del sábado 31-27 ante los Commodores de Vanderbilt, informó Mike Organ del Tennessean.
El entrenador en jefe del estado de Tennessee, Rod Reed, dijo a los periodistas que la lesión ocurrió poco antes del descanso.
"Llegó a la línea lateral y se derrumbó allí", dijo Reed.
Los entrenadores y el personal médico le dieron oxígeno a Abercrombie en la línea lateral antes de colocarlo en una camilla y llevarlo de vuelta para una mayor evaluación.
Un funcionario del estado de Tennessee le dijo a Chris Harris de WSMV en Nashville, Tennessee, que Abercrombie estaba fuera de cirugía en el Centro Médico Vanderbilt.
Harris agregó que "todavía no hay detalles sobre el tipo / extensión de la lesión" y el estado de Tennessee está tratando de averiguar cuándo ocurrió la lesión.
Abercrombie, un estudiante de segundo año de camiseta roja, está en su primera temporada con Tennessee State después de transferirse de Illinois.
Tuvo cinco tackles totales el sábado antes de salir del juego, lo que elevó su total de la temporada a 18 tackles.
A los compradores extranjeros se les cobrará un impuesto de timbre más alto cuando compren una propiedad en el Reino Unido
A los compradores extranjeros se les cobrará un impuesto de timbre más alto cuando compren una propiedad en el Reino Unido con el dinero extra utilizado para ayudar a los sin techo bajo los nuevos planes de los conservadores.
El movimiento neutralizará el éxito de la campaña de Corbyn para atraer a votantes jóvenes.
El aumento del impuesto de timbre se aplicará a los que no pagan impuestos en el Reino Unido.
El Tesoro espera recaudar hasta 120 millones de libras al año para ayudar a las personas sin hogar.
A los compradores extranjeros se les cobrará una tasa de impuesto de timbre más alta cuando compren propiedades en el Reino Unido, con el dinero extra utilizado para ayudar a los sin techo, anunció hoy Theresa May.
La medida se verá como un intento de neutralizar el éxito de la campaña de Jeremy Corbyn para atraer a los votantes jóvenes con promesas de proporcionar viviendas más asequibles y dirigirse a los altos ingresos.
El aumento del impuesto de timbre se aplicará a las personas y empresas que no pagan impuestos en el Reino Unido, y el dinero adicional impulsará el esfuerzo del Gobierno para combatir el sueño intenso.
El recargo, que se suma al actual impuesto de timbre, incluidos los niveles más elevados introducidos hace dos años en las segundas viviendas y las casas de alquiler, podría ascender hasta el 3%.
El Tesoro espera que el movimiento recaude hasta 120 millones de libras al año.
Se estima que el 13 por ciento de las propiedades de nueva construcción en Londres son compradas por residentes no británicos, lo que eleva los precios y dificulta que los compradores por primera vez puedan poner un pie en la escalera de la vivienda.
Muchas zonas ricas del país - especialmente en la capital - se han convertido en "ciudades fantasmas" debido al gran número de compradores extranjeros que pasan la mayor parte de su tiempo fuera del país.
La nueva política se produce pocas semanas después de que Boris Johnson pidiera un recorte en el impuesto de timbre para ayudar a más jóvenes a tener su primera casa.
Acusó a las grandes empresas constructoras de mantener altos los precios de las propiedades al acaparar tierras pero no usarlas, e instó a la Sra. May a abandonar las cuotas de viviendas asequibles para arreglar la "desgracia de la vivienda" de Gran Bretaña.
El Sr. Corbyn ha anunciado una serie de llamativas reformas de vivienda propuestas, incluidos los controles de alquileres y el fin de los desalojos "sin culpa".
También quiere dar a los consejos mayores poderes para construir nuevas casas.
La Sra. May dijo: "El año pasado dije que dedicaría mi mandato a restablecer el sueño británico: que la vida debería ser mejor para cada nueva generación.
Y eso significa arreglar nuestro mercado inmobiliario roto.
Gran Bretaña siempre estará abierta a las personas que quieran vivir, trabajar y construir una vida aquí.
Sin embargo, no puede ser correcto que sea tan fácil para las personas que no viven en el Reino Unido, así como para las empresas con sede en el extranjero, comprar viviendas como para los residentes británicos que trabajan duro.
Para demasiadas personas el sueño de tener su propia casa se ha vuelto demasiado lejano, y la indignidad de dormir en el suelo se mantiene muy real".
Jack Ross: "Mi mayor ambición es entrenar a Escocia"
El entrenador del Sunderland, Jack Ross, dice que su "ambición final" es convertirse en el entrenador de Escocia en algún momento.
El escocés, de 42 años, está disfrutando el desafío de revivir el club del noreste, que actualmente se encuentra en el tercer lugar de la Liga Uno, a tres puntos de la cima.
Se mudó al Estadio de la Luz este verano después de guiar a St Mirren de regreso a la Premier League escocesa la temporada pasada.
"Quería jugar para mi país como jugador.
Obtuve un B cap y eso fue todo", dijo Ross a BBC Scotland's Sportsound.
"Pero crecí viendo mucho Escocia en Hampden con mi padre cuando era niño, y siempre es algo que me ha traído de vuelta.
Sin embargo, esa oportunidad solo vendría si tenía éxito como gerente del club".
Los predecesores de Ross como entrenador del Sunderland incluyen a Dick Advocaat, David Moyes, Sam Allardyce, Martin O'Neill, Roy Keane, Gus Poyet y Paulo Di Canio.
El ex jefe del Alloa Athletic dice que no sentía temor en seguir a nombres tan establecidos en un club tan grande, habiendo rechazado previamente ofertas de Barnsley e Ipswich Town.
"El éxito para mí en este momento se medirá por '¿Puedo regresar a este club a la Premier League?'
Debido a la estructura y las instalaciones de este club, sin duda pertenece a la Premier League", dijo.
"No es una tarea fácil conseguirlo, pero probablemente solo me consideraría exitoso aquí si puedo conseguir que el club vuelva allí".
Ross solo lleva tres años en su carrera como gerente, después de un período como jefe asistente en Dumbarton y un período de 15 meses en el personal de entrenadores de Hearts.
Luego ayudó a Alloa a recuperarse del descenso a la tercera división, y transformó a St Mirren del borde del descenso a ganadores del título del Campeonato la temporada siguiente.
Y Ross dice que se siente más cómodo ahora que nunca durante su carrera jugando en Clyde, Hartlepool, Falkirk, St Mirren y Hamilton Academical.
"Probablemente fue una verdadera encrucijada", recordó, al hacerse cargo de Alloa.
"Realmente creía que manejar era lo mejor para mí, más que jugar.
Suena extraño porque lo hice bien, gané una buena vida con eso, y disfruté de unos altos razonables.
Pero jugar puede ser difícil.
Hay muchas cosas que tienes que hacer semanalmente.
Todavía paso por eso en términos del estrés y la presión del trabajo pero la gerencia simplemente se siente bien.
Siempre quise manejar y ahora lo estoy haciendo, me siento más cómoda en mi propia piel a lo largo de toda mi vida adulta".
Puede escuchar la entrevista completa en Sportsound el domingo 30 de septiembre, en Radio Scotland entre las 12:00 y las 13:00 BST
La hora perfecta para una pinta es a las 5:30 pm de un sábado, encuesta encuentra
La ola de calor del verano ha aumentado los ingresos de los pubs de Gran Bretaña, pero ha aumentado la presión sobre las cadenas de restaurantes.
Los grupos de pubs y bares vieron que las ventas aumentaron un 2,7 por ciento en julio, pero las ventas en los restaurantes cayeron un 4,8 por ciento, según las cifras.
Peter Martin, de la consultora de negocios CGA, que recopiló las cifras, dijo: "El sol continuo y la participación de Inglaterra en la Copa del Mundo más larga de lo esperado significaron que julio siguió un patrón similar al mes anterior de junio, cuando los pubs subieron un 2,8 por ciento, excepto que los restaurantes fueron golpeados aún más.
La caída del 1,8 por ciento en el comercio de restaurantes en junio empeoró en julio.
Los pubs y bares con bebidas alcohólicas se desempeñaron con mucho más fuertes, con un aumento más que los restaurantes.
Los pubs de comida también sufrieron en el sol, aunque no tan dramáticamente como los operadores de restaurantes.
Parece que la gente sólo quería salir a tomar una copa.
En todos los pubs y bares gestionados las ventas de bebidas subieron un 6,6 por ciento durante el mes, mientras que la comida disminuyó un tres por ciento".
Paul Newman, de los analistas de ocio y hospitalidad RSM dijo: "Estos resultados continúan la tendencia que hemos visto desde finales de abril.
El clima y el impacto de grandes eventos sociales o deportivos siguen siendo los factores más importantes en lo que respecta a las ventas en el mercado exterior.
No es de extrañar que los grupos de restaurantes sigan luchando, aunque una caída de las ventas del 4,8 por ciento interanual será particularmente dolorosa además de las continuas presiones de costos.
El largo y caluroso verano no podría haber llegado en un peor momento para los operadores de alimentos y el tiempo dirá si las temperaturas más moderadas que hemos experimentado en agosto proporcionarán un respiro muy necesario".
El crecimiento total de las ventas en pubs y restaurantes, incluidas las nuevas aperturas, fue del 2,7 por ciento en julio, lo que refleja la desaceleración en el despliegue de marcas.
El monitoreo de ventas de la industria Coffer Peach Tracker para el sector de los pubs, bares y restaurantes del Reino Unido recopila y analiza datos de rendimiento de 47 grupos operativos, con un volumen de negocios combinado de más de 9 mil millones de libras esterlinas, y es el punto de referencia establecido de la industria.
Uno de cada cinco niños tiene cuentas secretas en las redes sociales que ocultan a sus padres.
Una encuesta revela que uno de cada cinco niños, algunos de tan solo 11 años, tiene cuentas secretas en redes sociales que ocultan a sus padres y maestros
Una encuesta de 20.000 estudiantes de secundaria reveló un crecimiento en las páginas "falsas" de Insta
La noticia ha aumentado los temores de que se esté publicando contenido sexual
El 20% de los alumnos dijeron que tenían una cuenta "principal" para mostrar a los padres
Uno de cada cinco niños, algunos de tan solo 11 años, está creando cuentas en redes sociales que mantienen en secreto de los adultos.
Una encuesta de 20.000 estudiantes de secundaria reveló un rápido crecimiento en las cuentas "falsas de Insta" - una referencia al sitio de intercambio de fotos Instagram.
La noticia ha aumentado los temores de que se esté publicando contenido sexual.
El veinte por ciento de los alumnos dijeron que operan una cuenta "principal" desinfectada para mostrar a los padres, mientras que también tienen otras privadas.
Una madre que encontró por casualidad el sitio web secreto de su hija de 13 años encontró a un adolescente instando a otros a "violarizarme".
La investigación, realizada por Digital Awareness UK y la Conferencia de Directores de Escuelas Independientes (HMC, por sus siglas en inglés), encontró que el 40 por ciento de los niños de 11 a 18 años tenían dos perfiles, y la mitad de ellos admitieron tener cuentas privadas.
El jefe de HMC, Mike Buchanan, dijo: "Es inquietante que tantos adolescentes estén tentados a crear espacios en línea donde los padres y maestros no puedan encontrarlos".
Eilidh Doyle será "la voz de los atletas" en la junta de Atletismo Escocés
Eilidh Doyle ha sido elegida miembro de la junta directiva de Scottish Athletics como directora no ejecutiva en la reunión general anual del órgano rector.
Doyle es la atleta de atletismo más condecorada de Escocia y el presidente Ian Beattie describió el movimiento como una gran oportunidad para que quienes guían el deporte se beneficien de su amplia experiencia a nivel internacional durante la última década.
"Eilidh tiene un enorme respeto en toda la comunidad atlética escocesa, del Reino Unido y del mundo y estamos seguros de que el atletismo en Escocia se beneficiaría enormemente al incluirla en la junta", dijo Beattie.
Doyle dijo: "Estoy ansioso por actuar como voz de los atletas y espero poder realmente contribuir y ayudar a guiar el deporte en Escocia".
El estadounidense, que ganó los 200 metros y 400 metros en los Juegos de 1996 en Atlanta entre su total de cuatro medallas de oro olímpicas y ahora es un experto regular de la BBC, quedó incapaz de caminar después de sufrir un ataque isquémico transitorio.
Escribió en Twitter: "Hoy hace un mes sufrí un derrame cerebral.
No podía caminar.
Los médicos dijeron que solo el tiempo dirá si me recuperaré o en qué grado.
Ha sido un trabajo agotador pero se ha recuperado completamente, ha vuelto a aprender a caminar y hoy hace ejercicios de agilidad.
¡Gracias por los mensajes de aliento!"
El anuncio de la bomba materna que compara a las madres con las vacas divide la opinión en línea
Una compañía de bombas mamarias ha dividido la opinión en línea con un anuncio que compara a las madres lactantes con las vacas ordeñadas.
Para conmemorar el lanzamiento de lo que se dice que es la "primera protuberancia mamaria portátil silenciosa del mundo", la compañía de tecnología de consumo Elvie lanzó un anuncio inspirado en un video musical para mostrar la libertad que la nueva bomba da a las madres que se expresan.
Cuatro madres de verdad bailan en un establo de vacas lleno de heno a una canción que incluye letras como: "Sí, me ordeño, pero no ves ninguna cola" y "En caso de que no lo hayas notado, no son ubres, son mis tetas".
El coro continúa: "Pump it out, pump it out, estoy alimentando a esos bebés, pump it out, pump it out, estoy ordeñando a mis damas".
Sin embargo, el anuncio, que ha sido publicado en la página de Facebook de la empresa, ha causado controversia en línea.
Con 77.000 visitas y cientos de comentarios, el video ha recibido reacciones mixtas de los espectadores, con muchos diciendo que pone de relieve los "horrores" de la industria láctea.
"Muy mala decisión usar vacas para anunciar este producto.
Al igual que nosotros, necesitan quedar embarazadas y dar a luz para producir leche, excepto que sus bebés se les roban a los pocos días de haber dado a luz", escribió uno.
La bomba mamaria de Elvie encaja discretamente dentro de un sujetador de amamantamiento (Elvie/madre)
Otro comentó: "Comprensiblemente traumático tanto para la madre como para el bebé.
Pero sí, ¿por qué no usarlos para anunciar una bomba de leche para madres que se quedan con sus bebés?"
Otra persona añadió: "Un anuncio tan desactualizado".
Otros defendieron el anuncio, y una mujer admitió que la canción le pareció "hilarante".
"Creo que esta es una idea genérica.
Habría tenido uno si todavía estuviera amamantando.
El bombeo me hizo sentir exactamente como una vaca.
El anuncio es un poco loco pero lo tomé por lo que era.
Este es un producto genial", escribió uno.
Otro comentó: "Este es un anuncio divertido dirigido a madres que bombean (a menudo en sus lugares de trabajo o en los inodoros) y se sienten como "vacas".
Este no es un anuncio que elogia o juzga a la industria láctea".
Al final del video el grupo de mujeres revelan que todos han estado bailando con las bombas discretas metidas en sus sujetadores.
El concepto detrás de la campaña se basa en la idea de que muchas mujeres que se amamantan dicen que se sienten como vacas.
La bomba Elvie, sin embargo, es completamente silenciosa, no tiene cables ni tubos y cabe discretamente dentro de un sujetador de lactancia, dando a las mujeres la libertad de moverse, sostener a sus bebés e incluso salir mientras bombean.
Ana Balarin, socio y ECD de Mother, comentó: "La bomba Elvie es un producto tan revolucionario que merecía un lanzamiento audaz y provocativo.
Al trazar un paralelo entre las mujeres que expresan y las vacas lecheras queríamos poner el bombeo de mama y todos sus desafíos en el centro de atención, al tiempo que demostramos de una manera entretenida y relacionable la increíble sensación de libertad que traerá la nueva bomba.
Esta no es la primera vez que la bomba Elvie ha aparecido en los titulares.
Durante la Semana de la Moda de Londres, una madre de dos apareció en la pasarela de la diseñadora Marta Jakubowski mientras usaba el producto.
Cientos de niños inmigrantes se trasladan tranquilamente a un campamento de tiendas de campaña en la frontera de Texas
El número de niños migrantes detenidos se ha disparado a pesar de que los cruces fronterizos mensuales se han mantenido relativamente sin cambios, en parte porque la dura retórica y las políticas introducidas por la administración Trump han dificultado la colocación de niños con patrocinadores.
Tradicionalmente, la mayoría de los patrocinadores han sido ellos mismos inmigrantes indocumentados, y han temido poner en peligro su propia capacidad de permanecer en el país al avanzar para reclamar un hijo.
El riesgo aumentó en junio, cuando las autoridades federales anunciaron que los posibles patrocinadores y otros miembros adultos de sus hogares tendrían que presentar huellas dactilares y que los datos se compartirían con las autoridades de inmigración.
La semana pasada, Matthew Albence, un alto funcionario de Inmigración y Control de Aduanas, testificó ante el Congreso que la agencia había arrestado a docenas de personas que solicitaron el patrocinio de menores no acompañados.
Más tarde, la agencia confirmó que el 70 por ciento de los arrestados no tenían antecedentes penales.
"Casi el 80 por ciento de las personas que son patrocinadores o miembros del hogar de los patrocinadores están aquí en el país ilegalmente, y una gran parte de ellos son extranjeros criminales.
Así que seguimos persiguiendo a esos individuos", dijo el Sr. Albence.
Buscando procesar a los niños más rápidamente, los funcionarios introdujeron nuevas reglas que requerirán que algunos de ellos comparezcan ante el tribunal dentro de un mes de haber sido detenidos, en lugar de después de 60 días, que era el estándar anterior, según los trabajadores del refugio.
Muchos aparecerán a través de videoconferencia, en lugar de en persona, para alegar su caso de estatus legal ante un juez de inmigración.
Aquellos que sean considerados inelegibles para el alivio serán deportados rápidamente.
Cuanto más tiempo permanecen los niños bajo custodia, mayor es la probabilidad de que se sientan ansiosos o deprimidos, lo que puede llevar a arrebatos violentos o intentos de fuga, según los trabajadores del refugio y los informes que han surgido del sistema en los últimos meses.
Los defensores dijeron que esas preocupaciones aumentan en una instalación más grande como Tornillo, donde los signos de que un niño está luchando son más propensos a ser pasados por alto, debido a su tamaño.
Añadieron que trasladar a los niños a la ciudad de tiendas de campaña sin darles suficiente tiempo para prepararse emocionalmente o para despedirse de sus amigos podría agravar el trauma con el que muchos ya están luchando.
Siria le dice a las "fuerzas de ocupación" estadounidenses, francesas y turcas que se retiren inmediatamente.
Dirigiéndose a la Asamblea General de la ONU, el Ministro de Relaciones Exteriores Walid al-Moualem también pidió a los refugiados sirios que regresen a casa, a pesar de que la guerra del país está ahora en su octavo año.
Moualem, quien también se desempeña como viceprimer ministro, dijo que las fuerzas extranjeras estaban en suelo sirio ilegalmente, bajo el pretexto de luchar contra el terrorismo, y "serán tratadas en consecuencia".
"Deben retirarse inmediatamente y sin ninguna condición", dijo a la asamblea.
Moualem insistió en que la "guerra contra el terrorismo está casi terminada" en Siria, donde más de 360.000 personas han muerto desde 2011, con millones más desplazadas de sus hogares.
Dijo que Damasco continuará "luchando esta batalla sagrada hasta que limpiemos todos los territorios sirios" de ambos grupos terroristas y "cualquier presencia extranjera ilegal".
Estados Unidos tiene unos 2.000 soldados en Siria, principalmente entrenando y asesorando tanto a las fuerzas kurdas como a los árabes sirios que se oponen al presidente Bashar al-Assad.
Francia tiene más de 1.000 soldados en el terreno en el país devastado por la guerra.
Sobre el tema de los refugiados, Moualem dijo que las condiciones eran buenas para que regresaran, y culpó a "algunos países occidentales" por "difundir temores irracionales" que llevaron a los refugiados a mantenerse alejados.
"Hemos pedido a la comunidad internacional y a las organizaciones humanitarias que faciliten estos retornos", dijo.
"Están politizando lo que debería ser un asunto puramente humanitario".
Estados Unidos y la Unión Europea han advertido que no habrá ayuda para la reconstrucción de Siria hasta que haya un acuerdo político entre Assad y la oposición para poner fin a la guerra.
Los diplomáticos de la ONU dicen que un reciente acuerdo entre Rusia y Turquía para establecer una zona de amortiguación en el último gran bastión rebelde de Idlib ha creado una oportunidad para avanzar con las conversaciones políticas.
El acuerdo ruso-turco evitó un ataque a gran escala de las fuerzas sirias respaldadas por Rusia en la provincia, donde viven tres millones de personas.
Moualem, sin embargo, enfatizó que el acuerdo tenía "fechas límite claras" y expresó la esperanza de que la acción militar se dirija a los yihadistas, incluidos los combatientes del Frente Nusra vinculado a Al Qaeda, que "serán erradicados".
El enviado de la ONU Staffan de Mistura espera convocar pronto las primeras reuniones de un nuevo comité compuesto por miembros del gobierno y de la oposición para redactar una constitución de posguerra para Siria y allanar el camino a las elecciones.
Moualem estableció condiciones para la participación del gobierno sirio en el comité, diciendo que el trabajo del panel debería limitarse a "revisar los artículos de la Constitución actual", y advirtió contra la interferencia.
Por qué Trump ganará un segundo mandato
Por esa lógica, el Sr. Trump ganaría la reelección en 2020 a menos que, como muchos espectadores liberales probablemente esperan, el juicio político y el escándalo terminen su presidencia prematuramente.
En lo que sin duda sería "El final más dramático de una presidencia nunca!"
A partir de ahora, no hay signos de fatiga del espectador.
Desde 2014, las audiencias en horario estelar se han más que duplicado a 1,05 millones en CNN y casi se han triplicado a 1,6 millones en MSNBC.
Fox News tiene un promedio de 2.4 millones de espectadores en horario estelar, un aumento de 1.7 millones hace cuatro años, según Nielsen, y "The Rachel Maddow Show" de MSNBC ha encabezado las calificaciones de cable con hasta 3.5 millones de espectadores en las noches de noticias principales.
"Este es un fuego al que la gente se siente atraída porque no es algo que entendemos", dijo Neal Baer, presentador del drama de ABC "Designated Survivor", sobre un secretario de gabinete que se convierte en presidente después de que un ataque destruye el Capitolio.
Nell Scovell, una veterana escritora de comedias y autora de "Just the Funny Parts: And a Few Hard Truths About Sneaking Into the Hollywood Boys" Club", tiene otra teoría.
Ella recuerda un viaje en taxi en Boston antes de las elecciones de 2016.
El conductor le dijo que votaría por el Sr. Trump.
- ¿Por qué? - ¿Por qué? Ella me preguntó.
Me dijo: "Porque me hace reír", me dijo la Srta. Scovell.
Hay un valor de entretenimiento en el caos.
Por supuesto, a diferencia de cualquier otra cosa en la televisión, las líneas de la historia que vienen de Washington podrían determinar el futuro de Roe v. Wade, si las familias de inmigrantes pueden reunirse y la salud de la economía global.
Estar desconectado es un lujo que sólo los espectadores más privilegiados pueden permitirse.
Y sin embargo, va más allá de ser un ciudadano informado cuando te encuentras en la hora seis de ver a un panel de expertos debatir el uso de Bob Woodward de "sourcing de fondo profundo" para su libro "Fear," La chaqueta de bombarderos de piel de avestruz de $15,000 de Paul Manafort ("una prenda gruesa de arrogancia", dijo el Washington Post) y las implicaciones de las espeluznantes descripciones de Stormy Daniels de la anatomía del Sr. Trump.
Yo, por ejemplo, nunca volveré a mirar a Super Mario de la misma manera.
"Parte de lo que hace que parezca un reality show es que te da algo cada noche," dijo Brent Montgomery, director ejecutivo de Wheelhouse Entertainment y creador de "Pawn Stars", sobre el reparto rotativo del programa de Trump y los giros diarios de la trama (elegir una pelea con la NFL, elogiando a Kim Jong-un).
No puedes permitirte perder un episodio o te quedarás atrás.
Cuando llegué al Sr. Fleiss esta semana, hacía 80 grados de sol afuera de su casa en la costa norte de Kauai, pero estaba encerrado dentro viendo MSNBC mientras grababa CNN.
No podía alejarse, no con Brett Kavanaugh enfrentado al Comité Judicial del Senado y el futuro de la Corte Suprema en juego.
"Recuerdo cuando estábamos haciendo todos esos espectáculos locos y la gente decía: 'Este es el comienzo del fin de la civilización occidental'", me dijo el Sr. Fleiss.
"Pensé que era una especie de broma, pero resulta que tenían razón".
Amy Chozick, una escritora para The Times que cubre negocios, política y medios, es la autora de las memorias "Chasing Hillary".
El dinero del exterior inunda las elecciones de mitad de período más apretadas
No es de extrañar que el distrito 17 de Pensilvania esté viendo una avalancha de efectivo, gracias a una realineación de los distritos del Congreso que llevó a dos titulares en una carrera por el mismo asiento.
Este recientemente rediseñado distrito suburbano de Pittsburg enfrenta al representante demócrata Conor Lamb, quien ganó su escaño en otro distrito en una elección especial la primavera pasada.
Lamb está compitiendo contra otro titular, el republicano Keith Rothfus, que actualmente representa el antiguo distrito 12 de Pensilvania, que se superpone en gran medida con el nuevo 17.
Los mapas fueron rediseñados después de que la Corte Suprema de Pensilvania dictaminara en enero que los antiguos distritos fueron manipulados inconstitucionalmente a favor de los republicanos.
La carrera en el nuevo 17th ha dado inicio a una disputa de finanzas de campaña entre los principales brazos financieros del partido, el Comité de Campaña Demócrata del Congreso (DCCC) y el Comité Nacional de Campaña Republicano (NRCC).
Lamb se convirtió en un nombre familiar en Pensilvania después de una estrecha victoria en una elección especial ampliamente observada en marzo para el Distrito 18 del Congreso de Pensilvania.
Ese escaño había sido ocupado por un republicano durante más de una década, y el presidente Donald Trump ganó el distrito por 20 puntos.
Los expertos políticos han dado a los demócratas una ligera ventaja.
EE.UU. consideró penalizar a El Salvador por apoyar a China, luego se retractó
Los diplomáticos señalaron que la República Dominicana y Panamá ya habían reconocido a Pekín, con poco rechazo de Washington.
El Sr. Trump tuvo una cálida reunión con el presidente Juan Carlos Varela de Panamá en junio de 2017 y tuvo un hotel en Panamá hasta que los socios desalojaron al equipo directivo de la Organización Trump.
Funcionarios del Departamento de Estado decidieron llamar a los jefes de misiones diplomáticas estadounidenses de El Salvador, la República Dominicana y Panamá sobre las "decisiones recientes de no reconocer más a Taiwán", dijo Heather Nauert, portavoz del departamento, en un comunicado a principios de este mes.
Pero solo se consideraron sanciones contra El Salvador, que recibió una ayuda estadounidense estimada en 140 millones de dólares en 2017, incluidos los controles de narcóticos, el desarrollo y el apoyo económico.
Las sanciones propuestas, que incluían recortes en la ayuda financiera y restricciones específicas de visados, habrían sido dolorosas para el país centroamericano y sus altas tasas de desempleo y homicidios.
A medida que las reuniones internas progresaban, Las autoridades norteamericanas y centroamericanas pospusieron una conferencia de alto nivel centrada en la seguridad y la prosperidad económica para dar seguimiento a una reunión similar el año pasado que fue vista como un paso adelante en los esfuerzos para evitar que los migrantes se dirijan a los Estados Unidos.
Pero a mediados de septiembre, altos funcionarios de la administración dejaron en claro que querían que la conferencia siguiera adelante, poniendo fin efectivamente a cualquier consideración de sanciones para El Salvador.
El vicepresidente Mike Pence ahora está programado para dirigirse a la conferencia, ahora programada para mediados de octubre, en una señal de la importación que la administración coloca en la reunión, dijeron los diplomáticos.
Y los tres enviados estadounidenses regresaron silenciosamente a El Salvador, Panamá y la República Dominicana sin nuevos mensajes duros o castigos de Washington.
Un portavoz de la Casa Blanca para el Sr. Bolton se negó a comentar los detalles del debate que fueron descritos por los tres funcionarios estadounidenses, incluidos dos diplomáticos, que acordaron discutir las deliberaciones internas bajo condición de anonimato.
Sus relatos fueron corroborados por un analista externo que está cerca de la administración y también habló bajo condición de anonimato.
Estudio de la historia
El próximo caso podría ser el informe del abogado especial Robert Mueller sobre la posible obstrucción de la justicia del Sr. Trump, de la cual ahora hay pruebas muy sustanciales en el registro público.
Según los informes, el Sr. Mueller también está dirigiendo su investigación a si la campaña del Sr. Trump conspiró con Rusia en su ataque a nuestras elecciones.
Si el Congreso cambia de manos, el Sr. Trump se encontrará ante la responsabilidad en ese cuerpo, justo cuando se prepara para presentarse nuevamente ante los votantes, y tal vez eventualmente ante un jurado de sus pares.
Eso es mucho si, y no quiero sugerir que la caída del Sr. Trump sea inevitable, ni la de sus equivalentes en Europa.
Hay decisiones que todos debemos tomar a ambos lados del Atlántico que afectarán la duración de la lucha.
En 1938, los oficiales alemanes estaban listos para organizar un golpe de estado contra Hitler, si sólo Occidente le hubiera resistido y apoyado a los checoslovacos en Munich.
Fracasamos, y perdimos una oportunidad para evitar los años de carnicería que siguieron.
El curso de la historia gira en torno a tales puntos de inflexión, y la marcha inexorable de la democracia se acelera o retrasa.
Los estadounidenses se enfrentan a varios de estos puntos de inflexión ahora.
¿Qué haremos si el Sr. Trump despide al Fiscal General Adjunto Rod Rosenstein, el hombre que controla el destino de la investigación del Sr. Mueller?
Rosenstein ha estado en agua caliente desde que este periódico informó que, el año pasado, sugirió grabar secretamente al presidente y especuló sobre su incapacidad para el cargo.
El Sr. Rosenstein dice que el relato del Times es inexacto.
"¿Cómo responderemos si la recientemente solicitada investigación del FBI sobre Brett Kavanaugh no es completa ni justa - o si es confirmado en la Corte Suprema a pesar de acusaciones creíbles de agresión sexual y testimonio deshonesto?
Y sobre todo, ¿votaremos en las elecciones de mitad de período por un Congreso que haga que el Sr. Trump rinda cuentas?
Si fracasamos en esas pruebas, la democracia pasará un largo invierno.
Pero creo que no fallaremos, por la lección que aprendí en Praga.
Mi madre era judía checoslovaca que fue deportada a Auschwitz por el mismo régimen nazi que una vez ocupó mi casa de embajador.
Ella sobrevivió, emigró a América y, 60 años después, me envió a encender velas de sábado en esa mesa con la esvástica.
Con eso como mi herencia, ¿cómo no ser optimista acerca de nuestro futuro?"
Norman Eisen, investigador principal de la Brookings Institution, es el presidente de Ciudadanos por la Responsabilidad y la Ética en Washington y el autor de "El último palacio: el siglo turbulento de Europa en cinco vidas y una casa legendaria".
Graham Dorrans de los Rangers optimista antes del choque con el Rapid de Viena
Los Rangers recibirán al Rapid Vienna el jueves, sabiendo que la victoria sobre los austriacos, después del impresionante empate en España contra el Villarreal a principios de este mes, los pondrá en una posición fuerte para clasificarse del Grupo G de la Liga Europa.
Una lesión en la rodilla impidió que el mediocampista Graham Dorrans hiciera su primera aparición de la temporada hasta el empate 2-2 con el Villarreal, pero cree que los Rangers pueden usar ese resultado como un trampolín para grandes cosas.
"Fue un buen punto para nosotros porque el Villarreal es un buen equipo", dijo el jugador de 31 años.
"Entramos en el juego creyendo que podíamos conseguir algo y salimos con un punto.
Tal vez podríamos haberlo robado al final pero, en general, un empate fue probablemente un resultado justo.
Probablemente fueron mejores en la primera mitad y salimos en la segunda mitad y fuimos el lado mejor.
Al llegar el jueves, es otra gran noche europea.
Con suerte, podemos conseguir tres puntos pero será un juego difícil porque tuvieron un buen resultado en su último juego pero, con la multitud detrás de nosotros, estoy seguro de que podemos seguir adelante y obtener un resultado positivo.
El año pasado fue definitivamente duro, entre todo lo que pasó con mis lesiones y los cambios en el propio club pero hay un factor de sensación de bienestar sobre el lugar ahora.
El equipo es bueno y los chicos lo están disfrutando; el entrenamiento es bueno.
Con suerte, podemos seguir adelante ahora, dejar atrás la temporada pasada y ser exitosos".
Las mujeres están perdiendo el sueño por este miedo a los ahorros de jubilación.
A pesar de que los participantes en la encuesta tenían una idea clara de cómo querían ser atendidos, pocas personas hablaban de ello con sus familiares.
Alrededor de la mitad de las personas en el estudio nacional dijeron que estaban hablando con sus cónyuges sobre el costo de los cuidados a largo plazo.
Sólo el 10 por ciento dijo que habló con sus hijos al respecto.
"La gente quiere que un miembro de la familia cuide de ellos, pero no están tomando las medidas necesarias para tener la conversación", dijo Holly Snyder, vicepresidenta del negocio de seguros de vida de Nationwide.
Aquí es donde empezar.
Hable con su cónyuge y con los hijos: No puede preparar a su familia para atender si no hace saber sus deseos con suficiente antelación.
Trabaje con su asesor y su familia para discutir dónde y cómo recibir atención, ya que esas opciones pueden ser un factor importante en la determinación del costo.
Lleve a su asesor financiero: Su asesor también puede ayudarle a encontrar una manera de pagar esos gastos.
Sus opciones de financiamiento para el cuidado a largo plazo pueden incluir una póliza de seguro de cuidado a largo plazo tradicional, una póliza de seguro de vida híbrida de valor en efectivo para ayudar a cubrir estos gastos o autoasegurarse con su propia riqueza, siempre y cuando tenga el dinero.
Prepara tus documentos legales, evita las batallas legales en el paso.
Consigue un representante de atención médica para que designe a una persona de confianza para supervisar su atención médica y asegurarse de que los profesionales cumplan con sus deseos en caso de que no pueda comunicarse.
Además, considere un poder legal para sus finanzas.
Usted elegiría a una persona de confianza para tomar decisiones financieras por usted y asegurarse de que sus cuentas sean pagadas si usted es incapacitado.
No olvide los pequeños detalles: Imagínese que su anciano padre tiene una emergencia médica y está en camino al hospital.
¿Podría responder preguntas sobre medicamentos y alergias?
Escribe esos detalles en un plan escrito para que estés listo.
"¿No son sólo las finanzas las que están en juego, sino quiénes son los médicos?", preguntó Martin.
"¿Cuáles son los medicamentos?
¿Quién cuidará del perro?
Tenga ese plan en su lugar".
Un hombre recibió varios disparos con un rifle de aire en Ilfracombe .
Un hombre ha recibido varios disparos con un rifle de aire mientras caminaba a casa después de una noche de fiesta.
La víctima, de unos 40 años, estaba en el área de Oxford Grove de Ilfracombe, Devon, cuando le dispararon en el pecho, el abdomen y la mano.
Los oficiales describieron el tiroteo, que tuvo lugar alrededor de las 02:30 BST, como un "acto aleatorio".
La víctima no vio a su atacante.
Sus heridas no son mortales y la policía ha pedido testigos.
Terremotos y tsunamis en Indonesia
Al menos 384 personas han muerto por un poderoso terremoto y tsunami que azotó la ciudad indonesia de Palu el viernes, dijeron las autoridades, y se espera que la cifra de muertos aumente.
Con las comunicaciones apagadas, los funcionarios de ayuda no han podido obtener ninguna información de la regencia de Donggala, un área al norte de Palu que está más cerca del epicentro del terremoto de magnitud 7.5.
En Palu, más de 16.000 personas fueron evacuadas después del desastre.
He aquí algunos hechos clave sobre Palu y Donggala, en la isla de Sulawesi:
Palu es la capital de la provincia de Sulawesi Central, ubicada al final de una estrecha bahía en la costa oeste de la isla de Sulawesi, con una población estimada de 379.800 en 2017.
La ciudad estaba celebrando su 40 aniversario cuando el terremoto y el tsunami golpearon.
Donggala es una regencia que se extiende a lo largo de más de 300 km (180 millas) de costa en el noroeste de la isla de Sulawesi.
La regencia, una región administrativa por debajo de una provincia, tenía una población estimada de 299.200 en 2017.
La pesca y la agricultura son los pilares de la economía de la provincia de Sulawesi Central, especialmente la región costera de Donggala.
La minería de níquel también es importante en la provincia, pero se concentra principalmente en Morowali, en la costa opuesta de Sulawesi.
Palu y Donggala han sido golpeadas por tsunamis varias veces en los últimos 100 años, según la Agencia de Mitigación de Desastres de Indonesia.
En 1938, un tsunami mató a más de 200 personas y destruyó cientos de casas en Donggala.
Un tsunami también azotó el oeste de Donggala en 1996, matando a nueve.
Indonesia se encuentra en el anillo de fuego sísmico del Pacífico y es regularmente golpeada por terremotos.
Estos son algunos de los grandes terremotos y tsunamis de los últimos años:
2004: Un gran terremoto en la costa occidental de la provincia indonesia de Aceh en el norte de Sumatra el 26 de diciembre provocó un tsunami que azotó 14 países, matando a 226.000 personas a lo largo de la costa del Océano Índico, más de la mitad de ellas en Aceh.
2005: A finales de marzo y principios de abril, una serie de fuertes terremotos azotaron la costa occidental de Sumatra.
Cientos murieron en la isla de Nias, frente a la costa de Sumatra.
2006: Un terremoto de magnitud 6,8 golpeó al sur de Java, la isla más poblada de Indonesia, provocando un tsunami que azotó la costa sur, matando a casi 700 personas.
2009: Un terremoto de magnitud 7,6 se produce cerca de la ciudad de Padang, capital de la provincia de Sumatra Occidental.
Más de 1.100 personas murieron.
2010: Un terremoto de magnitud 7.5 golpeó una de las islas Mentawai, frente a Sumatra, provocando un tsunami de hasta 10 metros que destruyó docenas de aldeas y mató a unas 300 personas.
2016: Un terremoto superficial golpeó la regencia de Pidie Jaya en Aceh, causando destrucción y pánico mientras la gente recordaba la devastación del mortal terremoto y tsunami de 2004.
Esta vez no se produjo ningún tsunami, pero más de 100 murieron por los edificios derrumbados.
2018: Grandes terremotos azotan la isla turística de Lombok en Indonesia, matando a más de 500 personas, en su mayoría en el lado norte de la isla.
El terremoto destruyó miles de edificios y dejó temporalmente varados a miles de turistas.
El hijo mayor de Sarah Palin arrestado por cargos de violencia doméstica
Track Palin, el hijo mayor de la ex gobernadora de Alaska y candidata a la vicepresidencia Sarah Palin, ha sido arrestado por cargos de agresión.
Palin, de 29 años, de Wasilla, Alaska, fue arrestada bajo sospecha de violencia doméstica, interferir con un informe de violencia doméstica y resistirse al arresto, según un informe publicado el sábado por la Policía Estatal de Alaska.
Según el informe policial, cuando una mujer conocida intentó llamar a la policía para denunciar los presuntos crímenes, él le quitó su teléfono.
Palin está detenida en Mat-Su Pre-Trial Facility y está retenida bajo una fianza de $500 sin garantía, informó KTUU.
Apareció en la corte el sábado, donde se declaró "no culpable, seguro" cuando se le preguntó su declaración de culpabilidad, informó la red.
Palin enfrenta tres delitos menores de clase A, lo que significa que podría ser encarcelado por hasta un año y multado con $250,000.
También ha sido acusado de un delito menor de clase B, castigado con un día de cárcel y una multa de $2,000.
No es la primera vez que se presentan cargos criminales contra Palin.
En diciembre de 2017, fue acusado de agredir a su padre, Todd Palin.
Su madre, Sarah Palin, llamó a la policía para denunciar el presunto ataque.
El caso está actualmente ante el Tribunal de Veteranos de Alaska.
En enero de 2016 fue acusado de agresión doméstica, interferencia en el informe de un delito de violencia doméstica y posesión de un arma mientras estaba intoxicado en relación con el incidente.
Su novia había alegado que él la golpeó en la cara.
Sarah Palin fue criticada por grupos de veteranos en 2016 después de vincular el comportamiento violento de su hijo con el trastorno de estrés postraumático derivado de su servicio en Irak.
Terremoto y tsunami en Indonesia: cientos de muertos
Al menos 384 personas han muerto después de que un terremoto azotara la isla indonesia de Sulawesi el viernes.
El terremoto de magnitud 7,5 provocó un tsunami y ha destruido miles de hogares.
La electricidad y las redes de comunicación están caídas y se espera que las muertes aumenten en los próximos días.
El terremoto golpeó justo en el centro de Sulawesi que está al noreste de la capital de Indonesia, Yakarta.
Los videos están circulando en las redes sociales mostrando el momento del impacto.
Cientos de personas se habían reunido para una fiesta en la playa en la ciudad de Palu cuando el tsunami azotó la costa.
Los fiscales federales buscan la rara pena de muerte para el sospechoso del ataque terrorista de Nueva York .
Los fiscales federales en Nueva York buscan la pena de muerte para Sayfullo Saipov, el sospechoso del ataque terrorista en la ciudad de Nueva York que mató a ocho personas. Un castigo raro que no se ha llevado a cabo en el estado por un crimen federal desde 1953.
Saipov, de 30 años, supuestamente usó un camión de alquiler de Home Depot para llevar a cabo un ataque en un sendero para bicicletas a lo largo de la autopista West Side en Lower Manhattan, matando a peatones y ciclistas en su camino en octubre.
Para justificar una sentencia de muerte, Los fiscales tendrán que probar que Saipov "intencionalmente" mató a las ocho víctimas y "intencionalmente" infligió lesiones corporales graves, según el aviso de intención de buscar la pena de muerte, presentado en el Distrito Sur de Nueva York.
Ambos cargos conllevan una posible sentencia de muerte, según el documento judicial.
Semanas después del ataque, Un gran jurado federal acusó a Saipov con una acusación de 22 cargos que incluía ocho cargos de asesinato con fines de extorsión, típicamente utilizados por los fiscales federales en casos de crimen organizado, y un cargo de violencia y destrucción de vehículos motorizados.
El ataque requirió "planificación y premeditación sustanciales", dijeron los fiscales, describiendo la forma en que Saipov lo llevó a cabo como "abominable, cruel y depravado".
"Sayfullo Habibullaevic Saipov causó lesiones, daño, y pérdida a las familias y amigos de Diego Enrique Angelini, Nicholas Cleves, Ann-Laure Decadt, Darren Drake, Ariel Erlij, Hernan Ferruchi, Hernan Diego Mendoza, y Alejandro Damian Pagnucco", dice el aviso de intención.
Cinco de las víctimas eran turistas de Argentina.
Ha pasado una década desde la última vez que el Distrito Sur de Nueva York procesó un caso de pena de muerte.
El acusado, Khalid Barnes, fue condenado por el asesinato de dos proveedores de drogas, pero finalmente fue condenado a cadena perpetua en septiembre de 2009.
La última vez que se ejecutó la pena de muerte en un caso federal de Nueva York fue en 1953 para Julius y Ethel Rosenberg, una pareja casada ejecutada después de haber sido condenados por conspiración para cometer espionaje para la Unión Soviética durante la Guerra Fría dos años antes.
Ambos Rosenberg fueron ejecutados por la silla eléctrica el 19 de junio de 1953.
Saipov, originario de Uzbekistán, demostró una falta de remordimiento en los días y meses posteriores al ataque, según documentos judiciales.
Declaró a los investigadores que se sentía bien por lo que había hecho, dijo la policía.
Saipov dijo a las autoridades que se inspiró para llevar a cabo el ataque después de ver videos de ISIS en su teléfono, según la acusación.
También solicitó exhibir la bandera de ISIS en su habitación del hospital, dijo la policía.
Se ha declarado inocente de los 22 cargos.
David Patton, uno de los defensores públicos federales que representan a Saipov, dijo que están "obviamente decepcionados" con la decisión de la fiscalía.
"Creemos que la decisión de buscar la pena de muerte en lugar de aceptar una declaración de culpabilidad a cadena perpetua sin posibilidad de liberación solo prolongará el trauma de estos eventos para todos los involucrados", dijo Patton.
El equipo de defensa de Saipov había pedido previamente a los fiscales que no buscaran la pena de muerte.
El diputado conservador dice que NIGEL FARAGE debería estar a cargo de las negociaciones del Brexit
Nigel Farage prometió "movilizar el ejército del pueblo" hoy durante una protesta en la conferencia conservadora.
El ex líder del Ukip dijo que los políticos tenían que "sentir el calor" de los euroescépticos, ya que uno de los propios diputados de Theresa May sugirió que debería estar a cargo de las negociaciones con la UE.
El diputado conservador Peter Bone dijo a la marcha en Birmingham que el Reino Unido "habría salido" ya si el Sr. Farage fuera el Secretario del Brexit.
Pero el desafío al que se enfrenta la señora May para reconciliar sus filas profundamente divididas ha sido subrayado por los conservadores pro-Remain que se unen a una protesta separada contra el Brexit en la ciudad.
La primera ministra está luchando para mantener su plan de compromiso de Chequers en el camino en medio de los ataques de los partidarios del Brexit, los partidarios de la permanencia y la UE.
Los aliados insistieron en que seguirá adelante con el intento de llegar a un acuerdo con Bruselas a pesar de la reacción violenta, y obligará a los euroescépticos y los laboristas a elegir entre su paquete y el "caos".
El Sr. Bone dijo a la manifestación Leave Means Leave en Solihull que quería "sacar a Chequers".
El Sr. Farage debería haber sido nombrado par y haber recibido la responsabilidad de las negociaciones con Bruselas.
'Si él hubiera estado a cargo, ya estaríamos fuera', dijo.
El diputado de Wellingborough añadió: "Me pondré de pie para el Brexit, pero tenemos que tirar Chequers".
Al exponer su oposición a la UE, dijo: "No luchamos en las guerras mundiales para ser serviles.
Queremos hacer nuestras propias leyes en nuestro propio país'.
El Sr. Bone rechazó las sugerencias de que la opinión pública había cambiado desde la votación de 2016: "La idea de que el pueblo británico ha cambiado de opinión y quiere permanecer es completamente falsa".
Andrea Jenkyns, partidaria conservadora del Brexit, también estuvo en la marcha, diciendo a los periodistas: "Simplemente estoy diciendo: Primer Ministro, escuche al pueblo.
'Chequers es impopular con el público en general, la oposición no va a votar por él, es impopular con nuestro partido y nuestros activistas que en realidad golpean las calles y nos hacen elegir en primer lugar.
Por favor, deja de jugar a las damas y empieza a escuchar".
En un mensaje directo a la Sra. May, añadió: "Los primeros ministros mantienen sus puestos de trabajo cuando cumplen sus promesas".
El Sr. Farage dijo a los manifestantes que se debe hacer que los políticos "sientan el calor" si están a punto de traicionar la decisión tomada en el referéndum de 2016.
"Ahora se trata de una cuestión de confianza entre nosotros, el pueblo, y nuestra clase política", dijo.
"Están tratando de traicionar al Brexit y estamos aquí hoy para decirles que no les dejaremos salirse con la suya".
En un mensaje dirigido a la entusiasta multitud añadió: "Quiero que hagan sentir el calor a nuestra clase política, que está a punto de traicionar al Brexit.
"Estamos movilizando el ejército popular de este país que nos dio la victoria en el Brexit y nunca descansará hasta que nos hayamos convertido en un Reino Unido independiente, autónomo y orgulloso".
Mientras tanto, los Remainers marcharon por Birmingham antes de celebrar una manifestación de dos horas en el centro de la ciudad.
Un puñado de activistas ondearon pancartas de los conservadores contra el Brexit después del lanzamiento del grupo este fin de semana.
El colega laborista Lord Adonis se burló de los conservadores por los problemas de seguridad que sufrieron con una aplicación del partido cuando se abrió la conferencia.
"Estas son las personas que nos dicen que pueden tener los sistemas de TI en su lugar y toda la tecnología para Canadá más más, para la frontera sin fricciones, para el libre comercio sin fronteras en Irlanda", agregó.
Es una completa farsa.
No hay tal cosa como un buen Brexit", añadió.
Warren planea echar un 'duro vistazo' a su candidatura a la presidencia
La senadora estadounidense Elizabeth Warren dice que pondrá "una mirada dura a postularse para presidente" después de las elecciones de noviembre.
El Boston Globe informa que la demócrata de Massachusetts habló sobre su futuro durante un ayuntamiento en el oeste de Massachusetts el sábado.
Warren, un crítico frecuente del presidente Donald Trump, se postula para la reelección en noviembre contra el representante estatal republicano Geoff Diehl, quien fue copresidente de la campaña de Trump en Massachusetts en 2016.
Ella ha estado en el centro de la especulación de que podría enfrentarse a Trump en 2020.
El evento del sábado por la tarde en Holyoke fue su reunión número 36 con los electores usando el formato del ayuntamiento desde que Trump asumió el cargo.
Un asistente le preguntó si planeaba postularse para presidente.
Warren respondió que es hora de que "las mujeres vayan a Washington para arreglar nuestro gobierno roto, y eso incluye a una mujer en la cima".
Arrestado por matar a tiros a los Sims de la LSU.
La policía de Baton Rouge, Louisiana, anunció el sábado que un sospechoso ha sido arrestado en el asesinato por disparos del jugador de baloncesto de la LSU Wayde Sims el viernes.
El Departamento de Policía de Baton Rouge anunció el arresto de Dyteon Simpson, de 20 años, a las 11 a.m. Conferencia de prensa.
Habían publicado un video del tiroteo el viernes, pidiendo ayuda para identificar a un hombre visto en el metraje.
Sims, de 20 años, fue asesinado a tiros cerca del campus de la Universidad del Sur el viernes por la mañana.
"Wayde Sims sufrió una herida de bala en la cabeza y finalmente murió como resultado", dijo el jefe de policía Murphy J. Paul a los medios de comunicación el sábado, según 247sports.
Wayde intervino para defender a su amigo y Simpson le disparó.
Simpson fue interrogado y admitió estar en la escena, en posesión de un arma, y admitió haber disparado a Wayde Sims.
Simpson fue arrestado sin incidentes y puesto bajo custodia en el Departamento de Policía de East Baton Rouge.
Un junior de 6 pies y 6 pulgadas que creció en Baton Rouge, Sims jugó en 32 juegos con 10 aperturas la temporada pasada y promedió 17.4 minutos, 5.6 puntos y 2.9 rebotes por juego.
Gran Premio de Rusia: Lewis Hamilton se acerca al título mundial después de que las órdenes del equipo le dieran la victoria sobre Sebastian Vettel
Desde el momento en que Valtteri Bottas se clasificó delante de Lewis Hamilton el sábado, quedó claro que las órdenes del equipo de Mercedes jugarían un papel importante en la carrera.
Desde la pole, Bottas tuvo un buen comienzo y casi dejó a Hamilton a secar mientras defendía su posición en las dos primeras curvas e invitó a Vettel a atacar a su compañero de equipo.
Vettel entró en boxes primero y dejó a Hamilton para correr en el tráfico en la cola de la manada, algo que debería haber sido decisivo.
El Mercedes entró en boxes una vuelta más tarde y salió detrás de Vettel, pero Hamilton avanzó después de una acción de rueda a rueda que vio al piloto de Ferrari dejar a regañadientes el interior libre en riesgo de resistir después de un doble movimiento para defender en la tercera curva.
Max Verstappen comenzó desde la última fila de la parrilla y estaba séptimo al final de la primera vuelta en su cumpleaños número 21.
Luego lideró durante gran parte de la carrera mientras se aferraba a sus neumáticos para apuntar a un final rápido y adelantar a Kimi Raikkonen en cuarto lugar.
Finalmente entró en los boxes en la vuelta 44 pero no pudo aumentar su ritmo en las ocho vueltas restantes ya que Raikkonen ocupó el cuarto lugar.
Es un día difícil porque Valtteri hizo un trabajo fantástico todo el fin de semana y fue un verdadero caballero que me dijo que pasara.
El equipo ha hecho un trabajo tan excepcional para tener un uno dos", dijo Hamilton.
Ese fue un lenguaje corporal muy malo.
El presidente Donald Trump se burló de la senadora Dianne Feinstein en un mitin el sábado por su insistencia en que no filtró la carta de Christine Blasey Ford acusando al candidato a la Corte Suprema Brett Kavanaugh de agresión sexual.
Hablando en un mitin en Virginia Occidental, el presidente no se refirió directamente al testimonio dado por Ford ante el Comité Judicial del Senado, sino que comentó que lo que estaba sucediendo en el Senado mostraba que la gente era "malvada y desagradable y falsa".
"La única cosa que podría suceder y la cosa hermosa que está sucediendo en los últimos días en el Senado, cuando ves la ira, cuando ves a personas que están enojadas y malas y desagradables y falsas", dijo.
"Cuando miras los lanzamientos y filtraciones y luego dicen "oh, no lo hice.
Yo no lo hice".
¿Te acuerdas?
Dianne Feinstein, ¿has filtrado algo?
Recuerde su respuesta... ¿Ha filtrado usted el documento - "oh, oh, qué?
Oh, no es así.
No he filtrado".
Bueno, espera un minuto.
¿Hemos filtrado...No, no filtramos", añadió, imitando al senador.
A Feinstein se le envió la carta detallando las acusaciones contra Kavanaugh por Ford en julio, y se filtró a principios de septiembre, pero Feinstein negó que la filtración proviniera de su oficina.
"No oculté las acusaciones de la Dra. Ford, no filtré su historia", dijo Feinstein al comité, informó The Hill.
"Ella me pidió que lo mantuviera confidencial y lo mantuve confidencial como ella me pidió".
Pero su negación no pareció estar bien con el presidente, quien comentó durante el mitin del sábado por la noche: "Te diré qué, ese fue un lenguaje corporal realmente malo.
Tal vez no, pero ese es el peor lenguaje corporal que he visto".
Continuando su defensa del candidato a la Corte Suprema, quien ha sido acusado de mala conducta sexual por tres mujeres, el presidente sugirió que los demócratas estaban usando las acusaciones para sus propios fines.
"Están decididos a recuperar el poder por cualquier medio necesario.
Ves la mezquindad, la maldad, no les importa a quién lastimen, a quién tienen que atropellar para obtener poder y control", informó Mediaite el presidente diciendo.
Liga de Élite: Estrellas de Dundee 5-3 Gigantes de Belfast
Patrick Dwyer marcó dos goles para los Gigantes contra Dundee.
Dundee Stars expió la derrota de la Liga de Élite del viernes contra los Gigantes de Belfast al ganar el partido de vuelta 5-3 en Dundee el sábado.
Los Gigantes obtuvieron una ventaja temprana de dos goles a través de huelgas de Patrick Dwyer y Francis Beauvillier.
Mike Sullivan y Jordan Cownie trajeron el nivel del lado de casa antes de que Dwyer restaurara la ventaja de los Gigantes.
Francois Bouchard empató para Dundee antes de que dos goles de Lukas Lundvald Nielsen aseguraran su victoria.
Fue la tercera derrota de la Liga de Élite de la temporada para los hombres de Adam Keefe, que habían llegado desde atrás para vencer a Dundee 2-1 en Belfast el viernes por la noche.
Fue el cuarto encuentro de la temporada entre las partes, con los Gigantes ganando los tres partidos anteriores.
La apertura de Dwyer llegó en el cuarto minuto a las 3:35 de una asistencia de Kendall McFaull, con David Rutherford proporcionando la asistencia cuando Beauvillier duplicó la ventaja cuatro minutos más tarde.
En lo que fue un período de apertura ocupado, Sullivan trajo al equipo local de nuevo al juego a las 13:10 antes de que Matt Marquardt se convirtiera en proveedor para el empate de Cownie a las 15:16.
Dwyer se aseguró de que los Gigantes tomaran la ventaja en el primer descanso cuando marcó su segundo gol de la noche al final del primer período.
El equipo local se reagrupó y Bouchard una vez más los puso en igualdad de condiciones con un gol de juego de poder en 27:37.
Cownie y Charles Corcoran se combinaron para ayudar a Nielsen a dar a Dundee la ventaja por primera vez en el partido a finales del segundo período y se aseguró de la victoria con el quinto gol de su equipo a la mitad del último período.
Los Gigantes, que ahora han perdido cuatro de sus últimos cinco partidos, están en casa contra Milton Keynes en su próximo partido el viernes.
Un controlador de tráfico aéreo muere para asegurar que cientos en el avión puedan escapar del terremoto
Un controlador de tráfico aéreo en Indonesia está siendo aclamado como un héroe después de que murió asegurando que un avión que transportaba cientos de personas despegara con seguridad del suelo.
Más de 800 personas han muerto y muchas están desaparecidas después de que un gran terremoto azotara la isla de Sulawesi el viernes, provocando un tsunami.
Fuertes réplicas continúan azotando la zona y muchos están atrapados entre los escombros en la ciudad de Palu.
Pero a pesar de que sus colegas huyeron para salvar sus vidas, Anthonius Gunawan Agung, de 21 años, se negó a abandonar su puesto en la torre de control en el aeropuerto de Palu.
Se quedó quieto para asegurarse de que el vuelo 6321 de Batik Air, que estaba en la pista de aterrizaje en ese momento, pudiera despegar con seguridad.
Luego saltó de la torre de control de tráfico cuando pensó que se estaba derrumbando.
Murió más tarde en el hospital.
El portavoz de la Navegación Aérea de Indonesia, Yohannes Sirait, dijo que la decisión puede haber salvado cientos de vidas, informó ABC News de Australia.
Preparamos un helicóptero desde Balikpapan en Kalimantan para llevarlo a un hospital más grande en otra ciudad.
Desafortunadamente lo perdimos esta mañana antes de que el helicóptero llegara a Palu.
"Nuestro corazón se rompe al escuchar esto", agregó.
Mientras tanto, las autoridades temen que el número de muertos pueda llegar a los miles con la agencia de mitigación de desastres del país diciendo que el acceso a las ciudades de Donggala, Sigi y Boutong es limitado.
"Se cree que el número de muertos sigue aumentando ya que muchos cuerpos todavía estaban bajo los restos mientras que muchos no han podido ser alcanzados", dijo el portavoz de la agencia Sutopo Purwo Nugroho.
Las olas que alcanzaron hasta seis metros han devastado Palu, donde se realizará un entierro masivo el domingo.
Aviones militares y comerciales están trayendo ayuda y suministros.
Risa Kusuma, una madre de 35 años, dijo a Sky News: "Cada minuto una ambulancia trae cuerpos.
El agua limpia es escasa.
Los mini-mercados están saqueados por todas partes".
Jan Gelfand, jefe de la Cruz Roja Internacional en Indonesia, dijo a CNN: "La Cruz Roja de Indonesia está corriendo para ayudar a los sobrevivientes, pero no sabemos qué encontrarán allí.
Esto ya es una tragedia, pero podría ser mucho peor".
El presidente de Indonesia, Joko Widodo, llegó a Palu el domingo y dijo a los militares del país: "Les pido a todos que trabajen día y noche para completar todas las tareas relacionadas con la evacuación.
¿Están listos?" Lo informó la CNN.
A principios de este año Indonesia fue golpeada por terremotos en Lombok en los que murieron más de 550 personas.
Accidente de avión en Micronesia: Air Niugini dice ahora que un hombre está desaparecido después del accidente de avión en la laguna
La aerolínea que opera un vuelo que se estrelló en una laguna del Pacífico en Micronesia ahora dice que un hombre está desaparecido, después de haber dicho anteriormente que todos los 47 pasajeros y tripulantes habían evacuado con seguridad el avión que se hundía.
Air Niugini dijo en un comunicado que a partir del sábado por la tarde, no podía dar cuenta de un pasajero masculino.
La aerolínea dijo que estaba trabajando con las autoridades locales, hospitales e investigadores para tratar de encontrar al hombre.
La aerolínea no respondió inmediatamente a las solicitudes de más detalles sobre el pasajero, como su edad o nacionalidad.
Los barcos locales ayudaron a rescatar a los otros pasajeros y tripulantes después de que el avión chocara contra el agua mientras intentaba aterrizar en el aeropuerto de la isla Chuuk.
Las autoridades dijeron el viernes que siete personas habían sido llevadas a un hospital.
La aerolínea dijo que seis pasajeros permanecieron en el hospital el sábado, y todos ellos estaban en condición estable.
Lo que causó el accidente y la secuencia exacta de los acontecimientos siguen sin estar claros.
La aerolínea y la Marina de EE.UU. ambos dijeron que el avión aterrizó en la laguna cerca de la pista.
Algunos testigos pensaron que el avión sobrepasó la pista.
El pasajero estadounidense Bill Jaynes dijo que el avión cayó muy bajo.
"Eso es muy bueno", dijo Jaynes.
Jaynes dijo que él y otros lograron vadear a través del agua hasta la cintura hasta las salidas de emergencia del avión que se hundía.
Dijo que las azafatas estaban en pánico y gritando, y que sufrió una lesión leve en la cabeza.
La Armada de EE.UU. dijo que los marineros que trabajaban cerca en la mejora de un muelle también ayudaron en el rescate mediante el uso de un bote inflable para llevar a la gente a la costa antes de que el avión se hundiera en unos 30 metros (100 pies) de agua.
Los datos de la Red de Seguridad Aérea indican que 111 personas han muerto en accidentes de aerolíneas registradas en PNG en las últimas dos décadas, pero ninguna involucró a Air Niugini.
El analista establece la línea de tiempo de la noche en que la mujer fue quemada viva.
La fiscalía descansó su caso el sábado en el nuevo juicio de un hombre que está acusado de quemar viva a una mujer de Mississippi en 2014.
El analista del Departamento de Justicia de EE.UU. Paul Rowlett testificó durante horas como un testigo experto en el campo del análisis de inteligencia.
Explicó al jurado cómo usó registros de teléfonos celulares para unir los movimientos del acusado de 29 años, Quinton Tellis y la víctima de 19 años, Jessica Chambers, la noche de su muerte.
Rowlett dijo que recibió datos de ubicación de varios teléfonos celulares que mostraban que Tellis estaba con Chambers la noche de su muerte, contradiciendo sus afirmaciones anteriores, informó The Clarion Ledger .
Cuando los datos mostraron que su celular estaba con Chambers durante el tiempo que dijo que estaba con su amigo Michael Sanford, la policía fue a hablar con Sanford.
Sanford tomó el estrado el sábado y testificó que no estaba en la ciudad ese día.
Cuando los fiscales preguntaron si Tellis decía la verdad cuando dijo que estaba en el camión de Sanford esa noche, Sanford dijo que estaba "mintiendo, porque mi camión estaba en Nashville".
Otra inconsistencia fue que Tellis dijo que había conocido a Chambers durante unas dos semanas cuando murió.
Los registros de teléfonos móviles indicaban que sólo se conocían desde hace una semana.
Rowlett dijo que en algún momento después de la muerte de Chambers, Tellis borró los mensajes de texto, llamadas y información de contacto de Chambers de su teléfono.
"La borró de su vida", dijo Hale.
La defensa está programada para comenzar sus argumentos finales el domingo.
El juez dijo que esperaba que el juicio fuera al jurado más tarde ese día.
The High Breed: ¿Qué es el hip hop consciente?
Un trío de hip hop quiere desafiar la visión negativa del género llenando su música con mensajes positivos.
The High Breed, de Bristol, afirman que el hip hop se alejó de sus orígenes de mensajes políticos y abordar temas sociales.
Quieren volver a sus raíces y hacer que el hip hop consciente vuelva a ser popular.
Artistas como The Fugees y Common han visto un resurgimiento reciente en el Reino Unido a través de artistas como Akala y Lowkey.
¿Otra persona negra?
La niñera de Nueva York demanda a una pareja por despedirla después de un mensaje "racista"
Una niñera de Nueva York está demandando a una pareja por despido discriminatorio después de recibir un mensaje de texto mal dirigido de la madre quejándose de que ella era "otra persona negra".
La pareja niega que sean racistas, comparando la demanda con "extorsión".
Lynsey Plasco-Flaxman, madre de dos hijos, expresó consternación al descubrir que la nueva proveedora de cuidado infantil, Giselle Maurice, era negra al llegar a su primer día de trabajo en 2016.
"NOOOOOOOOOOOO Otra persona negra", escribió la Sra. Plasco-Flaxman a su marido en un mensaje de texto.
Sin embargo, en lugar de enviarlo a su marido, se lo envió a la Srta. Maurice, dos veces.
Después de darse cuenta de su falta, un "incómodo" Plasco-Flaxman despidió a la Srta. Maurice, afirmando que su niñera saliente, que era afroamericana, había hecho un mal trabajo y que en su lugar estaba esperando a un filipino, según el New York Post.
A la Srta. Maurice se le pagó por un día de trabajo y luego la enviaron a casa por un Uber.
Ahora, Maurice está demandando a la pareja por una compensación por el despido, y está buscando una compensación de 350 dólares al día por el concierto de seis meses que inicialmente había sido contratada para hacer, aunque sin contrato.
"Quiero mostrarles, mira, no haces cosas así", le dijo al Post el viernes, y agregó: "Sé que es discriminación".
La pareja ha respondido a las afirmaciones de que son racistas, diciendo que terminar el empleo de Maurice era lo más razonable, temiendo que no pudieran confiar en ella después de ofenderla.
"Mi esposa le había enviado algo que no quería decir.
Ella no es racista.
No somos racistas", dijo el esposo Joel Plasco al Post.
"Pero, ¿dejarías a tus hijos en manos de alguien a quien has sido grosero, aunque sea por error?
¿Su bebé recién nacido?
¡Vamos ahora!"
Comparando la demanda con "extorsión", Plasco dijo que a su esposa le faltaban solo dos meses para tener un bebé y que estaba en una "situación muy difícil".
"¿Vas a perseguir a alguien así?
Eso no es una cosa muy agradable de hacer", añadió el banquero de inversiones.
Mientras el caso legal aún está en curso, el tribunal de opinión pública se ha apresurado a denunciar a la pareja en las redes sociales, criticándolos por su comportamiento y lógica.
Los editores de Paddington temían que los lectores no se relacionaran con un oso que habla, revela una nueva carta.
La hija de Bond, Karen Jankel, que nació poco después de que el libro fuera aceptado, dijo sobre la carta: "Es difícil ponerse en el lugar de alguien que lo lee por primera vez antes de que sea publicado.
Es muy divertido saber ahora lo que sabemos sobre el gran éxito de Paddington".
Diciendo a su padre, que había trabajado como camarógrafo de la BBC antes de ser inspirado para escribir el libro infantil por un pequeño oso de juguete, habría sido optimista acerca de que su trabajo fuera rechazado, agregó que el 60 aniversario de la publicación del libro fue "agridulce" después de su muerte el año pasado.
De Paddington, a quien describe como un "miembro muy importante de nuestra familia", agregó que su padre estaba silenciosamente orgulloso de su eventual éxito.
"Era un hombre bastante tranquilo, y no era una persona jactanciosa", dijo ella.
"Pero debido a que Paddington era tan real para él, era casi como si tuvieras un hijo que lograra algo: te enorgulleces de él aunque no sea realmente por tu culpa.
Creo que él veía el éxito de Paddington de esa manera.
Aunque fue su creación y su imaginación, siempre le daba el crédito al propio Paddington".
Mi hija se estaba muriendo y tuve que despedirme por teléfono.
Al aterrizar su hija había sido trasladada de urgencia al Hospital Louis Pasteur 2 de Niza, donde los médicos trabajaron en vano para salvar su vida.
"Nad llamaba con regularidad para decir que estaba muy mal, que no se esperaba que lo hiciera", dijo la Sra. Ednan-Laperouse.
"Entonces recibí la llamada de Nad para decir que iba a morir en los próximos dos minutos y tuve que despedirme de ella.
Y lo hice.
Le dije: "Tashi, te quiero mucho, cariño.
Estaré con ustedes pronto.
Estaré con usted.
Los medicamentos que los médicos le habían dado para mantener su corazón bombeando se estaban agotando lentamente y saliendo de su sistema.
Ella había muerto algún tiempo antes de la mano y esto era todo el cierre.
Tenía que sentarme allí y esperar, sabiendo que todo esto se estaba desarrollando.
No podía aullar ni gritar ni llorar porque estaba en una situación rodeada de familias y personas.
Tenía que aguantarme".
Finalmente, la señora Ednan-Laperouse, ahora afligida por la pérdida de su hija, subió al avión junto con los otros pasajeros, ajenos a la terrible experiencia que estaba atravesando.
"Nadie lo sabía", dijo.
"Tenía la cabeza baja y lloraba todo el tiempo.
Es difícil de explicar, pero fue en el vuelo que sentí esta abrumadora sensación de simpatía por Nad.
Que necesitaba mi amor y comprensión.
Sabía lo mucho que la amaba".
Mujeres en duelo envían tarjetas para prevenir suicidios en puentes
Dos mujeres que perdieron seres queridos por suicidio trabajan para evitar que otros se suiciden.
Sharon Davis y Kelly Humphreys han estado colgando tarjetas en un puente galés con mensajes inspiradores y números de teléfono a los que la gente puede llamar para pedir apoyo.
El hijo de la Srta. Davis, Tyler, tenía 13 años cuando comenzó a sufrir depresión y se suicidó a los 18.
"No quiero que ningún padre se sienta como yo tengo que sentirme todos los días", dijo.
Davis, de 45 años, que vive en Lydney, dijo que su hijo era un prometedor chef con una sonrisa contagiosa.
"Todo el mundo lo conocía por su sonrisa.
Siempre decían que su sonrisa iluminaba cualquier habitación".
Sin embargo, dejó de trabajar antes de morir, ya que estaba "en un lugar muy oscuro".
En 2014, el hermano de Tyler, que tenía 11 años en ese momento, fue el que encontró a su hermano después de haberse quitado la vida.
La Sra. Davis dijo: "Me preocupa continuamente que vaya a haber un efecto de golpe".
La Sra. Davis creó las tarjetas, "para que la gente sepa que hay personas por ahí a las que puedes ir y hablar, incluso si es un amigo.
No te quedes en silencio, tienes que hablar".
La Sra. Humphreys, que ha sido amiga de la Sra. Davies durante años, perdió a Mark, su compañero de 15 años, poco después de la muerte de su madre.
"No dijo que se sintiera deprimido o deprimido ni nada", dijo ella.
"Un par de días antes de Navidad notamos un cambio en su actitud.
Estaba en el fondo el día de Navidad - cuando los niños abrían sus regalos no hizo contacto visual con ellos o nada".
Ella dijo que su muerte fue un gran trauma para ellos, pero que tienen que trabajar para superarlo: "Esto rompe un agujero en la familia.
Nos está separando.
Pero todos tenemos que seguir adelante y luchar".
Si usted está luchando para hacer frente, puede llamar a Samaritans gratis al 116 123 (Reino Unido e Irlanda), enviar un correo electrónico a jo@samaritans.org, o visitar el sitio web de Samaritans aquí.
El futuro de Brett Kavanaugh está en juego mientras el FBI comienza la investigación.
"Pensé: si realmente pudiéramos conseguir algo como lo que él estaba pidiendo - una investigación limitada en el tiempo, El Consejo de Ministros de Asuntos Exteriores y de Asuntos Exteriores de la Unión Europea (UE) ha aprobado una propuesta de resolución de la Comisión de Asuntos Exteriores y de Asuntos Exteriores de la Unión Europea (UE) sobre la aplicación de las disposiciones del Tratado de la Unión Europea (TUE) relativas a la protección de los derechos humanos y de las libertades fundamentales de los ciudadanos de la Unión Europea (UE).
¿Por qué el Sr. Kavanaugh y sus partidarios republicanos no querían que el FBI investigara?
Su renuencia se debe a la sincronización.
A solo cinco semanas de las elecciones de mitad de período, el 6 de noviembre, si, como se esperaba, los republicanos lo hacen mal, entonces estarán severamente debilitados en sus intentos de conseguir que el hombre que quieren sea elegido para la corte más alta del país.
George W. Bush ha estado tomando el teléfono para llamar a los senadores, presionándolos para apoyar al Sr. Kavanaugh, que trabajó en la Casa Blanca para el Sr. Bush y a través de él conoció a su esposa Ashley, que era la secretaria personal del Sr. Bush.
¿Qué pasa después de que el FBI produzca su informe?
Habrá una votación en el Senado, donde 51 republicanos y 49 demócratas se sientan actualmente.
Todavía no está claro si el Sr. Kavanaugh puede conseguir al menos 50 votos en el Senado, lo que permitiría a Mike Pence, el vicepresidente, romper un empate y confirmarlo en la Corte Suprema.
El número de desertores de Corea del Norte 'cae' bajo Kim
El número de desertores norcoreanos a Corea del Sur ha disminuido desde que Kim Jong-un llegó al poder hace siete años, dijo un legislador surcoreano.
Park Byeong-seug, citando datos del Ministerio de Unificación del Sur, dijo que hubo 1.127 deserciones el año pasado, en comparación con 2.706 en 2011.
El Sr. Park dijo que los controles fronterizos más estrictos entre Corea del Norte y China y las tasas más altas cobradas por los traficantes de personas fueron factores clave.
Pyongyang no ha hecho comentarios públicos.
A la gran mayoría de los desertores del Norte finalmente se les ofrece la ciudadanía surcoreana.
Seúl dice que más de 30.000 norcoreanos han cruzado ilegalmente la frontera desde el final de la Guerra de Corea en 1953.
La mayoría huye a través de China, que tiene la frontera más larga con Corea del Norte y es más fácil de cruzar que la Zona Desmilitarizada (DMZ) fuertemente protegida entre las dos Coreas.
China considera a los desertores como migrantes ilegales en lugar de refugiados y a menudo los repatria por la fuerza.
Las relaciones entre el Norte y el Sur, que todavía están técnicamente en guerra, han mejorado notablemente en los últimos meses.
A principios de este mes, los líderes de los dos países se reunieron en Pyongyang para conversaciones que se centraron en las estancadas negociaciones de desnuclearización.
Esto se produjo después de la histórica reunión de junio entre el presidente estadounidense Donald Trump y Kim Jong-un en Singapur, cuando acordaron en términos generales trabajar hacia una península coreana libre de armas nucleares.
Pero el sábado, el ministro de Relaciones Exteriores de Corea del Norte, Ri Yong-ho, culpó a las sanciones estadounidenses por la falta de progreso desde entonces.
"Sin ninguna confianza en Estados Unidos, no habrá confianza en nuestra seguridad nacional y en tales circunstancias, no hay manera de que nos desarmemos unilateralmente primero", dijo Ri en un discurso ante la Asamblea General de la ONU en Nueva York.
Nancy Pelosi llama a Brett Kavanaugh "histérico", dice que no es apto para servir en la Corte Suprema
La líder de la minoría de la Cámara Nancy Pelosi llamó al candidato a la Corte Suprema Brett Kavanaugh "histérico" y dijo que era temperamentalmente inadecuado para servir en la Corte Suprema.
Pelosi hizo los comentarios en una entrevista el sábado en el Festival Texas Tribune en Austin, Texas.
"No pude evitar pensar que si alguna vez una mujer hubiera actuado de esa manera, dirían 'histérica'", dijo Pelosi sobre su reacción al testimonio de Kavanaugh ante el Comité Judicial del Senado el jueves.
Kavanaugh negó emocionalmente las acusaciones de que había agredido sexualmente a la doctora Christine Blasey Ford cuando ambos eran adolescentes.
Durante su discurso de apertura, Kavanaugh fue muy emotivo, a veces casi gritando y ahogándose mientras hablaba de su familia y sus años de secundaria.
También condenó explícitamente a los demócratas en el comité, calificando las acusaciones contra él de un "grotesco y coordinado asesinato de carácter" organizado por liberales enojados porque Hillary Clinton perdió las elecciones presidenciales de 2016.
Pelosi dijo que creía que el testimonio de Kavanaugh demostró que no podía servir en la Corte Suprema, porque mostraba que estaba sesgado contra los demócratas.
"Creo que se descalifica a sí mismo con esas declaraciones y la forma en que atacó a los Clinton y los demócratas", dijo.
Pelosi objetó cuando se le preguntó si trataría de destituir a Kavanaugh si es confirmado, y si los demócratas ganan la mayoría en la Cámara de Representantes.
"Voy a decir esto... si no está diciendo la verdad al Congreso o al FBI, entonces no es apto no solo para estar en la Corte Suprema, sino para estar en la corte en la que está ahora", dijo Pelosi.
Kavanaugh es actualmente juez de la Corte de Apelaciones del Circuito de D.C.
Pelosi agregó que como demócrata estaba preocupada por posibles fallos de Kavanaugh contra la Ley de Cuidado de Salud Asequible o Roe v. Wade, ya que es considerado un juez conservador.
En sus audiencias de confirmación, Kavanaugh esquivó preguntas sobre si revocaría ciertas decisiones de la Corte Suprema.
"No es el momento para que una persona histérica y sesgada vaya a la corte y espere que digamos: '¿No es maravilloso?'", dijo Pelosi.
Y las mujeres necesitan manejarlo.
Es una diatriba justa, meses y años de furia derramándose, y ella no puede expresarla sin llorar.
"Lloramos cuando estamos enojados", me dijo la Sra. Steinem 45 años después.
"No creo que eso sea raro, ¿verdad?"
Ella continuó: "Me ayudó mucho una mujer que era ejecutiva en algún lugar, que dijo que también lloraba cuando se enojaba, pero desarrolló una técnica que significaba que cuando se enojaba y comenzaba a llorar, le decía a la persona con la que estaba hablando, "Puedes pensar que estoy triste porque estoy llorando.
Estoy enojado".
Y luego siguió adelante.
Y pensé que eso era genial".
Las lágrimas son permitidas como una descarga de ira en parte porque son fundamentalmente malentendidas.
Uno de mis recuerdos más claros de un trabajo temprano, en una oficina dominada por hombres, donde una vez me encontré llorando con una ira inexpresable, estaba siendo agarrado por el cuello por una mujer mayor - una gerente fría de la que siempre había estado ligeramente aterrorizada - que me arrastró a una escalera.
"Nunca dejes que te vean llorar", me dijo.
"No saben que estás furioso.
Piensan que estás triste y estarán contentos de haber llegado a ti".
Patricia Schroeder, entonces congresista demócrata de Colorado, había trabajado con Gary Hart en sus elecciones presidenciales.
En 1987, cuando el Sr. Hart fue atrapado en una aventura extramarital a bordo de un barco llamado Monkey Business y se retiró de la carrera, la Sra. Schroeder, profundamente frustrada, pensó que no había ninguna razón para que no explorara la idea de postularse para presidente ella misma.
"No fue una decisión bien pensada", me dijo con una sonrisa 30 años después.
"Ya había otros siete candidatos en la carrera, y lo último que necesitaban era otro.
Alguien lo llamó "Blancanieves y los siete enanos".
Debido a que era tarde en la campaña, ella estaba atrasada en la recaudación de fondos, y así que juró que no entraría en la carrera a menos que recaudara $2 millones.
Fue una batalla perdida.
Descubrió que algunos de sus partidarios que daban 1.000 dólares a los hombres solo le daban 250 dólares.
Ella se preguntó: "¿Piensan que recibo un descuento?"
Cuando hizo su discurso anunciando que no lanzaría una campaña formal, Estaba tan abrumada por las emociones: gratitud por las personas que la habían apoyado, frustración con el sistema que hacía tan difícil recaudar dinero y dirigirse a los votantes en lugar de a los delegados, y enojo por el sexismo, que se ahogó.
"Se habría pensado que había sufrido una crisis nerviosa", recordó la señora Schroeder sobre cómo la prensa reaccionó ante ella.
"Habría pensado que Kleenex era mi patrocinador corporativo.
Recuerdo haber pensado, ¿qué van a poner en mi lápida?
"¿Ella lloró?"
Cómo la guerra comercial entre Estados Unidos y China puede ser buena para Pekín
Las salvas iniciales de la guerra comercial entre Estados Unidos y China fueron ensordecedoras, y aunque la batalla está lejos de terminar, una ruptura entre los países puede ser beneficiosa para Beijing a largo plazo, dicen los expertos.
Donald Trump, el presidente de Estados Unidos, emitió la primera advertencia a principios de este año al gravar las principales exportaciones chinas, incluidos los paneles solares, el acero y el aluminio.
La escalada más significativa se produjo esta semana con nuevos aranceles que afectan a artículos por un valor de $ 200 mil millones (£ 150 mil millones), efectivamente gravando la mitad de todos los bienes que entran a los Estados Unidos desde China.
Beijing ha tomado represalias cada vez en especie, recientemente imponiendo aranceles de cinco a diez por ciento sobre $60 mil millones de bienes estadounidenses.
China se ha comprometido a igualar a EE.UU. tiro por tiro, y es poco probable que la segunda economía más grande del mundo parpadee en el corto plazo.
Obtener que Washington retroceda significa ceder a las demandas, pero inclinarse públicamente ante Estados Unidos sería demasiado embarazoso para Xi Jinping, el presidente de China.
Sin embargo, los expertos dicen que si Pekín puede jugar bien sus cartas, las presiones de la guerra comercial de Estados Unidos podrían apoyar positivamente a China a largo plazo al reducir la interdependencia de las dos economías.
"El hecho de que una rápida decisión política en Washington o Beijing podría crear las condiciones que inician un giro económico en cualquiera de los países es en realidad mucho más peligroso de lo que los espectadores han reconocido antes," dijo Abigail Grace, investigadora asociada que se centra en Asia en el Centro para la Nueva Seguridad Americana, un grupo de expertos.
Siria 'lista' para que los refugiados regresen, dice el ministro de Relaciones Exteriores
Siria dice que está lista para el regreso voluntario de los refugiados y está pidiendo ayuda para reconstruir el país devastado por una guerra de más de siete años.
Hablando ante la Asamblea General de las Naciones Unidas, el ministro de Relaciones Exteriores Walid al-Moualem dijo que las condiciones en el país están mejorando.
"Hoy la situación sobre el terreno es más estable y segura gracias a los progresos realizados en la lucha contra el terrorismo", dijo.
El gobierno continúa rehabilitando las áreas destruidas por los terroristas para restaurar la normalidad.
Ahora están todas las condiciones para el retorno voluntario de los refugiados al país que tuvieron que abandonar a causa del terrorismo y de las medidas económicas unilaterales dirigidas a su vida cotidiana y sus medios de subsistencia.
La ONU estima que más de 5,5 millones de sirios han huido del país desde que comenzó la guerra en 2011.
Otros seis millones de personas que aún viven en el país necesitan ayuda humanitaria.
Al-Moualem dijo que el régimen sirio daría la bienvenida a la ayuda para reconstruir el país devastado.
Pero hizo hincapié en que no aceptaría ayuda condicional o ayuda de países que patrocinaron la insurgencia.
Europa obtiene la victoria en la Ryder Cup en París
El equipo de Europa ha ganado la Copa Ryder 2018 derrotando al equipo de EE.UU. por un puntaje final de 16.5 a 10.5 en Le Golf National fuera de París, Francia.
Los EE.UU. han perdido seis veces consecutivas en suelo europeo y no han ganado una Copa Ryder en Europa desde 1993.
Europa recuperó la corona cuando el equipo del capitán danés Thomas Bjorn alcanzó los 14,5 puntos que necesitaban para vencer a los Estados Unidos.
La estrella estadounidense Phil Mickelson, que luchó la mayor parte del torneo, lanzó su tiro de salida al agua en el hoyo par-3 16, perdiendo su partido ante Francesco Molinari.
El golfista italiano Molinari brilló en todas sus rondas, convirtiéndose en uno de los cuatro jugadores en ir 5-0-0 desde que comenzó el formato actual del torneo en 1979.
El estadounidense Jordan Spieth fue eliminado 5 y 4 por el jugador de menor clasificación del equipo europeo, Thorbjorn Olesen de Dinamarca.
El jugador mejor clasificado del mundo, Dustin Johnson, perdió 2 y 1 ante Ian Poulter de Inglaterra quien pudo haber jugado en su última Ryder Cup.
Un veterano de ocho Copas Ryder, el español Sergio García se convirtió en el torneo europeo más ganador de todos los tiempos con 25.5 puntos en su carrera.
"Normalmente no lloro, pero hoy no puedo evitarlo.
Ha sido un año duro.
Estoy muy agradecido de que Thomas me eligiera y creyera en mí.
Estoy tan feliz, tan feliz de recuperar la copa.
Se trata del equipo, y estoy feliz de haber podido ayudar", dijo un emotivo García después de la victoria europea.
Pasó la antorcha a su compatriota John Ram quien derrotó a la leyenda del golf estadounidense Tiger Woods 2&1 en el juego de singles el domingo.
"El increíble orgullo que siento, de vencer a Tiger Woods, crecí viendo a ese tipo", dijo Rahm, de 23 años.
Woods perdió sus cuatro partidos en Francia y ahora tiene un récord de 13-21-3 en la Ryder Cup.
Una extraña estadística de uno de los mejores jugadores de todos los tiempos, habiendo ganado 14 títulos de Grandes Ligas sólo superado por Jack Nicklaus.
El equipo de EE.UU. luchó todo el fin de semana para encontrar los fairways con la excepción de Patrick Reed, Justin Thomas y Tony Finau, que jugaron golf de alto calibre durante todo el torneo.
El capitán de los EE.UU. Jim Furyk habló después de una actuación decepcionante para su escuadrón, "Estoy orgulloso de estos muchachos, lucharon.
Ha habido tiempo esta mañana cuando hemos puesto un poco de calor en Europa.
Nos hemos ido.
Le quito el sombrero a Thomas.
Es un gran capitán.
Todos sus 12 jugadores jugaron muy bien.
Nos reagruparemos, trabajaré con la PGA de América y nuestro Comité de la Copa Ryder y seguiremos adelante.
Amo a estos 12 chicos y estoy orgulloso de servir como capitán.
Tienes que inclinar tu gorra.
Fuimos superados".
Actualización de la marea roja: Las concentraciones disminuyen en Pinellas, Manatee y Sarasota
El último informe de la Comisión de Pesca y Vida Silvestre de Florida muestra una disminución general en las concentraciones de marea roja para partes del área de la Bahía de Tampa.
Según la FWC, se están reportando condiciones de floración patchier en áreas de los condados de Pinellas, Manatee, Sarasota, Charlotte y Collier, lo que sugiere una disminución de las concentraciones.
La marea roja se extiende aproximadamente 130 millas de costa desde el norte de Pinellas hasta el sur de los condados de Lee.
Los parches se pueden encontrar a unas 10 millas de la costa del condado de Hillsborough, pero en menos sitios en comparación con la semana pasada.
La marea roja también se ha observado en el condado de Pasco.
Se han reportado concentraciones medianas dentro o fuera del condado de Pinellas en la última semana. concentraciones bajas a altas en la costa del condado de Hillsborough, antecedentes de altas concentraciones en el condado de Manatee, antecedentes de concentraciones altas en el condado de Sarasota o en alta mar, antecedentes de concentraciones medias en el condado de Charlotte, antecedentes de concentraciones altas en el condado de Lee o en alta mar y concentraciones bajas en el condado de Collier.
La irritación respiratoria continúa siendo reportada en los condados de Pinellas, Manatee, Sarasota, Lee y Collier.
No se informó de irritación respiratoria en el noroeste de Florida durante la semana pasada.
