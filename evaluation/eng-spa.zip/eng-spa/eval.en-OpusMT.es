Welsh AMs preocupado por 'parecen muppets'
Hay consternación entre algunas AM en una sugerencia su título debería cambiar a MWPs (Miembro del Parlamento de Gales).
Ha surgido debido a los planes de cambiar el nombre de la asamblea al Parlamento galés.
A las AM de todo el espectro político les preocupa que pueda invitar al ridículo.
Una AM laborista dijo que su grupo estaba preocupado "por rimar con Twp y Pwp".
Para los lectores fuera de Gales: En galés twp significa tonto y pwp significa caca.
A Plaid AM dijo que el grupo en su conjunto era "no feliz" y ha sugerido alternativas.
Un conservador galés dijo que su grupo estaba "de mente abierta" sobre el cambio de nombre, pero señaló que era un corto salto verbal de MWP a Muppet.
En este contexto, la letra w galesa se pronuncia de manera similar a la pronunciación en inglés de Yorkshire de la letra u.
La Comisión de la Asamblea, que actualmente está redactando legislación para introducir los cambios de nombre, dijo: "La decisión final sobre cualquier descriptor de lo que se denomina a los miembros de la Asamblea será, por supuesto, una cuestión que corresponderá a los propios miembros".
La Ley del Gobierno de Gales de 2017 dio a la asamblea galesa la facultad de cambiar su nombre.
En junio, la Comisión publicó los resultados de una consulta pública sobre las propuestas que encontraron amplio apoyo para llamar a la Asamblea un Parlamento galés.
En cuanto al título de las AM, la Comisión favoreció a los diputados al Parlamento galés o a los PMM, pero la opción MWP recibió el mayor apoyo en una consulta pública.
Aparentemente, las AM están sugiriendo opciones alternativas, pero la lucha por llegar a un consenso podría ser un dolor de cabeza para el Presidente, Elin Jones, que se espera que presente un proyecto de ley sobre los cambios en cuestión de semanas.
La legislación sobre las reformas incluirá otros cambios en el funcionamiento de la asamblea, incluidas las normas sobre la descalificación de las AM y el diseño del sistema de comités.
Las AM obtendrán la votación final sobre la cuestión de lo que se les debería llamar cuando debatan la legislación.
Los macedonios van a las urnas en referéndum sobre cambiar el nombre del país
Los votantes votarán el domingo sobre si cambiar el nombre de su país a la "República del Norte de Macedonia".
El voto popular se estableció en un intento de resolver una disputa de décadas con la vecina Grecia, que tiene su propia provincia llamada Macedonia.
Atenas ha insistido desde hace mucho tiempo en que el nombre de su vecino del norte representa una reivindicación en su territorio y ha objetado reiteradamente sus ofertas de adhesión a la UE y a la OTAN.
El presidente macedonio Gjorge Ivanov, opositor del plebiscito sobre el cambio de nombre, ha dicho que ignorará la votación.
Sin embargo, los partidarios del referéndum, incluido el primer ministro Zoran Zaev, argumentan que el cambio de nombre es simplemente el precio a pagar para unirse a la UE y la OTAN.
Las campanas de la caída de San Martín Silenciosas como iglesias en la lucha de Harlem
"Históricamente, los ancianos con los que he hablado dicen que había un bar y una iglesia en cada esquina", dijo el Sr. Adams.
"Hoy, no hay ninguno."
Dijo que la desaparición de los bares era comprensible.
"La gente socializa de una manera diferente" hoy en día, dijo.
"Los bares ya no son salas de estar vecinales donde la gente va regularmente".
En cuanto a las iglesias, le preocupa que el dinero de la venta de activos no dure mientras los líderes lo esperen, "y tarde o temprano estarán de vuelta donde empezaron".
Las iglesias, añadió, podrían ser reemplazadas por edificios de apartamentos con condominios llenos del tipo de personas que no ayudarán a los santuarios restantes del barrio.
"La abrumadora mayoría de las personas que compran condominios en estos edificios serán blancos," él dijo, "y por lo tanto apresurará el día en que estas iglesias cierren por completo porque es poco probable que la mayoría de estas personas que se mudan a estos condominios se convertirán en miembros de estas iglesias."
Ambas iglesias fueron construidas por congregaciones blancas antes de Harlem se convirtió en una metrópolis negra - Comunidad Metropolitana en 1870, San Martín una década más tarde.
La congregación metodista blanca original se mudó en la década de 1930.
Una congregación negra que había estado adorando cerca tomó el título del edificio.
St. Martin fue tomado por una congregación negra bajo el Rev. John Howard Johnson, quien lideró un boicot a los minoristas en 125th Street, una calle principal para ir de compras en Harlem, quienes se resistieron a contratar o promover a los negros.
Un incendio en 1939 dejó el edificio gravemente dañado, pero cuando los feligreses del Padre Johnson hicieron planes para reconstruir, encargaron el carillón.
El reverendo David Johnson, hijo del padre Johnson y sucesor en St. Martin's, llamó orgullosamente al carillón "las campanas de los pobres".
El experto que tocó el carillón en julio lo llamó otra cosa: "Un tesoro cultural" y "un instrumento histórico irremplazable".
El experto, Tiffany Ng de la Universidad de Michigan, también señaló que fue el primer carillón del mundo en ser interpretado por un músico negro, Dionisio A. Lind, que se trasladó al carillón más grande de la iglesia Riverside hace 18 años.
El Sr. Merriweather dijo que St. Martin no lo reemplazó.
Lo que ha tenido lugar en San Martín en los últimos meses ha sido una complicada historia de arquitectos y contratistas, algunos traídos por los líderes laicos de la iglesia, otros por la diócesis episcopal.
La sacristía - el cuerpo gobernante de la parroquia, compuesto por líderes laicos - escribió la diócesis en julio con la preocupación de que la diócesis "buscaría pasar a lo largo de los costos" a la sacristía, a pesar de que la sacristía no había estado involucrado en la contratación de los arquitectos y contratistas que la diócesis envió.
Algunos feligreses se quejaron de una falta de transparencia por parte de la diócesis.
Tiburón herido de 13 años de edad en buceo de langosta en California
Un tiburón atacó e hirió a un niño de 13 años el sábado mientras buceaba para la langosta en California en el día de apertura de la temporada de langostas, dijeron los funcionarios.
El ataque ocurrió justo antes de las 7 a.m. cerca de la playa de Beacon en Encinitas.
Chad Hammel le dijo a KSWB-TV en San Diego que había estado buceando con amigos durante aproximadamente media hora el sábado por la mañana cuando escuchó al niño gritar pidiendo ayuda y luego remó con un grupo para ayudar a sacarlo del agua.
Hammel dijo al principio que pensaba que era sólo emoción de coger una langosta, pero luego "se dio cuenta de que estaba gritando, '¡Me mordieron!
¡Me mordieron!
Toda su clavícula estaba abierta," Hammel dijo que se dio cuenta una vez que llegó al niño.
"Le grité a todos que salieran del agua: '¡Hay un tiburón en el agua!'" Hammel agregó.
El niño fue trasladado por vía aérea al Hospital de Niños Rady en San Diego, donde está en estado crítico.
La especie de tiburón responsable del ataque era desconocida.
El Capitán de Salvavidas Larry Giles dijo en una reunión informativa de los medios que un tiburón había sido visto en la zona unas semanas antes, pero se determinó que no era una especie peligrosa de tiburón.
Giles agregó que la víctima sufrió lesiones traumáticas en su área superior del torso.
Funcionarios cerraron el acceso a la playa desde Ponto Beach en Casablad a Swami's en Ecinitas durante 48 horas para fines de investigación y seguridad.
Giles señaló que hay más de 135 especies de tiburones en la zona, pero la mayoría no son considerados peligrosos.
Los planes de Sainsbury empujan al mercado de belleza del Reino Unido
Sainsbury's se está enfrentando a Boots, Superdrug y Debenhams con pasillos de belleza al estilo de tiendas con personal especializado.
Como parte de un importante empuje en el mercado británico de belleza de 2,8 mil millones de libras, que sigue creciendo mientras las ventas de moda y artículos caseros retroceden, los pasillos de belleza más grandes serán probados en 11 tiendas de todo el país y llevados a más tiendas el próximo año si demuestra un éxito.
La inversión en belleza viene como supermercados de la búsqueda de maneras de utilizar el espacio de estante una vez demandado por televisores, microondas y artículos para el hogar.
Sainsbury dijo que duplicaría el tamaño de su oferta de belleza hasta 3.000 productos, incluyendo marcas como Revlon, Essie, Tweezerman y Dr. PawPaw por primera vez.
Las gamas existentes de L'Oreal, Maybelline y Burt's Bees también obtendrán más espacio con áreas de marca similares a las que se encuentran en tiendas como Boots.
El supermercado también está relanzando su gama de maquillaje Boutique para que la mayoría de los productos sean veganos - algo cada vez más demandado por los compradores más jóvenes.
Además, la tienda de perfumes Fragrance Shop probará concesiones en dos tiendas de Sainsbury, la primera de las cuales abrió en Croydon, al sur de Londres, la semana pasada, mientras que una segunda se abrirá en Selly Oak, Birmingham, a finales de este año.
Compras en línea y un cambio hacia la compra de pequeñas cantidades de alimentos diariamente en las tiendas locales significa que los supermercados están teniendo que hacer más para persuadir a la gente a visitar.
Mike Coupe, el director ejecutivo de Sainsbury's, ha dicho que los puntos de venta se verán cada vez más como grandes almacenes mientras la cadena de supermercados intenta luchar contra los descuento Aldi y Lidl con más servicios y no alimentos.
Sainsbury's ha estado poniendo puntos de venta de Argos en cientos de tiendas y también ha introducido una serie de Hábitats desde que compró ambas cadenas hace dos años, que dice que ha reforzado las ventas de comestibles y ha hecho las adquisiciones más rentables.
El anterior intento del supermercado de renovar su belleza y los departamentos de farmacia terminaron en fracaso.
Sainsbury puso a prueba una empresa conjunta con Boots a principios de la década de 2000, pero el empate terminó después de una pelea sobre cómo dividir los ingresos de las tiendas del químico en sus supermercados.
La nueva estrategia viene después de que Sainsbury's vendiera su negocio de farmacia de 281 tiendas a Celesio, el propietario de la cadena Lloyds Pharmacy, por 125 millones de libras hace tres años.
Dijo que Lloyds jugaría un papel en el plan, añadiendo una amplia gama de marcas de cuidado de la piel de lujo, incluyendo La Roche-Posay y Vichy en cuatro tiendas.
Paul Mills-Hicks, director comercial de Sainsbury, dijo: "Hemos transformado el aspecto y la sensación de nuestros pasillos de belleza para mejorar el entorno para nuestros clientes.
También hemos invertido en colegas especialmente entrenados que estarán presentes para ofrecer consejos.
Nuestra gama de marcas está diseñada para satisfacer todas las necesidades y el entorno atractivo y las ubicaciones convenientes significa que ahora somos un destino de belleza convincente que desafía la vieja forma de comprar".
Peter Jones 'furious' después de Holly Willoughby saca de £ 11 millones de trato
La estrella de Dragons Den Peter Jones dejó 'furious' después de que Holly Willoughby sacara de £11 millones de negocio de su marca de estilo de vida para centrarse en sus nuevos contratos con Marks y Spencer e ITV
Willoughby no tiene tiempo para su marca de ropa de hogar y accesorios Truly.
El negocio de la pareja había sido comparado con la marca Goop de Gwyneth Paltrow.
Esta presentadora matutina, de 37 años, llevó a Instagram para anunciar que se va.
Holly Willoughby ha dejado Dragons" estrella de Den Peter Jones fuming al retirarse de su lucrativo negocio de marca de estilo de vida en el último minuto - para centrarse en sus propios nuevos contratos parachoques con Marks & Spencer e ITV.
Las fuentes dicen que Jones estaba "furioso" cuando la chica dorada de TV admitió durante una tensa reunión el martes en la sede de su imperio de negocios en Marlow, Buckinghamshire, que sus nuevas ofertas - por un valor de hasta £1,5 millones - significaba que ya no tenía tiempo suficiente para dedicar a su marca de ropa de hogar y accesorios Truly.
El negocio había sido comparado con la marca Goop de Gwyneth Paltrow y se le dio propina para duplicar la fortuna estimada de Willoughby de 11 millones de libras.
Como Willoughby, de 37 años, llevó a Instagram para anunciar que se iba Truly, Jones salió de Gran Bretaña para dirigirse a una de sus casas de vacaciones.
Una fuente dijo: "La verdad era, con mucho, la prioridad de Holly.
Iba a ser su futuro a largo plazo que la vería a través de las próximas dos décadas.
Su decisión de retirarse dejó a todos los involucrados absolutamente atónitos.
Nadie podía creer lo que estaba pasando el martes, estaba tan cerca del lanzamiento.
Hay un almacén lleno de bienes en el cuartel general de Marlow que están listos para ser vendidos".
Los expertos creen en la partida del presentador de esta mañana, que es una de las estrellas más financiables de Gran Bretaña, podría costar millones a la firma debido a la fuerte inversión en productos que van desde cojines y velas a ropa y ropa de hogar, y el potencial de nuevos retrasos para su lanzamiento.
Y podría significar el fin de una larga amistad.
La madre de tres Willoughby y su esposo Dan Baldwin han estado cerca de Jones y su esposa Tara Capp durante diez años.
Willoughby estableció Truly con Capp en 2016 y Jones, de 52 años, se unió como presidente en marzo.
Las parejas de vacaciones juntos y Jones tiene un 40% de participación en la empresa de producción de TV de Baldwin.
Willoughby se convertirá en embajador de marca para M&S y reemplazará a Ant McPartlin como anfitrión de ITV soy una celebridad.
Una fuente cercana a Jones dijo anoche: "No comentaríamos sus asuntos de negocios".
Habla duro 'y luego nos enamoramos'
Bromeó sobre las críticas que recibiría de los medios de comunicación por hacer un comentario que algunos considerarían "no presidencial" y por ser tan positivo sobre el líder norcoreano.
¿Por qué ha renunciado tanto el presidente Trump?
Trump dijo en su voz simulada de "ancla de las noticias".
"No renuncié a nada".
Señaló que Kim está interesado en una segunda reunión después de que su reunión inicial en Singapur en junio fue aclamada por Trump como un gran paso hacia la desnuclearización de Corea del Norte.
Pero las negociaciones de desnuclearización se han estancado.
Más de tres meses después de la cumbre de junio en Singapur, el máximo diplomático de Corea del Norte, Ri Yong Ho, dijo a los líderes mundiales en la Asamblea General de las Naciones Unidas el sábado que el Norte no ve una "respuesta correspondiente" de Estados Unidos a las primeras medidas de desarme de Corea del Norte.
En su lugar, señaló, Estados Unidos continúa con las sanciones dirigidas a mantener la presión.
Trump adoptó un punto de vista mucho más optimista en su discurso de mitin.
"Lo estamos haciendo muy bien con Corea del Norte", dijo.
"Ibamos a la guerra con Corea del Norte.
Millones de personas habrían sido asesinadas.
Ahora tenemos esta gran relación".
Dijo que sus esfuerzos por mejorar las relaciones con Kim han dado resultados positivos: poner fin a las pruebas con cohetes, ayudar a liberar a los rehenes y recuperar los restos de militares estadounidenses.
Y defendió su enfoque inusual al hablar de relaciones con Kim.
"Es tan fácil ser presidencial, pero en lugar de tener a 10.000 personas afuera tratando de entrar en esta arena llena, tendríamos a unas 200 personas de pie justo ahí", dijo Trump, señalando a la multitud directamente frente a él.
Indonesia Tsunami y terremoto Devastan una isla, matando a cientos
A raíz del terremoto de Lombok, por ejemplo, se dijo que no eran necesarias las organizaciones no gubernamentales extranjeras.
Aunque más del 10 por ciento de la población de Lombok había sido dislocada, no se declaró ningún desastre nacional, un requisito previo para catalizar la ayuda internacional.
"En muchos casos, desafortunadamente, han sido muy claros de que no están solicitando asistencia internacional, por lo que es un poco difícil", dijo la Sra. Sumbung.
Mientras que Save the Children está reuniendo un equipo para viajar a Palu, todavía no está seguro de si el personal extranjero puede trabajar sobre el terreno.
El Sr. Sutopo, portavoz de la agencia nacional de desastres, dijo que funcionarios indonesios estaban evaluando la situación en Palu para ver si se permitiría a los organismos internacionales contribuir al esfuerzo de ayuda.
Dado el temblor de tierra que Indonesia soporta constantemente, el país sigue estando lamentablemente mal preparado para la ira de la naturaleza.
Si bien se han construido refugios contra tsunamis en Aceh, no son una vista común en otras costas.
Es probable que la aparente falta de una sirena de advertencia de tsunami en Palu, a pesar de que había estado en vigor, haya contribuido a la pérdida de vidas.
En el mejor de los casos, viajar entre las muchas islas de Indonesia es un reto.
Los desastres naturales complican aún más la logística.
Un barco hospital que había estado estacionado en Lombok para tratar a las víctimas del terremoto está llegando a Palu, pero tardará al menos tres días en llegar al lugar de la nueva calamidad.
El presidente Joko Widodo hizo de la mejora de la destrozada infraestructura de Indonesia una pieza central de su campaña electoral, y ha prodigado dinero en carreteras y ferrocarriles.
Pero los déficits de financiación han plagado la administración del Sr. Joko mientras se enfrenta a la reelección el próximo año.
El Sr. Joko también se enfrenta a la presión de las persistentes tensiones sectarias en Indonesia, donde los miembros de la mayoría musulmana han adoptado una forma de fe más conservadora.
Más de 1.000 personas murieron y decenas de miles se desplazaron de sus hogares mientras pandillas cristianas y musulmanas luchaban en las calles, usando machetes, arcos y flechas, y otras armas crudas.
Reloj: Daniel Sturridge de Liverpool bucea ecualizador profundo contra Chelsea
Daniel Sturridge salvó Liverpool de una derrota de la Premier League a Chelsea con una puntuación en el minuto 89 el sábado en el Stamford Bridge en Londres.
Sturridge recibió un pase de Xherdan Shaqiri mientras que a unos 30 metros del gol de Chelsea con su equipo a la zaga 1-0.
Chocó la bola a su izquierda antes de lanzar un tiro hacia el poste lejano.
El intento navegó por encima de la caja mientras se desplazaba hacia la esquina superior derecha de la red.
La pelota finalmente cayó sobre un salto Kepa Arrizabalaga y cayó en la red.
"Sólo estaba tratando de llegar a esa posición, para subir al balón y jugadores como Shaq siempre jugar hacia adelante tanto como fuera posible, así que traté de crearme a mí mismo tanto tiempo como fuera posible", dijo Sturridge a LiverpoolFC.com.
"Vi venir a Kante y tomé un toque y no pensé mucho en ello y simplemente le disparé".
Chelsea lideró 1-0 al medio tiempo después de conseguir una puntuación en el minuto 25 de la estrella belga Eden Hazard.
El delantero de Blues talonó un pase a Mateo Kovacic en esa obra, antes de girar cerca del medio campo y correr hacia la mitad de Liverpool.
Kovacic hizo un giro rápido en el medio campo.
Luego disparó una hermosa bola, llevando a Hazard a la caja.
Hazard superó a la defensa y terminó en el post-red con un tiro a la izquierda más allá de Alisson Becker de Liverpool.
Liverpool batalla contra Napoli en la etapa de grupo de la Liga de Campeones a las 3 p.m. el miércoles en el Stadio San Paolo en Nápoles, Italia.
Chelsea se enfrenta a Videoton en la UEFA Europa Leaguge a las 3 p.m. el jueves en Londres.
El número de víctimas mortales del tsunami de Indonesia asciende a 832
El número de muertos en el terremoto y tsunami de Indonesia ha subido a 832, la agencia de desastres del país dijo que a principios del domingo.
Se informó de que muchas personas estaban atrapadas en los escombros de los edificios derribados en el terremoto de magnitud 7,5 que golpeó el viernes y provocó olas de hasta 20 pies, dijo el portavoz de la agencia Sutopo Purwo Nugroho en una conferencia de prensa.
La ciudad de Palu, que tiene más de 380.000 personas, estaba llena de escombros de edificios colapsados.
Detienen a un policía de 32 años bajo sospecha de asesinato después de que una mujer es apuñalada hasta morir.
Se ha iniciado una investigación de asesinato después de que el cuerpo de la mujer fue encontrado en Birkenhead, Merseyside esta mañana.
El niño de 44 años fue encontrado a las 7.55 de la mañana con heridas de arma blanca en Grayson Mews en John Street, y un hombre de 32 años fue arrestado bajo sospecha de asesinato.
La policía ha instado a la gente de la zona que vio u oyó algo a que se presente.
El inspector Brian O'Hagan dijo: "La investigación está en las primeras etapas, pero apelaría a cualquiera que estuviera en las cercanías de John Street en Birkenhead que viera u oyera algo sospechoso para contactarnos.
También apelaría a cualquier persona, en particular a los taxistas, que hayan capturado cualquier cosa en las imágenes de las cámaras para que se pongan en contacto con nosotros, ya que pueden tener información vital para nuestra investigación.»
Un portavoz de la policía ha confirmado que la mujer cuyo cuerpo fue encontrado es local a Birkenhead y que fue encontrada dentro de una propiedad.
Esta tarde amigos que creen saber que la mujer ha llegado a la escena para hacer preguntas sobre dónde fue encontrada esta mañana.
Las investigaciones están en curso, ya que la policía ha dicho que están en el proceso de informar a los familiares de la víctima.
Un taxista que vive en Grayson Mews acaba de intentar volver a su apartamento, pero la policía le dice a nadie que entre o salga del edificio.
Estaba mudo cuando descubrió lo que pasó.
A los residentes se les dice que pasarán horas hasta que se les permita volver.
Se oyó a un oficial de policía decirle a un hombre que toda la zona está siendo tratada como una escena del crimen.
Una mujer apareció llorando en la escena.
Sigue repitiendo "es tan horrible".
A las 2 p.m. dos camionetas de la policía estaban dentro del cordón con otra camioneta justo afuera.
Varios oficiales estaban en el interior del cordón vigilando el bloque de pisos.
Cualquier persona con información se le pide a DM @MerPolCC, llame a 101 o póngase en contacto con Crimestoppers anónimamente el 0800 555 111 citando el registro 247 del 30 de septiembre.
La estatua de Cromwell del Parlamento se convierte en el último hito conmemorativo de la fila de "reescribir la historia"
Su destierro sería una justicia poética para su destrucción, similar a la de los talibanes, de tantos de los artefactos culturales y religiosos de Inglaterra llevados a cabo por sus fanáticos seguidores puritanos.
Pero la Sociedad Cromwell describió la sugerencia del Sr. Crick como "folly" y "intentar reescribir la historia".
John Goldsmith, presidente de la Sociedad Cromwell, dijo: "Fue inevitable en el actual debate sobre la remoción de estatuas que la figura de Oliver Cromwell fuera del Palacio de Westminster se convirtiera en un objetivo.
El iconoclasmo de las guerras civiles inglesas no fue ordenado ni llevado a cabo por Cromwell.
Tal vez el Cromwell equivocado sería sacrificado por las acciones de su antepasado Thomas en el siglo anterior.
La magnífica representación de Sir William Hamo Thorneycroft de Cromwell es evidencia de la opinión del siglo XIX y parte de la historiografía de una figura que muchos creen que aún vale la pena celebrar.
Goldsmith dijo a The Sunday Telegraph: "Cromwell es considerado por muchos, quizás más a finales del siglo XIX que hoy, como un defensor del parlamento contra la presión externa, en su caso, por supuesto, la monarquía.
Si se trata de una representación totalmente exacta es objeto de un debate histórico continuo.
Lo cierto es que el conflicto de mediados del siglo XVII ha dado forma al desarrollo posterior de nuestra nación, y Cromwell es una figura individual reconocible que representa un lado de esa división.
Sus logros como Lord Protector también son dignos de celebrar y conmemorar."
Asesino cerdo Mauls agricultor chino a la muerte
Un granjero fue atacado y asesinado por un cerdo en un mercado en el suroeste de China, según informes de los medios locales.
El hombre, identificado sólo por su apellido "Yuan", fue encontrado muerto con una arteria cortada, cubierto de sangre cerca de una ortiga en el mercado en Liupanshui en la provincia de Guizhou, informó el Sunday.
Un agricultor porcino se prepara para inyectar vacunas a los cerdos en una granja porcina el 30 de mayo de 2005 en Xining, provincia de Qinghai, China.
Según se informa, había viajado con su primo de la vecina provincia de Yunnan el miércoles para vender 15 cerdos en el mercado.
A la mañana siguiente, su primo lo encontró muerto y descubrió una puerta abierta a un cerdo vecino.
Dijo que en la pocilga había un gran cerdo macho con sangre en la boca.
Un examen forense confirmó que el cerdo de 550 libras había matado al agricultor, según el informe.
"Las piernas de mi primo estaban ensangrentadas y destrozadas", dijo el primo, referido por su apellido "Wu", citado por el Guiyang Evening News.
Las cámaras de seguridad mostraron a Yuan entrando al mercado a las 4.40 de la mañana del jueves para alimentar a sus cerdos.
Su cuerpo fue encontrado una hora después.
El animal que mató al hombre no pertenecía a Yuan ni a su primo.
Un gerente del mercado le dijo a Evening News que el cerdo había sido encerrado para evitar que atacara a nadie más, mientras la policía recogía pruebas en el lugar.
Según se informa, la familia de Yuan y las autoridades del mercado están negociando una indemnización por su muerte.
Aunque son raros, se han registrado casos de cerdos que atacan a seres humanos.
En 2016, un cerdo atacó a una mujer y a su marido en su granja en Massachusetts, dejando al hombre con heridas críticas.
Diez años antes, un cerdo de 650 libras cubrió a un granjero galés en su tractor hasta que su esposa asustó al animal.
Después de que un granjero de Oregon fue comido por sus cerdos en 2012, un granjero de Manitoba le dijo a CBC News que los cerdos no son normalmente agresivos, pero el sabor de la sangre puede actuar como un "trigger".
"Están siendo juguetones.
Son nippers, muy curiosos... no quieren hacerte daño.
Sólo tienes que pagarles la cantidad correcta de respeto", dijo.
Restos del huracán Rosa para llevar lluvias intensas al suroeste de EE.UU.
Como se pronostica, el huracán Rosa se está debilitando a medida que se mueve sobre las aguas más frías de la costa norte de México.
Sin embargo, Rosa traerá lluvias a lo largo del norte de México y el suroeste de Estados Unidos en los próximos días.
Rosa tenía vientos de 85 mph, un huracán de categoría 1, a las 5 a.m. Domingo a la hora del este, y se encontraba a 385 millas al suroeste de Punta Eugenia, México.
Se espera que Rosa se mueva hacia el norte el domingo.
Mientras tanto, un valle está empezando a tomar forma sobre el Océano Pacífico y moverse hacia el este hacia la costa oeste de los EE.UU. Mientras Rosa se acerca a la península de Baja California el lunes como una tormenta tropical que comenzará a empujar la humedad tropical profunda hacia el norte en el suroeste de EE.UU.
Rosa traerá hasta 10 pulgadas de lluvia en algunas partes de México el lunes.
Entonces, la humedad tropical interactuando con el abrevadero que se aproxima creará fuertes lluvias generalizadas en el Suroeste en los próximos días.
Localmente, de 1 a 4 pulgadas de lluvia causarán peligrosas inundaciones repentinas, flujos de escombros y posibles deslizamientos de tierra en el desierto.
La humedad tropical profunda hará que las tasas de precipitación se aproximen de 2 a 3 pulgadas por hora en lugares, especialmente en partes del sur de Nevada y Arizona.
Tanto como 2 a 4 pulgadas de lluvia se espera en partes del suroeste, especialmente en gran parte de Arizona.
Las inundaciones repentinas son posibles debido al rápido deterioro de las condiciones debido a la naturaleza dispersa de la lluvia tropical.
Sería extremadamente malo aventurarse en el desierto a pie con la amenaza de lluvias tropicales.
Lluvia fuerte podría hacer que los cañones se conviertan en ríos furiosos y tormentas eléctricas traerán vientos locales y polvo soplado.
El abrevadero que se acerca traerá algunas fuertes lluvias locales a partes de la costa sur de California.
Los totales de precipitaciones de más de media pulgada son posibles, lo que podría causar pequeños flujos de desechos y carreteras resbaladizas.
Esta sería la primera lluvia de la región de su estación húmeda.
Algunas lluvias tropicales dispersas comenzarán a acercarse a Arizona a finales del domingo y principios del lunes, antes de que la lluvia se generalice a finales del lunes y martes.
Lluvia fuerte se extenderá a las Cuatro Esquinas el martes y el pasado miércoles.
Octubre puede ver algunos cambios de temperatura intensos a través de los EE.UU. a medida que el Ártico se enfría, pero los trópicos permanecen bastante cálidos.
A veces esto lleva a cambios dramáticos en la temperatura en distancias cortas.
Hay un gran ejemplo de diferencias dramáticas de temperatura en el centro de Estados Unidos el domingo.
Hay una diferencia de temperatura de casi 20 grados entre Kansas City, Missouri, y Omaha, Nebraska, y entre St. Louis y Des Moines, Iowa.
En los próximos días, el calor de verano persistente tratará de construir y expandirse de nuevo.
Se espera que gran parte del centro y el este de Estados Unidos comiencen a ser cálidos desde los años 80 desde las llanuras del sur hasta partes del noreste hasta octubre.
La ciudad de Nueva York podría alcanzar los 80 grados el martes, lo que sería aproximadamente 10 grados por encima de la media.
Nuestro pronóstico climático a largo plazo está indicando altas posibilidades de temperaturas superiores a la media para el este de Estados Unidos hasta la primera quincena de octubre.
Más de 20 millones de personas vieron escuchar a Brett Kavanaugh
Más de 20 millones de personas vieron el apretujado testimonio del jueves por Brett Kavanaugh, candidato de la Corte Suprema, y la mujer que lo acusó de una agresión sexual que supuestamente ocurrió en la década de 1980, Christine Blasey Ford, en seis cadenas de televisión.
Mientras tanto, el enfrentamiento político continuó, con las emisoras interrumpiendo la programación regular para el giro de último minuto del viernes: un acuerdo diseñado por el Senador Jeff Flake de Arizona para que el FBI lleve a cabo una investigación de una semana de los cargos.
Ford le dijo al Comité Judicial del Senado que está 100% segura de que Kavanaugh la manoseó e intentó quitarse la ropa en una fiesta de secundaria.
Kavanaugh, en apasionado testimonio, dijo que está 100% seguro de que no sucedió.
Es probable que más de 20,4 millones de personas reportadas por Nielsen el viernes lo vieran.
La compañía estaba contando audiencia promedio en CBS, ABC, NBC, CNN, Fox News Channel y MSNBC.
Las cifras no estaban inmediatamente disponibles para otras redes que lo mostraron, incluyendo PBS, C-SPAN y Fox Business Network.
Y Nielsen generalmente tiene problemas para medir a las personas que observan en las oficinas.
Para ponerlo en perspectiva, ese es un tamaño de audiencia similar al de un partido de playoffs o los Oscar Awards.
Fox News Channel, cuyos anfitriones de opinión han apoyado fuertemente el nombramiento de Kavanaugh, lideró todas las redes con un promedio de 5,69 millones de espectadores durante la audiencia de todo el día, dijo Nielsen.
ABC fue segundo con 3,26 millones de espectadores.
CBS tenía 3,1 millones, NBC tenía 2,94 millones, MSNBC tenía 2,89 millones y CNN tenía 2,52 millones, dijo Nielsen.
El interés siguió siendo alto después de la audiencia.
Flake fue la figura central en el drama del viernes.
Después de que la oficina del republicano moderado emitiera una declaración de que votaría a favor de Kavanaugh, fue capturado por las cámaras CNN y CBS el viernes por la mañana siendo gritado por los manifestantes mientras intentaba subir un ascensor a una audiencia del Comité Judicial.
Se quedó con los ojos abatidos durante varios minutos mientras era censurado, televisado en vivo en CNN.
"Estoy aquí de pie frente a ti", dijo una mujer.
"¿Crees que está diciendo la verdad al país?
Se le dijo, "tienes poder cuando tantas mujeres son impotentes."
Flake dijo que su oficina había emitido una declaración y dijo, antes de que el ascensor se cerrara, que tendría más que decir en la audiencia del comité.
El cable y las cadenas de radiodifusión estaban cubriendo horas en vivo más tarde, cuando el Comité Judicial iba a votar para adelantar la nominación de Kavanaugh al Senado en pleno para una votación.
Pero Flake dijo que sólo lo haría con el entendimiento de que el FBI investigaría las acusaciones contra el candidato para la próxima semana, que los demócratas minoritarios han estado instando.
Flake fue convencido en parte por conversaciones con su amigo, el senador demócrata Chris Coons.
Después de una conversación con Coons y varios senadores, Flake tomó su decisión.
La elección de Flake tenía poder, porque era evidente que los republicanos no tendrían los votos para aprobar Kavanaugh sin la investigación.
El presidente Trump ha abierto una investigación del FBI sobre las acusaciones contra Kavanaugh.
El primer ministro británico May acusa a los críticos de 'jugar política' sobre el Brexit
La primera ministra Theresa May acusó a los críticos de sus planes de abandonar la Unión Europea de "jugar política" con el futuro de Gran Bretaña y socavar el interés nacional en una entrevista con el periódico Sunday Times.
La primera ministra británica Theresa May llega a la Conferencia del Partido Conservador en Birmingham, Reino Unido, 29 de septiembre de 2018.
En otra entrevista junto a la que tenía en la portada del periódico, su ex ministro de Asuntos Exteriores Boris Johnson presionó su ataque a su llamado plan Chequers para el Brexit, diciendo que una propuesta de que Gran Bretaña y la UE deberían cobrar los aranceles entre sí era "totalmente absurda".
Wayde Sims disparando: La policía arresta al sospechoso Dyteon Simpson en la muerte del jugador de LSU
La policía ha arrestado a un sospechoso en la muerte mortal de Wayde Sims, un jugador de baloncesto de 20 años en LSU.
Dyteon Simpson, de 20 años, ha sido arrestado y encarcelado por un cargo de asesinato en segundo grado, dijo el Departamento de Policía de Baton Rouge.
Los oficiales publicaron un video de la confrontación entre Sims y Simpson, y la policía dijo que Sims perdió sus gafas durante la pelea.
La policía recuperó las gafas de la escena y dijo que encontraron el ADN de Simpson en ellos, informes de la WAFB afiliada a la CBS.
Después de interrogar a Simpson, la policía dijo que admitió haber matado a Wayde.
Su fianza se ha fijado en 350.000 dólares, informa el abogado.
La oficina del forense de la parroquia de East Baton Rouge publicó un informe preliminar el viernes, diciendo que la causa de la muerte es una herida de bala en la cabeza en el cuello.
El departamento está acreditando a la fuerza de trabajo prófuga de la Policía Estatal de Luisiana, el laboratorio criminal de la policía estatal, la policía de la Universidad del Sur y los ciudadanos de la zona para ayudar en la investigación que condujo a la detención.
Joe Alleva, director atlético de LSU, agradeció a la policía del área por su "diligencia y búsqueda de justicia".
Sims tenía 20 años.
El 6 pies-6 adelante creció en Baton Rouge, donde su padre, Wayne, también jugó baloncesto para LSU.
Promedió 5.6 puntos y 2.6 rebotes en un partido la temporada pasada.
El viernes por la mañana, el entrenador de baloncesto de LSU Will Wade dijo que el equipo está "devastado" y "en shock" por la muerte de Wayde.
"Esto es de lo que te preocupas en todo momento", dijo Wade.
Volcán arroja cenizas en la Ciudad de México
El lanzamiento de ceniza desde el volcán Popocatepetl ha llegado a los barrios del sur de la capital de México.
El Centro Nacional para la Prevención de Desastres advirtió el sábado a los mexicanos que se mantuvieran alejados del volcán después de que la actividad se recogiera en el cráter y registrara 183 emisiones de gas y ceniza durante 24 horas.
El centro estaba monitoreando múltiples retumbamientos y temblores.
Las imágenes en las redes sociales mostraban capas delgadas de parabrisas de automóviles que cubrían cenizas en barrios de la Ciudad de México como Xochimilco.
Los geofísicos han notado un aumento en la actividad en el volcán que se encuentra a 45 millas (72 kilómetros) al sureste de la capital desde que un terremoto de magnitud 7.1 sacudió el centro de México en septiembre de 2017.
El volcán conocido como "Don Goyo" ha estado activo desde 1994.
La policía se enfrenta con los separatistas catalanes antes del aniversario de la votación por la independencia
Seis personas fueron arrestadas en Barcelona el sábado después de que manifestantes independentistas se enfrentaran con la policía antidisturbios, y mientras miles se unieron a manifestaciones rivales para conmemorar el primer aniversario de la polarización del voto de Cataluña sobre la secesión.
Un grupo de pro-separatistas enmascarados retenidos por la policía antidisturbios los arrojó con huevos y pintura en polvo, creando oscuras nubes de polvo en las calles que normalmente se llenaban de turistas.
Las peleas también estallaron más tarde en el día con la policía usando sus porras para contener los combates.
Durante varias horas, grupos independentistas coreando "Sin olvidar, sin perdón" se enfrentaron a manifestantes sindicalistas gritando: "Viva España".
Catorce personas recibieron tratamiento por lesiones leves recibidas en las protestas, informó la prensa local.
Las tensiones siguen siendo altas en la región independentista un año después del referéndum del 1 de octubre considerado ilegal por Madrid pero celebrado por los separatistas catalanes.
Los votantes optaron abrumadoramente por independizarse, aunque la participación fue baja con los que estaban en contra de la secesión boicoteando en gran medida la votación.
Según las autoridades catalanas, casi 1000 personas resultaron heridas el año pasado después de que la policía intentara detener la votación en los colegios electorales de toda la región en enfrentamientos violentos.
Los grupos independentistas habían acampado durante la noche del viernes para impedir una manifestación en apoyo de la policía nacional.
La manifestación siguió adelante, pero se vio obligada a tomar una ruta diferente.
Narcis Termes, de 68 años, electricista que asistió a la protesta separatista con su esposa, dijo que ya no tenía esperanzas sobre las perspectivas de la independencia de Cataluña.
"El año pasado vivimos uno de nuestros mejores momentos.
Vi a mis padres llorar con alegría por poder votar, pero ahora estamos atascados", dijo.
A pesar de haber logrado una victoria vital y estrecha en las elecciones regionales del pasado diciembre, Los partidos independentistas catalanes han luchado por mantener el impulso este año con muchos de sus líderes más conocidos, ya sea en el exilio autoimpuesto o en espera de juicio por su papel en la organización del referéndum y posterior declaración de independencia.
Joan Puig, un mecánico de 42 años que grabó la protesta en apoyo de la policía en su teléfono, dijo que el conflicto había sido avivado por políticos de ambos lados.
"Se está poniendo cada vez más tenso", dijo.
El sábado, Oriol Junqueras, uno de los nueve líderes catalanes en prisión preventiva desde finales del año pasado, anunció que se presentaría en las elecciones al Parlamento Europeo el próximo año.
"Pararse como candidato a las elecciones europeas es la mejor manera de denunciar la regresión en los valores democráticos y la represión que hemos visto desde el gobierno español", dijo.
Londonderry: Hombres arrestados después de una casa atropellada por un coche
Tres hombres, de 33, 34 y 39 años de edad, han sido arrestados después de que un coche fuera atropellado repetidamente en una casa en Londonderry.
El incidente se desarrolló en Ballynagard Crescent el jueves alrededor de las 19:30 BST.
Det Insp Bob Blemmings dijo que los daños fueron causados a las puertas y al propio edificio.
Una ballesta también pudo haber sido disparada contra el coche en algún momento.
Menga huelga da Livingston 1-0 ganar sobre Rangers
El primer gol de Dolly Menga para Livingston aseguró la victoria
Promocionado Livingston sorprendió a Rangers para enviar a Steven Gerrard a su segunda derrota en 18 juegos como gerente del club Ibrox.
La huelga de Dolly Menga resultó ser la diferencia ya que el lado de Gary Holt se movió a nivel con Hibernian en segundo lugar.
El lado de Gerrard permanece sin ganar en la Premiership esta temporada y se enfrenta a los líderes Corazones, a quienes siguen por ocho puntos, el próximo domingo.
Antes de eso, los Rangers albergan Rapid Vienna en la Europa League el jueves.
Livingston, mientras tanto, extiende su carrera invicta en la división a seis juegos, con el entrenador Holt aún a probar la derrota desde reemplazar a Kenny Miler el mes pasado.
Livingston pierde oportunidades contra los visitantes contundentes
El equipo de Holt debería haber estado por delante mucho antes de anotar, con su franqueza causando a los Rangers todo tipo de problemas.
Scott Robinson rompió pero arrastró su esfuerzo a través de la cara de la meta, luego Alan Lithgow sólo pudo dirigir su esfuerzo de ancho después de deslizarse para cumplir con Craig Halkett cabeza a través de la meta.
Los anfitriones estaban contentos de dejar que los Rangers jugaran delante de ellos, sabiendo que podían molestar a los visitantes en las piezas.
Y esa fue la manera en que llegó el objetivo crucial.
Rangers concedió un tiro libre y Livingston trabajó en una apertura, Declan Gallagher y Robinson combinando para establecer Menga, que tomó un toque y anotó desde el centro de la caja.
En esa etapa, Rangers había dominado la posesión pero había encontrado la defensa doméstica impenetrable y el portero Liam Kelly estaba en gran parte tranquilo,
Ese patrón continuó hasta la segunda mitad, aunque Alfredo Morelos obligó a salvar a Kelly.
Scott Pittman fue negado por los pies del portero de Rangers Allan McGregor y Lithgow se deslizó de otro set de Livingston.
Crosses continuamente entró en la caja de Livingston y fue continuamente limpiado, mientras que dos reclamaciones de penalidad - después del desafío de Halkett en el sustituto Glenn Middleton, y uno para el balonmano - fueron agitadas lejos.
"Fenomenal" de Livingston - análisis
BBC Scotland's Alasdair Lamont en el Tony Macaroni Arena
Una actuación fenomenal y resultado para Livingston.
Para un hombre, eran excelentes, continuando superando las expectativas en esta trayectoria ascendente.
Su estilo de juego y personal apenas ha cambiado desde su regreso al primer vuelo, pero un gran crédito tiene que ir a Holt por la forma en que ha galvanizado el equipo desde su llegada.
Tenía tantos héroes.
El capitán Halkett era inmenso, llevando a cabo una defensa magníficamente organizada, mientras que Menga mantuvo a Connor Goldson y Joe Worrall en sus dedos de los pies.
Sin embargo, los Rangers estaban cortos de inspiración.
Tan buenos como han sido a veces bajo Gerrard, se quedaron muy por debajo de esos estándares.
Su bola final faltaba - sólo una vez que cortaron el lado de casa abierto - y es algo de una llamada de atención para los Rangers, que se encuentran en medio de la mesa.
Erdogan recibe recepción mixta en Colonia
Hubo sonrisas y cielos azules el sábado (29 de septiembre) cuando los líderes de Turquía y Alemania se reunieron para desayunar en Berlín.
Es el último día de la controvertida visita del Presidente Erdogan a Alemania, cuyo objetivo es reparar las relaciones entre los aliados de la OTAN.
Se han enfrentado a cuestiones como los derechos humanos, la libertad de prensa y la adhesión de Turquía a la UE.
Erdogan se dirigió entonces a Colonia para abrir una mezquita nueva gigante.
La ciudad es el hogar de la mayor población turca fuera de Turquía.
La policía citó razones de seguridad para impedir que una multitud de 25.000 personas se reuniera frente a la mezquita, pero muchos partidarios salieron a ver a su presidente.
Cientos de manifestantes anti-Erdogan - muchos de ellos kurdos - también hicieron oír sus voces, condenando tanto las políticas de Erdogan como la decisión del gobierno alemán de darle la bienvenida al país.
Las protestas en duelo reflejan la división de un visitante aclamado como un héroe por algunos turcos alemanes y insultado como un autócrata por otros.
Deptford accidente de carretera: Cyclist muere en colisión con el coche
Un ciclista ha muerto en una colisión con un coche en Londres.
El accidente ocurrió cerca del cruce de Bestwood Street y Evelyn Street, una concurrida carretera en Deptford, en el sureste de la ciudad, alrededor de las 10:15 BST.
El conductor del coche se detuvo y los paramédicos asistieron, pero el hombre murió en la escena.
El accidente se produjo meses después de que otro ciclista muriera en un atropello y fuga en la calle Childers, a una milla del accidente del sábado.
La Policía Metropolitana dijo que los oficiales estaban trabajando para identificar al hombre e informar a sus familiares.
Hay cierres de carreteras y desvíos de autobuses y se ha aconsejado a los automovilistas que eviten la zona.
Cárcel de Long Lartin: Seis oficiales heridos en desorden
Seis funcionarios de prisiones han resultado heridos en un disturbio en una cárcel de hombres de alta seguridad, ha dicho la Oficina de Prisiones.
El desorden estalló en HMP Long Lartin en Worcestershire alrededor de las 09:30 BST el domingo y está en curso.
Oficiales especializados "Tornado" han sido traídos para hacer frente a la perturbación, que involucra a ocho reclusos y está contenido en un ala.
Los agentes fueron tratados por lesiones faciales leves en el lugar.
Un portavoz del Servicio Penitenciario dijo: "Se ha desplegado personal penitenciario especialmente capacitado para hacer frente a un incidente en curso en HMP Long Lartin.
Seis funcionarios han recibido tratamiento por lesiones.
No toleramos la violencia en nuestras cárceles, y tenemos claro que los responsables serán remitidos a la policía y podrían pasar más tiempo tras las rejas".
HMP Long Lartin tiene más de 500 prisioneros, incluidos algunos de los delincuentes más peligrosos del país.
En junio se informó que el gobernador de la prisión recibió tratamiento hospitalario después de ser atacado por un preso.
Y en octubre del año pasado los antidisturbios fueron llamados a la prisión para lidiar con un grave disturbio en el que el personal fue atacado con bolas de billar.
El huracán Rosa amenaza a Phoenix, Las Vegas, Salt Lake City con inundaciones repentinas (las áreas de sequía pueden beneficiarse)
Es raro que una depresión tropical golpee Arizona, pero eso es exactamente lo que es probable que suceda a principios de la semana que viene cuando el Huracán Rosa siga teniendo energía en todo el desierto suroeste, lo que conlleva riesgos de inundación repentina.
El Servicio Meteorológico Nacional ya ha emitido relojes de inundación repentina para el lunes y martes para el oeste de Arizona en el sur y este de Nevada, el sureste de California y Utah, incluyendo las ciudades de Phoenix, Flagstaff, Las Vegas y Salt Lake City.
Se espera que Rosa tome un camino directo sobre Phoenix el martes, acercándose a finales del lunes con lluvia.
El Servicio Meteorológico Nacional en Phoenix señaló en un tuit que sólo "diez ciclones tropicales han mantenido el estado de tormenta tropical o depresión dentro de 200 millas de Phoenix desde 1950!
Katrina (1967) fue un huracán a 40 millas de la frontera con AZ".
Los últimos modelos del Centro Nacional de Huracanes predicen de 2 a 4 pulgadas de lluvia, con cantidades aisladas de hasta 6 pulgadas en el Rim Mogollon de Arizona.
Otras áreas del desierto Suroeste incluyendo las Rocosas centrales y la Gran Cuenca es probable que consigan 1 a 2 pulgadas, con totales aislados hasta 4 pulgadas posibles.
Para aquellos que están fuera del riesgo de inundaciones repentinas, la lluvia de Rosa puede ser una bendición ya que la región está afectada por la sequía.
Aunque las inundaciones son una preocupación muy grave, es probable que algunas de estas lluvias sean beneficiosas ya que el suroeste está experimentando actualmente condiciones de sequía.
Según el Monitor de Sequía de los Estados Unidos, poco más del 40 por ciento de Arizona está experimentando al menos sequía extrema, la segunda categoría más alta", informó Weather.com.
En primer lugar, el camino del huracán Rosa conduce a la caída de tierra a través de la península de Baja California de México.
Rosa, todavía con fuerza de huracán el domingo por la mañana con vientos máximos de 85 millas por hora, está a 385 millas al sur de Punta Eugenia, México y moviéndose al norte a 12 millas por hora.
La tormenta está encontrando aguas más frías en el Pacífico y por lo tanto se está apagando.
Por lo tanto, se espera que llegue a México con fuerza de tormenta tropical por la tarde o por la noche el lunes.
Las lluvias en partes de México podrían ser fuertes, lo que representaría un riesgo significativo de inundación.
"Se esperan totales de caídas de 3 a 6 pulgadas desde Baja California hasta el noroeste de Sonora, con hasta 10 pulgadas posibles", informó Weather.com.
Rosa seguirá hacia el norte a través de México como una tormenta tropical antes de llegar a la frontera de Arizona en las primeras horas de la mañana del martes como una depresión tropical, que luego rastreará a través de Arizona y hacia el sur de Utah a finales de la noche del martes.
"El principal peligro que se espera de Rosa o sus restos son lluvias muy fuertes en Baja California, el noroeste de Sonora, y el suroeste del desierto de EE.UU.", dijo el Centro Nacional de Huracanes.
Se espera que estas lluvias produzcan inundaciones repentinas que pongan en peligro la vida y derramen desechos en los desiertos, y deslizamientos de tierra en terrenos montañosos.
Ataque de Midsomer Norton: Cuatro intentos de arresto por asesinato
Tres adolescentes y un hombre de 20 años han sido arrestados bajo sospecha de intento de asesinato después de que un joven de 16 años fuera encontrado con heridas de arma blanca en Somerset.
El adolescente fue encontrado herido en el área de Excelsior Terrace de Midsomer Norton, alrededor de las 04:00 BST del sábado.
Fue llevado al hospital donde permanece en una condición "estable".
Un joven de 17 años, dos de 18 años y un hombre de 20 años fueron arrestados durante la noche en la zona de Radstock, dijeron Avon y la policía de Somerset.
Los oficiales han apelado por cualquiera que pueda tener cualquier grabación de teléfono móvil de lo que pasó para presentarse.
Trump dice que Kavanaugh "sufrió, la maldad, la ira" del Partido Demócrata
"Un voto por el juez Kavanaugh es un voto para rechazar las tácticas despiadadas e indignantes del Partido Demócrata", dijo Trump en una manifestación en Wheeling, Virginia Occidental.
Trump dijo que Kavanaugh ha "sufrido la maldad, la ira" del Partido Demócrata a lo largo de su proceso de nominación.
Kavanaugh testificó ante el Congreso el jueves, negando con fuerza y emocionalmente una alegación de Christine Blasey Ford de que la agredió sexualmente hace décadas cuando eran adolescentes.
Ford también testificó en la audiencia sobre su alegación.
El Presidente dijo el sábado que el "pueblo estadounidense vio la brillante y la calidad y el coraje" de Kavanaugh ese día.
"Un voto para confirmar que el juez Kavanaugh es un voto para confirmar una de las mentes legales más exitosas de nuestro tiempo, un jurista con un excelente historial de servicio público", dijo a la multitud de partidarios de Virginia Occidental.
El Presidente se refirió oblicuamente a la nominación de Kavanaugh mientras hablaba de la importancia de la participación republicana en las elecciones de mitad de período.
"A cinco semanas de una de las elecciones más importantes de nuestra vida.
No estoy corriendo, pero realmente estoy corriendo", dijo.
"Es por eso que estoy por todas partes luchando por grandes candidatos."
Trump argumentó que los demócratas están en una misión de "resista y obstruya".
Se espera que la primera votación de procedimiento clave en el Senado sobre la nominación de Kavanaugh tenga lugar a más tardar el viernes, dijo a CNN un asesor superior del GOP.
Cientos de muertos por el terremoto indonesio, el tsunami, y el número de víctimas aumenta
Al menos 384 personas murieron, muchas fueron arrastradas mientras las olas gigantes chocaban contra las playas, cuando un gran terremoto y tsunami golpeó la isla indonesia de Sulawesi, dijeron las autoridades el sábado.
Cientos de personas se habían reunido para una fiesta en la playa en la ciudad de Palu el viernes cuando las olas de hasta seis metros (18 pies) se estrellaron en tierra al atardecer, barriendo a muchos hasta su muerte y destruyendo cualquier cosa en su camino.
El tsunami siguió a un terremoto de magnitud 7,5.
"Cuando la amenaza del tsunami surgió ayer, la gente todavía estaba haciendo sus actividades en la playa y no corrió inmediatamente y se convirtieron en víctimas", dijo Sutopo Purwo Nugroho, portavoz de la agencia de mitigación de desastres BNPB de Indonesia en una reunión informativa en Yakarta.
"El tsunami no vino por sí solo, arrastró coches, troncos, casas, golpeó todo en tierra", dijo Nugroho, y agregó que el tsunami había viajado a través del mar abierto a velocidades de 800 km/h antes de golpear la costa.
Algunas personas subieron árboles para escapar del tsunami y sobrevivieron, dijo.
Alrededor de 16.700 personas fueron evacuadas a 24 centros en Palu.
Las fotografías aéreas publicadas por la agencia de desastres mostraban muchos edificios y tiendas destruidos, puentes torcidos y colapsados y una mezquita rodeada de agua.
Las réplicas continuaron sacudiendo la ciudad costera el sábado.
La serie de terremotos se sintió en un área con 2,4 millones de personas.
La Agencia Indonesiana para la Evaluación y Aplicación de la Tecnología (BPPT) dijo en declaración que la energía liberada por el terremoto masivo del viernes fue alrededor de 200 veces el poder de la bomba atómica lanzada sobre Hiroshima en la Segunda Guerra Mundial.
La geografía de la ciudad, que se encuentra al final de una bahía larga y estrecha, podría haber magnificado el tamaño del tsunami, dijo.
Nugroho describió el daño como "extenso" y dijo que miles de casas, hospitales, centros comerciales y hoteles se habían derrumbado.
Los cuerpos de algunas víctimas fueron encontrados atrapados bajo los escombros de edificios colapsados, dijo, añadiendo 540 personas heridas y 29 desaparecidas.
Nugroho dijo que las bajas y los daños podrían ser mayores a lo largo de la costa 300 km al norte de Palu, un área llamada Donggala, que está más cerca del epicentro del terremoto.
Las comunicaciones "estaban totalmente paralizadas sin información" de Donggala, dijo Nugroho.
Hay más de 300.000 personas viviendo allí", dijo la Cruz Roja en un comunicado, agregando que su personal y voluntarios se dirigían a las zonas afectadas.
"Esto ya es una tragedia, pero podría empeorar mucho", dijo.
La agencia fue ampliamente criticada el sábado por no informar que un tsunami había golpeado a Palu, aunque los funcionarios dijeron que las olas habían llegado en el momento en que se emitió la advertencia.
En las imágenes de aficionados compartidas en las redes sociales se puede escuchar a un hombre en el piso superior de un edificio gritando frenéticas advertencias sobre el tsunami que se acerca a la gente en la calle de abajo.
En cuestión de minutos una pared de agua se estrella en la orilla, llevando edificios y coches.
Reuters no pudo autenticar inmediatamente la grabación.
El terremoto y el tsunami causaron un corte de energía importante que cortó las comunicaciones alrededor de Palu haciendo difícil para las autoridades coordinar los esfuerzos de rescate.
Los militares han comenzado a enviar aviones de carga con ayuda de Yakarta y otras ciudades, dijeron las autoridades, pero los evacuados todavía necesitan alimentos y otras necesidades básicas.
El aeropuerto de la ciudad ha sido reabierto sólo para los esfuerzos de socorro y permanecerá cerrado hasta octubre.
El Presidente Joko Widodo tenía previsto visitar los centros de evacuación en Palu el domingo.
Indonesia El peaje del tsunami se eleva por encima de 800.
Es muy malo.
Mientras que el personal de World Vision de Donggala ha llegado con seguridad a la ciudad de Palu, donde los empleados se refugian en refugios de lona instalados en el patio de su oficina, pasaron escenas de devastación en el camino, dijo el Sr. Doseba.
"Me dijeron que vieron muchas casas que fueron destruidas", dijo.
Es muy malo.
Aun cuando los grupos de ayuda comenzaron los movimientos sombríos de poner en marcha los engranajes del socorro en casos de desastre, algunos se quejaron de que se impedía viajar a Palu a los trabajadores humanitarios extranjeros con gran experiencia.
Según las normas indonesias, la financiación, los suministros y la dotación de personal procedentes del extranjero sólo pueden comenzar a fluir si el lugar de una calamidad se declara zona de desastre nacional.
Eso no ha sucedido todavía.
"Sigue siendo un desastre a nivel de provincia", dijo Aulia Arriani, portavoz de la Cruz Roja de Indonesia.
"Una vez que el gobierno diga, "bien, esto es un desastre nacional", podemos abrirnos a la asistencia internacional, pero todavía no hay estatus".
Mientras la segunda noche caía sobre Palu después del terremoto y tsunami del viernes, amigos y familiares de los que seguían desaparecidos estaban sosteniendo la esperanza de que sus seres queridos serían los milagros que fermentarían las sombrías líneas de historia de los desastres naturales.
El sábado, un niño fue sacado de una alcantarilla.
El domingo, los rescatistas liberaron a una mujer que había estado atrapada bajo los escombros durante dos días con el cuerpo de su madre a su lado.
Gendon Subandono, el entrenador del equipo nacional indonesio de parapente, había entrenado a dos de los parapenteadores desaparecidos para los Juegos Asiáticos, que terminaron a principios de este mes en Indonesia.
Otros de los atrapados en el Hotel Roa Roa, incluido el Sr. Mandagi, eran sus estudiantes.
"Como senior en el campo de parapente, tengo mi propia carga emocional", dijo.
El Sr. Gendon relató cómo, en las horas posteriores al colapso del Hotel Roa Roa circulaba entre la comunidad de parapente, había enviado desesperadamente mensajes de WhatsApp a los competidores de Palu, que participaban en el festival de la playa.
Sus mensajes, sin embargo, sólo resultaron en una marca de verificación gris, en lugar de un par de cheques azules.
"Creo que eso significa que los mensajes no fueron entregados," dijo.
Los ladrones toman $26.750 durante la recarga de cajeros automáticos en Newport en el Levee
Los ladrones del viernes por la mañana robaron $26.750 de un trabajador de Brink recargando un cajero automático en Newport en el Levee, según un comunicado de prensa del Departamento de Policía de Newport.
El conductor del coche había estado vaciando un cajero automático en el complejo de entretenimiento y preparándose para entregar más dinero, Det. Dennis McCarthy escribió en el lanzamiento.
Mientras estaba ocupado, otro hombre "se levantó por detrás del empleado de Brink" y robó una bolsa de dinero destinada a la entrega.
Según la liberación, los testigos descubrieron a varios sospechosos que huían del lugar, pero la policía no especificó el número de personas involucradas en el incidente.
Cualquier persona con información sobre su identidad debe contactar con la policía de Newport al 859-292-3680.
Kanye West: Rapper cambia su nombre a Ye
El rapero Kanye West está cambiando su nombre a Ye.
Anunciando el cambio en Twitter el sábado, escribió: "El ser conocido formalmente como Kanye West".
West, de 41 años, ha sido apodado Ye durante algún tiempo y utilizó el apodo como título de su octavo álbum, que fue lanzado en junio.
El cambio se adelanta a su aparición en Saturday Night Live, donde se espera que lance su nuevo álbum Yandhi.
Reemplaza a la cantante Ariana Grande en el programa que canceló por "razones emocionales", dijo el creador del programa.
Además de ser una abreviatura de su nombre profesional actual, West ha dicho anteriormente que la palabra tiene significado religioso para él.
"Creo que 'ye' es la palabra más comúnmente usada en la Biblia, y en la Biblia significa 'ye'", dijo West a principios de este año, discutiendo su título de álbum con el presentador de radio Big Boy.
"Así que soy tú, yo somos nosotros, somos nosotros.
Pasó de Kanye, lo que significa el único, a sólo Ye - sólo siendo un reflejo de nuestro bien, nuestro mal, nuestro confuso, todo.
El álbum es más bien un reflejo de quiénes somos".
Es uno de los muchos raperos famosos por cambiar su nombre.
Sean Combs ha sido conocido como Puff Daddy, P. Diddy o Diddy, pero este año anunció su preferencia por los nombres Love y Brother Love.
Un ex-colaborador occidental, JAY-Z, también ha hecho con o sin guión y capitales.
AMLO de México promete no usar militares contra civiles
El presidente electo mexicano Andrés Manuel López Obrador ha prometido nunca usar la fuerza militar contra los civiles mientras el país se acerca al 50 aniversario de una sangrienta represalia contra los estudiantes.
López Obrador prometió el sábado en la Plaza Tlatelolco "nunca usar los militares para reprimir al pueblo mexicano".
Tropas dispararon contra una manifestación pacífica en la plaza el 2 de octubre de 1968, matando hasta 300 personas en un momento en que los movimientos estudiantiles de izquierda estaban arraigando en toda América Latina.
López Obrador se ha comprometido a apoyar a los jóvenes mexicanos dando subsidios mensuales a quienes estudian y abren universidades públicas más libres.
Ha dicho que el desempleo y la falta de oportunidades educativas atraen a los jóvenes a bandas criminales.
EE.UU. debería duplicar el financiamiento de IA.
A medida que China se vuelve más activa en la inteligencia artificial, EE.UU. debería duplicar la cantidad que gasta en investigación en el campo, dice el inversionista y practicante de IA Kai-Fu Lee, que ha trabajado para Google, Microsoft y Apple.
Los comentarios vienen después de que varias partes del gobierno de Estados Unidos han hecho anuncios de IA, incluso cuando Estados Unidos carece en general de una estrategia formal de IA.
Mientras tanto, China presentó su plan el año pasado: su objetivo es ser el número 1 en la innovación de la IA para 2030.
"Doble el presupuesto de investigación de IA sería un buen comienzo, dado que todos los demás países están mucho más lejos de Estados Unidos, y estamos buscando el próximo avance en IA", dijo Lee.
El doble financiamiento podría duplicar las posibilidades de que el próximo gran logro de IA se haga en los EE.UU., Lee le dijo a CNBC en una entrevista esta semana.
Lee, cuyo libro "AI Superpowers: China, Silicon Valley y el Nuevo Orden Mundial" fue publicado este mes por Houghton Mifflin Harcourt, es CEO de Sinovation Ventures, que ha invertido en una de las compañías de IA más destacadas de China, Face++.
En la década de 1980 en la Universidad Carnegie Mellon trabajó en un sistema de IA que venció al jugador de Otelo estadounidense más alto, y más tarde fue un ejecutivo en Microsoft Research y presidente de la rama china de Google.
Lee reconoció anteriores concursos de tecnología del gobierno de los EE.UU. como el Desafío Robótico de la Agencia de Proyectos de Investigación Avanzada de Defensa y preguntó cuándo sería el próximo, con el fin de ayudar a identificar a los próximos visionarios.
Los investigadores en los EE.UU. a menudo tienen que trabajar duro para ganar subvenciones del gobierno, dijo Lee.
"No es China la que está quitando a los líderes académicos; son las corporaciones", dijo Lee.
Facebook, Google y otras compañías tecnológicas han contratado luminarias de universidades para trabajar en IA en los últimos años.
Lee dijo que los cambios en la política de inmigración también podrían ayudar a Estados Unidos a reforzar sus esfuerzos de IA.
"Creo que las tarjetas verdes deberían ofrecerse automáticamente a los doctorados en IA", dijo.
El Consejo de Estado de China publicó su Plan de Desarrollo de Inteligencia Artificial de Próxima Generación en julio de 2017.
La Fundación Nacional de Ciencias Naturales de China proporciona fondos a personas en instituciones académicas similares a la forma en que la Fundación Nacional de Ciencias y otras organizaciones gubernamentales destinan dinero a investigadores estadounidenses, pero la calidad del trabajo académico es menor en China, dijo Lee.
A principios de este año, el Departamento de Defensa de Estados Unidos estableció un Centro Conjunto de Inteligencia Artificial, que está destinado a involucrar a socios de la industria y el mundo académico, y la Casa Blanca anunció la formación de un Comité Selecto de Inteligencia Artificial.
Y este mes DARPA anunció una inversión de $2 mil millones en una iniciativa llamada AI Next.
En cuanto a la NSF, actualmente invierte más de $100 millones al año en investigación de IA.
Mientras tanto, la legislación estadounidense que buscaba crear una Comisión de Seguridad Nacional sobre Inteligencia Artificial no ha visto acción en meses.
Los macedonios votan en referéndum sobre si cambiar el nombre del país
El pueblo de Macedonia votó en un referéndum el domingo sobre si cambiar su nombre a "República de Macedonia del Norte", una medida que resolvería una disputa de décadas de antigüedad con Grecia que había bloqueado sus ofertas de adhesión a la Unión Europea y la OTAN.
Grecia, que tiene una provincia llamada Macedonia, sostiene que el nombre de su vecino del norte representa una reclamación en su territorio y ha vetado su entrada en la OTAN y la UE.
Los dos gobiernos llegaron a un acuerdo en junio sobre la base del nuevo nombre propuesto, pero los opositores nacionalistas argumentan que el cambio socavaría la identidad étnica de la población mayoritaria eslava de Macedonia.
El presidente Gjorge Ivanov ha dicho que no va a votar en el referéndum y una campaña de boicot ha puesto en duda si la participación alcanzará el mínimo del 50 por ciento requerido para que el referéndum sea válido.
La pregunta en la votación del referéndum decía: "¿Está usted a favor de la OTAN y la adhesión a la UE con la aceptación del acuerdo con Grecia?"
Los partidarios del cambio de nombre, incluido el primer ministro Zoran Zaev, sostienen que es un precio que vale la pena pagar para perseguir la admisión en organismos como la UE y la OTAN para Macedonia, uno de los países que emerge del colapso de Yugoslavia.
"Hoy he venido a votar por el futuro del país, por los jóvenes de Macedonia para que puedan vivir libremente bajo el paraguas de la Unión Europea porque significa una vida más segura para todos nosotros", dijo Olivera Georgijevska, de 79 años, en Skopje.
Aunque no son jurídicamente vinculantes, suficientes parlamentarios han dicho que acatarán el resultado de la votación para hacerlo decisivo.
El cambio de nombre requeriría una mayoría de dos tercios en el parlamento.
La comisión electoral estatal dijo que no había habido informes de irregularidades a las 13.00 horas.
Sin embargo, la participación fue de sólo el 16 por ciento, en comparación con el 34 por ciento en las últimas elecciones parlamentarias en 2016, cuando el 66 por ciento de los votantes registrados emitieron su voto.
"Salí a votar por mis hijos, nuestro lugar está en Europa", dijo Gjose Tanevski, de 62 años, votante en la capital, Skopje.
El primer ministro de Macedonia, Zoran Zaev, su esposa Zorica y su hijo Dushko emitieron su voto para el referéndum en Macedonia sobre el cambio de nombre del país que abriría el camino para que se uniera a la OTAN y la Unión Europea en Strumica, Macedonia 30 de septiembre de 2018.
Frente al parlamento de Skopje, Vladimir Kavardarkov, de 54 años, estaba preparando un pequeño escenario y levantando sillas frente a las tiendas de campaña establecidas por los que boicotearán el referéndum.
"Estamos a favor de la OTAN y la UE, pero queremos unirnos con la cabeza en alto, no a través de la puerta de servicio", dijo Kavadarkov.
"Somos un país pobre, pero tenemos dignidad.
Si no quieren tomarnos como Macedonia, podemos recurrir a otros como China y Rusia y convertirnos en parte de la integración euroasiática".
El primer ministro Zaev dice que los miembros de la OTAN traerán inversiones muy necesarias a Macedonia, que tiene una tasa de desempleo de más del 20 por ciento.
"Creo que la gran mayoría estará a favor porque más del 80 por ciento de nuestros ciudadanos están a favor de la UE y la OTAN", dijo Zaev después de emitir su voto.
Dijo que un resultado "sí" sería la "confirmación de nuestro futuro".
Una encuesta publicada el lunes pasado por el Instituto de Investigación de Políticas de Macedonia dijo que entre el 30 y el 43 por ciento de los votantes participarían en el referéndum - por debajo de la participación requerida.
Otra encuesta, realizada por Telma TV de Macedonia, encontró el 57 por ciento de los encuestados que planean votar el domingo.
De ellos, el 70 por ciento dijo que votarían sí.
Para que el referéndum tenga éxito, la participación debe ser del 50 por ciento más un voto.
Un fracaso en el referéndum representaría el primer golpe serio a la política del gobierno prooccidental desde que asumió el control en mayo del año pasado.
Reloj: Sergio Aguero, de Manchester City, navega a través de toda la defensa de Brighton por gol
Sergio Aguero y Raheem Sterling enviaron de la defensa de Brighton en la victoria 2-0 de Manchester City el sábado en el Estadio Etihad en Manchester, Inglaterra.
Aguero lo hizo ver ridículamente fácil en su puntuación en el minuto 65.
El delantero argentino recibió un pase en medio campo al inicio de la secuencia.
Corrió entre tres defensores de Brighton, antes de entrar en campo abierto.
Aguero se encontró rodeado de cuatro camisas verdes.
Empujó alrededor de un defensor antes de superar a varios más en el borde de la caja de Brighton.
Luego empujó un pase a su izquierda, encontrando a Sterling.
El delantero inglés usó su primer toque en la caja para devolver la pelota a Aguero, quien usó su bota derecha para vencer al guardián de Brighton Mathew Ryan con un disparo en el lado derecho de la red.
"Aguero está luchando con algunos problemas en sus pies", dijo el gerente de la ciudad, Pep Guardiola, a los periodistas.
"Hablamos de él jugando 55, 60 minutos.
Eso es lo que pasó.
Tuvimos suerte de que anotó un gol en ese momento".
Pero fue Sterling quien le dio a los Sky Blues la ventaja inicial en la pelea de la Premier League.
Ese gol llegó en el minuto 29.
Aguero recibió la pelota en el territorio de Brighton en esa jugada.
Envió una hermosa bola a lo largo del flanco izquierdo a Leroy Sane.
Sane tomó algunos toques antes de llevar a Sterling hacia el poste lejano.
El Sky Blues hacia adelante golpeó la bola en la red justo antes de deslizarse fuera de los límites.
City batallas Hoffenheim en la Liga de Campeones juego de grupo a las 12:55 p.m. el martes en Rhein-Neckar-Arena en Sinsheim, Alemania.
Scherzer quiere jugar spoiler vs. Rockies
Con los Nacionales eliminados de la contienda de playoffs, no había mucha razón para forzar otro comienzo.
Pero el siempre competitivo Scherzer espera tomar el montículo el domingo contra los Rockies de Colorado, pero sólo si todavía hay implicaciones de playoff para los Rockies, que tienen una ventaja de un juego sobre los Dodgers de Los Ángeles en el NL West.
Los Rockies lograron al menos un comodín con una victoria de 5-2 sobre los Nacionales el viernes por la noche, pero todavía están buscando cerrar su título de primera división.
"A pesar de que estamos jugando por nada, al menos podemos ser capaces de tocar el caucho sabiendo que la atmósfera aquí en Denver con la multitud y el otro equipo estaría jugando al más alto nivel de cualquier punto que me gustaría enfrentar este año.
¿Por qué no querría competir en eso?"
Los Nacionales todavía no han anunciado un comienzo para el domingo, pero se dice que están inclinados a dejar que Scherzer lanzar en tal situación.
Scherzer, que estaría haciendo su 34o comienzo, lanzó una sesión de bullpen el jueves y estaría lanzando en su descanso normal el domingo.
La derecha de Washington es 18-7 con una efectividad de 2.53 y 300 ponches en 220 2/3 entradas esta temporada.
Manifestaciones de Trump en Virginia Occidental
El Presidente se refirió oblicuamente a la situación que rodeaba a su elección por la Corte Suprema de Brett Kavanaugh mientras hablaba de la importancia de la participación republicana en las elecciones de mitad de período.
"Todo lo que hemos hecho está en juego en noviembre.
A cinco semanas de una de las elecciones más importantes de nuestra vida.
Este es uno de los grandes, grandes -- no estoy corriendo, pero realmente estoy corriendo por eso estoy por todas partes luchando por grandes candidatos", dijo.
Trump continuó: "Ves a este horrible, horrible grupo radical de demócratas, lo ves sucediendo ahora mismo.
Y están decididos a recuperar el poder mediante el uso de cualquier medio necesario, se ve la mezquindad, la maldad.
No les importa a quién hieren, a quién tienen que atropellar para obtener poder y control, eso es lo que quieren es poder y control, no se lo vamos a dar".
Los demócratas, dijo, están en una misión de "resistir y obstruir".
"Y se ve que en los últimos cuatro días", dijo, llamando a los demócratas "enfadado y malvado y desagradable y falso".
Se refirió al Comité Judicial del Senado que clasificaba a la senadora demócrata Dianne Feinstein por su nombre, que recibió ruidosos abucheos de la audiencia.
"¿Recuerdas su respuesta?
¿Has filtrado el documento?
Uh, uh, qué.
No, no, espero que uno - que era realmente mal lenguaje corporal - el peor lenguaje corporal que he visto en mi vida."
El trabajo ya no es una iglesia amplia.
Es intolerante con los que dicen lo que piensan.
Cuando los activistas de Momentum en mi partido local votaron para censurarme, no fue una sorpresa.
Después de todo, soy el último en una línea de parlamentarios laboristas en ser dicho que no somos bienvenidos - todo por decir nuestras mentes.
Mi colega parlamentaria Joan Ryan recibió un trato similar porque se enfrentó resueltamente al antisemitismo.
En mi caso, la moción de censura me criticó por no estar de acuerdo con Jeremy Corbyn.
Sobre la importancia de una política económica responsable, sobre la seguridad nacional, sobre Europa, cuestiones irónicamente similares en las que Jeremy no estaba de acuerdo con los líderes anteriores.
El anuncio para la reunión de Nottingham East Labour el viernes declaró que "queremos que las reuniones sean inclusivas y productivas".
Durante la mayor parte de mis ocho años como diputado laborista local, las reuniones del CG del viernes por la noche han sido exactamente eso.
Lamentablemente, hoy en día no es el tono de muchas reuniones y la promesa de una política "más amable y más amable" se ha olvidado por mucho tiempo si, de hecho, comenzó alguna vez.
Cada vez es más evidente que en el Partido Laborista no se toleran opiniones divergentes y todas las opiniones se juzgan en función de si son aceptables para la dirección del partido.
Esto comenzó poco después de que Jeremy se convirtió en líder, Como colegas con los que había pensado anteriormente que compartía una perspectiva política similar, empecé a esperar que hiciera un giro en U y a tomar posiciones con las que nunca hubiera estado de acuerdo, ya sea en materia de seguridad nacional o del mercado único de la UE.
Cada vez que hablo públicamente -y realmente no importa lo que diga- hay una diatriba de abuso en las redes sociales que pide la deselección, denunciando la política del centro, diciéndome que no debería estar en el Partido Laborista.
Y esa no es sólo mi experiencia.
De hecho, sé que soy más afortunado que algunos de mis colegas, ya que los comentarios dirigidos a mí tienden a ser políticos.
Me asombra el profesionalismo y la determinación de aquellos colegas que se enfrentan a un torrente de abusos sexistas o racistas todos los días, pero nunca rehúyen.
Uno de los aspectos más decepcionantes de esta era de la política es cómo los niveles de abuso se han normalizado.
Jeremy Corbyn afirmó la semana pasada que el Partido Laborista debería fomentar una cultura de tolerancia.
La realidad es que ya no somos esa iglesia amplia y con cada movimiento de "no confianza" o cambio de reglas de selección el partido se vuelve más estrecho.
He tenido muchos consejos en los últimos dos años instándome a mantener la cabeza baja, a no ser tan vocal y entonces "estaría bien".
Pero eso no es lo que vine a hacer en la política.
Desde que me uní al Laborismo hace 32 años como alumno escolar, provocado por la negligencia del gobierno de Thatcher que había dejado mi aula de la escuela completa literalmente cayendo, he tratado de defender mejores servicios públicos para aquellos que más los necesitan, ya sea como concejal local o ministro del gobierno.
Nunca he ocultado mi política, incluso en las últimas elecciones.
Nadie en Nottingham Este podría haber sido confundido de ninguna manera acerca de mis posiciones políticas y áreas de desacuerdo con el liderazgo actual.
A los que promovieron la moción el viernes, Todo lo que diría es que cuando el país está arado hacia un Brexit que perjudicará a los hogares, las empresas y nuestros servicios públicos, no entiendo el deseo de perder tiempo y energía en mi lealtad al líder del Partido Laborista.
Pero realmente el único mensaje que tengo no es para Nottingham Momentum, es para mis electores, sean o no miembros laboristas: Estoy orgulloso de servirle y prometo que ninguna cantidad de amenazas de deselección o conveniencia política me disuadirá de actuar en lo que creo que son los mejores intereses de todos ustedes.
Chris Leslie es diputado de Nottingham East
Ayr 38 - 17 Melrose: Unbeaten Ayr go top
Dos intentos tardíos pueden haber sesgado un poco el resultado final, pero no hay duda de que Ayr merecía triunfar en este maravilloso encuentro de Tennent's Premiership del día.
Ahora encabezan la mesa, el único lado invicto de los diez.
Al final, fue su defensa superior, tanto como su mejor oportunidad, que llevó el lado de casa y entrenador Peter Murchie tenía todo el derecho a estar complacido.
"Hemos sido probados en nuestros juegos hasta ahora, y todavía estamos invictos, así que tengo que ser feliz", dijo.
Robyn Christie de Melrose dijo: "Crédito a Ayr, se arriesgaron mejor que nosotros".
El intento de 14 minutos de Grant Anderson, convertido por Frazier Climo, puso a Ayr al frente, pero, una tarjeta amarilla para la gorra de Escocia Rory Hughes, lanzada para el juego por Warriors, permitió a Melrose hacer que los números contaran y Jason Baggot tomó un intento no converso.
Climo estiró la ventaja de Ayr con una penalización, antes, justo en el medio tiempo, anotó luego convirtió un solo tratar de hacerlo 17-5 a Ayr en el descanso.
Pero Melrose comenzó la segunda mitad bien y el intento de Patrick Anderson, convertido por Baggot, redujo el margen de maniobra a cinco puntos.
Hubo entonces un largo atraco por una lesión grave a Ruaridh Knott, que fue estirado, y desde el reinicio, Ayr subió más adelante a través de un intento de Stafford McDowall, convertido por Climo.
El capitán en funciones de Ayr, Blair Macpherson, tenía una tarjeta amarilla, y de nuevo, Melrose hizo que el hombre de más pagara con un intento de Bruce Colvine no convertido, al final de un hechizo de feroz presión.
El lado de casa regresó, sin embargo, y cuando Struan Hutchinson estaba amarillento por hacer frente a Climo sin la pelota, desde la línea de penalti, MacPherson aterrizó en la parte posterior de la avanzada Ayr maul.
Climo se convirtió, como lo hizo de nuevo casi desde el reinicio, después de Kyle Rowe reunió la patada de la caja de David Armstrong y envió a flanger Gregor Henry para el quinto intento de la casa.
Still Game Star busca una nueva carrera en la industria de restaurantes
La estrella del juego, Ford Kieran, parece que se mudará a la industria de la hospitalidad después de descubrirse que ha sido nombrado director de una compañía de restaurantes con licencia.
El joven de 56 años interpreta a Jack Jarvis en el popular programa de la BBC, que escribe y co-protagoniza con Greg Hemphill, compañero de comedia desde hace mucho tiempo.
El dúo ha anunciado que la novena serie será la final en la carrera de la serie, y parece que Kiernan está planeando para toda la vida después de Craiglang.
Según los registros oficiales, es el director de Adriftmorn Limited.
El actor se negó a comentar la historia, aunque una fuente de Scottish Sun insinuó que Kiernan estaba buscando involucrarse en el "emocionante comercio de restaurantes" de Glasgow.
'El mar es nuestro': Bolivia sin litoral espera que la corte reabra el camino hacia el Pacífico
Los marineros patrullan un cuartel general de la Marina en La Paz.
Los edificios públicos ondean una bandera azul-océano.
Las bases navales desde el lago Titicaca hasta el Amazonas están salpicadas con el lema: "El mar es nuestro por la derecha.
Recuperarlo es un deber".
A lo largo de toda Bolivia sin litoral, la memoria de una costa perdida por Chile en un sangriento conflicto de recursos del siglo XIX sigue viva, al igual que el anhelo de navegar por el Océano Pacífico una vez más.
Esas esperanzas se encuentran quizás en su punto más alto en décadas, ya que Bolivia espera una decisión de la Corte Internacional de Justicia el 1o de octubre después de cinco años de deliberaciones.
"Bolivia tiene el impulso, un espíritu de unidad y serenidad, y por supuesto espera con una visión positiva el resultado", dijo Roberto Calzadilla, diplomático boliviano.
Muchos bolivianos verán el fallo de la Corte Internacional de Justicia en grandes pantallas por todo el país, con la esperanza de que el tribunal de La Haya encuentre a favor de la afirmación de Bolivia de que, después de décadas de conversaciones aptas, Chile está obligado a negociar la concesión a Bolivia de una salida soberana al mar.
Evo Morales, el carismático presidente indígena de Bolivia -que enfrenta una controvertida batalla por la reelección el próximo año- también tiene mucho que ver con el fallo del lunes.
"Estamos muy cerca de regresar al Océano Pacífico", prometió a finales de agosto.
Pero algunos analistas creen que es poco probable que la corte decida a favor de Bolivia - y que poco cambiaría si lo hiciera.
El organismo de las Naciones Unidas con sede en los Países Bajos no tiene poder para otorgar territorio chileno, y ha estipulado que no determinará el resultado de posibles conversaciones.
Que el fallo de la Corte Internacional de Justicia llegue sólo seis meses después de que se escucharan los argumentos finales indica que el caso "no fue complicado", dijo Paz Zárate, experta chilena en derecho internacional.
Y lejos de promover la causa de Bolivia, los últimos cuatro años pueden haberla retrasado.
"El tema del acceso al mar ha sido secuestrado por la actual administración boliviana", dijo Zárate.
La retórica beligerante de Morales ha socavado cualquier buena voluntad chilena residual, sugirió.
Bolivia y Chile seguirán hablando en algún momento, pero será extremadamente difícil mantener discusiones después de esto.
Los dos países no han intercambiado embajadores desde 1962.
El ex presidente Eduardo Rodríguez Veltzé, representante de Bolivia en La Haya, rechazó la idea de que la toma de decisiones de la corte fuera inusualmente rápida.
El lunes traerá a Bolivia "una oportunidad extraordinaria para abrir una nueva era de relaciones con Chile" y una oportunidad para "poner fin a 139 años de desacuerdos con beneficios mutuos", dijo.
Calzadilla también negó que Morales, todavía uno de los presidentes más populares de América Latina, estuviera usando el tema marítimo como muleta política.
"Bolivia nunca renunciará a su derecho a tener acceso al Océano Pacífico", agregó.
"El fallo es una oportunidad para ver que necesitamos superar el pasado".
Corea del Norte dice que el desarme nuclear no vendrá a menos que pueda confiar en EE.UU.
El ministro de Relaciones Exteriores de Corea del Norte, Ri Yong Ho, dice que su nación nunca desarmará sus armas nucleares primero si no puede confiar en Washington.
Ri habló el sábado en la Asamblea General de las Naciones Unidas.
Hizo un llamamiento a los Estados Unidos para que cumplieran las promesas hechas durante una cumbre en Singapur entre los líderes de los rivales.
Sus comentarios vienen como EE.UU.. El Secretario de Estado Mike Pompeo parece estar a punto de reiniciar la diplomacia nuclear estancada más de tres meses después de Singapur con Kim Jong Un de Corea del Norte.
Ri dice que es un "sueño de tubería" que las sanciones continuas y la objeción de Estados Unidos a una declaración que ponga fin a la guerra de Corea pondrán al Norte de rodillas.
Washington es cauteloso de aceptar la declaración sin que Pyongyang haga primero importantes iniciativas de desarme.
Tanto Kim como el presidente estadounidense Donald Trump quieren una segunda cumbre.
Pero hay un escepticismo generalizado de que Pyongyang es serio en cuanto a renunciar a un arsenal que el país probablemente ve como la única manera de garantizar su seguridad.
Pompeo planea visitar Pyongyang el próximo mes para prepararse para una segunda cumbre Kim-Trump.
Los desfiles de moda de París revelan la última línea de ropa de cabeza masiva en su camino a una High Street cerca de usted
Si quieres aumentar el tamaño de tu colección de sombreros o bloquear completamente el sol, entonces no busques más.
Los diseñadores Valentino y Thom Browne dieron a conocer una serie de engranajes de gran tamaño para su colección TC19 en la pista que deslumbraba el estilo ambientado en la Paris Fashion Week.
Sombreros altamente poco prácticos han barrido Instagram este verano y estos diseñadores han enviado sus creaciones impresionantes por la pasarela.
La pieza destacada de Valentino era un sombrero de color beige adornado con un borde ancho parecido a una pluma que inundaba las cabezas de los modelos.
Otros accesorios de gran tamaño incluyen sandías bejewelled, un sombrero de mago e incluso una piña - pero no están diseñados para mantener la cabeza caliente.
Thom Browne también reveló una selección de máscaras extrañas- y justo a tiempo para Halloween.
Muchas de las coloridas máscaras habían cosido los labios y se parecían más a Hannibal Lecter que a la alta costura.
Una creación se parecía al equipo de buceo completo con snorkel y gafas, mientras que otra parecía un cono de helado derretido.
Y si continúas con la gran declaración de moda... estás de suerte.
Los observadores de estilo predicen que los enormes capós podrían estar llegando a las calles altas cerca de ti.
Los sombreros de tamaño grande vienen calientes en los talones de 'La Bomba', el sombrero de paja con un borde de dos pies de ancho que se ha visto en todos los de Rihanna a Emily Ratajkowski.
La etiqueta de culto detrás del sombrero altamente poco práctico que fue salpicado a través de las redes sociales envió otra gran creación por la pasarela - una bolsa de playa de paja casi tan grande como el modelo vestido de traje de baño que lo cubre.
La bolsa de rafia anaranjada, recortada con fringing de rafia y rematada con un mango de cuero blanco, fue la pieza destacada de la colección La Riviera SS19 de Jacquemus en la Paris Fashion Week.
El estilista de famosos Luke Armitage le dijo a FEMAIL: "Estoy esperando ver grandes sombreros y bolsas de playa llegar a la calle para el próximo verano - ya que el diseñador ha hecho un impacto tan enorme que sería difícil ignorar la demanda de los accesorios de gran tamaño."
John Edward: Las habilidades lingüísticas son esenciales para los ciudadanos globales
Las escuelas independientes de Escocia mantienen un historial de excelencia académica, y esto ha continuado en 2018 con otro conjunto de excelentes resultados del examen, que sólo se ve fortalecido por el éxito individual y colectivo en el deporte, el arte, la música y otros esfuerzos comunitarios.
Con más de 30.000 alumnos en Escocia, estas escuelas, representadas por el Consejo Escocés de Escuelas Independientes (SCIS), se esfuerzan por ofrecer el mejor nivel de servicio a sus alumnos y padres.
Las escuelas independientes tienen como objetivo preparar a sus alumnos para la educación superior y superior, su carrera elegida y su lugar como ciudadanos mundiales.
Como sector educativo que puede diseñar e implementar un currículo escolar a medida, estamos viendo que las lenguas modernas continúan como un tema popular y deseado de elección dentro de las escuelas.
Nelson Mandela dijo: "Si hablas con un hombre en un idioma que él entiende, eso se le sube a la cabeza.
Si usted habla con él en su propio idioma que va a su corazón."
Este es un recordatorio poderoso de que no podemos simplemente confiar en el inglés cuando queremos construir relaciones y confianza con personas de otros países.
A partir de los recientes resultados del examen de este año, podemos ver que los idiomas están superando las tablas de la liga con las tasas de aprobación más altas dentro de las escuelas independientes.
El 68% de los alumnos que estudiaron idiomas extranjeros obtuvieron un grado A superior.
Los datos, recopilados de las 74 escuelas miembros del SCIS, muestran que el 72% de los estudiantes obtuvieron un grado A superior en mandarín, mientras que el 72% de los que estudiaban alemán, el 69% de los que estudiaban francés y el 63% de los que estudiaban español también obtuvieron una A.
Esto demuestra que las escuelas independientes de Escocia apoyan las lenguas extranjeras como habilidades vitales que los niños y los jóvenes sin duda necesitarán en el futuro.
Actualmente, los idiomas, como asignatura optativa, se celebran en el mismo sentido que las asignaturas STEM (ciencia, tecnología, ingeniería y matemáticas) en los programas escolares independientes y en otros lugares.
Una encuesta realizada por la Comisión del Reino Unido para el Empleo y las Capacidades en 2014 reveló que, por las razones que dieron los empleadores para luchar por cubrir las vacantes, el 17% se atribuyó a una escasez de conocimientos lingüísticos.
Por lo tanto, cada vez más, los conocimientos lingüísticos se están volviendo imperativos para preparar a los jóvenes para sus carreras futuras.
Con más posibilidades de empleo que requieren idiomas, estas competencias son esenciales en un mundo globalizado.
Independientemente de la carrera que alguien elija, si han aprendido un segundo idioma, tendrán una verdadera ventaja en el futuro teniendo una habilidad de por vida como esta.
Ser capaz de comunicarse directamente con personas de países extranjeros automáticamente pondrá a una persona multilingüe por delante de la competencia.
Según una encuesta de YouGov de más de 4.000 adultos del Reino Unido en 2013, el 75% no podía hablar un idioma extranjero lo suficientemente bien como para mantener una conversación y con el francés como único idioma hablado por un porcentaje de dos dígitos, el 15%.
Esta es la razón por la que invertir en la enseñanza de idiomas ahora es importante para los niños de hoy.
Tener múltiples idiomas, en particular los de las economías en desarrollo, dotará a los niños de mayores posibilidades de encontrar un empleo significativo.
Dentro de Escocia, cada escuela difiere en los idiomas que enseña.
Varias escuelas se centrarán en las lenguas modernas más clásicas, mientras que otras enseñarán lenguas que se consideran más importantes para el Reino Unido a la hora de mirar hacia 2020, como el mandarín o el japonés.
Cualquiera que sea el interés de su hijo, siempre habrá un número de idiomas para elegir dentro de las escuelas independientes, con el personal docente que son especialistas en esta área.
Las escuelas escocesas independientes se dedican a proporcionar un entorno de aprendizaje que prepare a los niños y los arme con las habilidades necesarias para tener éxito, sea cual sea el futuro.
No se puede negar en este momento, en un entorno empresarial global, que los idiomas siguen siendo de vital importancia para el futuro del país, por lo que esto debe reflejarse en la educación.
De hecho, los lenguajes modernos realmente deben ser considerados "habilidades de comunicación internacional".
Las escuelas independientes seguirán ofreciendo esta opción, diversidad y excelencia a los jóvenes escoceses.
Il faut bien le faire.
John Edward es Director del Consejo Escocés de Escuelas Independientes
LeBron hará el debut de los Lakers el domingo en San Diego
La espera está a punto de terminar para los fans que buscan ver a LeBron James hacer su primer comienzo para los Los Angeles Lakers.
El entrenador de Lakers Luke Walton ha anunciado que James jugará en la apertura de la pretemporada del domingo contra los Denver Nuggets en San Diego.
Pero aún no se ha determinado cuántos minutos va a jugar.
"Será más de uno y menos de 48", dijo Walton en el sitio web oficial de los Lakers.
Mike Trudell, reportero de Lakers, tuiteó que James probablemente jugará minutos limitados.
Siguiendo la práctica a principios de esta semana, James fue preguntado acerca de sus planes para los Lakers "seis juegos de programación pretemporada.
"No necesito juegos de pretemporada en esta etapa de mi carrera para prepararme", dijo.
Tiempo del Rally de Virginia Occidental de Trump, Canal de YouTube
El presidente Donald Trump comienza una oleada de mítines de campaña esta noche en Wheeling, Virginia Occidental.
Es el primero de los cinco rallyes programados de Trump en la próxima semana, incluyendo paradas en lugares amistosos como Tennessee y Mississippi.
Con el voto de confirmación en espera para su elección para llenar la vacante de la Corte Suprema, Trump está tratando de construir apoyo para las próximas elecciones de mitad de período ya que los republicanos están en riesgo de perder el control del Congreso cuando se emitan los votos en noviembre.
¿A qué hora es la manifestación de Trump en West Virginia esta noche y cómo se ve en línea?
El mitin de Trump Wheeling, West Virginia está programado para las 7 p.m. ET esta noche, sábado 29 de septiembre de 2018.
Puedes ver el mitin de Trump en West Virginia online a continuación a través del streaming en vivo en YouTube.
Es probable que Trump aborde las audiencias de esta semana para el candidato de la Corte Suprema Brett Kavanaugh, que se puso tenso por acusaciones de mala conducta sexual con una esperada votación de confirmación del Senado en espera de hasta una semana mientras el FBI investiga.
Pero el objetivo principal de esta oleada de mítines es ayudar a los republicanos que se enfrentan a las elecciones de noviembre a ganar algo de impulso.
Por lo tanto, la campaña del presidente Trump dijo que estos cinco mítines de la próxima semana están dirigidos a "energizar a voluntarios y partidarios mientras los republicanos tratan de proteger y expandir las mayorías que tienen en el Senado y la Cámara de Representantes", según Reuters.
"El control del Congreso es tan crítico para su agenda que el presidente viajará a tantos estados como sea posible en la temporada de campaña", dijo a Reuters un portavoz de la campaña de Trump que se negó a ser nombrado.
Programado para Wesbanco Arena en Wheeling, el mitin de esta noche podría traer seguidores de "Ohio y Pennsylvania y obtener cobertura de los medios de comunicación de Pittsburgh", según el West Virginia Metro News.
El sábado será la segunda vez en el último mes que Trump ha visitado Virginia Occidental, el estado que ganó por más de 40 puntos porcentuales en 2016.
Trump está tratando de ayudar al candidato al Senado Republicano de Virginia Occidental Patrick Morrisey, que está a la zaga en las encuestas.
"No es una buena señal para Morrisey que el presidente tenga que venir a tratar de darle un impulso en las encuestas", dijo Simon Haeder, politólogo de la Universidad de West Virginia, según Reuters.
Ryder Cup 2018: El equipo de EE.UU. muestra estómago por la lucha para mantener vivas las esperanzas que se dirigen a los solteros del domingo
Después de tres sesiones parciales, los cuartetos del sábado por la tarde podrían haber sido lo que esta Copa Ryder necesitaba.
El péndulo oscilante del impulso es un concepto deportivo completamente inventado pero en el que los jugadores realmente creen, y nunca más que en competiciones como estas.
Entonces, ¿dónde dirían que está el impulso ahora?
"Tenían una ventaja de seis puntos y ahora son cuatro, así que supongo que estamos llevando eso como un poco de impulso", dijo Jordan Spieth mientras se paseaba por el día.
Europa tiene la ventaja, por supuesto, de cuatro puntos por delante con doce más en juego.
Los americanos, como dice Spieth, sienten que tienen un poco de viento en sus velas y tienen mucho que ser alentados por, no menos importante la forma de Spieth y Justin Thomas que jugaron juntos todo el día y cada uno se jacta de tres puntos de cuatro.
Spieth ha sido letal de tee a green y está liderando con el ejemplo.
Esos gritos guturales de celebración se hicieron más fuertes a medida que su ronda continuaba, hundiendo un putt crucial para tomar partido cuatro todo-cuadrado cuando él y Thomas habían estado dos abajo después de dos.
Su putt que les ganó el partido en 15 fue encontrado con un grito similar, el tipo que le dice que cree que el equipo americano no está fuera de esto.
"Realmente tienes que cavar profundo y preocuparte por tu propio partido", dijo Spieth.
Es todo lo que cada uno de estos jugadores ha dejado ahora.
18 hoyos para hacer una marca.
Los únicos jugadores con más puntos que Spieth y Thomas en los últimos dos días son Francesco Molinari y Tommy Fleetwood, la historia indiscutible de la Ryder Cup.
La pareja extraña pero adorable de Europa son cuatro de cuatro y no puede hacer nada malo.
"Moliwood" eran los únicos que no disparaban a un bogey el sábado por la tarde, pero también evitaban los bogeys el sábado por la mañana, el viernes por la tarde y las nueve traseras el viernes por la mañana.
Esa carrera, y la forma en que su energía parece fluir tanto hacia y desde esta multitud bulliciosa cementos que son los jugadores para vencer el domingo, y no habría jugador más popular para sellar una posible victoria europea mientras el sol se pone sobre Le Golf National que Fleetwood o Molinari.
Preferiblemente ambos simultáneamente en diferentes agujeros.
Sin embargo, hablar de gloria europea sigue siendo prematuro.
Bubba Watson y Webb Simpson hicieron un corto trabajo de Sergio García, el héroe de cuatro bolas de la mañana, cuando se emparejaron con Alex Noren.
Un bogey y dos dobles en el frente nueve cavó el español y el sueco en un agujero del que nunca se acercaron a salir.
El domingo, sin embargo, no hay nadie que te ayude a salir de tu agujero.
Las cuatro bolas y los cuartetos son tan fascinantes de ver de cerca debido a las interacciones entre los emparejamientos, los consejos que dan, los consejos que no dan y la forma en que una estrategia puede cambiar en un instante.
Europa ha jugado mejor como equipo hasta ahora y tiene una ventaja significativa en el último día, pero esta sesión de cuartetos también demostró que Team USA tiene el estómago para la lucha que algunos, especialmente Stateside, habían estado dudando.
Europa toma 10-6 ventaja en Ryder Cup último día
Europa tomará una ventaja saludable en el último día de la Ryder Cup después de emerger de los partidos de cuatro bolas y cuartetos del sábado con una ventaja de 10-6 sobre los Estados Unidos.
El dúo inspirado Tommy Fleetwood y Francesco Molinari lideraron el ataque con dos victorias sobre un Tiger Woods en lucha para llevar su cuenta hasta ahora en Le Golf National a cuatro puntos.
El lado europeo de Thomas Bjorn, con la oferta de retener el trofeo que perdieron en Hazeltine hace dos años, dominó a un lado estadounidense en las cuatro bolas de la mañana, tomando la serie 3-1.
Estados Unidos ofreció más resistencia en los cuartetos, ganando dos partidos, pero no pudieron comer en el déficit.
El lado de Jim Furyk necesita ocho puntos de los partidos de los 12 sencillos del domingo para retener el trofeo.
Fleetwood es el primer novato europeo en ganar cuatro puntos seguidos, mientras que él y Molinari, apodados "Molliwood" después de un fin de semana sensacional son sólo el segundo par en ganar cuatro puntos de sus cuatro primeros partidos en la historia de la Ryder Cup.
Después de haber aplastado Woods y Patrick Reed en las cuatro bolas que luego geled magníficamente para vencer a un desinflado Woods y novato estadounidense Bryson Dechambeau por un 5&4 aún más enfático.
Woods, que se arrastró a través de dos partidos el sábado, mostró estallidos ocasionales de brillantez, pero ahora ha perdido 19 de sus 29 partidos en cuatro bolas y cuartetos y siete en una fila.
Justin Rose, descansó para las cuatro bolas de la mañana, regresó al compañero Henrik Stenson en los cuartetos a una derrota de 2 & 1 de Dustin Johnson y Brooks Koepka - clasificado uno y tres en el mundo.
Europa no lo tenía a su manera aunque en un día agradable, breezy al suroeste de París.
El tres veces ganador principal Jordan Spieth y Justin Thomas establecieron el punto de referencia para los estadounidenses con dos puntos el sábado.
Ganaron una arenosa victoria 2 & 1 sobre Jon Rahm e Ian Poulter de España en las cuatro bolas y regresaron más tarde para vencer a Poulter y Rory McIlroy 4 & 3 en los cuartetos habiendo perdido los dos agujeros de apertura.
Sólo dos veces en la historia de la Ryder Cup ha vuelto un equipo de un déficit de cuatro puntos en los sencillos, aunque como titulares el lado de Furyk sólo necesita dibujar para retener el trofeo.
Sin embargo, después de ser el segundo mejor durante dos días, un contraataque dominical parece estar más allá de ellos.
Corea del Norte dice que "ninguna manera" se desarmará unilateralmente sin confianza
El ministro de Relaciones Exteriores de Corea del Norte dijo el sábado a las Naciones Unidas que las continuas sanciones estaban profundizando su desconfianza en los Estados Unidos y que no había manera de que el país renunciara unilateralmente a sus armas nucleares en tales circunstancias.
Ri Yong Ho dijo a la Asamblea General anual del organismo mundial que Corea del Norte había tomado "medidas significativas de buena voluntad" en el último año, como detener los ensayos nucleares y de misiles, desmantelar el polígono de ensayos nucleares y comprometerse a no proliferar las armas nucleares y la tecnología nuclear.
"Sin embargo, no vemos ninguna respuesta correspondiente de Estados Unidos", dijo.
"Sin ninguna confianza en Estados Unidos no habrá confianza en nuestra seguridad nacional y en tales circunstancias no hay manera de que nos desarmaremos unilateralmente primero".
Mientras Ri repitió las conocidas quejas de Corea del Norte sobre la resistencia de Washington a un enfoque "faseado" de la desnuclearización bajo el cual Corea del Norte sería recompensada al dar pasos graduales, su declaración parecía significativa en el sentido de que no rechazaba la desnuclearización unilateral fuera de control como lo ha hecho Pyongyang en el pasado.
Ri se refirió a una declaración conjunta emitida por Kim Jong Un y Donald Trump en una primera cumbre entre un presidente estadounidense en servicio y un líder norcoreano en Singapur el 12 de junio. cuando Kim se comprometió a trabajar hacia la "desnuclearización de la península de Corea", mientras que Trump prometió garantías de seguridad de Corea del Norte.
Corea del Norte ha estado buscando un fin formal a la Guerra de Corea de 1950-53, pero los Estados Unidos han dicho que Pyongyang debe renunciar a sus armas nucleares primero.
Washington también se ha resistido a los llamamientos para relajar las duras sanciones internacionales contra Corea del Norte.
"Estados Unidos insiste en la "desnuclearización primero" y aumenta el nivel de presión mediante sanciones para lograr su propósito de manera coercitiva, e incluso objetando la "declaración del fin de la guerra", dijo Ri.
"La percepción de que las sanciones pueden llevarnos de rodillas es un sueño de la gente que es ignorante acerca de nosotros.
Pero el problema es que las continuas sanciones están profundizando nuestra desconfianza".
Ri no mencionó los planes para una segunda cumbre entre Kim y Trump que el líder estadounidense destacó en las Naciones Unidas a principios de semana.
En cambio, el ministro destacó tres reuniones entre Kim y el líder surcoreano Moon Jae-in en los últimos cinco meses y añadió: "Si el partido en este tema de la desnuclearización fuera Corea del Sur y no Estados Unidos, la desnuclearización de la península de Corea no habría llegado a tal punto muerto".
Aun así, el tono del discurso de Ri fue dramáticamente diferente al del año pasado, cuando le dijo a la Asamblea General de las Naciones Unidas que atacar a Estados Unidos con cohetes de Corea del Norte era inevitable después de que el "Presidente Malvado" Trump llamara a Kim un "hombre de cohetes" en una misión suicida.
Este año, en las Naciones Unidas, Trump, quien el año pasado amenazó con "destruir totalmente" a Corea del Norte, alabó a Kim por su valentía al tomar medidas para desarmarse, pero dijo que aún quedaba mucho trabajo por hacer y que las sanciones debían mantenerse hasta que Corea del Norte se desnuclearizara.
El miércoles, Trump dijo que no tenía un marco de tiempo para esto, diciendo "Si toma dos años, tres años o cinco meses - no importa".
China y Rusia sostienen que el Consejo de Seguridad de las Naciones Unidas debería recompensar a Pyongyang por las medidas adoptadas.
Sin embargo, el Secretario de Estado de Estados Unidos, Mike Pompeo, dijo el jueves al Consejo de Seguridad de las Naciones Unidas: "La aplicación de las sanciones del Consejo de Seguridad debe continuar vigorosamente y sin falta hasta que nos demos cuenta de la desnuclearización completa, definitiva y verificada".
El Consejo de Seguridad ha impulsado unánimemente las sanciones contra Corea del Norte desde 2006 en un intento de bloquear la financiación de los programas nucleares y de misiles balísticos de Pyongyang.
Pompeo se reunió con Ri al margen de la Asamblea General de las Naciones Unidas y dijo después que volvería a visitar Pyongyang el próximo mes para prepararse para una segunda cumbre.
Pompeo ya ha visitado Corea del Norte tres veces este año, pero su último viaje no ha ido bien.
Se fue de Pyongyang en julio diciendo que se habían hecho progresos, sólo para Corea del Norte en cuestión de horas para denunciarlo por hacer "demandas de tipo gangster".
Corea del Norte prometió en una reunión con Moon este mes desmantelar un emplazamiento de misiles y también un complejo nuclear si los Estados Unidos tomaban "medidas correspondientes".
Dijo que Kim le había dicho que las "medidas correspondientes" que buscaba eran garantías de seguridad que Trump había prometido en Singapur y que avanzaba hacia la normalización de las relaciones con Washington.
Los estudiantes de Harvard toman cursos para descansar lo suficiente.
Un nuevo curso en la Universidad de Harvard este año ha conseguido que todos sus graduados duerman más en un intento de combatir la creciente cultura machista de estudiar a través de la cafeína alimentada 'todas las noches'.
Un estudiante académico encontrado en la universidad número uno del mundo a menudo no tiene idea cuando se trata de lo básico sobre cómo cuidar de sí mismos.
Charles Czeisler, profesor de medicina del sueño en la Harvard Medical School y especialista en el Brigham and Women's Hospital, diseñó el curso, que él cree que es el primero de su tipo en los Estados Unidos.
Fue inspirado a comenzar el curso después de dar una charla sobre el impacto de la privación del sueño en el aprendizaje.
Al final se me acercó una chica y me dijo: '¿Por qué sólo me dicen esto ahora, en mi último año?'
Dijo que nadie le había hablado nunca de la importancia del sueño, lo que me sorprendió", le dijo a The Telegraph.
El curso, lanzado por primera vez este año, explica a los estudiantes lo esencial de cómo los buenos hábitos de sueño ayudan al rendimiento académico y atlético, así como a mejorar su bienestar general.
Paul Barreira, profesor de psiquiatría en la Escuela de Medicina de Harvard y director ejecutivo de los servicios de salud de la universidad, dijo que la universidad decidió introducir el curso después de encontrar estudiantes seriamente privados de sueño durante la semana.
El curso de una hora de duración implica una serie de tareas interactivas.
En una sección hay una imagen de un dormitorio, donde los estudiantes hacen clic en tazas de café, cortinas, entrenadores y libros para ser contados sobre los efectos de la cafeína y la luz y cómo el rendimiento atlético se ve afectado por la deficiencia de sueño, y la importancia de una rutina de acostarse.
En otra sección, se explica a los participantes cómo la privación del sueño a largo plazo puede aumentar los riesgos de ataques cardíacos, accidentes cerebrovasculares, depresión y cáncer.
Un mapa del campus, con iconos interactivos, anima a los participantes a pensar en su rutina diaria.
"Sabemos que no cambiará el comportamiento de los estudiantes al instante.
Pero creemos que tienen derecho a saber, al igual que usted tiene derecho a saber los efectos para la salud de elegir fumar cigarrillos", añadió el profesor Czeisler.
La cultura del orgullo de 'lanzar una noche entera' todavía existe, dijo, y agregó que la tecnología moderna y la presión cada vez mayor sobre los estudiantes significaba que la privación del sueño era un problema creciente.
Asegurando que usted tiene suficiente sueño, de buena calidad, debe ser el "arma secreta" de un estudiante para combatir el estrés, el agotamiento y la ansiedad, dijo - incluso para evitar el aumento de peso, ya que la privación del sueño pone el cerebro en modo de inanición, haciéndolos constantemente hambrientos.
Raymond So, un californiano de 19 años que estudia química y biología física, ayudó al profesor Czeisler a diseñar el curso, habiendo tomado una de sus clases el año pasado durante su primer año en Harvard.
Dijo que el curso le había abierto los ojos y lo inspiró a presionar por un curso en todo el campus.
El siguiente paso, espera, es pedir a todos los estudiantes de posgrado que completen un programa de estudios similar antes de unirse a la institución competitiva.
El profesor Czeisler recomendó que los estudiantes consideraran la posibilidad de establecer una alarma para cuándo acostarse, así como para cuándo despertar, y ser consciente de los efectos dañinos de la 'luz azul' emitida por las pantallas electrónicas y la iluminación LED, que puede lanzar su ritmo circadiano fuera de kilter, lo que conduce a problemas para dormirse.
Livingston 1 - 0 Rangers: Menga gol derriba a los hombres de Gerrard
Los Rangers sufrieron otro ataque de blues de otro día mientras la huelga de Dolly Menga consignó el lado desconectado de Steven Gerrard a una derrota de 1-0 en Livingston.
El lado Ibrox buscaba grabar su primera victoria en la carretera desde el triunfo 4-1 de febrero en St Johnstone, Pero el equipo de Gary Holt infligió la segunda derrota de Gerrard en 18 partidos como manager para dejar su lado ocho puntos a la deriva de los líderes de Ladbrokes Premiership Corazones.
Menga golpeó siete minutos antes de la mitad del tiempo y una formación de Rangers corto en la inspiración nunca pareció nivelar.
Mientras los Rangers bajan al sexto puesto, Livingston sube al tercero y solo detrás de Hibernian en la diferencia de goles.
Y podría haber más problemas en la tienda de Rangers después de que el lineman Calum Spence tuvo que ser tratado por una herida en la cabeza después de que un objeto aparentemente fue lanzado desde el extremo lejano.
Gerrard hizo ocho cambios en el lado que barrió más allá de Ayr en las semifinales de la Copa Betfred.
Holt, por otro lado, fue con el mismo Livi 11 que tomó un punto de Corazones la semana pasada y él habría estado encantado con la forma en que su bien perforado equipo sofocaba a sus oponentes en cada turno.
Los Rangers pueden haber dominado la posesión, pero Livingston hizo más con la pelota que tenían.
Deberían haber anotado solo dos minutos cuando el primer despido de Menga envió a Scott Pittman a través del gol de Allan McGregor, pero el mediocampista tiró de su gran oportunidad.
Un Keaghan Jacobs encontró al capitán Craig Halkett, pero su compañero defensivo Alan Lithgow solo pudo apuñalar en el poste trasero.
Los Rangers se apoderaron del control, pero parecía haber más esperanza que creencia sobre su juego en la tercera final.
Alfredo Morelos sin duda sintió que debería haber tenido una penalización en el plazo de un cuarto de hora mientras él y Steven Lawless chocaron, pero el árbitro Steven Thomson anuló las apelaciones del colombiano.
Rangers logró sólo dos tiros de la primera mitad en el objetivo, pero el ex portero Ibrox Liam Kelly apenas estaba preocupado por el encabezado de Lassana Coulibaly y un ataque domesticado de Ovie Ejaria.
Mientras que el abridor de 34 minutos de Livi pudo haber estado en contra de la carrera de juego, nadie puede negar que se lo merecían solo por su injerto.
De nuevo los Rangers fallaron en lidiar con un set de Jacobs profundo.
Scott Arfield no reaccionó mientras Declan Gallagher ranuraba la pelota a Scott Robinson, que mantuvo su fresco para elegir Menga para un simple final.
Gerrard actuó en el descanso mientras cambiaba a Coulibaly por Ryan Kent y el interruptor casi proporcionaba un impacto inmediato mientras el winger estaba en Morelos, pero la impresionante Kelly corrió de su línea a bloquear.
Pero Livingston continuó chupando a los visitantes para jugar exactamente el tipo de juego que disfrutan, con Lithgow y Halkett barriendo la bola larga después de la bola larga.
El lado de Holt podría haber estirado su ventaja en las etapas finales, pero McGregor se levantó bien para negar a Jacobs antes de que Lithgow se dirigiera desde la esquina.
El sustituto de los Rangers Glenn Middleton tenía otra demanda tardía de una sanción mientras se enredaba con Jacobs, pero de nuevo Thomson miró hacia otro lado.
Almanac: El inventor del contador Geiger
Y ahora una página de nuestro "Domingo por la mañana" Almanaque: 30 de septiembre de 1882, hace 136 años hoy, y la cuenta ... el día en que el futuro físico Johannes Wilhelm "Hans" Geiger nació en Alemania.
Geiger desarrolló un método para detectar y medir la radiactividad, una invención que finalmente condujo al dispositivo conocido como Geiger Counter.
Un pilar de la ciencia desde entonces, el Geiger Counter se convirtió en un pilar de la cultura pop, así como en la película de 1950 "Bells of Coronado", protagonizada por los científicos de cowpoke Roy Rogers y Dale Evans:
Hombre: "¿Qué demonios es eso?"
Rogers: "Es un contador Geiger, utilizado para localizar minerales radiactivos, como el uranio.
Cuando se ponen estos auriculares, en realidad se pueden escuchar los efectos de los átomos emitidos por la radiactividad en los minerales".
Evans: "¡Di, seguro que está apareciendo ahora!"
"Hans" Geiger murió en 1945, a pocos días de cumplir 63 años.
Pero el invento que lleva su nombre sigue vivo.
La nueva vacuna contra el cáncer puede enseñar al sistema inmunitario a 'ver' células pícaras
La nueva vacuna contra el cáncer puede enseñar al sistema inmunitario a 'ver' células pícaras y matarlos
La vacuna enseña al sistema inmunitario a reconocer las células malignas como parte del tratamiento
El método consiste en extraer células inmunes de un paciente, alterándolas en el laboratorio.
Pueden entonces 'ver' una proteína común a muchos cánceres y luego reinyectada
Una vacuna de ensayo está mostrando resultados prometedores en pacientes con una gama de cánceres.
Una mujer tratada con la vacuna, que enseña al sistema inmunitario a reconocer células pícaras, vio desaparecer su cáncer de ovario durante más de 18 meses.
El método consiste en extraer células inmunitarias de un paciente, alterarlas en el laboratorio para que puedan "ver" una proteína común a muchos cánceres llamados HER2, y luego reinyectar las células.
El profesor Jay Berzofsky, del Instituto Nacional del Cáncer de los Estados Unidos en Bethesda, Maryland, dijo: "Nuestros resultados sugieren que tenemos una vacuna muy prometedora".
HER2 "conduce el crecimiento de varios tipos de cáncer", incluyendo cánceres de mama, ovario, pulmón y colorrectal, explicó el profesor Berzofsky.
Un enfoque similar de sacar las células inmunitarias de los pacientes y "enseñar" a las células cancerosas ha funcionado en el tratamiento de un tipo de leucemia.
Kanye West se embarcó en una Diatriba Pro Trump, usando un sombrero MAGA, después de su aparición en el SNL.
No salió bien.
Kanye West fue abucheado en el estudio durante un sábado por la noche en vivo después de una actuación divagante en la que elogió al presidente estadounidense Donald Trump y dijo que se postularía para el cargo en 2020.
Después de interpretar su tercera canción de la noche, llamada Ghost Town, en la que llevaba una gorra Make America Great, se despojó de los demócratas y reiteró su apoyo a Trump.
"Muchas veces hablo con una persona blanca y dicen: "¿Cómo podría gustarte Trump, es racista?"
Bueno, si estuviera preocupado por el racismo me habría mudado de Estados Unidos hace mucho tiempo", dijo.
SNL comenzó el show con una película protagonizada por Matt Damon en la que la estrella de Hollywood se burló del testimonio de Brett Kavanaugh ante el Comité Judicial del Senado sobre denuncias de agresión sexual hechas por Christine Blasey Ford.
Aunque no fue transmitido, el video de la despotricación de West fue subido a las redes sociales por el comediante Chris Rock.
No está claro si Rock estaba tratando de burlarse de West con la publicación.
Además, West se había quejado a la audiencia de que había tenido un tiempo difícil detrás del escenario sobre su desgaste de la cabeza.
"Me intimidaron entre bastidores.
Dijeron: 'No salgas con ese sombrero puesto'.
¡Me acosaron!
Y luego dicen que estoy en un lugar hundido", dijo, según el Washington Examiner.
West continuó: "¿Quieres ver el lugar hundido?" diciendo que él "Pondría mi capa de superhombre, porque esto significa que no puedes decirme qué hacer. ¿Quieres que el mundo avance?
Prueba el amor".
Sus comentarios sacaron abucheos al menos dos veces de la audiencia y los miembros del elenco del SNL parecían estar avergonzados, informó Variety, y una persona le dijo a la publicación: "El estudio entero se quedó en silencio".
West había sido traído como un reemplazo tardío para la cantante Ariana Grande, cuyo ex novio, el rapero Mac Miller había muerto hace unos días.
West desconcertó a muchos con una interpretación de la canción I Love it, vestida como una botella Perrier.
West recibió el apoyo del jefe del grupo conservador TPUSA, Candace Turner, quien tuiteó: "A uno de los espíritus más valientes: GRACIAS por estar de pie hasta el trabajo".
Pero la presentadora del programa Karen Hunter tuiteó que West era simplemente "ser quien es y eso es absolutamente maravilloso".
"Pero no elegí recompensar a alguien (comprando su música o ropa o apoyando su "arte") que creo que está abrazando y lanzando ideología que es perjudicial para mi comunidad.
Es libre.
Nosotros también", agregó.
Antes del show, el rapero anunció en Twitter que había cambiado su nombre, diciendo que ahora era "el conocido formalmente como Kanye West".
No es el primer artista en cambiar su nombre y sigue los pasos de Diddy, también conocido como Puff Daddy, Puffy y P Diddy.
Compañero rapero, Snoop Dogg ha tenido el nombre de Snoop Lion y, por supuesto, la leyenda de la música tardía Prince, cambió su nombre a un símbolo y luego el artista anteriormente conocido como Prince.
Intento de asesinato por apuñalamiento en el restaurante Belfast
Un hombre de 45 años ha sido acusado de intento de asesinato después de que un hombre fue apuñalado en un restaurante en el este de Belfast el viernes.
El incidente ocurrió en Ballyhackamore, dijo la policía.
Se espera que el acusado comparezca ante el Tribunal de Magistrados de Belfast el lunes.
Los cargos serán revisados por el Ministerio Público.
Juego de Tronos estrella Kit Harington golpea a cabo en la masculinidad tóxica
Kit Harington es conocido por su rol como Jon Snow en la violenta serie de fantasía medieval de HBO Game of Thrones.
Pero el actor, de 31 años, ha luchado contra el estereotipo del héroe macho, diciendo que tales papeles en la pantalla significan que los jóvenes a menudo sienten que tienen que ser difíciles de ser respetados.
Hablando con The Sunday Times Culture, Kit dijo que cree que "algo ha salido mal" y cuestionó cómo abordar el problema de la masculinidad tóxica en la era #MeToo.
Kit, que recientemente se casó con su co-estrella de Game of Thrones Rose Leslie, también 31, admitió que siente "muy fuerte" al abordar el tema.
"Me siento personalmente, con bastante fuerza, en este momento - ¿en qué nos hemos equivocado con la masculinidad?", dijo.
'¿Qué hemos estado enseñando a los hombres cuando están creciendo, en términos del problema que vemos ahora?'
Kit cree que la televisión puede ser en parte responsable del aumento de la masculinidad tóxica gracias a sus personajes muy masculinos.
Continuó: '¿Qué es innato y qué se enseña?
¿Qué se enseña en la televisión, y en las calles, que hace que los jóvenes sientan que tienen que ser este cierto lado de ser un hombre?
Creo que esa es una de las grandes preguntas de nuestro tiempo. ¿Cómo cambiamos eso?
Porque claramente algo ha ido mal para los jóvenes.
En la entrevista también admitió que no estaría haciendo ninguna precuela de Game of Thrones o secuelas cuando la serie llegue a su fin el próximo verano, diciendo que está "acabado con campos de batalla y caballos".
A partir de noviembre Kit protagonizará un renacimiento del verdadero oeste de Sam Shepard que es la historia de un productor de cine y su hermano, que es un ladrón.
El actor reveló recientemente que considera que conocer a su esposa Rose es lo mejor para salir de Game of Thrones.
"Conocí a mi esposa en este espectáculo, así que de esa manera me dio mi futura familia, y mi vida de aquí en adelante", dijo.
Rose interpretó a Ygritte, el interés amoroso del personaje de Kit, Jon Snow, en la galardonada serie de fantasía Emmy.
La pareja se casó en junio de 2018 en los terrenos de la finca familiar de Leslie en Escocia.
VIH/SIDA: China reporta aumento del 14% en nuevos casos
China ha anunciado un aumento del 14% en el número de sus ciudadanos que viven con el VIH y el SIDA.
Más de 820.000 personas se ven afectadas en el país, dicen los funcionarios de salud.
Sólo en el segundo trimestre de 2018 se notificaron unos 40.000 nuevos casos.
La gran mayoría de los nuevos casos se transmitieron a través del sexo, lo que marcó un cambio con respecto al pasado.
Tradicionalmente, el VIH se propagó rápidamente a través de algunas partes de China como resultado de transfusiones de sangre infectadas.
Pero el número de personas que contraen el VIH de esta manera se había reducido a casi cero, dijeron los funcionarios de salud chinos en una conferencia en la provincia de Yunnan.
Sin embargo, año tras año, el número de personas que viven con el VIH y el SIDA en China ha aumentado en 100.000 personas.
La transmisión del VIH a través del sexo es un problema agudo en la comunidad LGBT de China.
La homosexualidad fue despenalada en China en 1997, pero se dice que la discriminación contra las personas LGBT está muy extendida.
Debido a los valores conservadores del país, los estudios han estimado que 70-90% de los hombres que tienen relaciones sexuales con hombres eventualmente se casarán con mujeres.
Muchas de las transmisiones de las enfermedades provienen de protecciones sexuales inadecuadas en estas relaciones.
Desde 2003, el Gobierno de China ha prometido el acceso universal a la medicación contra el VIH como parte de un esfuerzo para abordar el problema.
Maxine Waters niega que el personal filtrara los datos de los senadores del Partido Republicano, destroza "mentiras peligrosas" y "teorías de conspiración"
El sábado, la representante estadounidense Maxine Waters denunció acusaciones de que un miembro de su personal había publicado la información personal de tres senadores republicanos estadounidenses en las páginas de Wikipedia de los legisladores.
El demócrata de Los Ángeles afirmó que las afirmaciones estaban siendo vendidas por expertos y sitios web de "ultraderecha".
"Mentiras, mentiras y mentiras más despreciables", dijo Waters en un comunicado en Twitter.
Según se informa, la información publicada incluía las direcciones de domicilio y los números de teléfono de los Estados Unidos Sens. Lindsey Graham de Carolina del Sur, y Mike Lee y Orrin Hatch, ambos de Utah.
La información apareció en línea el jueves, publicada por una persona desconocida en Capitol Hill durante la audiencia de un panel del Senado sobre las acusaciones de mala conducta sexual contra el candidato de la Corte Suprema Brett Kavanaugh.
La filtración llegó en algún momento después de que los tres senadores hubieran interrogado a Kavanaugh.
Sitios conservadores como Gateway Pundit y RedState informaron que la dirección IP que identifica la fuente de los puestos estaba asociada con la oficina de Waters y dio a conocer la información de un miembro del personal de Waters, informó la Colina.
"Esta acusación infundada es completamente falsa y una mentira absoluta", continuó Waters.
"El miembro de mi personal -cuya identidad, información personal y seguridad han sido comprometidas como resultado de estas acusaciones fraudulentas y falsas- no fue responsable en modo alguno de la filtración de esta información.
Esta alegación infundada es completamente falsa y una mentira absoluta".
La declaración de Waters rápidamente atrajo críticas en línea, incluso de Ari Fleischer, ex secretario de prensa de la Casa Blanca.
"Esta negación está enojada", escribió Fleischer.
"Esto sugiere que no tiene el temperamento de ser miembro del Congreso.
Cuando alguien es acusado de algo que no hizo, no debe estar enojado.
No deben ser desafiantes.
No deben cuestionar los motivos del acusador.
Deben estar tranquilos y serenos".
Fleischer parecía comparar la reacción de Waters a las críticas de los demócratas al juez Kavanaugh, acusado por los críticos de parecer demasiado enojado durante la audiencia del jueves.
Omar Navarro, un candidato republicano que postula para desbancar a Waters en las elecciones de mitad de período, también expresó sus pensamientos en Twitter.
"Grande si es verdad", tuiteó.
En su declaración, Waters dijo que su oficina había alertado "a las autoridades competentes y a las fuerzas del orden de estas denuncias fraudulentas.
"Nos aseguraremos de que los perpetradores sean revelados", continuó, "y de que sean considerados legalmente responsables de todas sus acciones que sean destructivas y peligrosas para todos y cada uno de mis miembros".
Johnny English Strikes De nuevo revisión - Rowan Atkinson espía subpoderoso spoof
Ahora es tradicional buscar significados del Brexit en cualquier nueva película con una inclinación británica y eso sí parece aplicable a este renacimiento de la franquicia de Johnny English action-comedia spoof - que comenzó en 2003 con Johnny English y volvió a la vida en 2011 con Johnny English Reborn.
¿Será la lengua-en-cariño-auto-satisfacción sobre el tema de cuán obviamente basura somos la nueva oportunidad de exportación de la nación?
En cualquier caso, El incompetente Johnny English, con ojos pop y cara de goma, ha renovado por segunda vez su licencia para follar cosas - ese nombre de su señal más que cualquier otra cosa de que es una amplia creación cómica diseñada para territorios cinematográficos de habla no inglesa.
Es, por supuesto, el estúpido agente secreto que a pesar de sus extrañas pretensiones de smoothie glamour tiene un poco de Clouseau, una pizca de Mr Bean y una muñeca de ese tipo aportando una sola nota a la canción de los Carros de Fuego en la ceremonia de apertura de los Juegos Olímpicos de Londres 2012.
También se basa originalmente en el viajero y hombre internacional del misterio Atkinson una vez jugado en los ahora olvidados anuncios de Barclaycard TV, dejando el caos en su estela.
Hay uno o dos momentos agradables en esta última salida de JE.
Me encantó Johnny Inglés acercándose a un helicóptero mientras estaba vestido con un traje medieval de armadura y las cuchillas del rotor brevemente aludiendo contra su casco.
El regalo de Atkinson para la comedia física está en exhibición, pero el humor se siente bastante débil y extrañamente superfluo, especialmente como las marcas de películas "serias" como 007 y Mission Impossible ofrecen ahora con confianza comedia como un ingrediente.
El humor se siente como si se lanzara a los niños en lugar de a los adultos, y para mí las locas desventuras de Johnny English no son tan inventivas y enfocadas como las bromas de películas mudas de Atkinson en la persona de Bean.
La premisa perennemente actual ahora es que Gran Bretaña está en serios problemas.
Un ciber-hacker se ha infiltrado en la red súper secreta de espías de Gran Bretaña, revelando las identidades de todos los agentes británicos en el campo, para consternación del agente de servicio - un tristemente pequeño papel para Kevin Eldon.
Es el último colmo para un primer ministro que es una figura pomposa y asediada, que ya sufre un completo colapso de la impopularidad política: Emma Thompson hace todo lo posible con este personaje cuasi-Teresa-May, pero no hay mucho con qué trabajar en el guión.
Sus asesores de inteligencia le informan que como cada espía activo ha sido comprometido, tendrá que sacar a alguien del retiro.
Y eso significa abuchear a Johnny Inglés mismo, ahora empleado como maestro de escuela en algún establecimiento elegante, pero dando lecciones extraoficiales sobre cómo ser un agente encubierto: algunos buenos chistes aquí, como Inglés ofrece una Escuela de Rock-tipo academia de espionaje.
Inglés es llevado de vuelta a Whitehall para un informe de emergencia y reunido con su antiguo compañero de larga paciencia Bough, interpretado de nuevo por Ben Miller.
Bough es ahora un hombre casado, unido a un comandante submarino, un papel jolly-hockey-sticks en el que Vicki Pepperdine está un poco desperdiciado.
Así que Batman y Robin de conseguir cosas terriblemente mal en el Servicio Secreto de Su Majestad están de vuelta en acción, encontrándose con la hermosa mujer fatal de Olga Kurylenko Ofelia Bulletova.
Mientras tanto, el primer ministro está cayendo peligrosamente bajo el hechizo del multimillonario carismático de la tecnología que afirma que puede resolver los problemas informáticos de Gran Bretaña: el siniestro Jason Volta, interpretado por Jake Lacy.
Inglés y Bough comienzan su odisea de farsas: disfrazados de camareros, prendieron fuego a un restaurante francés; crean caos contrabandeando a bordo del yate de lujo de Volta; y el inglés desencadena pura anarquía mientras intenta usar un auricular de Realidad Virtual para familiarizarse con el interior de la casa de Volta.
Todas las paradas son sin duda retiradas para esa última secuencia, pero por amable y bulliciosa que sea, hay un montón de televisión infantil sobre todo el asunto.
Algo bastante moderado.
Y como con las otras películas de Johnny English no pude evitar pensar: ¿no puede la industria cinematográfica británica darle a Rowan Atkinson un papel que realmente hace justicia a su talento?
La mano de obra niega que esté diseñando un plan para que los británicos trabajen una semana de cuatro días, pero que se les pague durante cinco días
El Partido Laborista de Jeremy Corbyn va a considerar un plan radical que hará que los británicos trabajen cuatro días a la semana, pero que les paguen por cinco.
Según se informa, el partido quiere que los jefes de empresa transfieran a los trabajadores los ahorros obtenidos a través de la revolución de la inteligencia artificial (AI) dándoles un día libre adicional.
Vería a los empleados disfrutar de un fin de semana de tres días - pero todavía llevar a casa la misma paga.
Fuentes dijeron que la idea "ajustaría" a la agenda económica del partido y planea inclinar al país a favor de los trabajadores.
El cambio a una semana de cuatro días ha sido aprobado por el Congreso Sindical como una manera para que los trabajadores aprovechen la cambiante economía.
Una fuente de alto nivel del Partido Laborista dijo a The Sunday Times: "Se espera que se anuncie una revisión de la política antes de fin de año.
"No sucederá de la noche a la mañana, pero una semana laboral de cuatro días es una aspiración que encaja con el enfoque del partido de reequilibrar la economía a favor del trabajador, así como la estrategia industrial general del partido".
El Partido Laborista no sería el primero en apoyar tal idea, con el Partido Verde prometiendo una semana laboral de cuatro días durante su campaña electoral general de 2017.
Sin embargo, en la actualidad el Partido Laborista en su conjunto no apoya esa aspiración.
Un portavoz del Partido Laborista dijo: "Una semana laboral de cuatro días no es política del partido y no está siendo considerada por el partido".
El Canciller de la Sombra John McDonnell utilizó la conferencia laborista de la semana pasada para concretar su visión de una revolución socialista en la economía.
El Sr. McDonnell dijo que estaba decidido a recuperar el poder de los "directores sin rostro" y los "ganadores" de las empresas de servicios públicos.
Los planes del canciller en la sombra también significan que los accionistas actuales en las compañías de agua no pueden recuperar toda su participación, ya que un gobierno laborista podría hacer "deducciones" sobre la base de la percepción de mala conducta.
También confirmó los planes de poner a los trabajadores en los consejos de administración de la empresa y crear Fondos de Propiedad Inclusiva para entregar el 10% del capital de las empresas del sector privado a los empleados, que se embolsan dividendos anuales de hasta £500.
Lindsey Graham, John Kennedy dicen "60 Minutos" si la investigación del FBI sobre Kavanaugh podría cambiar de opinión
La investigación del FBI sobre las acusaciones contra el juez Brett Kavanaugh ha retrasado una votación final sobre su nombramiento a la Corte Suprema por lo menos una semana, y plantea la cuestión de si los hallazgos de la oficina podrían influir en los senadores republicanos para obtener su apoyo.
En una entrevista emitida el domingo, el corresponsal de "60 Minutes" Scott Pelley preguntó a los republicanos Sens. John Kennedy y Lindsey Graham si el FBI podría descubrir algo que los llevara a cambiar de opinión.
Kennedy apareció más abierto que su colega de Carolina del Sur.
"Quiero decir, por supuesto", dijo Kennedy.
"Dije ir a la audiencia, dije, he hablado con el juez Kavanaugh.
Lo llamé después de que esto sucediera, esa acusación salió y dijo: '¿Lo hiciste?'
Era decidido, decidido, inequívoco".
El voto de Graham, sin embargo, aparece en piedra.
"Mi mente se ha decidido sobre Brett Kavanaugh y se necesitaría una acusación de dinamita", dijo.
"Dr. Ford, no sé qué pasó, pero sé esto: Brett lo negó vigorosamente", añadió Graham, refiriéndose a Christine Blasey Ford.
"Y todos sus nombres no pudieron verificarlo.
Tiene 36 años.
No veo nada nuevo que cambie".
¿Qué es el Festival Ciudadano Global y ha hecho algo para reducir la pobreza?
Este sábado Nueva York será sede del Global Citizen Festival, un evento musical anual que tiene una impresionante alineación de estrellas actuando y una misión igualmente impresionante: acabar con la pobreza mundial.
Ahora en su séptimo año, El Festival Ciudadano Global verá a decenas de miles de personas acudir al Gran Jardín de Central Park para no sólo disfrutar de actos como Janet Jackson, Cardi B y Shawn Mendes, sino también para crear conciencia sobre el verdadero objetivo del evento de acabar con la pobreza extrema para 2030.
El Global Citizen Festival, que declaró en 2012, es una extensión del Global Poverty Project, un grupo de defensa internacional que espera poner fin a la pobreza aumentando el número de personas que luchan activamente contra ella.
Con el fin de recibir una entrada gratuita para el evento (a menos que esté dispuesto a pagar por una entrada VIP), Concertgoers tuvo que completar una serie de tareas, o "acciones" tales voluntariado, enviar un correo electrónico a un líder mundial, hacer una llamada telefónica o cualquier otra manera significativa para ayudar a crear conciencia de su objetivo de poner fin a la pobreza.
Pero, ¿cuán exitoso ha sido Global Citizen con 12 años para lograr su objetivo?
¿Es la idea de recompensar a la gente con un concierto libre una forma genuina de persuadir a la gente para que exija un llamado a la acción, o simplemente otro caso del llamado "clicktivismo" - la gente siente que está haciendo una verdadera diferencia firmando una petición en línea o enviando un tuit?
Desde 2011, Global Citizen dice que ha registrado más de 19 millones de "acciones" de sus partidarios, presionando por una serie de objetivos diferentes.
Dice que estas acciones han ayudado a los líderes mundiales a anunciar compromisos y políticas equivalentes a más de 37.000 millones de dólares que afectarán las vidas de más de 2.250 millones de personas para 2030.
A principios de 2018, el grupo citó 390 compromisos y anuncios derivados de sus acciones, de los cuales al menos 10 000 millones de dólares ya han sido desembolsados o recaudados.
El grupo estima que los fondos garantizados han tenido hasta ahora un impacto directo en casi 649 millones de personas en todo el mundo.
Algunos de los compromisos clave incluyen El poder de la nutrición, Una asociación basada en el Reino Unido de inversores e implementadores comprometidos a "ayudar a los niños a crecer a su máximo potencial", prometiendo proveer a Ruanda con 35 millones de dólares para ayudar a acabar con la desnutrición en el condado después de recibir más de 4.700 tuits de Ciudadanos Globales.
"Con el apoyo del gobierno del Reino Unido, donantes, gobiernos nacionales y ciudadanos globales como tú, podemos hacer de la injusticia social de la desnutrición una nota de pie de página en la historia", dijo el embajador de The Power of Nutrition, Tracey Ullman, durante un concierto en vivo en Londres en abril de 2018.
El grupo también dijo que después de más de 5,Se adoptaron 000 medidas para mejorar la nutrición de las madres y los niños en el Reino Unido, y el Gobierno anunció la financiación de un proyecto, el Power of Nutrition, que beneficiará a 5 millones de mujeres y niños con intervenciones en materia de nutrición.
En respuesta a una de las preguntas frecuentes en su sitio web, "¿qué te hace pensar que podemos acabar con la pobreza extrema?"
El ciudadano global respondió: "Será un camino largo y difícil - a veces caeremos y fracasaremos.
Pero, como los grandes movimientos de derechos civiles y antiapartheid que tenemos ante nosotros, tendremos éxito, porque juntos somos más poderosos.
Janet Jackson, The Weeknd, Shawn Mendes, Cardi B, Janelle Monáe están entre algunos de los actos que actuarán en el evento de este año en Nueva York, que será organizado por Deborra-Lee Furness y Hugh Jackman.
EE.UU. podría utilizar la Marina para "bloquear" para obstaculizar las exportaciones de energía rusa - Interior Secretary
Washington puede "si es necesario" recurrir a su Marina para evitar que la energía rusa llegue a los mercados, incluso en Oriente Medio, reveló el secretario interno de Estados Unidos, Ryan Zinke, citado por Washington Examiner.
Zinke alegó que el compromiso de Rusia en Siria -en particular, donde opera por invitación del gobierno legítimo- es un pretexto para explorar nuevos mercados energéticos.
"Creo que la razón por la que están en Oriente Medio es que quieren intercambiar energía al igual que lo hacen en Europa oriental, la barriga meridional de Europa", dijo.
Y, según el funcionario, hay formas y medios para abordarlo.
"Estados Unidos tiene esa capacidad, con nuestra Marina, para asegurarse de que las vías marítimas estén abiertas, y, si es necesario, para bloquear, para asegurarse de que su energía no vaya al mercado", dijo.
Zinke se dirigió a los asistentes al evento organizado por Consumer Energy Alliance, un grupo sin fines de lucro que se parece a sí mismo como la "voz del consumidor de energía" en los Estados Unidos.
Fue a comparar los enfoques de Washington para tratar con Rusia e Irán, señalando que son efectivamente los mismos.
"La opción económica en Irán y Rusia es, más o menos, aprovechar y reemplazar combustibles", dijo, mientras se refería a Rusia como un "pony de un solo truco" con una economía dependiente de combustibles fósiles.
Las declaraciones llegan cuando la administración Trump ha estado en una misión para impulsar la exportación de su gas natural licuado a Europa, reemplazando a Rusia, la opción mucho más barata para los consumidores europeos.
Para ese efecto, los funcionarios de la administración Trump, incluido el propio presidente estadounidense Donald Trump, tratan de persuadir a Alemania para que se retire del proyecto "inapropiado" del gasoducto Nord Stream 2, que, según Trump, convirtió a Berlín en el "captivo" de Moscú.
Moscú ha subrayado en repetidas ocasiones que el gasoducto Nord Stream 2, de 11.000 millones de dólares, que duplicará la capacidad actual del gasoducto a 110 mil millones de metros cúbicos, es un proyecto puramente económico.
El Kremlin argumenta que la ferviente oposición de Washington al proyecto está motivada simplemente por razones económicas y es un ejemplo de competencia desleal.
"Creo que compartimos la opinión de que la energía no puede ser una herramienta para ejercer presión y que los consumidores deben poder elegir a los proveedores", dijo el ministro ruso de Energía, Aleksandr Novak, tras una reunión con el secretario estadounidense de Energía, Rick Perry, en Moscú en septiembre.
La postura de Estados Unidos ha provocado una reacción de Alemania, que ha reafirmado su compromiso con el proyecto.
La organización líder de Alemania para la industria, la Federación de Industrias Alemanas (BDI), ha pedido a los Estados Unidos que se alejen de la política energética de la UE y de los acuerdos bilaterales entre Berlín y Moscú.
"Tengo un gran problema cuando un tercer estado interfiere en nuestro suministro de energía", dijo Dieter Kempf, jefe de la Federación de Industrias Alemanas (BDI), tras una reciente reunión entre la canciller alemana Angela Merkel y el presidente ruso Vladimir Putin.
Elizabeth Warren tomará "look duro" al postularse para presidente en 2020, Senadora de Massachusetts dice
La Senadora de Massachusetts Elizabeth Warren dijo el sábado que haría una "difícil mirada" a la candidatura a la presidencia después de las elecciones de mitad de período.
Durante un ayuntamiento en Holyoke, Massachusetts, Warren confirmó que consideraría correr.
"Es hora de que las mujeres vayan a Washington y arreglen nuestro gobierno roto y eso incluye a una mujer en la cima", dijo, según The Hill.
"Después del 6 de noviembre, echaré un vistazo a la candidatura a la presidencia".
Warren habló sobre el presidente Donald Trump durante el ayuntamiento, diciendo que estaba "tomando este condado en la dirección equivocada.
"Me preocupa hasta los huesos lo que Donald Trump le está haciendo a nuestra democracia", dijo.
Warren ha sido franca en sus críticas a Trump y a su candidato a la Corte Suprema Brett Kavanaugh.
En un tuit del viernes, Warren dijo "por supuesto que necesitamos una investigación del FBI antes de votar".
Sin embargo, una encuesta publicada el jueves mostró que la mayoría de los electores de Warren no creen que deba postularse en 2020.
El 58 por ciento de los votantes "probables" de Massachusetts dijo que el senador no debería postularse, según la encuesta del Centro de Investigación Política de la Universidad de Suffolk/Boston Globe.
El treinta y dos por ciento apoyó tal carrera.
La encuesta mostró más apoyo a una carrera del ex gobernador Deval Patrick, con un 38 por ciento apoyando una carrera potencial y un 48 por ciento en contra.
Otros nombres demócratas de alto perfil discutidos con respecto a una posible carrera 2020 incluyen al ex vicepresidente Joe Biden y al senador Bernie Sanders de Vermont.
Biden dijo que decidiría oficialmente en enero, informó la Associated Press.
Sarah Palin cita el PTSD de Track Palin en el mitin de Donald Trump
Track Palin, de 26 años, pasó un año en Irak después de alistarse en septiembre.
Fue arrestado y acusado en un incidente de violencia doméstica el lunes por la noche
"Lo que está pasando mi propio hijo, lo que está pasando al regresar, puedo relacionarme con otras familias que sienten ramificaciones del estrés postraumático y algunas de las heridas con las que regresan nuestros soldados", dijo a la audiencia en un mitin para Donald Trump en Tulsa, Oklahoma.
Palin llamó a su arresto "el elefante en la habitación" y dijo de su hijo y otros veteranos de guerra, "vuelven un poco diferentes, vuelven endurecidos, vuelven preguntándose si hay ese respeto por lo que sus compañeros soldados y aviadores, y todos los demás miembros del ejército, le han dado al país".
Fue arrestado el lunes en Wasilla, Alaska, y acusado de agresión a una mujer por violencia doméstica, interfiriendo con un informe de violencia doméstica y posesión de un arma mientras estaba intoxicado, según Dan Bennett, portavoz del Departamento de Policía de Wasilla.
18 estados, D.C. apoyan el desafío a la nueva política de asilo
Dieciocho estados y el Distrito de Columbia están apoyando un desafío legal a una nueva política estadounidense que niega asilo a las víctimas que huyen de pandillas o violencia doméstica.
Representantes de los 18 estados y el distrito presentaron un informe de amigos de la corte el viernes en Washington para apoyar a un solicitante de asilo desafiando la política, informó NBC News.
El nombre completo del demandante en el caso Grace c. Sessions que la Unión Americana de Libertades Civiles presentó en agosto contra la política federal no se ha revelado.
Dijo que su pareja "y sus violentos hijos de pandilleros", abusaron de ella, pero los funcionarios estadounidenses negaron su solicitud de asilo el 20 de julio.
Fue detenida en Texas.
Los abogados de los estados que apoyan a Grace describieron a El Salvador, Honduras y Guatemala, que producen un gran número de solicitantes de asilo en Estados Unidos, como naciones que enfrentan problemas generalizados con pandillas y violencia doméstica.
La nueva política de asilo de Estados Unidos revocó una decisión de 2014 de la Junta de Apelaciones de Inmigrantes que permitía a los inmigrantes indocumentados que huían de la violencia doméstica solicitar asilo.
El Fiscal General del Distrito de Columbia, Karl Racine, dijo en un comunicado el viernes que la nueva política "ignora décadas de derecho estatal, federal e internacional".
"La ley federal requiere que todas las solicitudes de asilo sean resueltas sobre los hechos y circunstancias particulares de la demanda, y tal prohibición viola ese principio", dijo el amigo del informe de la corte.
Los abogados argumentaron además en el informe que la política de negar la entrada a los inmigrantes perjudica la economía estadounidense, diciendo que son más propensos a convertirse en empresarios y "suministrar mano de obra necesaria".
El Fiscal General Jeff Sessions ordenó a los jueces de inmigración que dejaran de conceder asilo a las víctimas que huían del abuso doméstico y la violencia de las pandillas en junio.
"El asilo está disponible para aquellos que salen de su país de origen debido a la persecución o el miedo por motivos de raza, religión, nacionalidad o pertenencia a un grupo social u opinión política", dijo Sessions en su anuncio de la política el 11 de junio.
El asilo nunca tuvo por objeto aliviar todos los problemas -- incluso todos los problemas graves -- que la gente enfrenta todos los días en todo el mundo.
Desesperados esfuerzos de rescate en Palu mientras el número de muertos se duplica en la carrera para encontrar sobrevivientes
Para los supervivientes, la situación era cada vez más grave.
"Se siente muy tenso", dijo la madre de 35 años Risa Kusuma, confortando a su febril bebé en un centro de evacuación en la destripada ciudad de Palu.
"Cada minuto una ambulancia trae cuerpos.
El agua limpia es escasa".
Los residentes fueron vistos regresando a sus hogares destruidos, recogiendo pertenencias inundadas, tratando de salvar cualquier cosa que pudieran encontrar.
Cientos de personas resultaron heridas y los hospitales, dañados por el terremoto de magnitud 7,5, quedaron abrumados.
Algunos de los heridos, incluyendo Dwi Haris, que sufrió una fractura de espalda y hombro, descansaron fuera del Hospital del Ejército de Palu, donde los pacientes estaban siendo tratados al aire libre debido a las fuertes réplicas.
Lágrimas llenaron sus ojos mientras relataba sentir el violento terremoto sacudir la habitación del hotel del quinto piso que compartió con su esposa e hija.
"No había tiempo para salvarnos a nosotros mismos.
Creo que me metieron en las ruinas de la pared", dijo Haris a Associated Press, y agregó que su familia estaba en la ciudad para una boda.
"Escuché a mi esposa llorar pidiendo ayuda, pero luego silencio.
No sé qué le pasó a ella y a mi hija.
Espero que estén a salvo."
Embajador de EE.UU. acusa a China de "acoso" con "anuncios de propaganda"
Una semana después de que un periódico oficial chino publicara un anuncio de cuatro páginas en un diario estadounidense promocionando los beneficios mutuos del comercio entre Estados Unidos y China, el embajador estadounidense en China acusó a Pekín de usar la prensa estadounidense para difundir propaganda.
El presidente estadounidense Donald Trump se refirió el miércoles pasado al suplemento pagado del diario chino en el Registro Des Moines, el periódico más vendido del estado de Iowa, después de acusar a China de intentar inmiscuirse en las elecciones al Congreso del 6 de noviembre, una acusación que China niega.
La acusación de Trump de que Pekín estaba tratando de inmiscuirse en las elecciones estadounidenses marcó lo que los funcionarios estadounidenses le dijeron a Reuters que era una nueva fase en una creciente campaña de Washington para presionar a China.
Aunque es normal que los gobiernos extranjeros coloquen anuncios para promover el comercio, Pekín y Washington están actualmente atrapados en una creciente guerra comercial que los ha visto nivelar rondas de aranceles sobre las importaciones de los demás.
Los aranceles de represalia de China a principios de la guerra comercial fueron diseñados para golpear a exportadores en estados como Iowa que apoyaron al Partido Republicano de Trump, expertos chinos y estadounidenses han dicho.
Terry Branstad, el embajador de Estados Unidos en China y el ex gobernador de Iowa, un importante exportador de productos agrícolas a China, dijo que Pekín había herido a trabajadores, agricultores y empresas estadounidenses.
China, Branstad escribió en un artículo de opinión del Sunday's Des Moines Register, "ahora se está duplicando el acoso al publicar anuncios de propaganda en nuestra propia prensa libre".
"Al difundir su propaganda, el gobierno de China se está valiendo de la querida tradición de libertad de expresión y prensa de Estados Unidos colocando un anuncio pagado en el Registro Des Moines", escribió Branstad.
"En contraste, en el quiosco de la calle aquí en Beijing, encontraréis escasas voces disidentes y no veréis ningún verdadero reflejo de las opiniones dispares que el pueblo chino puede tener sobre la preocupante trayectoria económica de China, dado que los medios de comunicación están bajo el firme pulgar del Partido Comunista Chino", escribió.
Agregó que "uno de los periódicos más destacados de China esquivó la oferta de publicar" su artículo, aunque no dijo qué periódico.
Republicanos allegando a mujeres votantes antes de los períodos intermedios con Kavanaugh Debacle, analistas advierten
Como muchos republicanos de alto rango están de pie y defienden al candidato de la Corte Suprema Brett Kavanaugh ante varias acusaciones de agresión sexual, el analista ha advertido que verán una reacción violenta, particularmente de las mujeres, durante las próximas elecciones de mitad de período.
Las emociones en torno a esto han sido extremadamente altas, y la mayoría de los republicanos ya están en el registro mostrando que querían seguir adelante con una votación.
Esas cosas no se pueden recuperar", dijo Grant Reeher, profesor de ciencias políticas de la Escuela Maxwell de la Universidad de Syracuse, a The Hill por un artículo publicado el sábado.
Reeher dijo que duda de que el impulso de última hora del Senador Jeff Flake (R-Arizona) para una investigación del FBI sea suficiente para aplacar a los votantes enojados.
"Las mujeres no van a olvidar lo que pasó ayer - no van a olvidarlo mañana y no en noviembre,Karine Jean-Pierre, asesora senior y portavoz nacional del grupo progresista MoveOn, dijo el viernes, según el periódico Washington, D.C.
El viernes por la mañana, Los manifestantes corearon "¡Se acerca noviembre!" como se manifestaron en el pasillo del Senado mientras los republicanos controlaban el Comité Judicial decidían avanzar con la nominación de Kavanaugh a pesar del testimonio de la Dra. Christine Blasey Ford, informó Mic.
"El entusiasmo y la motivación democráticos van a estar fuera de lugar", dijo Stu Rothenberg, un analista político no partidista, al sitio de noticias.
"La gente dice que ya ha sido alto; eso es cierto.
Pero podría ser más alto, particularmente entre las mujeres votantes de los suburbios y los votantes más jóvenes, de 18 a 29 años, que aunque no les gusta el presidente, a menudo no votan".
Incluso antes de que el testimonio público de Ford detallara sus acusaciones de agresión sexual contra el candidato de la Corte Suprema, los analistas sugirieron que una reacción podría seguir si los republicanos avanzaban con la confirmación.
"Esto se ha convertido en un lío confuso para el Partido Republicano", dijo Michael Steele, ex presidente del Comité Nacional Republicano, a principios de la semana pasada, según NBC News.
"No se trata de la votación de la comisión o la votación final o si Kavanaugh es puesto en el banquillo, También se trata de la forma en que los republicanos han manejado esto y cómo la han tratado", señaló Guy Cecil, director de Prioridades EE.UU., un grupo que ayuda a elegir a los demócratas, al canal de noticias.
Sin embargo, los estadounidenses parecen estar algo divididos sobre quién creer en la estela de los testimonios de Ford y Kavanaugh, con un poco más de lado con este último.
Una nueva encuesta de YouGov muestra que el 41 por ciento de los encuestados definitivamente o probablemente creyeron el testimonio de Ford, mientras que el 35 por ciento dijo que definitivamente o probablemente creyeron Kavanaugh.
Además, el 38 por ciento dijo que pensaban que Kavanaugh probablemente o definitivamente mintió durante su testimonio, mientras que sólo el 30 por ciento dijo lo mismo sobre Ford.
Después del empujón de Flake, el FBI está investigando actualmente las acusaciones presentadas por Ford, así como por lo menos otro acusador, Deborah Ramírez, informó The Guardian.
Ford testificó ante el Comité Judicial del Senado bajo juramento la semana pasada que Kavanaugh la agredió borrachamente a la edad de 17 años.
Ramírez alega que el candidato de la Corte Suprema le expuso sus genitales mientras asistían a una fiesta durante su tiempo estudiando en Yale en la década de 1980.
El inventor de la World Wide Web planea iniciar una nueva Internet para Google y Facebook
Tim Berners-Lee, el inventor de la World Wide Web, está lanzando una startup que busca rivalizar con Facebook, Amazon y Google.
El último proyecto de la leyenda de la tecnología, Inrupt, es una empresa que construye a partir de la plataforma de código abierto de Berners-Lee Solid.
Solid permite a los usuarios elegir dónde se almacenan sus datos y qué personas pueden tener acceso a qué información.
En una entrevista exclusiva con Fast Company, Berners-Lee bromeó diciendo que la intención detrás de Inrupt es "dominación mundial".
"Tenemos que hacerlo ahora," dijo sobre la startup.
"Es un momento histórico".
La aplicación utiliza la tecnología de Solid para permitir a las personas crear su propia "tienda de datos personales en línea" o un POD.
Puede contener listas de contactos, listas de tareas pendientes, calendario, biblioteca de música y otras herramientas personales y profesionales.
Es como Google Drive, Microsoft Outlook, Slack y Spotify están disponibles en un solo navegador y todos al mismo tiempo.
Lo que es único en la tienda de datos personales en línea es que depende completamente del usuario que puede acceder a qué tipo de información.
La compañía lo llama "empoderamiento personal a través de datos".
La idea de Inrupt, según el CEO de la compañía, John Bruce, es que la compañía traiga recursos, procesos y habilidades apropiadas para ayudar a poner Solid a disposición de todos.
Actualmente la compañía está compuesta por Berners-Lee, Bruce, una plataforma de seguridad comprada por IBM, algunos desarrolladores contratados para trabajar en el proyecto, y una comunidad de programadores voluntarios.
A partir de esta semana, los desarrolladores de tecnología de todo el mundo podrían crear sus propias aplicaciones descentralizadas utilizando las herramientas disponibles en el sitio web Inrupt.
Berners-Lee dijo que él y su equipo no están hablando con "Facebook y Google sobre si introducir o no un cambio completo donde todos sus modelos de negocio están completamente alterados de la noche a la mañana.
"No les estamos pidiendo permiso."
En un post publicado el sábado en Medium, Berners-Lee escribió que "la misión de Inrupt es proporcionar energía comercial y un ecosistema para ayudar a proteger la integridad y la calidad de la nueva web construida en Solid".
En 1994, Berners-Lee transformó Internet cuando estableció el World Wide Web Consortium en el Massachusetts Institute of Technology.
En los últimos meses, Berners-Lee ha sido una voz influyente en el debate sobre la neutralidad de la red.
Incluso durante el lanzamiento de Inrupt, Berners-Lee seguirá siendo el fundador y director del World Wide Web Consortium, la Web Foundation y el Open Data Institute.
"Soy increíblemente optimista para esta próxima era de la web", agregó Berners-Lee.
Bernard Vann: Celebración del clérigo de la Cruz Victoria
El único clérigo de la Iglesia de Inglaterra que ganó una Cruz Victoria durante la Primera Guerra Mundial como combatiente se ha celebrado en su ciudad natal 100 años después.
Teniente Coronel El reverendo Bernard Vann ganó el premio el 29 de septiembre de 1918 en el ataque en Bellenglise y Lehaucourt.
Sin embargo, fue asesinado por un francotirador cuatro días después y nunca supo que había ganado el más alto honor militar británico.
Una piedra conmemorativa fue descubierta por sus dos nietos en un desfile en Rushden, Northamptonshire, el sábado.
Uno de sus nietos, Michael Vann, dijo que era "brillantemente simbólico" que la piedra se revelaría exactamente 100 años después de la hazaña galardonada de su abuelo.
Según la Gaceta de Londres, el 29 de septiembre de 1918 el Teniente Coronel Vann dirigió su batallón a través del Canal de Saint-Quentin "a través de una niebla muy espesa y bajo fuego pesado de campo y ametralladoras".
Más tarde corrió a la línea de fuego y con la "mayor galantería" llevó la línea hacia delante antes de lanzar una pistola de campo con una sola mano y noqueó a tres del destacamento.
El teniente coronel Vann fue asesinado por un francotirador alemán el 4 de octubre de 1918, poco más de un mes antes de que terminara la guerra.
Michael Vann, de 72 años, dijo que las acciones de su abuelo eran "algo que sé que nunca podría estar a la altura de algo que es humillante".
Él y su hermano el Dr. James Vann también colocaron una corona después del desfile, que fue dirigido por la Banda Juvenil Imperial de Brentwood.
Michael Vann dijo que "se sentía muy honrado de desempeñar un papel en el desfile" y agregó que "el valor de un héroe genuino está siendo demostrado por el apoyo que va a ser dado por mucha gente".
Los fans de MMA se quedaron despiertos toda la noche para ver Bellator 206, tienen Peppa Pig en su lugar
Imagínese esto, usted se ha quedado despierto toda la noche para ver el un Bellator 206 lleno sólo para ser negado a ver el evento principal.
El proyecto de ley de San José contenía 13 peleas, incluyendo seis en la tarjeta principal y se mostraba en vivo durante la noche en el Reino Unido en el Canal 5.
A las 6 de la mañana, justo cuando Gegard Mousasi y Rory MacDonald se preparaban para enfrentarse, los espectadores en el Reino Unido quedaron atónitos cuando la cobertura cambió a Peppa Pig.
Algunos no estaban impresionados después de que habían permanecido despiertos hasta las primeras horas, especialmente para la pelea.
Un fan en Twitter describió el cambio a la caricatura de los niños como "una especie de broma enferma".
"Es la regulación del gobierno que a las 6 a.m. ese contenido no era adecuado así que tuvieron que cambiar a la programación infantil", dijo Dave Schwartz, vicepresidente sénior de marketing y comunicación de Bellator, cuando se le preguntó sobre la transmisión.
""Peppa el cerdo," sí."
El presidente de la compañía Bellator, Scott Coker, dijo que van a trabajar en su programación para incluir a los espectadores del Reino Unido en el futuro.
"Creo que cuando pienso en la repetición, creo que probablemente podamos resolverlo", dijo Coker.
"Pero son las seis de la mañana de un domingo y no podremos resolver esto hasta el domingo de nuestro tiempo, el lunes de su tiempo.
Pero estamos trabajando en ello.
Créanme, cuando cambió, había un montón de mensajes yendo y viniendo y todos no eran amistosos.
Tratamos de arreglarlo, pensamos que era un fallo técnico.
Pero no lo era, era un asunto gubernamental.
Puedo prometerte que la próxima vez no va a pasar.
Lo mantendremos en cinco peleas en lugar de seis, como normalmente hacemos, y tratamos de sobreentregar a los fans y acabamos de pasar.
Es una situación lamentable".
Discos de Desert Island: Tom Daley sintió 'inferior' sobre la sexualidad
El buzo olímpico Tom Daley dice que creció sintiéndose inferior a todos debido a su sexualidad - pero eso le dio la motivación para convertirse en un éxito.
El niño de 24 años dijo que no se dio cuenta hasta que fue a la escuela secundaria de que "no todos son como yo".
Hablando en los primeros discos de Radio 4 Desert Island presentados por Lauren Laverne, dijo que habló sobre los derechos de los gays para dar a otros "esperanza".
También dijo que convertirse en padre hizo que le importara menos ganar las Olimpiadas.
El presentador regular del programa de larga duración, Kirsty Young, se ha tomado varios meses de descanso debido a la enfermedad.
Al aparecer como un náufrago en el primer programa de Laverne, Daley dijo que se sentía "menos" que todos los demás que crecían porque "no era socialmente aceptable gustar a los niños y las niñas".
Dijo: "Hasta el día de hoy, esos sentimientos de sentir menos que, y sentirse diferente, han sido las cosas reales que me han dado el poder y la fuerza para ser capaz de tener éxito".
Quería demostrar que era "algo", dijo, para no decepcionar a todos cuando finalmente se enteraron de su sexualidad.
El dos veces medallista olímpico de bronce se ha convertido en un destacado activista LGBT y utilizó su aparición en los Juegos de la Commonwealth de este año en Australia para hacer un llamamiento a más países para despenalizar la homosexualidad.
Dijo que habló porque se sentía afortunado de poder vivir abiertamente sin ramificaciones y quería dar a otros "esperanza".
El tres veces campeón del mundo dijo que enamorarse de un hombre - el cineasta estadounidense Dustin Lance Black, a quien conoció en 2013 - "me atrapó por sorpresa".
Daley se casó con el ganador del Oscar, que es 20 años mayor, el año pasado, pero dijo que la diferencia de edad nunca había sido un problema.
"Cuando usted pasa por tanto a una edad tan joven" - él fue a sus primeros Juegos Olímpicos de 14 años y su padre murió de cáncer tres años más tarde - dijo que era difícil encontrar a alguien de la misma edad que había experimentado altos y bajos similares.
La pareja se convirtió en padres en junio, a un hijo llamado Robert Ray Black-Daley, y Daley dijo que su "perspectiva completa" había cambiado.
"Si me lo hubieras preguntado el año pasado, todo se trataba de 'necesito ganar una medalla de oro'", dijo.
"Sabes qué, hay cosas más grandes que las medallas de oro olímpicas.
Mi medalla de oro olímpica es Robbie".
Su hijo tiene el mismo nombre que su padre Robert, que murió en 2011 a los 40 años después de ser diagnosticado con cáncer de cerebro.
Daley dijo que su padre no aceptó que iba a morir y una de las últimas cosas que había preguntado era si todavía tenían sus entradas para Londres 2012 - ya que quería estar en la primera fila.
"No podía decirle 'no vas a estar cerca para estar en la primera fila de papá'", dijo.
"Estaba sosteniendo su mano mientras dejaba de respirar y no fue hasta que realmente dejó de respirar y estaba muerto que finalmente reconocí que no era invencible", dijo.
Al año siguiente Daley compitió en los Juegos Olímpicos de 2012 y ganó bronce.
"Simplemente sabía que esto era lo que había soñado de toda mi vida: bucear frente a una multitud local en los Juegos Olímpicos, no había mejor sensación", dijo.
También inspiró su primera elección de canción - Orgullosa por Heather Small - que había resonado con él en la construcción hasta los Juegos Olímpicos y todavía le dio gansos.
Desert Island Discs está en BBC Radio 4 el domingo a las 11:15 BST.
Mickelson hizo banca en la Ryder Cup el sábado
El estadounidense Phil Mickelson establecerá un récord el domingo cuando juegue su 47o partido de la Copa Ryder, pero tendrá que cambiar su forma para evitar que sea un hito infeliz.
Mickelson, jugando en el evento bienal por 12a vez récord, fue bancado por el capitán Jim Furyk para las cuatro bolas y cuartetos del sábado.
En lugar de estar en el centro de la acción, como tan a menudo lo ha estado para los Estados Unidos, el cinco veces mayor ganador dividió su día entre ser una animadora y trabajar en su juego en el campo de tiro con la esperanza de rectificar lo que le aflige.
Nunca el más recto de los pilotos, ni siquiera en el apogeo de su carrera, el de 48 años de edad no es un lugar ideal para el apretado campo nacional de Le Golf, donde la larga ruda castiga rutinariamente disparos errantes.
Y si el curso por sí solo no es lo suficientemente desalentador, Mickelson, en el noveno partido del domingo, se enfrenta al campeón del British Open Francesco Molinari, que se ha asociado con el novato Tommy Fleetwood para ganar los cuatro partidos de esta semana.
Si los americanos, cuatro puntos abajo comenzando los 12 partidos singles, bajan a un arranque caliente, el partido de Mickelson podría ser absolutamente crucial.
Furyk expresó confianza en su hombre, no que pudiera decir mucho más.
"Entendió completamente el papel que tenía hoy, me dio una palmadita en la espalda y puso su brazo alrededor de mí y dijo que estaría listo mañana," dijo Furyk.
"Tiene mucha confianza en sí mismo.
Es un Hall of Famer y ha añadido mucho a estos equipos en el pasado, y esta semana.
Probablemente no lo imaginé jugando dos partidos.
Imaginé más, pero así es como funcionó y así es como pensamos que teníamos que ir.
Quiere estar ahí fuera, como todos los demás".
Mickelson superará el récord de Nick Faldo para los partidos más Ryder Cup jugados el domingo.
Podría marcar el final de una carrera de la Ryder Cup que nunca ha coincidido con las alturas de su récord individual.
Mickelson tiene 18 victorias, 20 derrotas y siete mitades, aunque Furyk dijo que su presencia trajo algunos intangibles al equipo.
"Es gracioso, es sarcástico, ingenioso, le gusta burlarse de la gente, y es un gran tipo para tener en la sala de equipo", explicó.
"Creo que los jugadores más jóvenes se divirtieron con él, también, esta semana, lo cual fue divertido de ver.
Provee mucho más que jugar".
El capitán europeo Thomas Bjorn sabe que el gran plomo puede desaparecer pronto.
Thomas Bjorn, el capitán europeo, sabe por experiencia que una ventaja considerable que se dirige a los sencillos de último día en la Ryder Cup puede convertirse fácilmente en un viaje incómodo.
El danés hizo su debut en el partido de 1997 en Valderrama, donde un lado capitaneado por Seve Ballesteros tenía una ventaja de cinco puntos sobre los estadounidenses, pero sólo acaba de superar la línea de meta con sus narices en frente por los márgenes más estrechos, ganando 141⁄2-131/2.
"Sigues recordándote a ti mismo que teníamos una gran ventaja en Valderrama; Tuvimos una gran ventaja en Brookline, donde perdimos, y en Valderrama, donde ganamos, pero sólo justo", dijo Bjorn, imaginado, después de ver a la Clase de 2018 ganar 5-3 tanto el viernes como ayer para liderar 10-6 en Le Golf National.
Así que la historia nos mostrará a mí y a todos en ese equipo que esto no ha terminado.
Mañana te aburrirás mucho.
Sal ahí fuera y haz todo lo correcto.
Esto no termina hasta que no tengas los puntos en el tablero.
Tenemos un objetivo, y es tratar de ganar este trofeo, y ahí es donde el foco se queda.
He dicho todo el tiempo, me concentro en los 12 jugadores que están de nuestro lado, pero somos muy conscientes de lo que está de pie en el otro lado - los mejores jugadores del mundo ".
Encantado de cómo sus jugadores han actuado en un campo de golf duro, Bjorn agregó: "Nunca me adelantaría a mí mismo en esto.
Mañana es una bestia diferente.
Mañana son las actuaciones individuales que se presentan, y eso es una cosa diferente a hacer.
Es genial estar ahí fuera con un compañero cuando las cosas van bien, pero cuando estás por ahí individualmente, entonces te prueban hasta el máximo de tu capacidad como golfista.
Ese es el mensaje que necesitas para llegar a los jugadores, es sacar lo mejor de ti mismo mañana.
Ahora, deja a tu compañero atrás y él tiene que ir y sacar lo mejor de sí mismo, también."
En contraste con Bjorn, el número opuesto Jim Furyk estará buscando a sus jugadores para actuar mejor individualmente que lo hicieron como socios, las excepciones son Jordan Spieth y Justin Thomas, que recogió tres puntos de cuatro.
Furyk mismo ha estado en ambos extremos de esos grandes giros del último día, habiendo sido parte del equipo ganador en Brookline antes de terminar siendo un perdedor cuando Europa sacó el "Miracle en Medinah".
"Recuerdo cada maldita palabra", dijo en respuesta a la pregunta de cómo Ben Crenshaw, el capitán en 1999, había reunido a sus jugadores en el último día.
"Tenemos 12 partidos importantes mañana, pero te gustaría empezar rápido como lo viste en Brookline, como viste en Medinah.
Cuando ese impulso va en una dirección, pone mucha presión en esos partidos intermedios.
Preparamos nuestra alineación en consecuencia y pusimos a los chicos en la forma que sentimos, ya sabes, estamos tratando de hacer algo de magia mañana".
Thomas ha sido entregado la tarea de tratar de liderar la lucha y se enfrenta a Rory McIlroy en el primer partido, con Paul Casey, Justin Rose, Jon Rahm, Tommy Fleetwood e Ian Poulter los otros europeos en la mitad superior de la orden.
"Fui con este grupo de chicos en este orden porque creo que cubre todo el camino a través de", dijo Bjorn de sus selecciones individuales.
El nuevo buque de guerra de Alemania volvió a aplazarse
La nueva fragata de la Armada alemana debería haber sido encargada en 2014 para reemplazar a los viejos buques de guerra de la era de la Guerra Fría, pero no estará allí hasta al menos el próximo año debido a los sistemas defectuosos y el costo de las bolas de nieve, informaron los medios locales.
La puesta en marcha de la "Rheinland-Pfalz", el buque líder de las nuevas fragatas Baden-Wuerttemberg, se ha aplazado hasta la primera mitad de 2019, según el periódico Die Zeit citando a un portavoz militar.
La nave debería haberse unido a la Marina en 2014, pero las problemáticas cuestiones posteriores a la entrega plagaron el destino del ambicioso proyecto.
Los cuatro buques de la clase Baden-Wuerttemberg que la Marina ordenó en 2007 serán reemplazados por las antiguas fragatas de la clase Bremen.
Se entiende que contarán con un cañón poderoso, una serie de misiles antiaéreos y antibuques, así como algunas tecnologías sigilosas, como la reducción de las firmas de radar, infrarrojos y acústicos.
Otras características importantes incluyen períodos de mantenimiento más largos - debería ser posible desplegar las fragatas más nuevas por hasta dos años lejos de los puertos de origen.
Sin embargo, los retrasos continuos significan que los buques de guerra de vanguardia -que según se dice permiten a Alemania proyectar el poder en el extranjero- ya estarán obsoletos para el momento en que entren en servicio, señala Die Zeit.
La fallida fragata F125 salió en los titulares el año pasado, cuando la Armada alemana se negó oficialmente a encargar el buque y lo devolvió al astillero de Blohm & Voss en Hamburgo.
Esta fue la primera vez que la Marina ha devuelto un barco a un constructor naval después de la entrega.
Poco se sabía de las razones detrás del regreso, pero los medios alemanes citaron una serie de "deficiencias de software y hardware" cruciales que hicieron que el buque de guerra fuera inútil si se desplegaba en una misión de combate.
Las deficiencias de software fueron especialmente importantes, ya que los buques de la clase Baden-Wuerttemberg serán operados por una tripulación de unos 120 marineros, sólo la mitad de la mano de obra de las antiguas fragatas de la clase Bremen.
Además, surgió que la nave tiene un sobrepeso dramático, lo que reduce su rendimiento y limita la capacidad de la Marina para agregar mejoras futuras.
Se cree que los 7.000 toneladas de "Rheinland-Pfalz" son dos veces más pesados que los buques de clase similar utilizados por los alemanes en la Segunda Guerra Mundial.
Aparte de hardware defectuoso, el precio de todo el proyecto - incluyendo la formación de la tripulación - también se está convirtiendo en un problema.
Se dice que ha alcanzado la asombrosa cifra de 3.100 millones de euros (3.600 millones de dólares), lo que supone un aumento respecto de los 2 200 millones iniciales.
Los problemas que afectan a las nuevas fragatas se vuelven especialmente importantes a la luz de las recientes advertencias de que el poder naval de Alemania se está reduciendo.
A principios de este año, Hans-Peter Bartels, jefe del comité de defensa del parlamento alemán, reconoció que la Marina en realidad "se está quedando sin barcos con capacidad de despliegue".
El funcionario dijo que el tema ha sido de bolas de nieve con el tiempo, porque los viejos barcos fueron desmantelados, pero no se proporcionaron buques de reemplazo.
Lamentó que ninguna de las fragatas de la clase Baden-Wuerttemberg pudiera unirse a la Marina.
National Trust escucha a escondidas la vida secreta de los murciélagos
Nueva investigación que se está llevando a cabo en una finca en las Highlands escocesas tiene como objetivo revelar cómo los murciélagos utilizan el paisaje en su búsqueda de alimentos.
Se espera que los resultados arrojen nueva luz sobre el comportamiento de los mamíferos voladores únicos y ayuden a orientar las futuras actividades de conservación.
El estudio realizado por científicos del National Trust for Scotland seguirá a los pipistrelles comunes y sopranos, así como a los murciélagos pardos de orejas largas y Daubenton en Inverewe Gardens en Wester Ross.
Grabadoras especiales se colocarán en lugares clave alrededor de la propiedad para seguir las actividades de murciélagos durante toda la temporada.
El personal del Servicio Nacional de Salud y los voluntarios también realizarán encuestas móviles utilizando detectores portátiles.
El análisis de sonido experto de todas las grabaciones determinará la frecuencia de las llamadas de los murciélagos y qué especies están haciendo qué.
A continuación se elaborará un mapa del hábitat y un informe para crear una imagen detallada de su comportamiento a escala paisajística.
Rob Dewar, asesor de conservación de la naturaleza para NTS, espera que los resultados revelen qué áreas de hábitat son más importantes para los murciélagos y cómo son utilizados por cada una de las especies.
Esta información ayudará a determinar los beneficios del trabajo de manejo de hábitats como la creación de prados y la mejor manera de mantener bosques para murciélagos y otras especies asociadas.
Las poblaciones de murciélagos en Escocia y en todo el Reino Unido han disminuido considerablemente en el último siglo.
Están amenazados por trabajos de construcción y desarrollo que afectan a los pastos y la pérdida de hábitat.
Las turbinas eólicas y la iluminación también pueden plantear un riesgo, al igual que los flypapers y algunos tratamientos químicos de materiales de construcción, así como los ataques de gatos de mascotas.
Los murciélagos no son realmente ciegos.
Sin embargo, debido a sus hábitos nocturnos de caza, sus oídos son más útiles que sus ojos cuando se trata de atrapar presas.
Utilizan una sofisticada técnica de eco-localización para detectar errores y obstáculos en su trayectoria de vuelo.
El NTS, que es responsable del cuidado de más de 270 edificios históricos, 38 jardines importantes y 76.000 hectáreas de tierra en todo el país, toma los murciélagos muy en serio.
Cuenta con diez expertos capacitados, que llevan a cabo periódicamente encuestas, inspecciones de pastos y, a veces, rescates.
La organización incluso ha establecido la primera y única reserva de murciélagos de Escocia en Threave estate en Dumfries y Galloway, que es el hogar de ocho de las diez especies de murciélagos de Escocia.
David Thompson dice que la finca es el territorio ideal para ellos.
"Aquí en Threave tenemos una gran área para los murciélagos," dijo.
"Tenemos los viejos edificios, muchos árboles veteranos y todo el buen hábitat.
Pero hay mucho acerca de los murciélagos que todavía se desconoce, por lo que el trabajo que hacemos aquí y en otras propiedades nos ayudará a entender más acerca de lo que necesitan para prosperar".
Hace hincapié en la importancia de comprobar si hay murciélagos antes de llevar a cabo el mantenimiento dentro de las propiedades, ya que es posible la destrucción involuntaria de un solo gallo de maternidad podría matar hasta 400 hembras y jóvenes, posiblemente aniquilando a toda una población local.
Los murciélagos están protegidos y es ilegal matarlos, acosarlos o molestarlos o destruir sus gallos.
Elisabeth Ferrell, oficial escocesa del Bat Conservation Trust, ha alentado al público a ayudar.
Ella dijo: "Todavía tenemos mucho que aprender sobre nuestros murciélagos y para muchas de nuestras especies simplemente no sabemos cómo les va a sus poblaciones".
Ronaldo desestima las denuncias de violación como abogados encargados de demandar a la revista alemana
Cristiano Ronaldo ha calificado las denuncias de violación en su contra como "noticia falsa", diciendo que la gente "quiere promoverse a sí misma" usando su nombre.
Sus abogados demandarán a la revista alemana Der Spiegel, que publicó las acusaciones.
El Portugal y la Juventus han sido acusados de violar a una mujer americana, llamada Kathryn Mayorga, en una habitación de hotel en Las Vegas en 2009.
Se dice que luego le pagó $375,000 para guardar silencio sobre el incidente, informó Der Spiegel el viernes.
Hablando en un video en vivo de Instagram a sus 142 millones de seguidores horas después de que las afirmaciones fueran reportadas, Ronaldo, de 33 años, clasificó los informes como "noticia falsa".
"No, no, no, no, no.
Lo que dijeron hoy, noticias falsas", dice el cinco veces ganador de Ballon d'Or a la cámara.
"Quieren promocionarse usando mi nombre.
Es normal.
Quieren ser famosos por decir mi nombre, pero es parte del trabajo.
Soy un hombre feliz y todo bien", añadió el jugador, sonriendo.
Los abogados de Ronaldo se están preparando para demandar a Der Spiegel por las acusaciones, que han llamado "un reporte inadmisible de sospechas en el área de la privacidad", según Reuters.
El abogado Christian Schertz dijo que el jugador pediría indemnización por "daños morales en una cantidad correspondiente a la gravedad de la infracción, que es probablemente una de las violaciones más graves de los derechos personales en los últimos años".
Se dice que el presunto incidente tuvo lugar en junio de 2009 en una suite del Palms Hotel and Casino en Las Vegas.
Después de reunirse en un club nocturno, Ronaldo y Mayorga habrían vuelto a la habitación del jugador, donde supuestamente la violó analmente, según documentos presentados en el Tribunal de Distrito del Condado Clark en Nevada.
Mayorga afirma que Ronaldo cayó de rodillas después del supuesto incidente y le dijo que era "99 por ciento" un "buen tipo" defraudado por el "uno por ciento".
Los documentos afirman que Ronaldo confirmó que la pareja tuvo sexo, pero que fue consensual.
Mayorga también afirma que fue a la policía y que le tomaron fotografías de sus heridas en un hospital, pero más tarde accedió a un acuerdo extrajudicial porque se sentía "terrible de represalias" y estaba preocupada por "ser humillada públicamente".
La joven de 34 años dice que ahora está tratando de anular el asentamiento mientras sigue traumatizada por el supuesto incidente.
Ronaldo estaba a punto de unirse al Real Madrid desde el Manchester United en el momento del supuesto asalto, y este verano se trasladó a los gigantes italianos Juve en un acuerdo de 100 millones de euros.
Brexit: Reino Unido 'se arrepentiría para siempre' perder fabricantes de coches
El Reino Unido "lo lamentaría para siempre" si perdiera su estatus como líder mundial en la fabricación de automóviles después del Brexit, dijo el secretario de negocios Greg Clark.
Añadió que era "preocupante" que Toyota UK le hubiera dicho a la BBC que si Gran Bretaña abandonaba la UE sin un acuerdo, detendría temporalmente la producción en su fábrica en Burnaston, cerca de Derby.
"Necesitamos un trato", dijo el Sr. Clark.
El fabricante de automóviles japonés dijo que el impacto de los retrasos fronterizos en el caso de un Brexit sin acuerdo podría costar puestos de trabajo.
La planta de Burnaston, que fabrica Auris y Avensis de Toyota, produjo cerca de 150.000 automóviles el año pasado, de los cuales el 90% se exportaron al resto de la Unión Europea.
"Mi opinión es que si Gran Bretaña sale de la UE a finales de marzo veremos paradas de producción en nuestra fábrica", dijo Marvin Cooke, director gerente de Toyota en Burnaston.
Otros fabricantes de automóviles del Reino Unido han suscitado temores de salir de la UE sin llegar a un acuerdo sobre cómo funcionará el comercio transfronterizo, incluidos Honda, BMW y Jaguar Land Rover.
BMW, por ejemplo, dice que cerrará su Mini planta en Oxford durante un mes después del Brexit.
Las principales preocupaciones se refieren a lo que dicen los fabricantes de automóviles son los riesgos de la cadena de suministro en caso de un Brexit no-deal.
La línea de producción de Toyota se ejecuta "justo a tiempo", con piezas que llegan cada 37 minutos de proveedores tanto en el Reino Unido como en la UE para automóviles hechos a pedido.
Si el Reino Unido abandona la UE sin un acuerdo el 29 de marzo, podría producirse una interrupción en la frontera que, según la industria, podría provocar retrasos y escasez de piezas.
Sería imposible para Toyota tener más de un día de inventario en su planta de Derbyshire, dijo la compañía, y por lo tanto la producción se detendría.
El Sr. Clark dijo que el plan Chequers de Theresa May para futuras relaciones con la UE está "precisamente calibrado para evitar esos controles en la frontera".
"Necesitamos un trato. Queremos tener el mejor trato que permita, como digo, no sólo disfrutar del éxito actual, sino que aprovechemos esta oportunidad", dijo a BBC Radio 4's Today.
"La evidencia no sólo de Toyota sino de otros fabricantes es que tenemos que ser absolutamente capaces de continuar lo que ha sido un conjunto de cadenas de suministro altamente exitoso".
Toyota no pudo decir cuánto tiempo se detendría la producción, pero a más largo plazo, advirtió que los costos adicionales reducirían la competitividad de la planta y eventualmente costarían puestos de trabajo.
Peter Tsouvallaris, que ha trabajado en Burnaston durante 24 años y es el organizador del sindicato Unite en la planta, dijo que sus miembros están cada vez más preocupados: "En mi experiencia una vez que estos trabajos se van nunca vuelven.
Un portavoz del Gobierno dijo: "Hemos presentado un plan preciso y creíble para nuestra futura relación con la UE".
La reunión de Trump con Rosenstein puede retrasarse de nuevo, dice la Casa Blanca
La reunión de alto nivel de Donald Trump con el viceprocurador general Rod Rosenstein podría "regresar otra semana" mientras la lucha por el candidato de la Corte Suprema Brett Kavanaugh continúa, dijo la Casa Blanca el domingo.
Rosenstein supervisa el trabajo del abogado especial Robert Mueller, que está investigando la interferencia electoral rusa, los vínculos entre los ayudantes de Trump y Rusia y la posible obstrucción de la justicia por parte del presidente.
El hecho de que Trump despida o no al fiscal general adjunto y ponga en peligro la independencia de Mueller ha alimentado los chismes de Washington durante meses.
A principios de este mes, el New York Times informó que Rosenstein discutió usar un micrófono para grabar conversaciones con Trump y la posibilidad de destituir al presidente a través de la enmienda 25.
Rosenstein negó el informe.
Pero el lunes pasado fue a la Casa Blanca, en medio de informes que estaba a punto de renunciar.
En cambio, se anunció para el jueves una reunión con Trump, que entonces estaba en las Naciones Unidas en Nueva York.
Trump dijo que "preferiría no" despedir a Rosenstein, pero luego la reunión se retrasó para evitar un enfrentamiento con la audiencia del comité judicial del Senado en la que Kavanaugh y una de las mujeres que lo han acusado de mala conducta sexual, la Dra. Christine Blasey Ford, testificaron.
El viernes, Trump ordenó una investigación del FBI de una semana de reclamaciones contra Kavanaugh, retrasando aún más la votación del Senado.
La secretaria de prensa de Trump, Sarah Sanders, apareció en Fox News Sunday.
Preguntada sobre la reunión de Rosenstein, dijo: "Una fecha para eso no se ha fijado, podría ser esta semana, pude ver que empujando hacia atrás otra semana dada todas las otras cosas que están pasando con la corte suprema.
Pero ya veremos y siempre me gusta mantener actualizada a la prensa".
Algunos reporteros impugnarían esa afirmación: Sanders no ha celebrado una rueda de prensa de la Casa Blanca desde el 10 de septiembre.
El anfitrión Chris Wallace preguntó por qué.
Sanders dijo que la escasez de sesiones informativas no se debía a un disgusto para los reporteros de televisión "grandstanding", aunque dijo: "No voy a estar en desacuerdo con el hecho de que son grandstanding".
Luego sugirió que aumentaría el contacto directo entre Trump y la prensa.
"El presidente hace más sesiones de preguntas y respuestas que cualquier presidente anterior a él", dijo, agregando sin citar pruebas: "Hemos mirado esos números".
Las reuniones de información seguirán ocurriendo, dijo Sanders, pero "si la prensa tiene la oportunidad de hacerle preguntas directamente al presidente de los Estados Unidos, eso es infinitamente mejor que hablar conmigo.
Tratamos de hacerlo mucho y nos han visto hacerlo mucho en las últimas semanas y eso va a tomar el lugar de una rueda de prensa cuando puedan hablar con el presidente de los Estados Unidos".
Trump toma preguntas regularmente cuando sale de la Casa Blanca o participa en sesiones abiertas o conferencias de prensa con dignatarios visitantes.
Las conferencias de prensa individuales son raras.
En Nueva York esta semana el presidente tal vez demostró por qué, haciendo una aparición libre y a veces extraña antes de los reporteros reunidos.
Secretario de Salud escribe a trabajadores de la UE en el NHS Escocia sobre los temores del Brexit
El Secretario de Sanidad ha escrito al personal de la UE que trabaja en el Servicio Nacional de Salud de Escocia para expresar la gratitud del país y su deseo de que permanezcan en el puesto de Brexit.
Jeane Freeman MSP envió una carta con menos de seis meses hasta que el Reino Unido se retire de la UE.
El Gobierno escocés ya se ha comprometido a sufragar el coste de las solicitudes de estatuto establecido para los ciudadanos de la UE que trabajan en sus servicios públicos descentralizados.
En su carta, la Sra. Freeman escribió: "Durante el verano, las negociaciones entre el Reino Unido y la UE sobre la retirada han continuado, dirigiéndose hacia las decisiones previstas para este otoño.
Pero el Gobierno del Reino Unido también ha intensificado sus preparativos para un posible escenario sin arreglo.
Sé que este debe ser un momento muy inquietante para todos ustedes.
Por eso quería reiterar ahora cuánto valoro la contribución de cada miembro del personal, independientemente de su nacionalidad.
Colegas de toda la UE, y más allá, aportan valiosa experiencia y habilidades que fortalecen y mejoran el trabajo del servicio de salud, y benefician a los pacientes y las comunidades a las que servimos.
Escocia es absolutamente su hogar y queremos mucho que se quede aquí."
Christion Abercrombie se somete a cirugía de emergencia después de sufrir lesión en la cabeza
El linebacker de Tennessee State Tigers, Christion Abercrombie, se sometió a una cirugía de emergencia después de sufrir una lesión en la cabeza en la derrota del sábado 31-27 ante el Vanderbilt Commodores, informó el órgano Mike de Tennessean.
El entrenador del estado de Tennessee Rod Reed le dijo a los reporteros que la lesión ocurrió poco antes del medio tiempo.
"Vino a la línea lateral y simplemente se derrumbó allí", dijo Reed.
Entrenadores y personal médico le dieron oxígeno a Abercrombie en la línea lateral antes de ponerlo en una camilla y llevarlo de vuelta para una evaluación adicional.
Un funcionario del estado de Tennessee le dijo a Chris Harris de WSMV en Nashville, Tennessee, que Abercrombie estaba fuera de cirugía en el Centro Médico Vanderbilt.
Harris agregó que "no hay detalles sobre el tipo o extensión de la lesión todavía" y el estado de Tennessee está tratando de averiguar cuándo ocurrió la lesión.
Abercrombie, un estudiante de segundo año de camiseta roja, está en su primera temporada con Tennessee State después de transferirse de Illinois.
Tuvo cinco tackleadas totales el sábado antes de salir del partido, lo que llevó su temporada total a 18 tackleadas.
Los compradores extranjeros cobrarán más derechos de timbre cuando compren una propiedad en el Reino Unido
A los compradores extranjeros se les cobrará más derechos de timbre cuando compren una propiedad en el Reino Unido con el dinero adicional utilizado para ayudar a las personas sin hogar bajo nuevos planes Tory
La medida neutralizará el éxito de la campaña de Corbyn para atraer a jóvenes votantes
El aumento de los derechos de timbre se aplicará a los que no paguen impuestos en el Reino Unido
El Tesoro espera que aumente hasta 120 millones de libras al año para ayudar a las personas sin hogar
Los compradores extranjeros están dispuestos a cobrar una tasa de derechos de timbre más alta cuando compren una propiedad en el Reino Unido - con el dinero adicional utilizado para ayudar a las personas sin hogar, Theresa May anunciará hoy.
La medida será vista como un intento de neutralizar el éxito de la campaña de Jeremy Corbyn para atraer a los votantes jóvenes con promesas de proporcionar una vivienda más asequible y apuntar a los altos ingresos.
El aumento de los derechos de timbre se aplicará a las personas físicas y las empresas que no paguen impuestos en el Reino Unido, con el dinero adicional que impulsa el impulso del Gobierno para luchar contra el sueño duro.
El recargo -que se suma al derecho de timbre actual, incluidos los niveles más altos introducidos hace dos años en las segundas viviendas y en las ventas- podría llegar a ser del 3%.
El Tesoro espera que el movimiento aumente hasta 120 millones de libras al año.
Se estima que un 13% de las propiedades de nueva construcción de Londres son compradas por residentes que no son del Reino Unido, lo que aumenta los precios y hace que sea más difícil para los compradores por primera vez conseguir un pie en la escalera de la vivienda.
Muchas zonas ricas del país - particularmente en la capital - se han convertido en "pueblos fantasmas" debido al gran número de compradores extranjeros que pasan la mayor parte de su tiempo fuera del país.
La nueva política llega pocas semanas después de que Boris Johnson pidiera un recorte en el impuesto de timbre para ayudar a más jóvenes a poseer su primer hogar.
Acusó a las grandes empresas de construcción de mantener altos los precios de la propiedad al romper la tierra pero no utilizarla, e instó a la Sra. May a abandonar las cuotas en viviendas asequibles para arreglar la "hogar desgracia" de Gran Bretaña.
El Sr. Corbyn ha anunciado una serie llamativa de reformas de la vivienda propuestas, incluidos los controles de alquiler y el fin de los desalojos "sin culpa".
También quiere dar a los consejos mayores poderes para construir nuevas casas.
La Sra. May dijo: "El año pasado dije que dedicaría mi presidencia a restaurar el sueño británico: que la vida debería ser mejor para cada nueva generación.
Y eso significa arreglar nuestro mercado de viviendas rotas.
Gran Bretaña siempre estará abierta a las personas que quieran vivir, trabajar y construir una vida aquí.
Sin embargo, no puede ser correcto que sea tan fácil para las personas que no viven en el Reino Unido, así como para las empresas con sede en el extranjero, comprar casas como residentes británicos trabajadores.
Para demasiadas personas el sueño de la propiedad de la casa se ha vuelto demasiado lejano, y la indignidad del sueño áspero sigue siendo demasiado real".
Jack Ross: 'Mi última ambición es administrar Escocia'
El jefe de Sunderland, Jack Ross, dice que su "última ambición" es convertirse en el manager de Escocia en algún momento.
El escocés, de 42 años, está disfrutando del desafío de revivir el club del noreste, que actualmente ocupa el tercer lugar en la Liga Uno, tres puntos de ventaja.
Se trasladó al Estadio de la Luz este verano después de guiar a St Mirren de vuelta a la Premiership escocesa la temporada pasada.
"Quería jugar para mi país como jugador.
Tengo una gorra B y eso fue todo", dijo Ross a BBC Scotland's Sportsound.
"Pero crecí viendo Escocia en Hampden mucho con mi padre de niño, y siempre es algo que me ha atraído de vuelta.
Sin embargo, esa oportunidad sólo llegaría si tuviera éxito en la gestión del club".
Los predecesores de Ross como gerente de Sunderland incluyen a Dick Advocaat, David Moyes, Sam Allardyce, Martin O'Neill, Roy Keane, Gus Poyet y Paulo Di Canio.
El ex jefe de Alloa Athletic dice que no sintió temor en seguir nombres tan establecidos en un club tan grande, habiendo rechazado previamente las oberturas de Barnsley e Ipswich Town.
"El éxito para mí en este momento será medido por '¿Puedo devolver este club a la Premier League?'
Debido a la estructura y las instalaciones de este club, sin duda pertenece a la Premier League", dijo.
"No es una tarea fácil llegar allí, pero probablemente solo me consideraría exitoso si pudiera volver a tener el club allí".
Ross está a sólo tres años de su carrera de gerente, después de un período como jefe asistente en Dumbarton y un hechizo de 15 meses en el equipo de entrenamiento de Corazones.
Luego ayudó a Alloa a recuperarse de la relegación al tercer nivel, y transformó a St Mirren del borde de la relegación a los ganadores del título del Campeonato la temporada siguiente.
Y Ross dice que se siente más cómodo ahora que nunca durante su carrera en Clyde, Hartlepool, Falkirk, St Mirren y Hamilton Academical.
"Probablemente fue una verdadera encrucijada", recordó, de hacerse cargo de Alloa.
"De verdad creía que la dirección era la adecuada para mí, más que jugar.
Suena extraño porque lo hice bien, hice una vida razonable de ello, y disfruté de algunos máximos razonables.
Pero jugar puede ser duro.
Hay un montón de cosas que tienes que conseguir a través de una base semanal.
Todavía lo hago en términos de las tensiones y la presión del trabajo, pero la dirección se siente bien.
Siempre quise manejarlo y ahora lo estoy haciendo, se siente lo más cómodo que he estado en mi propia piel durante toda mi vida adulta".
Puedes escuchar la entrevista completa en Sportsound el domingo 30 de septiembre, en Radio Escocia entre las 12:00 y las 13:00 BST
El momento perfecto para una pinta es a las 17:30 en un sábado, encuesta encuentra
La ola de calor de verano ha aumentado las tomas para los pubs británicos que luchan, pero ha acumulado más presión sobre las cadenas de restaurantes.
Los grupos de bares y pubs registraron un aumento de ventas del 2,7% en julio, pero los ingresos en restaurantes disminuyeron un 4,8%, según las cifras.
Peter Martin, de la consultora de negocios CGA, que compiló las cifras, dijo: "Continuó el sol y la participación más larga de lo esperado en Inglaterra en la Copa del Mundo significó que julio siguió un patrón similar al mes anterior de junio, cuando los pubs subieron un 2,8%, excepto que los restaurantes fueron golpeados aún más fuerte.
La caída del 1,8% en el comercio de restaurantes en junio acaba de empeorar en julio.
Bares y pubs con bebidas realizados por lejos el más fuerte con gusto-por-como arriba más que los restaurantes estaban abajo.
Los pubs de comida también sufrieron bajo el sol, aunque no tan dramáticamente como los operadores de restaurantes.
Parece que la gente sólo quería salir a tomar una copa.
Las ventas de bebidas en los bares y bares aumentaron un 6,6% durante el mes, con una disminución de la comida del 3%".
Paul Newman, de los analistas de ocio y hospitalidad RSM dijo: "Estos resultados continúan la tendencia que hemos visto desde finales de abril.
El clima y el impacto de los grandes eventos sociales o deportivos siguen siendo los factores más importantes cuando se trata de ventas en el mercado fuera del hogar.
No es de extrañar que los grupos de restaurantes sigan luchando, aunque una caída de ventas del 4,8% interanual será particularmente dolorosa, además de las constantes presiones sobre los costos.
El largo verano caluroso no podría haber llegado en un momento peor para los operadores dirigidos por alimentos y el tiempo dirá si las temperaturas más moderadas que hemos experimentado en agosto proporcionarán un respiro muy necesario".
El crecimiento total de las ventas en los pubs y restaurantes, incluidas las nuevas aperturas, fue del 2,7% en julio, lo que refleja la desaceleración en el despliegue de la marca.
El monitor de ventas de la industria de Coffer Peach Tracker para el sector de pubs, bares y restaurantes del Reino Unido recopila y analiza datos de rendimiento de 47 grupos operativos, con un volumen de negocios combinado de más de £9 mil millones, y es el punto de referencia establecido de la industria.
Uno de cada cinco niños tiene cuentas secretas en las redes sociales que ocultan a sus padres
Uno de cada cinco niños - algunos de tan solo 11 años - tienen cuentas secretas en las redes sociales que se esconden de sus padres y maestros, la encuesta revela
Encuesta de 20.000 alumnos de secundaria reveló crecimiento en páginas "falsas de Insta"
La noticia ha aumentado los temores de que el contenido sexual está siendo publicado
El 20% de los alumnos dijo tener una cuenta "principal" para mostrar a los padres
Uno de cada cinco niños - algunos de tan solo 11 años - están creando cuentas en las redes sociales que mantienen en secreto a los adultos.
Una encuesta de 20.000 alumnos de secundaria reveló un rápido crecimiento en las cuentas "falsas de Insta", una referencia al sitio de fotos compartidas Instagram.
La noticia ha aumentado los temores de que se publique contenido sexual.
Veinte por ciento de los alumnos dijeron que tenían una cuenta "principal" sanitizada para mostrar a los padres, mientras que también tenían una cuenta privada.
Una madre que tropezó con el sitio secreto de su hija de 13 años encontró a un adolescente instando a otros a "violarme".
La investigación, realizada por Digital Awareness UK y la Conferencia de Directores y Directoras (HMC) de escuelas independientes, reveló que el 40 por ciento de los niños de 11 a 18 años tenían dos perfiles, y la mitad de los que admitían llevar cuentas privadas.
Mike Buchanan, jefe de HMC, dijo: "Es inquietante que muchos adolescentes estén tentados a crear espacios en línea donde padres y maestros no puedan encontrarlos".
Eilidh Doyle será "voz para los atletas" en la tabla de Atletismo Escocés
Eilidh Doyle ha sido elegido miembro del Consejo de Atletismo Escocés como director no ejecutivo en la reunión general anual del órgano rector.
Doyle es la atleta de pista y campo más condecorada de Escocia y presidente Ian Beattie describió el movimiento como una gran oportunidad para aquellos que guían el deporte para beneficiarse de su amplia experiencia a nivel internacional durante la última década.
"Eilidh tiene un gran respeto en toda la comunidad escocesa, británica y mundial de atletismo y estamos seguros de que el atletismo en Escocia se beneficiaría enormemente al traerla al tablero", dijo Beattie.
Doyle dijo: "Estoy dispuesto a actuar como una voz para los atletas y espero poder contribuir y ayudar a guiar el deporte en Escocia".
El americano, que ganó los 200 metros y 400 metros en los Juegos de 1996 en Atlanta entre sus cuatro oros olímpicos y ahora es un pundit habitual de la BBC, no pudo caminar después de sufrir un ataque isquémico transitorio.
Escribió en Twitter: "Hace un mes sufrí un derrame cerebral.
No podía caminar.
Los médicos dijeron que sólo el tiempo dirá si me recuperaré o en qué grado.
Su trabajo ha sido agotador, pero hizo una recuperación completa, re-aprendió a caminar y hoy haciendo ejercicios de agilidad!
¡Gracias por los mensajes de aliento!"
Bomba de pecho anuncio comparando madres con vacas divide opinión en línea
Una empresa de leche materna ha dividido la opinión en línea con un anuncio que compara a las madres lactantes con las vacas que están siendo ordeñadas.
Para marcar el lanzamiento de lo que se dice que es el "primer golpe de pecho portátil silencioso del mundo", la empresa de tecnología de consumo Elvie lanzó un anuncio musical inspirado en el vídeo para mostrar la libertad que la nueva bomba da a las madres que expresan.
Cuatro madres reales bailan en un granero lleno de heno de vacas a una canción que incluye letras como: "Sí, me ordeño, pero no ves cola" y "En caso de que no te hayas dado cuenta de que no son ubres, son mis tetas".
El coro continúa: "Sácalo, sácalo, les estoy dando de comer bebés, sácalo, sácalo, estoy ordeñando a mis damas".
Sin embargo, el anuncio, que ha sido publicado en la página de Facebook de la firma, ha causado controversia en línea.
Con 77,000 vistas y cientos de comentarios, el video ha recibido reacciones mixtas de los espectadores, y muchos dicen que hace luz de los "horrores" de la industria láctea.
"Muy mala decisión de usar vacas para anunciar este producto.
Al igual que nosotros, necesitan quedar embarazadas y dar a luz para producir leche, excepto que sus bebés son robados a los pocos días de dar a luz", escribió uno.
El extractor de Elvie encaja discretamente dentro de un sostén de lactancia (Elvie/Madre)
Otro comentó: "Comprendeblemente traumático tanto para la madre como para el bebé.
Pero sí, ¿por qué no usarlos para anunciar un extractor de leche para las madres que pueden quedarse con sus bebés?"
Otra persona añadió: "Tal anuncio fuera de contacto".
Otros defendieron el anuncio, con una mujer admitiendo que encontraba la canción "hilarante".
"Creo que es una idea de género.
Habría tenido uno si todavía estuviera amamantando.
El bombeo me hizo sentir exactamente como una vaca.
El anuncio es un poco loco pero lo tomé por lo que era.
Este es un producto genial", escribió uno.
Otro comentó: "Este es un divertido anuncio dirigido a las madres que bombean (a menudo en sus lugares de trabajo o baños) y se sienten como "vacas".
Este no es un anuncio alabando o juzgando a la industria láctea".
Al final del video el grupo de mujeres revelan que han estado bailando con las discretas bombas metidas en sus sujetadores.
El concepto detrás de la campaña se basa en la percepción de que muchas mujeres que maman dicen que se sienten como vacas.
El Elvie Pump, sin embargo, es completamente silencioso, no tiene cables ni tubos y cabe discretamente dentro de un sostén de enfermería, dando a las mujeres la libertad de moverse, sostener a sus bebés, e incluso salir mientras bombean.
Ana Balarin, socia y ECD de Mother comentó: "El Elvie Pump es un producto tan revolucionario que merece un lanzamiento audaz y provocador.
Dibujando un paralelo entre la expresión de las mujeres y las vacas lecheras queríamos poner el bombeo de pecho y todos sus desafíos en el centro de atención, al tiempo que demostrábamos de una manera entretenida y relacionable la increíble sensación de libertad que traerá la nueva bomba.
Esta no es la primera vez que la bomba Elvie ha llegado a los titulares.
Durante la Semana de la Moda de Londres, una madre de dos hijos apareció en la pasarela para la diseñadora Marta Jakubowski mientras usaba el producto.
Cientos de niños migrantes se trasladaron en silencio a un campamento de tiendas en la frontera de Texas
El número de niños migrantes detenidos ha aumentado a pesar de que los cruces fronterizos mensuales han permanecido relativamente sin cambios, en parte porque la retórica y las políticas duras introducidas por la administración Trump han hecho más difícil colocar a los niños con patrocinadores.
Tradicionalmente, la mayoría de los patrocinadores han sido inmigrantes indocumentados, y han temido poner en peligro su propia capacidad de permanecer en el país al dar un paso adelante para reclamar un hijo.
El riesgo aumentó en junio, cuando las autoridades federales anunciaron que los posibles patrocinadores y otros miembros adultos de sus hogares tendrían que presentar huellas dactilares y que los datos se compartirían con las autoridades de inmigración.
La semana pasada, Matthew Albence, un alto funcionario de Inmigración y Aduanas, testificó ante el Congreso que la agencia había arrestado a docenas de personas que solicitaron patrocinar a menores no acompañados.
La agencia confirmó más tarde que el 70 por ciento de los arrestados no tenían antecedentes penales.
"Cerca del 80 por ciento de las personas que son patrocinadores o miembros de la familia de patrocinadores están aquí ilegalmente en el país, y una gran parte de ellos son extranjeros criminales.
Así que seguimos persiguiendo a esas personas", dijo el Sr. Albence.
Al tratar de procesar a los niños más rápidamente, los funcionarios introdujeron nuevas normas que exigirán que algunos de ellos comparezcan ante los tribunales dentro de un mes después de haber sido detenidos, en lugar de después de 60 días, que era la norma anterior, según los trabajadores de los refugios.
Muchos aparecerán a través de videoconferencias, en lugar de en persona, para defender su caso de estatus legal ante un juez de inmigración.
Aquellos que sean considerados no elegibles para el alivio serán rápidamente deportados.
Cuanto más tiempo permanezcan los niños bajo custodia, más probable es que se sientan ansiosos o deprimidos, lo que puede conducir a estallidos violentos o intentos de fuga, según los trabajadores de los refugios y los informes que han surgido del sistema en los últimos meses.
Los defensores dijeron que esas preocupaciones se intensifican en una instalación más grande como Tornillo, donde es más probable que se pasen por alto las señales de que un niño está luchando, debido a su tamaño.
Añadieron que trasladar a los niños a la tienda de campaña sin darles tiempo suficiente para prepararse emocionalmente o despedirse de sus amigos podría agravar el trauma con el que muchos ya están luchando.
Siria dice a Estados Unidos, Francia y Turquía "fuerzas ocupantes" que se retiren inmediatamente
Al dirigirse a la Asamblea General de las Naciones Unidas, el Ministro de Relaciones Exteriores Walid al-Moualem también pidió a los refugiados sirios que volvieran a sus hogares, a pesar de que la guerra del país está en su octavo año.
Moualem, quien también sirve como viceprimer ministro, dijo que las fuerzas extranjeras estaban en suelo sirio ilegalmente, bajo el pretexto de luchar contra el terrorismo, y "serán tratadas en consecuencia".
"Deben retirarse inmediatamente y sin condiciones", dijo a la asamblea.
Moualem insistió en que la "guerra contra el terror está casi acabada" en Siria, donde más de 360.000 personas han muerto desde 2011, con millones más desarraigados de sus hogares.
Dijo que Damasco continuaría "luchando esta batalla sagrada hasta que purguemos todos los territorios sirios" de ambos grupos terroristas y "cualquier presencia extranjera ilegal".
Los Estados Unidos tienen unas 2.000 tropas en Siria, principalmente entrenando y asesorando a las fuerzas kurdas y a los árabes sirios que se oponen al presidente Bashar al-Assad.
Francia tiene más de 1.000 tropas sobre el terreno en el país asolado por la guerra.
En cuanto al tema de los refugiados, Moualem dijo que las condiciones estaban bien para que regresaran, y culpó a "algunos países occidentales" por "difundir temores irracionales" que llevaron a los refugiados a mantenerse alejados.
"Hemos llamado a la comunidad internacional y a las organizaciones humanitarias a facilitar estos retornos", dijo.
"Están politizando lo que debería ser una cuestión puramente humanitaria".
Los Estados Unidos y la Unión Europea han advertido que no habrá ayuda para la reconstrucción de Siria hasta que haya un acuerdo político entre Assad y la oposición para poner fin a la guerra.
Los diplomáticos de la ONU dicen que un reciente acuerdo entre Rusia y Turquía para establecer una zona de amortiguación en el último bastión rebelde de Idlib ha creado una oportunidad para seguir adelante con las conversaciones políticas.
El acuerdo ruso-turco evitó un ataque a gran escala de las fuerzas sirias apoyadas por Rusia en la provincia, donde viven tres millones de personas.
Sin embargo, Moualem destacó que el acuerdo tenía "plazos claros" y expresó la esperanza de que la acción militar se dirija a los yihadistas, incluidos los combatientes del Frente Nusra vinculado a Al-Qaeda, que "serán erradicados".
El enviado de la ONU Staffan de Mistura espera convocar pronto las primeras reuniones de un nuevo comité compuesto por miembros del gobierno y de la oposición para redactar una constitución de posguerra para Siria y allanar el camino hacia las elecciones.
Moualem estableció las condiciones para la participación del gobierno sirio en el comité, diciendo que el trabajo del panel debería restringirse "a revisar los artículos de la constitución actual", y advirtió contra la interferencia.
Por qué Trump ganará un segundo mandato
Por esa lógica, Trump ganaría la reelección en 2020 a menos que, como muchos televidentes liberales probablemente están esperando, el juicio político y el escándalo terminen su presidencia prematuramente.
En lo que sin duda sería "El final más dramático de una presidencia nunca!"
A partir de ahora, no hay signos de fatiga de los espectadores.
Desde 2014, las calificaciones en horario primario se han duplicado a 1,05 millones en CNN y casi se han triplicado a 1,6 millones en MSNBC.
Fox News tiene un promedio de 2,4 millones de espectadores en horario de máxima audiencia, frente a 1,7 millones hace cuatro años, según Nielsen, y el "The Rachel Maddow Show" de MSNBC ha superado la audiencia por cable con hasta 3,5 millones de espectadores en las principales noches de noticias.
"Este es un fuego al que la gente está siendo atraída porque no es algo que entendemos", dijo Neal Baer, corredor del drama ABC "Superviviente Designado", sobre un secretario de gabinete que se convierte en presidente después de un ataque destruye el Capitolio.
Nell Scovell, un veterano escritor de comedia y autor de "Just the Funny Parts: And a few Hard Truths about Sneaking Into the Hollywood Boys" Club", tiene otra teoría.
Recuerda un viaje en taxi en Boston antes de las elecciones de 2016.
El conductor le dijo que votaría por el Sr. Trump.
¿Por qué? Ella preguntó.
"Dijo: "Porque me hace reír", me dijo la Sra. Scovell.
Hay un valor de entretenimiento en el caos.
Por supuesto, a diferencia de cualquier otra cosa en la televisión, las líneas de la historia que salen de Washington podrían determinar el futuro de Roe v. Wade, si las familias inmigrantes pueden reunirse y la salud de la economía global.
Sintonizar es un lujo que sólo los espectadores más privilegiados pueden permitirse.
Y sin embargo, va más allá de ser un ciudadano informado cuando usted se encuentra en la hora seis de ver a un panel de expertos debatir el uso de Bob Woodward de "fondo profundo" abastecimiento para su libro "Miedo,"La chaqueta bombardero de piel de avestruz de $15,000 de Paul Manafort ("una prenda gruesa con arrogancia", dijo The Washington Post) y las implicaciones de las descripciones escalofriantes de Stormy Daniels de la anatomía del Sr. Trump.
Yo, por mi parte, nunca volveré a mirar a Super Mario de la misma manera.
"Parte de lo que está haciendo que hace sentir como un reality show es que te está dando algo cada noche,", dijo Brent Montgomery, director ejecutivo de Wheelhouse Entertainment y creador de "Pawn Stars", sobre el reparto rotativo del programa Trump y los giros diarios de la trama (enfrentando una pelea con el N.F.L., alabando a Kim Jong-un).
No puedes permitirte perderte un episodio o te quedas atrás.
Cuando llegué al Sr. Fleiss esta semana, había un soleado 80 grados fuera de su casa en la orilla norte de Kauai, pero estaba escondido dentro viendo MSNBC mientras grababa CNN.
No podía alejarse, no con Brett Kavanaugh preparado para enfrentar el Comité Judicial del Senado y el futuro de la Corte Suprema colgando en la balanza.
"Recuerdo cuando estábamos haciendo todos esos espectáculos locos en el pasado y la gente dijo: "Este es el principio del fin de la civilización occidental", me dijo el Sr. Fleiss.
"Pensé que era una especie de broma, pero resulta que tenían razón".
Amy Chozick, una escritora en libertad para The Times que cubre negocios, política y medios de comunicación, es la autora de la memoria "Perseguir a Hillary".
El dinero exterior inunda las elecciones de mitad de período más ajustadas
No es de extrañar que el 17 de Pensilvania esté viendo una inundación de dinero, gracias a un reajuste de los distritos del Congreso que aterrizó a dos titulares en una carrera por el mismo asiento.
Este recientemente redibujado distrito de Pittsburg boxes demócrata Rep. Conor Lamb - que ganó su escaño en otro distrito en una elección especial la primavera pasada.
Lamb se enfrenta a otro titular, el republicano Keith Rothfus, que actualmente representa el antiguo distrito 12 de Pennsylvania, que se superpone en gran medida con el nuevo 17.
Los mapas fueron redibujados después de que la Corte Suprema de Pensilvania dictaminara en enero que los antiguos distritos estaban inconstitucionalmente a favor de los republicanos.
La carrera en el nuevo 17 ha provocado un slugfest de finanzas de campaña entre las principales armas financieras del partido, el Comité del Congreso de Campaña Democrática (DCCC) y el Comité Nacional Republicano de Campaña (NRCC).
Lamb se convirtió en un nombre familiar en Pennsylvania después de una victoria estrecha en una amplia vista en las elecciones especiales de marzo para el 18o Distrito del Congreso de Pensilvania.
Ese escaño había estado ocupado por un republicano durante más de una década, y el presidente Donald Trump ganó el distrito por 20 puntos.
Los expertos políticos han dado a los demócratas una ligera ventaja.
EE.UU. consideró penalizar a El Salvador por su apoyo a China, y luego se retiró
Diplomáticos señalaron que la República Dominicana y Panamá ya habían reconocido Beijing, con poco retroceso desde Washington.
El Sr. Trump tuvo una cálida reunión con el presidente Juan Carlos Varela de Panamá en junio de 2017 y tuvo un hotel en Panamá hasta que los socios desalojaron al equipo directivo de la Organización Trump.
Funcionarios del Departamento de Estado decidieron llamar a los jefes estadounidenses de las misiones diplomáticas desde El Salvador, la República Dominicana y Panamá sobre las "recientes decisiones de no reconocer más a Taiwán", dijo Heather Nauert, portavoz del departamento, en un comunicado a principios de este mes.
Pero solo se consideraron sanciones contra El Salvador, que recibió una ayuda estimada en 140 millones de dólares estadounidenses en 2017, incluyendo el control de narcóticos, el desarrollo y el apoyo económico.
Las sanciones propuestas, que incluían recortes a la ayuda financiera y restricciones específicas de visados, habrían sido dolorosas para el país centroamericano y sus altas tasas de desempleo y asesinato.
A medida que avanzaban las reuniones internas, Funcionarios norteamericanos y centroamericanos pospusieron una conferencia de alto nivel centrada en la seguridad y la prosperidad económica para dar seguimiento a una reunión similar el año pasado que se consideró un paso adelante en los esfuerzos para evitar que los migrantes se dirigieran a los Estados Unidos.
Pero a mediados de septiembre, altos funcionarios de la administración dejaron claro que querían que la conferencia siguiera adelante, poniendo fin efectivamente a cualquier consideración de sanciones para El Salvador.
El vicepresidente Mike Pence ahora está programado para dirigirse a la conferencia, ahora programada para mediados de octubre, en una señal de la importación de los lugares de la administración en la reunión, dijeron los diplomáticos.
Y los tres enviados estadounidenses regresaron en silencio a El Salvador, Panamá y la República Dominicana sin nuevos y duros mensajes ni castigos de Washington.
Un portavoz de la Casa Blanca para el Sr. Bolton se negó a comentar los detalles del debate que fueron descritos por los tres funcionarios estadounidenses, incluyendo dos diplomáticos, que acordaron discutir las deliberaciones internas sobre la condición de anonimato.
Sus relatos fueron corroborados por un analista externo cercano a la administración y también habló bajo condición de anonimato.
Historial del estudio
El próximo zapato en caer podría ser el informe del abogado especial Robert Mueller sobre la posible obstrucción de la justicia del Sr. Trump, de la que ahora hay pruebas muy sustanciales en el registro público.
Según se informa, el Sr. Mueller también está convirtiendo su investigación en si la campaña del Sr. Trump estuvo en connivencia con Rusia en su ataque a nuestras elecciones.
En caso de que el Congreso cambie de manos, el Sr. Trump se encontrará frente a la rendición de cuentas en ese cuerpo, al igual que se prepara para ir de nuevo ante los votantes, y tal vez eventualmente un jurado de sus pares.
Eso es mucho, y no quiero sugerir que la caída del Sr. Trump sea inevitable, ni la de sus equivalentes en Europa.
Hay opciones que debemos tomar todos nosotros a ambos lados del Atlántico que afectarán lo prolongada que pueda ser la lucha.
En 1938, oficiales alemanes estaban listos para organizar un golpe de Estado contra Hitler, si sólo Occidente le hubiera resistido y apoyado a los checoslovacos en Munich.
Fracasamos y perdimos la oportunidad de evitar los años de matanza que siguieron.
El curso de la historia gira alrededor de tales puntos de inflexión, y la marcha inexorable de la democracia se acelera o retrasa.
Los estadounidenses enfrentan varios de estos puntos de inflexión ahora.
¿Qué haremos si el Sr. Trump despide al Fiscal General Adjunto Rod Rosenstein, el hombre que controla el destino de la investigación del Sr. Mueller?
Rosenstein ha estado en agua caliente desde que este periódico informó que, el año pasado, sugirió grabar en secreto al presidente y especuló sobre su incapacidad para el cargo.
El Sr. Rosenstein dice que el relato del Times es inexacto.
"¿Cómo responderemos si la recién solicitada investigación F.B.I. de Brett Kavanaugh no es completa o justa - o si se confirma a la Corte Suprema a pesar de las acusaciones creíbles de agresión sexual y testimonio deshonesto?
Y, sobre todo, ¿votaremos en los exámenes de mitad de período para un Congreso que haga rendir cuentas al Sr. Trump?
Si fracasamos en esas pruebas, la democracia durará un largo invierno.
Pero creo que no fracasaremos, debido a la lección que aprendí en Praga.
Mi madre era un judío checoslovaco que fue deportado a Auschwitz por el mismo régimen nazi que una vez ocupó mi casa de embajadores.
Sobrevivió, emigró a América y, 60 años más tarde, me envió a encender velas de sábado en esa mesa con la esvástica.
Con eso como mi herencia, ¿cómo no puedo ser optimista sobre nuestro futuro?"
Norman Eisen, miembro senior de la Brookings Institution, es el presidente de Citizens for Responsibility and Ethics en Washington y el autor de "The Last Palace: Europe's Turbulent Century in Five Lives and One Legendary House".
Graham Dorrans de Rangers optimista antes del choque rápido de Viena
Los Rangers son anfitriones de Rapid Vienna el jueves, sabiendo que la victoria sobre los austriacos, después del impresionante empate en España contra Villarreal a principios de este mes, los pondrá en una posición fuerte para clasificarse del Grupo G de la Liga Europa.
Una lesión en la rodilla impidió que el mediocampista Graham Dorrans hiciera su primera aparición de la temporada hasta el empate de 2-2 con Villarreal, pero cree que Rangers puede usar ese resultado como trampolín para cosas mayores.
"Fue un buen punto para nosotros porque Villarreal es un buen lado", dijo el joven de 31 años.
"Entramos en el juego creyendo que podíamos conseguir algo y llegamos a un punto.
Tal vez podríamos haberlo robado al final pero, en general, un empate fue probablemente un resultado justo.
Probablemente fueron mejores en la primera mitad y salimos en la segunda mitad y fuimos el mejor lado.
El jueves es otra gran noche europea.
Con suerte, podemos conseguir tres puntos, pero será un juego difícil porque tuvieron un buen resultado en su último juego, pero, con la multitud detrás de nosotros, estoy seguro de que podemos seguir adelante y obtener un resultado positivo.
El año pasado fue definitivamente duro, entre todo lo que pasó con mis lesiones y los cambios en el club en sí, pero hay un factor de sentirse bien sobre el lugar ahora.
El escuadrón es bueno y los chicos realmente lo están disfrutando; el entrenamiento es bueno.
Con suerte, podemos continuar ahora, dejar atrás la última temporada y tener éxito".
Las mujeres están perdiendo el sueño por este miedo de ahorro de jubilación
A pesar de que los participantes en la encuesta tenían una idea clara de cómo querían ser atendidos, pocas personas estaban hablando con sus familiares al respecto.
Alrededor de la mitad de las personas en el estudio a nivel nacional dijeron que estaban hablando con sus cónyuges sobre el costo de la atención a largo plazo.
Sólo el 10 por ciento dijo que hablaron con sus hijos sobre ello.
"La gente quiere que un familiar los cuide, pero no están dando los pasos para tener la conversación", dijo Holly Snyder, vicepresidenta del negocio de seguros de vida de Nationwide.
Aquí es donde empezar.
Hable con su cónyuge y los hijos: No puede preparar a su familia para proporcionar atención si no hace saber sus deseos con suficiente antelación.
Trabaje con su asesor y su familia para discutir dónde y cómo recibir atención, ya que esas opciones pueden ser un factor significativo para determinar el costo.
Traiga a su asesor financiero: Su asesor también puede ayudarle a encontrar una manera de pagar esos gastos.
Sus opciones de financiamiento para el cuidado a largo plazo pueden incluir una póliza tradicional de seguro de cuidado a largo plazo, una póliza híbrida de seguro de vida con valor en efectivo para ayudar a cubrir estos gastos o autoasegurarse con su propia riqueza, siempre y cuando tenga el dinero.
Saque sus documentos legales: Enfréntese a las batallas legales en el pase.
Obtener un representante de atención médica en su lugar para que designe a un individuo de confianza para supervisar su atención médica y asegurarse de que los profesionales cumplen con sus deseos en caso de que no pueda comunicarse.
Además, considere un poder notarial para sus finanzas.
Usted seleccionaría a una persona de confianza para tomar decisiones financieras por usted y asegurarse de que sus facturas se pagan si usted está incapacitado.
No olvide los pequeños detalles: Imagínese que su padre anciano tiene una emergencia médica y está de camino al hospital.
¿Sería capaz de responder preguntas sobre medicamentos y alergias?
Deletree esos detalles en un plan escrito para que esté listo.
"No son sólo las finanzas las que están en juego, sino ¿quiénes son los médicos?", preguntó Martin.
"¿Cuáles son los medicamentos?
¿Quién cuidará al perro?
Ten ese plan en su lugar."
Hombre disparó varias veces con rifle de aire en Ilfracombe
A un hombre le han disparado varias veces con un rifle de aire mientras caminaba a casa desde una noche.
La víctima, de 40 años, estaba en el área de Oxford Grove de Ilfracombe, Devon, cuando le dispararon en el pecho, el abdomen y la mano.
Los oficiales describieron el tiroteo, que tuvo lugar alrededor de las 02:30 BST, como un "acto aleatorio".
La víctima no vio a su atacante.
Sus heridas no ponen en peligro su vida y la policía ha apelado a testigos.
Terremotos y tsunamis en Indonesia
Al menos 384 personas han muerto por un poderoso terremoto y tsunami que golpeó la ciudad indonesia de Palu el viernes, dijeron los funcionarios, con el número de muertos que se espera que aumente.
Con las comunicaciones apagadas, los oficiales de socorro no han podido obtener ninguna información de la regencia Donggala, una zona al norte de Palu que está más cerca del epicentro del terremoto de magnitud 7.5.
En Palu, más de 16.000 personas fueron evacuadas después del desastre.
He aquí algunos datos clave sobre Palu y Donggala, en la isla de Sulawesi:
Palu es la capital de la provincia central de Sulawesi, situada al final de una estrecha bahía en la costa oeste de la isla de Sulawesi, con una población estimada de 379.800 habitantes en 2017.
La ciudad estaba celebrando su 40 aniversario cuando el terremoto y el tsunami golpearon.
Donggala es una regencia que se extiende a lo largo de más de 300 km (180 millas) de costa en el noroeste de la isla de Sulawesi.
La regencia, una región administrativa por debajo de una provincia, tenía una población estimada de 299.200 habitantes en 2017.
La pesca y la agricultura son los pilares de la economía de la provincia central de Sulawesi, especialmente la región costera de Donggala.
La minería de níquel también es importante en la provincia, pero se concentra principalmente en Morowali, en la costa opuesta de Sulawesi.
Palu y Donggala han sido golpeados por tsunamis varias veces en los últimos 100 años, según la Agencia Indonesia de Mitigación de Desastres.
En 1938, un tsunami mató a más de 200 personas y destruyó cientos de casas en Donggala.
Un tsunami también azotó el oeste de Donggala en 1996, matando a nueve.
Indonesia se sienta en el anillo de fuego sísmico del Pacífico y es golpeada regularmente por terremotos.
He aquí algunos de los grandes terremotos y tsunamis de los últimos años:
2004: Un gran terremoto en la costa occidental de la provincia de Aceh, en el norte de Sumatra, el 26 de diciembre provocó un tsunami que afectó a 14 países, matando a 226.000 personas a lo largo de la costa del Océano Índico, más de la mitad de ellas en Aceh.
2005: Una serie de fuertes terremotos golpearon la costa occidental de Sumatra a finales de marzo y principios de abril.
Cientos murieron en la isla de Nias, frente a la costa de Sumatra.
2006: Una magnitud de 6,8 golpeó al sur de Java, la isla más poblada de Indonesia, desencadenando un tsunami que se estrelló en la costa sur, matando a casi 700 personas.
2009: Un terremoto de magnitud 7,6 golpeó cerca de la ciudad de Padang, capital de la provincia de Sumatra Occidental.
Más de 1.100 personas murieron.
2010: Un terremoto de magnitud 7,5 golpeó una de las islas Mentawai, frente a Sumatra, provocando un tsunami de hasta 10 metros que destruyó docenas de aldeas y mató a unas 300 personas.
2016: Un terremoto poco profundo azotó la regencia de Pidie Jaya en Aceh, causando destrucción y pánico cuando la gente fue recordada por la devastación del mortal terremoto y tsunami de 2004.
Esta vez no se desencadenó ningún tsunami, pero más de 100 fueron asesinados por edificios caídos.
2018: Grandes terremotos golpearon la isla turística de Indonesia, Lombok, matando a más de 500 personas, en su mayoría en el lado norte de la isla.
El terremoto destruyó miles de edificios y dejó a miles de turistas temporalmente varados.
El hijo mayor de Sarah Palin arrestado por cargos de violencia doméstica
Track Palin, el hijo mayor de la exgobernadora de Alaska y candidata a la vicepresidencia Sarah Palin, ha sido arrestado por cargos de asalto.
Palin, de 29 años, de Wasilla, Alaska, fue arrestado bajo sospecha de violencia doméstica, interfiriendo con un informe de violencia doméstica y resistiendo el arresto, según un informe publicado el sábado por los soldados estatales de Alaska.
Según el informe de la policía, cuando una conocida intentó llamar a la policía para denunciar los presuntos delitos, le quitó el teléfono.
Palin está siendo detenido en la prisión preventiva de Mat-Su y está retenido en una fianza no garantizada de 500 dólares, informó KTUU.
Apareció en la corte el sábado, donde se declaró "inocente, seguro" cuando se le preguntó su declaración, informó de la red.
Palin se enfrenta a tres faltas de clase A, lo que significa que podría ser encarcelado por un año y multado con $250,000.
También ha sido acusado de un delito menor de clase B, punible con un día de cárcel y una multa de 2.000 dólares.
No es la primera vez que se presentan cargos penales contra Palin.
En diciembre de 2017, fue acusado de agredir a su padre, Todd Palin.
Su madre, Sarah Palin, llamó a la policía para denunciar el presunto ataque.
El caso está actualmente ante la Corte de Veteranos de Alaska.
En enero de 2016 fue acusado de agresión doméstica, interferir en la denuncia de un delito de violencia doméstica, y poseer un arma mientras estaba intoxicado en relación con el incidente.
Su novia había alegado que él la golpeó en la cara.
Sarah Palin fue criticada por grupos de veteranos en 2016 después de vincular el comportamiento violento de su hijo al PTSD derivado de su servicio en Irak.
Tsunami del terremoto de Indonesia: cientos de muertos
Al menos 384 personas han muerto después de que un terremoto golpeara la isla indonesia de Sulawesi el viernes.
El terremoto de 7,5 magnitudes provocó un tsunami y ha destruido miles de hogares.
La electricidad y las redes de comunicación han disminuido y se espera que aumente el número de muertos en los próximos días.
El terremoto golpeó justo al lado del centro de Sulawesi, que está al noreste de la capital indonesia, Yakarta.
Los videos están circulando en las redes sociales mostrando el momento de impacto.
Cientos de personas se habían reunido para un festival de playa en la ciudad de Palu cuando el tsunami se estrelló en la orilla.
Fiscales federales buscan pena de muerte rara para sospechoso de ataque terrorista en Nueva York
Los fiscales federales en Nueva York están buscando la pena de muerte para Sayfullo Saipov, el sospechoso en el ataque terrorista de la ciudad de Nueva York que mató a ocho personas, un castigo raro que no se ha llevado a cabo en el estado por un crimen federal desde 1953.
Saipov, de 30 años, supuestamente utilizó un camión de alquiler de Home Depot para llevar a cabo un ataque en un carril bici a lo largo de la autopista West Side en el Bajo Manhattan, cortando peatones y ciclista en su camino en octubre.
Para justificar una sentencia de muerte, Los fiscales tendrán que probar que Saipov "intencionalmente" mató a las ocho víctimas e "intencionalmente" infligió lesiones corporales graves, de acuerdo con la notificación de intención de solicitar la pena de muerte, presentada en el Distrito Sur de Nueva York.
Ambos cargos conllevan una posible pena de muerte, según el documento del tribunal.
Semanas después del ataque, un gran jurado federal abofeteó a Saipov con una acusación de 22 cargos que incluía ocho cargos de asesinato en ayuda de la delincuencia organizada, generalmente utilizados por fiscales federales en casos de crimen organizado, y una acusación de violencia y destrucción de vehículos de motor.
El ataque requirió "planificación sustancial y premeditación", dijeron los fiscales, describiendo la manera en que Saipov lo llevó a cabo como "heinoso, cruel y depravado".
"Sayfullo Habibullaevic Saipov causó lesiones, daño y pérdida a las familias y amigos de Diego Enrique Angelini, Nicholas Cleves, Ann-Laure Decadt, Darren Drake, Ariel Erlij, Hernán Ferruchi, Hernán Diego Mendoza y Alejandro Damian Pagnucco", afirma el aviso de intención.
Cinco de las víctimas eran turistas de Argentina.
Ha pasado una década desde la última vez que el Distrito Sur de Nueva York procesó un caso de pena de muerte.
El acusado, Khalid Barnes, fue declarado culpable de asesinar a dos proveedores de drogas, pero finalmente fue condenado a cadena perpetua en septiembre de 2009.
La última vez que la pena de muerte se llevó a cabo en un caso federal de Nueva York fue en 1953 para Julius y Ethel Rosenberg, un matrimonio ejecutado después de que fueron condenados por conspiración para cometer espionaje para la Unión Soviética durante la Guerra Fría dos años antes.
Ambos Rosenberg fueron asesinados por la silla eléctrica el 19 de junio de 1953.
Saipov, natural de Uzbekistán, demostró falta de remordimiento en los días y meses posteriores al ataque, según documentos judiciales.
Declaró a los investigadores que se sentía bien por lo que había hecho, dijo la policía.
Saipov dijo a las autoridades que se inspiró para llevar a cabo el ataque después de ver videos de ISIS en su teléfono, de acuerdo con la acusación.
También solicitó mostrar la bandera del ISIS en su habitación del hospital, dijo la policía.
Se ha declarado inocente de la acusación de 22 cargos.
David Patton, uno de los defensores públicos federales que representan a Saipov, dijo que están "obviamente decepcionados" con la decisión de la fiscalía.
"Creemos que la decisión de buscar la pena de muerte en lugar de aceptar una declaración de culpabilidad a cadena perpetua sin posibilidad de liberación sólo prolongará el trauma de estos eventos para todos los involucrados", dijo Patton.
El equipo de defensa de Saipov había pedido previamente a los fiscales que no solicitaran la pena de muerte.
Tory MP dice que NIGEL FARAGE debe ser puesto a cargo de las negociaciones del Brexit
Nigel Farage prometió 'movilizar al ejército popular' hoy durante una protesta en la conferencia Tory.
El ex líder de Ukip dijo que los políticos tenían que "sentir el calor" de los euroescépticos, ya que uno de los diputados de Theresa May sugirió que debería estar a cargo de las negociaciones con la UE.
El backbencher conservador Peter Bone dijo a la marcha en Birmingham que el Reino Unido "habría estado fuera" si el Sr. Farage fuera secretario del Brexit.
Pero el reto al que se enfrenta la señora May para reconciliar sus filas profundamente divididas ha sido subrayado por los conservadores pro-Remain que se unen a una protesta separada contra el Brexit en la ciudad.
El primer ministro está luchando para mantener su plan de compromiso Chequers en marcha en medio de los ataques de Brexiteers, Remainers y la UE.
Los aliados insistieron en que intentaría llegar a un acuerdo con Bruselas a pesar de la reacción - y obligar a los euroescépticos y laboristas a elegir entre su paquete y el "caos".
El Sr. Bone le dijo a la manifestación de Leave Means Leave en Solihull que quería "chuck Chequers".
Sugiere que el Sr. Farage debería haberse convertido en un colega y que se le confiera la responsabilidad de las negociaciones con Bruselas.
"Si hubiera estado a cargo, ya habríamos salido", dijo.
El diputado de Wellingborough añadió: 'Voy a defender el Brexit, pero tenemos que tirar Chequers'.
Exponiendo su oposición a la UE, dijo: "No luchamos contra las guerras mundiales para ser sumisos.
Queremos hacer nuestras propias leyes en nuestro propio país".
El Sr. Bone rechazó las sugerencias de que la opinión pública había cambiado desde la votación de 2016: "La idea de que el pueblo británico ha cambiado de opinión y quiere permanecer es completamente falsa".
Tory Brexiteer Andrea Jenkyns también estuvo en la marcha, diciendo a los periodistas: "Estoy diciendo simplemente: Primer Ministro, escucha al pueblo.
"Chequers es impopular con el público en general, la Oposición no va a votar a favor, es impopular con nuestro partido y nuestros activistas que en realidad golpean las calles y nos hacen elegir en primer lugar.
Por favor, deja Chequers y empieza a escuchar.
En un mensaje dirigido a la Sra. May, añadió: «Los primeros ministros mantienen sus puestos de trabajo cuando cumplen sus promesas».
El Sr. Farage dijo que los políticos del mitin deben "sentir el calor" si estaban a punto de traicionar la decisión tomada en el referéndum de 2016.
"Ahora se trata de una cuestión de confianza entre nosotros -el pueblo- y nuestra clase política", dijo.
"Están tratando de traicionar el Brexit y estamos aquí hoy para decirles 'no vamos a dejar que te salgas con la tuya haciendo eso'".
En un mensaje a la entusiasta multitud añadió: "Quiero que hagan sentir el calor a nuestra clase política, que está a punto de traicionar el Brexit.
"Estamos movilizando el ejército popular de este país que nos dio la victoria en el Brexit y nunca descansaremos hasta que nos hayamos convertido en un Reino Unido independiente, autónomo y orgulloso".
Mientras tanto, los restos marcharon por Birmingham antes de celebrar una manifestación de dos horas en el centro de la ciudad.
Un puñado de activistas agitaron las pancartas de Tories Against Brexit después del lanzamiento del grupo este fin de semana.
El compañero laborista Lord Adonis se burló de los conservadores por los problemas de seguridad que sufrieron con una aplicación del partido cuando se abrió la conferencia.
"Estas son las personas que nos dicen que pueden tener los sistemas de TI en su lugar y toda la tecnología para Canadá plus, para la frontera sin fricción, para el libre comercio sin fronteras en Irlanda", agregó.
Es una farsa completa.
No hay tal cosa como un buen Brexit", agregó.
Warren planea hacer una 'mirada dura' de postularse para presidente
La senadora estadounidense Elizabeth Warren dice que después de las elecciones de noviembre "hará un vistazo duro a la candidatura a la presidencia".
El Boston Globe informa que la demócrata de Massachusetts habló de su futuro durante un ayuntamiento en el oeste de Massachusetts el sábado.
Warren, un crítico frecuente del presidente Donald Trump, se presenta a la reelección en noviembre contra el representante estatal del Partido Republicano, Geoff Diehl, quien fue copresidente de la campaña de Trump en Massachusetts en 2016.
Ha estado en el centro de la especulación de que podría enfrentarse a Trump en 2020.
El evento del sábado por la tarde en Holyoke fue su 36a reunión con los electores usando el formato de ayuntamiento desde que Trump asumió el cargo.
Un asistente le preguntó si planeaba presentarse a la presidencia.
Warren respondió que es hora "de que las mujeres vayan a Washington para arreglar nuestro gobierno roto, y eso incluye a una mujer en la cima".
Arresto por disparar a los Sims de LSU
La policía en Baton Rouge, La., anunció el sábado que un sospechoso ha sido arrestado en la muerte del jugador de baloncesto de LSU Wayde Sims el viernes.
El Departamento de Policía de Baton Rouge anunció el arresto de Dyteon Simpson, de 20 años, a las 11 a.m. Conferencia de noticias ET.
Habían lanzado un video del tiroteo el viernes, pidiendo ayuda para identificar a un hombre visto en las imágenes.
Sims, de 20 años, fue asesinado a tiros cerca del campus de Southern University a principios del viernes.
"Wayde Sims sufrió una herida de bala en la cabeza y finalmente murió como resultado", dijo el jefe de policía Murphy J. Paul a los medios de comunicación el sábado, por 247 deportes.
Wayde intervino para defender a su amigo y fue baleado por Simpson.
Simpson fue interrogado y admitido a estar en la escena, en posesión de un arma, y admitido a disparar a Wayde Sims.
Simpson fue arrestado sin incidentes y detenido en el Departamento de Policía de la Parroquia East Baton Rouge.
Un junior de 6 pies-6 que creció en Baton Rouge, Sims jugó en 32 partidos con 10 inicios la temporada pasada y promedió 17,4 minutos, 5,6 puntos y 2,9 rebotes por partido.
Grand Prix ruso: Lewis Hamilton cierra en el título mundial después de que las órdenes del equipo le dan ganar sobre Sebastian Vettel
Desde el momento en que Valtteri Bottas se clasificó por delante de Lewis Hamilton el sábado, quedó claro que las órdenes del equipo de Mercedes jugarían un papel importante en la carrera.
Desde pole, Bottas tuvo un buen comienzo y casi colgó a Hamilton para secarse mientras defendía su posición en los dos primeros turnos e invitó a Vettel a atacar a su compañero de equipo.
Vettel fue a los hoyos primero y dejó Hamilton para correr en el tráfico en la cola de la manada, algo que debería haber sido decisivo.
El Mercedes dio una vuelta más tarde y salió por detrás de Vettel, pero Hamilton siguió adelante después de una acción rueda a rueda que vio al conductor Ferrari dejar el interior libre a regañadientes en riesgo de resistir después de un doble movimiento para defenderse en la tercera esquina.
Max Verstappen comenzó desde la última fila de la cuadrícula y fue séptimo al final de la primera vuelta en su 21 cumpleaños.
Luego lideró una gran parte de la carrera mientras se aferraba a sus neumáticos para apuntar a una rápida meta y superar a Kimi Raikkonen por cuarto.
Finalmente llegó a los hoyos en la 44a vuelta, pero fue incapaz de aumentar su ritmo en las ocho vueltas restantes como Raikkonen tomó cuarto.
Es un día difícil porque Valtteri hizo un trabajo fantástico todo el fin de semana y un verdadero caballero me dijo que me dejara pasar.
El equipo ha hecho un trabajo tan excepcional para tener un uno dos", dijo Hamilton.
Eso fue realmente mal lenguaje corporal
El presidente Donald Trump se burló de la senadora Dianne Feinstein en un mitin el sábado por su insistencia en no filtrar la carta de Christine Blasey Ford acusando al candidato de la Corte Suprema Brett Kavanaugh de agresión sexual.
Hablando en una manifestación en Virginia Occidental, el presidente no se refirió directamente al testimonio dado por Ford ante el Comité Judicial del Senado, en lugar de comentar que lo que estaba pasando en el Senado mostraba que la gente era "maliciosa y desagradable y falsa".
"La única cosa que podría suceder y la cosa hermosa que está sucediendo en los últimos días en el Senado, cuando se ve la ira, cuando se ve a personas que están enojadas y mezquinas y desagradables y desmentidas", dijo.
"Cuando miras liberaciones y fugas y luego dicen "oh, yo no lo hice.
Yo no lo hice".
¿Recuerdas?
Dianne Feinstein, ¿fugaste?
Recuerda su respuesta... ¿filtraste el documento?
Oh, no.
Yo no goteé".
Bueno, espera un minuto.
¿Nos filtramos...No, no filtramos", agregó, en una impresión del senador.
Feinstein fue enviado la carta detallando las acusaciones contra Kavanaugh por Ford en julio, y se filtró a principios de septiembre - pero Feinstein negó que la filtración vino de su oficina.
"No oculté las acusaciones del Dr. Ford, no filtré su historia", dijo Feinstein al comité, informó The Hill.
"Ella me pidió que lo mantuviera confidencial y yo lo mantuve confidencial como ella lo pidió."
Pero su negación no parecía sentarse bien con el presidente, que comentó durante el mitin del sábado por la noche: "Te diré qué, eso fue un lenguaje corporal realmente malo.
Tal vez no lo hizo, pero ese es el peor lenguaje corporal que he visto".
Continuando con su defensa del candidato de la Corte Suprema, quien ha sido acusado de mala conducta sexual por tres mujeres, el presidente sugirió que los demócratas estaban usando las acusaciones para sus propios fines.
"Están decididos a recuperar el poder por cualquier medio necesario.
Ves la maldad, la maldad, no les importa a quién lastimen, a quién tienen que atropellar para obtener poder y control", informó Mediaite el presidente.
Liga Elite: Dundee Stars 5-3 Belfast Giants
Patrick Dwyer bateó dos goles para los Gigantes contra Dundee
Dundee Stars cedió por la derrota de la Elite League el viernes contra Belfast Giants al ganar el partido de vuelta 5-3 en Dundee el sábado.
Los Gigantes obtuvieron una ventaja inicial de dos objetivos a través de los ataques de Patrick Dwyer y Francis Beauvillier.
Mike Sullivan y Jordan Cownie trajeron el nivel de casa antes de que Dwyer restaurara la ventaja de los Gigantes.
Francois Bouchard igualó para Dundee antes de que dos goles de Lukas Lundvald Nielsen aseguraran su victoria.
Fue una tercera derrota de la Elite League de la temporada para los hombres de Adam Keefe, que habían venido por detrás para vencer a Dundee 2-1 en Belfast el viernes por la noche.
Fue una cuarta reunión de la temporada entre los lados, con los Gigantes ganando los tres partidos anteriores.
El abridor de Dwyer llegó en el cuarto minuto en 3:35 de una asistencia Kendall McFaull, con David Rutherford proporcionando la asistencia como Beauvillier duplicó la ventaja cuatro minutos más tarde.
En lo que fue un ajetreado período de apertura, Sullivan trajo el lado de casa de nuevo en el juego en 13:10 antes de Matt Marquardt se convirtió en proveedor del ecualizador de Cownie en 15:16.
Dwyer se aseguró de que los Gigantes tomaran una ventaja en el primer descanso cuando alcanzó su segundo gol de la noche al final del primer período.
El lado de casa se reagrupó y Bouchard una vez más los puso en términos de nivel con un gol de juego de poder en 27:37.
Cownie y Charles Corcoran se combinaron para ayudar a Nielsen a dar a Dundee la ventaja por primera vez en el partido a finales del segundo período y se aseguró de la victoria con el quinto de su equipo a mitad del período final.
Los Gigantes, que ahora han perdido cuatro de sus últimos cinco partidos, están en casa de Milton Keynes en su próximo partido el viernes.
Controlador de Tráfico Aéreo muere para asegurar que cientos de aviones puedan escapar del terremoto
Un controlador de tráfico aéreo en Indonesia está siendo aclamado como un héroe después de su muerte asegurando que un avión que transportaba a cientos de personas logró despegar del suelo con seguridad.
Más de 800 personas han muerto y muchas están desaparecidas después de que un gran terremoto golpeara la isla de Sulawesi el viernes, desencadenando un tsunami.
Fuertes réplicas siguen plagando la zona y muchos están atrapados en escombros en la ciudad de Palu.
Pero a pesar de que sus colegas huían por sus vidas, Anthonius Gunawan Agung, de 21 años, se negó a abandonar su puesto en la torre de control salvajemente oscilante en el aeropuerto de Mutiara Sis Al Jufri Palu.
Se quedó para asegurarse de que el vuelo aéreo Batik 6321, que estaba en la pista en ese momento, era capaz de despegar con seguridad.
Luego saltó de la torre de control de tráfico cuando pensó que se estaba derrumbando.
Murió más tarde en el hospital.
El portavoz de Navegación Aérea Indonesia, Yohannes Sirait, dijo que la decisión pudo haber salvado cientos de vidas, informó ABC News de Australia.
Preparamos un helicóptero desde Balikpapan en Kalimantan para llevarlo a un hospital más grande en otra ciudad.
Desafortunadamente lo perdimos esta mañana antes de que el helicóptero llegara a Palu.
"Nuestro corazón se rompe al escuchar esto", agregó.
Mientras tanto, las autoridades temen que el número de muertos llegue a los miles con la agencia de mitigación de desastres del país diciendo que el acceso a las ciudades de Donggala, Sigi y Boutong es limitado.
"Se cree que el peaje sigue aumentando ya que muchos cuerpos todavía estaban bajo los escombros, mientras que muchos no han podido ser alcanzados", dijo el portavoz de la agencia, Sutopo Purwo Nugroho.
Las olas de hasta seis metros han devastado Palu, que celebrará un entierro masivo el domingo.
Los aviones militares y comerciales están trayendo ayuda y suministros.
Risa Kusuma, una madre de 35 años, le dijo a Sky News: "Cada minuto una ambulancia trae cuerpos.
El agua limpia es escasa.
Los minimercados son saqueados por todas partes".
Jan Gelfand, jefe de la Cruz Roja Internacional en Indonesia, dijo a CNN: "La Cruz Roja Indonesia está corriendo para ayudar a los sobrevivientes, pero no sabemos qué encontrarán allí.
Esto ya es una tragedia, pero podría empeorar mucho".
El presidente de Indonesia, Joko Widodo, llegó a Palu el domingo y le dijo a los militares del país: "Les pido a todos que trabajen día y noche para completar todas las tareas relacionadas con la evacuación.
¿Estás listo?" CNN informó.
Indonesia fue golpeada a principios de este año por terremotos en Lombok en los que murieron más de 550 personas.
Accidente de avión en Micronesia: Air Niugini dice ahora que un hombre desapareció después de un accidente de avión en la laguna
La aerolínea que opera un vuelo que se estrelló en una laguna del Pacífico en Micronesia ahora dice que un hombre está desaparecido, después de decir antes que los 47 pasajeros y la tripulación habían evacuado con seguridad el avión que se hundía.
Air Niugini dijo en un comunicado que a partir de la tarde del sábado, no fue capaz de dar cuenta de un pasajero masculino.
La aerolínea dijo que estaba trabajando con las autoridades locales, hospitales e investigadores para tratar de encontrar al hombre.
La compañía aérea no respondió inmediatamente a las solicitudes de más detalles sobre el pasajero, como su edad o nacionalidad.
Lanchas locales ayudaron a rescatar a los demás pasajeros y a la tripulación después de que el avión golpeara el agua mientras intentaba aterrizar en el aeropuerto de la isla Chuuk.
Los funcionarios dijeron el viernes que siete personas habían sido llevadas a un hospital.
La aerolínea dijo que seis pasajeros permanecieron en el hospital el sábado, y todos ellos estaban en condiciones estables.
Lo que causó el accidente y la secuencia exacta de eventos sigue sin estar claro.
La aerolínea y la Marina de los EE.UU. dijeron que el avión aterrizó en la laguna a poca distancia de la pista.
Algunos testigos pensaron que el avión sobrevoló la pista.
El pasajero estadounidense Bill Jaynes dijo que el avión llegó muy bajo.
"Eso es algo extremadamente bueno", dijo Jaynes.
Jaynes dijo que él y otros lograron vadear a través del agua de la cintura hasta las salidas de emergencia en el avión que se hunde.
Dijo que las azafatas estaban entrando en pánico y gritando, y que sufrió una lesión leve en la cabeza.
La Marina de los Estados Unidos dijo que los marineros que trabajaban cerca para mejorar un muelle también ayudaron en el rescate mediante el uso de un bote inflable para transportar a la gente a tierra antes de que el avión se hundiera en unos 30 metros (100 pies) de agua.
Los datos de la Red de Seguridad Aérea indican que 111 personas han muerto en accidentes de compañías aéreas registradas en PNG en las últimas dos décadas, pero ninguna de ellas ha implicado a Air Niugini.
Analista establece la línea de tiempo de la mujer de la noche fue quemada viva
La fiscalía concluyó su caso el sábado en el nuevo juicio de un hombre acusado de quemar viva a una mujer de Mississippi en 2014.
Paul Rowlett, analista del Departamento de Justicia de los Estados Unidos, testificó durante horas como testigo experto en el campo del análisis de inteligencia.
Esbozó para el jurado cómo usó los registros de celulares para armar los movimientos del acusado de 29 años Quinton Tellis y la víctima de 19 años, Jessica Chambers, la noche en que murió.
Rowlett dijo que recibió datos de ubicación de varios teléfonos celulares que mostraban que Tellis estaba con Chambers la noche de su muerte, contradiciendo sus afirmaciones anteriores, informó The Clarion Ledger.
Cuando los datos mostraron que su móvil estaba con Chambers durante el tiempo que dijo que estaba con su amigo Michael Sanford, la policía fue a hablar con Sanford.
Sanford subió al estrado el sábado y testificó que no estaba en la ciudad ese día.
Cuando los fiscales preguntaron si Tellis estaba diciendo la verdad cuando dijo que estaba en el camión de Sanford esa noche, Sanford dijo que estaba "mentir, porque mi camión estaba en Nashville".
Otra inconsistencia fue que Tellis dijo que había conocido a Chambers durante unas dos semanas cuando ella murió.
Los registros de celulares indicaban que sólo se conocían desde hacía una semana.
Rowlett dijo que en algún momento después de la muerte de Chambers, Tellis borró los mensajes de Chambers, llamadas e información de contacto de su teléfono.
"La borró de su vida," dijo Hale.
Está previsto que la defensa comience sus alegatos finales el domingo.
El juez dijo que esperaba que el juicio fuera al jurado más tarde ese día.
La Alta Raza: ¿Qué es el hip hop consciente?
Un trío de hip hop quiere desafiar la visión negativa del género llenando su música con mensajes positivos.
The High Breed, de Bristol, afirma que el hip hop se alejó de sus orígenes de mensajes políticos y abordar cuestiones sociales.
Quieren volver a sus raíces y hacer popular el hip hop consciente de nuevo.
Artistas como The Fugees y Common han visto un reciente resurgimiento en el Reino Unido a través de artistas como Akala y Lowkey.
¿Otra persona negra?
NY niñera demanda pareja por despido después de texto "racista"
Una niñera de Nueva York está demandando a una pareja por despido discriminatorio después de recibir un mensaje mal dirigido de la madre que se queja de que era "otra persona negra".
La pareja niega que sean racistas, comparando el traje con la "extorsión".
Lynsey Plasco-Flaxman, madre de dos hijos, expresó su consternación al descubrir que la nueva cuidadora, Giselle Maurice, era negra al llegar para su primer día de trabajo en 2016.
"NOOOOOOOOOOOOOOOOOOOO OTRA PERSONA NEGRO", escribió la Sra. Plasco-Flaxman a su marido en un texto.
Sin embargo, en lugar de enviárselo a su marido, se lo envió a la Sra. Maurice, dos veces.
Después de darse cuenta de su sorpresa, un "incómodo" Plasco-Flaxman despidió a la Sra. Maurice, declarando que su niñera saliente, que era afroamericana, había hecho un mal trabajo y que en su lugar estaba esperando un filipino, según el New York Post.
A la Sra. Maurice le pagaron un día de trabajo y luego la enviaron a casa por un Uber.
Ahora, Maurice está demandando a la pareja por una compensación por el despido, y está buscando una compensación por la suma de 350 dólares al día por el concierto de seis meses que había sido contratada inicialmente para hacer, aunque sin contrato.
"Quiero mostrarles, mira, no haces esas cosas", le dijo al Post el viernes, y agregó: "Sé que es discriminación".
La pareja ha respondido a las afirmaciones de que son racistas, diciendo que terminar con el empleo de Maurice era lo más razonable, temiendo que no pudieran confiar en ella después de ofenderla.
"Mi esposa le había enviado algo que no quería decir.
No es racista.
No somos racistas", dijo al Post el esposo Joel Plasco.
"¿Pero pondrías a tus hijos en manos de alguien con quien has sido grosero, aunque fuera por error?
¿Tu bebé recién nacido?
Vamos."
Al comparar el traje con la "extorsión", Plasco dijo que su esposa estaba a sólo dos meses de tener un bebé y estaba en una "situación muy difícil".
"¿Vas a ir tras alguien así?
Eso no es algo muy agradable de hacer", agregó el banquero de inversión.
Mientras el caso legal sigue en curso, la corte de opinión pública se ha apresurado a denunciar a la pareja en las redes sociales, golpeándolos por su comportamiento y lógica.
Los editores de Paddington temían que los lectores no se relacionaran con un oso parlante, revela nueva carta
La hija de Bond, Karen Jankel, que nació poco después de que el libro fuera aceptado, dijo de la carta: "Es difícil ponerse en el lugar de alguien que lo lee por primera vez antes de que se publique.
Es muy divertido saber ahora lo que sabemos sobre el gran éxito de Paddington".
Diciendo su padre, que había trabajado como camarógrafo de la BBC antes de ser inspirado para escribir el libro de los niños por un pequeño oso de juguete, habría sido sanguinario sobre su trabajo siendo rechazado, agregó que el 60 aniversario de la publicación de libros era "bittersweet" después de su muerte el año pasado.
De Paddington, a quien describe como un "miembro muy importante de nuestra familia", agregó que su padre estaba en silencio orgulloso de su eventual éxito.
"Era un hombre bastante tranquilo, y no era una persona jactanciosa," dijo ella.
"Pero como Paddington era tan real con él, era casi como si tuvieras un hijo que lograra algo: estás orgulloso de ellos a pesar de que en realidad no lo haces tú.
Creo que vio el éxito de Paddington de esa manera.
Aunque era su creación y su imaginación, siempre daba el crédito al propio Paddington".
Mi hija se estaba muriendo y tuve que despedirme por teléfono.
Al aterrizar su hija había sido llevada al Hospital Louis Pasteur 2 de Niza, donde los médicos trabajaron en vano para salvar su vida.
"Nad llamaba regularmente para decir que era realmente malo, que no se esperaba que lo lograra", dijo la señora Ednan-Laperouse.
"Entonces recibí la llamada de Nad para decir que iba a morir en los próximos dos minutos y tuve que despedirme de ella.
Y lo hice.
Le dije: "Tashi, te quiero mucho, cariño.
Estaré contigo pronto.
Estaré contigo.
Las drogas que le habían dado los médicos para mantener su corazón bombeando lentamente se estaban desgastando y dejando su sistema.
Ella había muerto un tiempo antes de la mano y todo esto se estaba apagando.
Tuve que sentarme allí y esperar, sabiendo que todo esto se estaba desarrollando.
No podía aullar o gritar o llorar porque estaba en una situación rodeada de familias y personas.
Realmente tuve que mantenerme unido".
Finalmente, la Sra. Ednan-Laperouse, ahora afligida por la pérdida de su hija, subió al avión junto a los demás pasajeros, sin tener en cuenta la terrible experiencia que estaba atravesando.
"Nadie lo sabía," dijo.
"Tenía la cabeza baja, y las lágrimas caían todo el tiempo.
Es difícil de explicar, pero fue en el vuelo que sentí este sentimiento abrumador de simpatía por Nad.
Que necesitaba mi amor y comprensión.
Sabía lo mucho que la amaba".
Afligir a las mujeres postales para prevenir suicidios en el puente
Dos mujeres que perdieron a sus seres queridos por suicidio están trabajando para evitar que otros se quiten la vida.
Sharon Davis y Kelly Humphreys han estado publicando tarjetas en un puente galés con mensajes inspiradores y números de teléfono que la gente puede llamar por apoyo.
El hijo de la Sra. Davis Tyler tenía 13 años cuando comenzó a sufrir de depresión y se suicidó a los 18 años.
"No quiero que ningún padre sienta lo que tengo que sentir todos los días", dijo.
La Sra. Davis, de 45 años, que vive en Lydney, dijo que su hijo era un chef prometedor con una sonrisa infecciosa.
"Todo el mundo lo conocía por su sonrisa.
Siempre decían que su sonrisa iluminaba cualquier habitación".
Sin embargo, abandonó el trabajo antes de morir, ya que estaba "en un lugar realmente oscuro".
En 2014, el hermano de Tyler, que tenía 11 años en ese momento, fue el que encontró a su hermano después de haber tomado su propia vida.
La Sra. Davis dijo: "Siempre me preocupa que haya un golpe en el efecto".
La Sra. Davis creó las cartas, "para que la gente sepa que hay gente a la que puedes ir y con la que puedes hablar, incluso si es un amigo.
No te sientes en silencio - tienes que hablar."
La Sra. Humphreys, que ha sido amiga de la Sra. Davies durante años, perdió a Mark, su pareja de 15 años, poco después de la muerte de su madre.
"No dijo que se sentía deprimido o deprimido, ni nada", dijo.
"Un par de días antes de Navidad notamos su cambio de actitud.
Él estaba en el fondo de la roca el día de Navidad - cuando los niños abrieron sus regalos no hizo contacto visual con ellos ni nada."
Ella dijo que su muerte fue un trauma enorme para ellos, pero tienen que trabajar a través de él: "Se rompe un agujero a través de la familia.
Nos destroza.
Pero todos tenemos que seguir y luchar".
Si usted está luchando para hacer frente, puede llamar a los samaritanos gratis en 116 123 (Reino Unido e Irlanda), correo electrónico jo@samaritans.org, o visitar el sitio web de los samaritanos aquí.
El futuro de Brett Kavanaugh está en juego mientras el FBI inicia la investigación
"Pensé, Si pudiéramos conseguir algo como lo que estaba pidiendo... una investigación limitada en el tiempo, de alcance limitado - tal vez podríamos traer un poco de unidad ", dijo el Sr. Flake el sábado, añadiendo que temía que la comisión se estuviera "deshaciendo" en medio de un atrincheramiento partisano arraigado.
¿Por qué el Sr. Kavanaugh y sus partidarios republicanos no querían que el FBI investigara?
Su reticencia se debe al momento oportuno.
Las elecciones de mitad de período están a sólo cinco semanas, el 6 de noviembre - si, como se esperaba, los republicanos lo hacen mal, entonces se verán severamente debilitados en sus intentos de conseguir que el hombre que quieren sea elegido a la corte más alta del país.
George W. Bush ha estado contestando el teléfono para llamar a los senadores, cabildeando para apoyar al Sr. Kavanaugh, quien trabajó en la Casa Blanca para el Sr. Bush y a través de él conoció a su esposa Ashley, que era la secretaria personal del Sr. Bush.
¿Qué pasará después de que el FBI produzca su informe?
Habrá una votación en el Senado, donde 51 republicanos y 49 demócratas se sentarán actualmente.
Todavía no está claro si el Sr. Kavanaugh puede conseguir al menos 50 votos en el Senado, lo que permitiría a Mike Pence, el vicepresidente, romper un empate y confirmarlo ante la Corte Suprema.
Corea del Norte desertor números 'drop' bajo Kim
El número de desertores norcoreanos a Corea del Sur ha disminuido desde que Kim Jong-un llegó al poder hace siete años, dijo un legislador surcoreano.
Park Byeong-seug, citando datos del ministerio de unificación del Sur, dijo que el año pasado hubo 1.127 deserciones, en comparación con 2.706 en 2011.
El Sr. Park dijo que los controles fronterizos más estrictos entre Corea del Norte y China y las tasas más altas que cobran los contrabandistas son factores clave.
Pyongyang no ha hecho comentarios públicos.
A la gran mayoría de los desertores del Norte se les ofrece finalmente la ciudadanía surcoreana.
Seúl dice que más de 30.000 norcoreanos han cruzado ilegalmente la frontera desde el final de la Guerra de Corea en 1953.
La mayoría huye a través de China, que tiene la frontera más larga con Corea del Norte y es más fácil de cruzar que la zona desmilitarizada fuertemente protegida (DMZ) entre las dos Coreas.
China considera a los desertores como migrantes ilegales y no como refugiados y a menudo los repatria por la fuerza.
Las relaciones entre el Norte y el Sur -que técnicamente siguen en guerra- han mejorado notablemente en los últimos meses.
A principios de este mes, los líderes de los dos países se reunieron en Pyongyang para celebrar conversaciones que se centraron en el estancamiento de las negociaciones de desnuclearización.
Esto vino después de la histórica reunión de junio entre el presidente estadounidense Donald Trump y Kim Jong-un en Singapur, cuando acordaron en términos generales trabajar hacia la península de Corea libre de armas nucleares.
Pero el sábado, el ministro de Relaciones Exteriores de Corea del Norte, Ri Yong-ho, culpó a las sanciones estadounidenses por la falta de progreso desde entonces.
"Sin ninguna confianza en Estados Unidos, no habrá confianza en nuestra seguridad nacional y en tales circunstancias, no hay manera de que nos desarmaremos unilateralmente primero", dijo Ri en un discurso ante la Asamblea General de la ONU en Nueva York.
Nancy Pelosi llama a Brett Kavanaugh "histérico", dice que no es apto para servir en la Corte Suprema
Nancy Pelosi, líder de la minoría de la Cámara, llamó al candidato de la Corte Suprema Brett Kavanaugh "histérico" y dijo que era temperamentalmente incapaz de servir en la Corte Suprema.
Pelosi hizo los comentarios en una entrevista el sábado en el Texas Tribune Festival en Austin, Texas.
"No pude evitar pensar que si una mujer hubiera actuado de esa manera, dirían 'histéricamente'", dijo Pelosi sobre su reacción al testimonio de Kavanaugh ante el Comité Judicial del Senado el jueves.
Kavanaugh negó emocionalmente las acusaciones de que había agredido sexualmente a la Dra. Christine Blasey Ford cuando ambos eran adolescentes.
Durante su discurso de apertura, Kavanaugh fue muy emocional, a veces casi gritando y ahogándose mientras discutía sobre su familia y sus años de secundaria.
También condenó explícitamente a los demócratas en el comité, calificando las acusaciones en su contra de "asesinato grotesco y coordinado de carácter" organizado por liberales enojados de que Hillary Clinton perdió las elecciones presidenciales de 2016.
Pelosi dijo que ella creía que el testimonio de Kavanaugh probó que él no podía servir en la Corte Suprema, porque mostró que está sesgado contra los demócratas.
"Creo que se descalifica a sí mismo con esas declaraciones y la manera en que fue tras los Clinton y los demócratas", dijo.
Pelosi se disculpó cuando se le preguntó si iba a tratar de destituir a Kavanaugh si se confirma, y si los demócratas ganan la mayoría en la Cámara de Representantes.
"Diré esto, si no está diciendo la verdad al Congreso o al FBI, entonces no es adecuado no sólo para estar en la Corte Suprema, sino para estar en la corte que está en este momento", dijo Pelosi.
Kavanaugh es actualmente juez en el Tribunal de Apelaciones del Circuito de Washington.
Pelosi añadió que, como demócrata, le preocupaban las posibles decisiones de Kavanaugh contra la Ley de atención médica asequible o Roe c. Wade, como se le considera una justicia conservadora.
En sus audiencias de confirmación, Kavanaugh eludió las preguntas sobre si revocaría ciertas decisiones de la Corte Suprema.
"No es hora de que una persona histérica y sesgada vaya a la corte y espere que digamos: 'No es maravilloso'", dijo Pelosi.
Y las mujeres necesitan limpiarlo.
Es una diatriba justa, meses y años de furia que se derraman, y ella no puede sacarla sin llorar.
"Lloramos cuando nos enojamos", me dijo la Sra. Steinem 45 años después.
"No creo que eso sea raro, ¿verdad?"
Ella continuó, "Me ayudó mucho una mujer que era ejecutiva en algún lugar, quien dijo que también lloraba cuando se enfadaba, pero desarrolló una técnica que significaba que cuando se enfadaba y empezaba a llorar, le decía a la persona con la que estaba hablando: "Puedes pensar que estoy triste porque estoy llorando.
Estoy enojado."
Y luego siguió adelante.
Y pensé que eso era brillante".
Las lágrimas son permitidas como una salida para la ira en parte porque son fundamentalmente malentendidas.
Uno de mis recuerdos más agudos de un trabajo temprano, en una oficina dominada por hombres, donde una vez me encontré llorando con rabia inexpresable, fue mi ser agarrado por el desaliento de mi cuello por una mujer mayor - un gerente frío de quien siempre había estado un poco aterrorizado - que me arrastró a una escalera.
"Nunca dejes que te vean llorar", me dijo.
"Ellos no saben que estás furioso.
Creen que estás triste y que estarás contento porque te atraparon".
Patricia Schroeder, entonces congresista demócrata de Colorado, había trabajado con Gary Hart en sus carreras presidenciales.
En 1987, cuando el Sr. Hart fue atrapado en una aventura extramatrimonial a bordo de un barco llamado Monkey Business y se inclinó fuera de la carrera, la Sra. Schroeder, profundamente frustrada, pensó que no había razón para no explorar la idea de presentarse a la presidencia ella misma.
"No fue una decisión bien pensada", me dijo con una risa 30 años después.
"Ya había otros siete candidatos en la carrera, y lo último que necesitaban era otro.
Alguien lo llamó "Blanca Nieve y los Siete Enanos".
Debido a que era tarde en la campaña, estaba atrasada en la recaudación de fondos, y así que prometió que no entraría a la carrera a menos que recaudara $2 millones.
Fue una batalla perdida.
Descubrió que algunos de sus partidarios que dieron $1,000 a los hombres le darían sólo $250.
"¿Creen que recibo un descuento?", se preguntó.
Cuando pronunció su discurso anunciando que no lanzaría una campaña formal, Estaba tan abrumada por las emociones -gracias a la gente que la había apoyado, frustración con el sistema que hacía tan difícil recaudar dinero y apuntar a los votantes en lugar de a los delegados, y rabia por el sexismo- que se ahogó.
"Hubieran pensado que había tenido una crisis nerviosa", recordó la Sra. Schroeder sobre cómo la prensa reaccionó ante ella.
"Hubieras pensado que Kleenex era mi patrocinador corporativo.
Recuerdo que pensé, ¿qué van a poner en mi lápida?
¿Lloró?
Cómo la guerra comercial entre Estados Unidos y China puede ser buena para Beijing
Las salvas de apertura de la guerra comercial entre EE.UU. y China fueron ensordecedoras, y mientras la batalla está lejos de terminar, una ruptura entre los países puede ser beneficiosa para Beijing a largo plazo, dicen los expertos.
Donald Trump, el presidente estadounidense, lanzó la primera advertencia a principios de este año al gravar las exportaciones chinas clave, incluyendo paneles solares, acero y aluminio.
La escalada más significativa se extendió en esta semana con nuevos aranceles que afectan a 200 mil millones de dólares (150 mil millones de libras esterlinas) de artículos, gravando efectivamente la mitad de todos los bienes que llegan a los EE.UU. desde China.
Beijing ha tomado represalias cada vez en especie, la última vez abofeteando aranceles de cinco a diez por ciento sobre 60.000 millones de dólares de bienes estadounidenses.
China se ha comprometido a igualar el tiro a tiro de Estados Unidos, y es poco probable que la segunda economía más grande del mundo pestañee pronto.
Hacer que Washington retroceda significa caer en demandas, pero inclinarse públicamente ante los Estados Unidos sería demasiado embarazoso para Xi Jinping, el presidente de China.
Sin embargo, los expertos dicen que si Pekín puede jugar bien sus cartas, las presiones de la guerra comercial de Estados Unidos podrían apoyar positivamente a China a largo plazo reduciendo la interdependencia de las dos economías.
"El hecho de que una rápida decisión política en Washington o Beijing podría crear las condiciones que comienzan un giro económico en cualquiera de los países es en realidad mucho más peligroso de lo que los espectadores han reconocido antes,", dijo Abigail Grace, una investigadora asociada que se centra en Asia en el Centro para la Nueva Seguridad Americana, un think tank.
Siria "listo" para que los refugiados regresen, dice el Ministro de Asuntos Exteriores
Siria dice que está lista para el regreso voluntario de los refugiados y pide ayuda para reconstruir el país devastado por una guerra de más de siete años.
Hablando ante la Asamblea General de las Naciones Unidas, el Ministro de Relaciones Exteriores Walid al-Moualem dijo que las condiciones en el país están mejorando.
"Hoy la situación sobre el terreno es más estable y segura gracias a los progresos realizados en la lucha contra el terrorismo", dijo.
El gobierno continúa rehabilitando las áreas destruidas por los terroristas para restaurar la normalidad.
Ahora están presentes todas las condiciones para el regreso voluntario de los refugiados al país que tuvieron que abandonar debido al terrorismo y a las medidas económicas unilaterales dirigidas a su vida cotidiana y a sus medios de subsistencia.
La ONU estima que más de 5,5 millones de sirios han huido del país desde que comenzó la guerra en 2011.
Otros seis millones de personas que aún viven en el país necesitan asistencia humanitaria.
Al-Moualem dijo que el régimen sirio agradecería ayuda para reconstruir el país devastado.
Sin embargo, subrayó que no aceptaría asistencia condicional ni ayuda de los países que patrocinaban la insurgencia.
Europa cierra la victoria de la Copa Ryder en París
Team Europe ha ganado la Ryder Cup 2018 derrotando al Team USA por una puntuación final de 16.5 a 10.5 en Le Golf National fuera de París, Francia.
Estados Unidos ha perdido ahora seis veces consecutivas en suelo europeo y no ha ganado una Copa Ryder en Europa desde 1993.
Europa recuperó la corona cuando el equipo del capitán danés Thomas Bjorn alcanzó los 14,5 puntos que necesitaban para vencer a los Estados Unidos.
La estrella estadounidense Phil Mickelson, que luchó la mayor parte del torneo, tiró su tee-shot al agua en el hoyo 16 del par-3, concediendo su partido a Francesco Molinari.
El golfista italiano Molinari brilló en todas sus rondas, convirtiéndose en 1-de-4 jugadores para ir siempre 5-0-0 desde que el formato actual del torneo comenzó en 1979.
El estadounidense Jordan Spieth fue derribado 5 & 4 por el jugador más bajo del equipo europeo, Thorbjorn Olesen de Dinamarca.
El mejor jugador del mundo, Dustin Johnson, cayó 2 y 1 ante Ian Poulter de Inglaterra que pudo haber jugado en su última Ryder Cup.
Un veterano de ocho Ryder Cups, el español Sergio García se convirtió en el torneo más ganador de todos los tiempos en Europa con 25.5 puntos de carrera.
"No suelo llorar, pero hoy no puedo evitarlo.
Ha sido un año duro.
Tan agradecido por Thomas de elegirme y creer en mí.
Estoy tan feliz, tan feliz de recuperar la copa.
Se trata del equipo., y estoy feliz de haber podido ayudar", dijo un emotivo García tras la victoria europea.
Pasa la antorcha a su compatriota John Ram, quien derribó a la leyenda del golf estadounidense Tiger Woods 2&1 en singles que juegan el domingo.
"El increíble orgullo que siento, para vencer a Tiger Woods, crecí viendo a ese tipo", dijo Rahm, de 23 años.
Woods perdió los cuatro partidos en Francia y ahora tiene un récord de 13-21-3 carreras Ryder Cup.
Una estadística extraña por uno de los mejores jugadores de todos los tiempos, habiendo ganado 14 grandes títulos después de sólo Jack Nicklaus.
Team USA luchó todo el fin de semana para encontrar las calles con la excepción de Patrick Reed, Justin Thomas y Tony Finau, que jugó golf de alto calibre durante todo el torneo.
El capitán estadounidense Jim Furyk habló después de una actuación decepcionante para su equipo, "Estoy orgulloso de estos tipos, lucharon.
Esta mañana tuvimos tiempo de poner algo de calor en Europa.
Nos desguazamos.
Sombreros de Thomas.
Es un gran capitán.
Los 12 jugadores jugaron muy bien.
Nos reagruparemos, trabajaré con la PGA de América y nuestro Comité de la Copa Ryder y avanzaremos.
Me encantan estos 12 tipos y estoy orgulloso de servir como capitán.
Tienes que darle propina a tu gorra.
Nos superaron".
Actualización de la marea roja: disminución de las concentraciones en Pinellas, Manatea y Sarasota
El informe más reciente de la Comisión de Pesca y Vida Silvestre de Florida muestra una disminución general de las concentraciones de Tida Roja en partes del área de la Bahía de Tampa.
Según la FWC, se están reportando condiciones de floración más parches en áreas de los condados de Pinellas, Manatee, Sarasota, Charlotte y Collier, lo que sugiere una disminución de las concentraciones.
Una floración La marea roja se extiende aproximadamente 130 millas de costa desde el norte de Pinellas hasta los condados del sur de Lee.
Los parches se pueden encontrar a unas 10 millas de la costa del condado de Hillsborough, pero en menos sitios relativos a la semana pasada.
La marea roja también se ha observado en el condado de Pasco.
En la última semana se han notificado concentraciones medias en el condado de Pinellas o fuera de él, concentraciones bajas a altas frente al condado de Hillsborough, antecedentes de concentraciones elevadas en el condado de Manatee, antecedentes de concentraciones altas en el condado de Sarasota o fuera de él, antecedentes de concentraciones medias en el condado de Charlotte, antecedentes de concentraciones altas en el condado de Lee o fuera de él, y concentraciones bajas en el condado de Collier.
Se sigue reportando irritación respiratoria en los condados de Pinellas, Manatee, Sarasota, Lee y Collier.
La irritación respiratoria no fue reportada en el noroeste de Florida durante la semana pasada.
