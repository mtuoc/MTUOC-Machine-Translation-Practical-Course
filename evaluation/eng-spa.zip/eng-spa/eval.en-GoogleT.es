Los diputados galeses están preocupados por "parecer marionetas".
Algunos miembros de la Asamblea Nacional de Gales (AM) se muestran consternados ante la sugerencia de que su título cambie a MWP (Miembro del Parlamento Galés).
Esto ha surgido a raíz de los planes para cambiar el nombre de la asamblea a Parlamento Galés.
Los miembros de la Asamblea Nacional de todo el espectro político temen que esto pueda dar pie a burlas.
Un miembro laborista de la Asamblea Nacional de Gales dijo que a su grupo le preocupaba que "rimara con Twp y Pwp".
Para los lectores fuera de Gales: En galés, twp significa tonto y pwp significa caca.
Un miembro de Plaid Cymru afirmó que el grupo en su conjunto "no estaba contento" y sugirió alternativas.
Un miembro del Partido Conservador galés afirmó que su grupo tenía una mentalidad abierta respecto al cambio de nombre, pero señaló que la transición verbal de MWP a Muppet era muy sencilla.
En este contexto, la letra w galesa se pronuncia de forma similar a la pronunciación de la letra u en el inglés de Yorkshire.
La Comisión de la Asamblea, que actualmente está elaborando la legislación para introducir los cambios de nombre, declaró: "La decisión final sobre cómo se denominará a los miembros de la Asamblea será, por supuesto, una cuestión que corresponderá a los propios miembros".
La Ley del Gobierno de Gales de 2017 otorgó a la Asamblea de Gales la facultad de cambiar su nombre.
En junio, la Comisión publicó los resultados de una consulta pública sobre las propuestas, que arrojó un amplio apoyo a la idea de denominar a la asamblea Parlamento galés.
En lo que respecta al título de los miembros de la Asamblea Nacional de Gales (AM), la Comisión se inclinó por la denominación de Miembros del Parlamento Galés (WMP, por sus siglas en inglés), pero la opción de Miembros del Parlamento de Gales (MWP, por sus siglas en inglés) fue la que recibió mayor apoyo en una consulta pública.
Al parecer, los miembros de la Asamblea Nacional están sugiriendo opciones alternativas, pero la dificultad para alcanzar un consenso podría suponer un quebradero de cabeza para la Presidenta de la Asamblea, Elin Jones, de quien se espera que presente un proyecto de ley sobre los cambios en las próximas semanas.
La legislación sobre las reformas incluirá otros cambios en el funcionamiento de la asamblea, incluidas las normas sobre la inhabilitación de los miembros y el diseño del sistema de comisiones.
Los miembros de la Asamblea Nacional tendrán la última palabra sobre cómo deberían llamarse cuando debatan la legislación.
Los macedonios acuden a las urnas en un referéndum sobre el cambio de nombre del país.
Los votantes decidirán el domingo si cambian el nombre de su país a "República de Macedonia del Norte".
La votación popular se organizó con el objetivo de resolver una disputa de décadas con la vecina Grecia, que tiene su propia provincia llamada Macedonia.
Atenas ha insistido durante mucho tiempo en que el nombre de su vecino del norte representa una reivindicación sobre su territorio y se ha opuesto repetidamente a sus solicitudes de adhesión a la UE y la OTAN.
El presidente macedonio, Gjorge Ivanov, opositor al plebiscito sobre el cambio de nombre, ha declarado que ignorará el resultado de la votación.
Sin embargo, los partidarios del referéndum, incluido el primer ministro Zoran Zaev, argumentan que el cambio de nombre es simplemente el precio a pagar para unirse a la UE y la OTAN.
Las campanas de St. Martin's enmudecen mientras las iglesias de Harlem luchan por sobrevivir.
"Históricamente, las personas mayores con las que he hablado dicen que había un bar y una iglesia en cada esquina", dijo el Sr. Adams.
"Hoy no existe ninguna de las dos cosas."
Dijo que la desaparición de los bares era comprensible.
"Hoy en día la gente se relaciona socialmente de una manera diferente", dijo.
"Los bares ya no son las salas de estar del barrio a las que la gente acude con regularidad."
En cuanto a las iglesias, le preocupa que el dinero procedente de la venta de activos no dure tanto como esperan los líderes, "y que tarde o temprano vuelvan a estar en la misma situación que al principio".
Añadió que las iglesias podrían ser sustituidas por edificios de apartamentos con condominios habitados por el tipo de personas que no ayudarán a los santuarios que aún quedan en el barrio.
"La inmensa mayoría de las personas que compren condominios en estos edificios serán blancas,—dijo—, y por lo tanto, aceleraremos el día en que estas iglesias cierren definitivamente, porque es poco probable que la mayoría de las personas que se muden a estos condominios se conviertan en miembros de estas iglesias.
Ambas iglesias fueron construidas por congregaciones blancas antes de que Harlem se convirtiera en una metrópolis negra: Metropolitan Community en 1870 y St. Martin's una década después.
La congregación metodista blanca original se mudó en la década de 1930.
Una congregación negra que había estado celebrando sus cultos en las cercanías se hizo con la propiedad del edificio.
La iglesia de St. Martin fue tomada por una congregación negra bajo el liderazgo del reverendo John Howard Johnson, quien encabezó un boicot contra los comerciantes de la calle 125, una de las principales calles comerciales de Harlem, que se resistían a contratar o ascender a personas negras.
Un incendio en 1939 dejó el edificio gravemente dañado, pero cuando los feligreses del padre Johnson hicieron planes para reconstruirlo, encargaron la fabricación del carillón.
El reverendo David Johnson, hijo del padre Johnson y su sucesor en St. Martin's, se refería con orgullo al carillón como "las campanas de los pobres".
El experto que tocó el carillón en julio lo describió de otra manera: "Un tesoro cultural" y "un instrumento histórico insustituible".
La experta Tiffany Ng, de la Universidad de Michigan, también señaló que fue el primer carillón del mundo tocado por un músico negro, Dionisio A. Lind, quien se trasladó al carillón más grande de la Iglesia Riverside hace 18 años.
El señor Merriweather dijo que St. Martin's no lo reemplazó.
Lo que ha ocurrido en St. Martin's durante los últimos meses ha sido una historia compleja de arquitectos y contratistas, algunos contratados por los líderes laicos de la iglesia y otros por la diócesis episcopal.
La sacristía - el órgano de gobierno de la parroquia, integrado por líderes laicos, escribió a la diócesis en julio expresando su preocupación de que la diócesis "intentara trasladar los costos" al consejo parroquial, a pesar de que este no había participado en la contratación de los arquitectos y contratistas que la diócesis envió.
Algunos feligreses se quejaron de la falta de transparencia por parte de la diócesis.
Un tiburón hiere a un niño de 13 años durante una inmersión para pescar langostas en California.
Un tiburón atacó e hirió a un niño de 13 años el sábado mientras buceaba en busca de langosta en California, en el día de la apertura de la temporada de pesca de langosta, según informaron las autoridades.
El ataque tuvo lugar poco antes de las 7 de la mañana cerca de Beacon's Beach en Encinitas.
Chad Hammel declaró a la cadena KSWB-TV de San Diego que llevaba buceando con amigos aproximadamente media hora el sábado por la mañana cuando oyó al niño gritar pidiendo ayuda y entonces remó hasta allí con un grupo para ayudar a sacarlo del agua.
Hammel dijo que al principio pensó que era solo la emoción de pescar una langosta, pero luego "se dio cuenta de que estaba gritando: '¡Me han picado!'
¡Me mordieron!
"Tenía la clavícula completamente desgarrada", dijo Hammel que notó una vez que llegó hasta el niño.
"Les grité a todos que salieran del agua: '¡Hay un tiburón en el agua!'" Hammel añadió.
El niño fue trasladado en helicóptero al Hospital Infantil Rady en San Diego, donde su estado es crítico.
Se desconoce la especie de tiburón responsable del ataque.
El capitán de los socorristas, Larry Giles, declaró en una rueda de prensa que unas semanas antes se había avistado un tiburón en la zona, pero se determinó que no se trataba de una especie peligrosa.
Giles añadió que la víctima sufrió lesiones traumáticas en la parte superior del torso.
Las autoridades cerraron el acceso a la playa desde Ponto Beach en Casablad hasta Swami's en Ecinitas durante 48 horas con fines de investigación y seguridad.
Giles señaló que hay más de 135 especies de tiburones en la zona, pero la mayoría no se consideran peligrosas.
Sainsbury's planea incursionar en el mercado de belleza del Reino Unido.
Sainsbury's está compitiendo con Boots, Superdrug y Debenhams con pasillos de belleza al estilo de los grandes almacenes, atendidos por asistentes especializados.
Como parte de una importante incursión en el mercado de la belleza del Reino Unido, valorado en 2.800 millones de libras esterlinas, Mientras que las ventas de moda y artículos para el hogar siguen creciendo, los pasillos de belleza más amplios se probarán en 11 tiendas de todo el país y, si resultan un éxito, se implementarán en más tiendas el próximo año.
La inversión en productos de belleza se produce en un momento en que los supermercados buscan maneras de aprovechar el espacio en los estantes que antes ocupaban televisores, microondas y artículos para el hogar.
Sainsbury's anunció que duplicará su oferta de productos de belleza hasta alcanzar los 3.000 artículos, incluyendo por primera vez marcas como Revlon, Essie, Tweezerman y Dr. PawPaw.
Las gamas de productos ya existentes de L'Oreal, Maybelline y Burt's Bees también dispondrán de más espacio, con zonas de marca similares a las que se encuentran en tiendas como Boots.
El supermercado también está relanzando su gama de maquillaje Boutique para que la mayoría de los productos sean aptos para veganos, algo cada vez más demandado por los compradores más jóvenes.
Además, la cadena de perfumerías The Fragrance Shop pondrá a prueba sus espacios de venta en dos tiendas Sainsbury's; la primera abrió sus puertas en Croydon, al sur de Londres, la semana pasada, mientras que la segunda abrirá en Selly Oak, Birmingham, a finales de este año.
Las compras online y la tendencia a comprar pequeñas cantidades de alimentos a diario en tiendas locales significan que los supermercados tienen que esforzarse más para convencer a la gente de que los visite.
Mike Coupe, director ejecutivo de Sainsbury's, ha declarado que los establecimientos se parecerán cada vez más a unos grandes almacenes, a medida que la cadena de supermercados intenta competir con los supermercados de descuento Aldi y Lidl ofreciendo más servicios y productos no alimentarios.
Sainsbury's ha estado instalando tiendas Argos en cientos de establecimientos y también ha introducido varias tiendas Habitat desde que compró ambas cadenas hace dos años, lo que, según afirma, ha impulsado las ventas de comestibles y ha hecho que las adquisiciones sean más rentables.
El intento anterior del supermercado por renovar sus secciones de belleza y farmacia terminó en fracaso.
Sainsbury's probó una empresa conjunta con Boots a principios de la década de 2000, pero la alianza terminó tras una disputa sobre cómo repartir los ingresos de las farmacias ubicadas en sus supermercados.
Esta nueva estrategia surge después de que Sainsbury's vendiera su negocio de farmacias, con 281 establecimientos, a Celesio, propietaria de la cadena Lloyds Pharmacy, por 125 millones de libras hace tres años.
Según la empresa, Lloyds desempeñaría un papel importante en el plan, añadiendo una gama más amplia de marcas de cuidado de la piel de lujo, como La Roche-Posay y Vichy, en cuatro de sus tiendas.
Paul Mills-Hicks, director comercial de Sainsbury's, dijo: "Hemos transformado el aspecto y la atmósfera de nuestros pasillos de belleza para mejorar el ambiente para nuestros clientes."
También hemos invertido en compañeros especialmente capacitados que estarán disponibles para ofrecer asesoramiento.
Nuestra gama de marcas está diseñada para satisfacer todas las necesidades, y el ambiente atractivo y la conveniente ubicación nos convierten en un destino de belleza irresistible que desafía la antigua forma de comprar."
Peter Jones está furioso después de que Holly Willoughby se retirara del acuerdo de 11 millones de libras.
Peter Jones, estrella del programa Dragons' Den, se mostró furioso después de que la presentadora de televisión Holly Willoughby cancelara un acuerdo de 11 millones de libras con su marca de estilo de vida para centrarse en sus nuevos contratos con Marks and Spencer e ITV.
Willoughby no tiene tiempo para su marca de ropa y accesorios para el hogar, Truly.
El negocio de la pareja había sido comparado con la marca Goop de Gwyneth Paltrow.
La presentadora de This Morning, de 37 años, anunció su marcha a través de Instagram.
Holly Willoughby ha enfurecido a Peter Jones, estrella del programa "Dragons' Den", al retirarse en el último minuto de su lucrativo negocio de marca de estilo de vida para centrarse en sus nuevos y lucrativos contratos con Marks & Spencer e ITV.
Según las fuentes, Jones estaba "furioso" cuando la chica de oro de la televisión admitió durante una tensa reunión el martes en la sede de su imperio empresarial en Marlow, Buckinghamshire, que sus nuevos contratos, por un valor de hasta 1,5 millones de libras, significaban que ya no tenía suficiente tiempo para dedicárselo a su marca de ropa y accesorios para el hogar, Truly.
Se había comparado la empresa con la marca Goop de Gwyneth Paltrow y se preveía que duplicaría la fortuna estimada de Willoughby, de 11 millones de libras esterlinas.
Mientras Willoughby, de 37 años, anunciaba en Instagram su marcha de Truly, Jones partió de Gran Bretaña rumbo a una de sus casas de vacaciones.
Una fuente dijo: "Realmente era, con diferencia, la principal prioridad de Holly".
Ese iba a ser su futuro a largo plazo, el que la acompañaría durante las próximas dos décadas.
Su decisión de retirarse dejó a todos los implicados completamente atónitos.
Nadie podía creer lo que estaba pasando el martes; faltaba muy poco para el lanzamiento.
En la sede central de Marlow hay un almacén lleno de mercancías listas para la venta.
Los expertos creen que la salida del presentador de This Morning, La adquisición de una de las estrellas más rentables de Gran Bretaña podría costarle a la empresa millones debido a la fuerte inversión en productos que van desde cojines y velas hasta ropa y artículos para el hogar, y la posibilidad de nuevos retrasos en su lanzamiento.
Y podría significar el fin de una larga amistad.
Willoughby, madre de tres hijos, y su marido, Dan Baldwin, han mantenido una estrecha relación con Jones y su esposa, Tara Capp, durante diez años.
Willoughby fundó Truly junto con Capp en 2016 y Jones, de 52 años, se unió como presidente en marzo.
Las parejas pasan las vacaciones juntas y Jones posee una participación del 40 por ciento en la productora de televisión de Baldwin.
Willoughby se convertirá en embajadora de la marca M&S y sustituirá a Ant McPartlin como presentadora del programa "I'm A Celebrity" de ITV.
Una fuente cercana a Jones declaró anoche: "No haremos comentarios sobre sus asuntos comerciales".
Conversación dura: "Y entonces nos enamoramos".
Bromeó sobre las críticas que recibiría de los medios de comunicación por hacer un comentario que algunos considerarían "poco presidencial" y por ser tan positivo sobre el líder norcoreano.
¿Por qué el presidente Trump ha renunciado a tanto?
Trump lo dijo con su voz burlona de "presentador de noticias".
"No renuncié a nada."
Señaló que Kim está interesado en una segunda reunión después de que su encuentro inicial en Singapur en junio fuera aclamado por Trump como un gran paso hacia la desnuclearización de Corea del Norte.
Pero las negociaciones sobre la desnuclearización se han estancado.
Más de tres meses después de la cumbre de junio en Singapur, el principal diplomático de Corea del Norte, Ri Yong Ho, dijo el sábado a los líderes mundiales en la Asamblea General de la ONU que Corea del Norte no ve una "respuesta correspondiente" por parte de Estados Unidos a las primeras medidas de desarme de Corea del Norte.
En cambio, señaló, Estados Unidos continúa imponiendo sanciones destinadas a mantener la presión.
En su discurso durante el mitin, Trump adoptó una postura mucho más optimista.
"Nos va muy bien con Corea del Norte", dijo.
"Íbamos a la guerra con Corea del Norte."
Millones de personas habrían muerto.
Ahora tenemos una relación estupenda."
Afirmó que sus esfuerzos por mejorar las relaciones con Kim han dado resultados positivos: el fin de las pruebas de misiles, la ayuda en la liberación de rehenes y la repatriación de los restos de militares estadounidenses.
Y defendió su inusual enfoque al hablar de las relaciones con Kim.
"Es muy fácil comportarse como un presidente, pero en lugar de tener a 10.000 personas afuera tratando de entrar a este estadio abarrotado, tendríamos a unas 200 personas de pie justo ahí", dijo Trump, señalando a la multitud que tenía justo delante.
Un tsunami y un terremoto devastan una isla en Indonesia, causando cientos de muertos.
Tras el terremoto de Lombok, por ejemplo, se les dijo a las organizaciones no gubernamentales extranjeras que no eran necesarias.
Aunque más del 10 por ciento de la población de Lombok había sido desplazada, no se declaró ningún desastre nacional, requisito indispensable para impulsar la ayuda internacional.
"En muchos casos, lamentablemente, han dejado muy claro que no solicitan ayuda internacional, así que resulta un poco complicado", dijo la Sra. Sumbung.
Si bien Save the Children está organizando un equipo para viajar a Palu, aún no está segura de si el personal extranjero podrá trabajar sobre el terreno.
El Sr. Sutopo, portavoz de la agencia nacional de gestión de desastres, dijo que los funcionarios indonesios estaban evaluando la situación en Palu para determinar si se permitiría a las agencias internacionales contribuir a las labores de ayuda.
Dada la constante actividad telúrica que sufre Indonesia, el país sigue estando lamentablemente poco preparado para la furia de la naturaleza.
Si bien en Aceh se han construido refugios contra tsunamis, no son algo común en otras zonas costeras.
La aparente ausencia de una sirena de alerta de tsunami en Palu, a pesar de que la alerta estaba en vigor, probablemente haya contribuido a la pérdida de vidas.
Incluso en las mejores circunstancias, viajar entre las numerosas islas de Indonesia resulta complicado.
Los desastres naturales complican aún más la logística.
Un buque hospital que había estado estacionado en Lombok para atender a las víctimas del terremoto se dirige ahora a Palu, pero tardará al menos tres días en llegar al lugar de la nueva catástrofe.
El presidente Joko Widodo convirtió la mejora de la maltrecha infraestructura de Indonesia en un pilar fundamental de su campaña electoral, y ha invertido grandes sumas de dinero en carreteras y ferrocarriles.
Pero la falta de financiación ha sido un problema recurrente para la administración del Sr. Joko, que se enfrenta a la reelección el próximo año.
El señor Joko también se enfrenta a la presión derivada de las persistentes tensiones sectarias en Indonesia, donde los miembros de la mayoría musulmana han adoptado una forma más conservadora de la fe.
Más de 1.000 personas murieron y decenas de miles fueron desplazadas de sus hogares mientras bandas cristianas y musulmanas se enfrentaban en las calles, utilizando machetes, arcos y flechas, y otras armas rudimentarias.
Mira: Daniel Sturridge del Liverpool anota el gol del empate contra el Chelsea.
Daniel Sturridge salvó al Liverpool de una derrota en la Premier League ante el Chelsea con un gol en el minuto 89 el sábado en Stamford Bridge, Londres.
Sturridge recibió un pase de Xherdan Shaqiri a unos 30 metros de la portería del Chelsea, cuando su equipo perdía 1-0.
Tocó el balón con la izquierda antes de lanzar un disparo hacia el segundo palo.
El disparo pasó muy por encima del área mientras se dirigía hacia la esquina superior derecha de la portería.
Finalmente, el balón cayó por encima de Kepa Arrizabalaga, que intentaba estirarse, y acabó entrando en la portería.
"Simplemente intentaba llegar a esa posición, tener el balón, y jugadores como Shaq siempre lo juegan hacia adelante tanto como sea posible, así que intenté crearme el mayor tiempo posible", declaró Sturridge a LiverpoolFC.com.
"Vi venir a Kanté, le di un toque, no lo pensé demasiado y simplemente disparé."
El Chelsea ganaba 1-0 al descanso tras conseguir un gol en el minuto 25 gracias al tanto de la estrella belga Eden Hazard.
En esa jugada, el delantero del Chelsea le devolvió el balón con el tacón a Mateo Kovacic, antes de girar cerca del centro del campo y correr hacia la mitad del terreno de juego del Liverpool.
Kovacic hizo una rápida pared en el centro del campo.
Acto seguido, lanzó un magnífico pase en profundidad que dejó a Hazard dentro del área.
Hazard superó a la defensa y, con un disparo con la pierna izquierda, batió a Alisson Becker, portero del Liverpool, enviando el balón al fondo de la red en el segundo palo.
El Liverpool se enfrenta al Napoli en la fase de grupos de la Liga de Campeones el miércoles a las 15:00 horas en el Estadio San Paolo de Nápoles, Italia.
El Chelsea se enfrenta al Videoton en la UEFA Europa League el jueves a las 15:00 horas en Londres.
El número de muertos por el tsunami en Indonesia asciende a 832.
La agencia de gestión de desastres del país informó a primera hora del domingo que el número de muertos por el terremoto y el tsunami en Indonesia ha ascendido a 832.
Según informó el portavoz de la agencia, Sutopo Purwo Nugroho, en una rueda de prensa, muchas personas quedaron atrapadas entre los escombros de los edificios derrumbados por el terremoto de magnitud 7,5 que sacudió la región el viernes y que provocó olas de hasta 6 metros de altura.
La ciudad de Palu, que cuenta con más de 380.000 habitantes, quedó cubierta de escombros procedentes de los edificios derrumbados.
La policía arresta a un hombre de 32 años como sospechoso de asesinato tras el apuñalamiento mortal de una mujer.
Se ha iniciado una investigación por asesinato tras el hallazgo del cuerpo de una mujer esta mañana en Birkenhead, Merseyside.
El hombre de 44 años fue encontrado a las 7:55 de la mañana con heridas de arma blanca en Grayson Mews, en John Street, y un hombre de 32 años fue arrestado como sospechoso de asesinato.
La policía ha instado a los vecinos de la zona que hayan visto u oído algo a que se pongan en contacto con ellos.
El inspector detective Brian O'Hagan dijo: "La investigación está en sus primeras etapas, pero hago un llamamiento a cualquier persona que estuviera en las inmediaciones de John Street en Birkenhead y que viera u oyera algo sospechoso para que se ponga en contacto con nosotros."
También hago un llamamiento a cualquier persona, en particular a los taxistas, que pueda haber grabado algo con la cámara de su salpicadero para que se pongan en contacto con nosotros, ya que podrían tener información vital para nuestra investigación.
Un portavoz de la policía ha confirmado que la mujer cuyo cuerpo fue hallado era residente de Birkenhead y que fue encontrada dentro de una propiedad.
Esta tarde, unos amigos que creen conocer a la mujer han llegado al lugar de los hechos para preguntar dónde fue encontrada esta mañana.
Las investigaciones continúan y la policía ha indicado que está en proceso de informar a los familiares de la víctima.
Un taxista que vive en Grayson Mews acaba de intentar volver a su piso, pero la policía le ha dicho que nadie tiene permitido entrar ni salir del edificio.
Se quedó sin palabras cuando descubrió lo que había sucedido.
Ahora se les está informando a los residentes que pasarán horas antes de que se les permita regresar.
Se oyó a un agente de policía decirle a un hombre que toda la zona está siendo tratada como la escena de un crimen.
Una mujer apareció en el lugar llorando.
Ella no deja de repetir: "Es horrible".
A las 2 de la tarde, dos furgonetas policiales se encontraban dentro del cordón policial, con otra justo fuera.
Varios agentes se encontraban dentro del cordón policial, vigilando el bloque de pisos.
Cualquier persona que tenga información debe enviar un mensaje directo a @MerPolCC, llamar al 101 o contactar con Crimestoppers de forma anónima al 0800 555 111, indicando el número de registro 247 del 30 de septiembre.
La estatua de Cromwell en el Parlamento se convierte en el último monumento afectado por la polémica sobre la "reescritura de la historia".
Su destierro sería una justicia poética por la destrucción, al estilo talibán, de tantos artefactos culturales y religiosos de Inglaterra, llevada a cabo por sus fanáticos seguidores puritanos.
Pero la Sociedad Cromwell calificó la sugerencia del Sr. Crick de "una locura" y de "un intento de reescribir la historia".
John Goldsmith, presidente de la Sociedad Cromwell, dijo: "Era inevitable que, en el debate actual sobre la retirada de estatuas, la figura de Oliver Cromwell situada frente al Palacio de Westminster se convirtiera en un objetivo."
La iconoclasia de las guerras civiles inglesas no fue ni ordenada ni llevada a cabo por Cromwell.
Quizás se estaría sacrificando al Cromwell equivocado por las acciones de su antepasado Thomas en el siglo anterior.
La magnífica representación de Cromwell realizada por Sir William Hamo Thorneycroft es testimonio de la opinión pública del siglo XIX y forma parte de la historiografía de una figura que muchos consideran que aún merece ser celebrada.
El señor Goldsmith declaró a The Sunday Telegraph: "Muchos consideran a Cromwell, quizás más a finales del siglo XIX que en la actualidad, como un defensor del parlamento frente a la presión externa, en su caso, por supuesto, la monarquía."
Si esa representación es totalmente precisa o no, es objeto de un debate histórico continuo.
Lo que es seguro es que el conflicto de mediados del siglo XVII ha moldeado el desarrollo posterior de nuestra nación, y Cromwell es una figura individual reconocible que representa uno de los lados de esa división.
Sus logros como Lord Protector también merecen ser celebrados y conmemorados."
Un cerdo asesino mata a golpes a un granjero chino.
Según informes de los medios locales, un agricultor fue atacado y asesinado por un cerdo en un mercado del suroeste de China.
El hombre, identificado únicamente por su apellido "Yuan", fue hallado muerto con una arteria seccionada y cubierto de sangre cerca de un establo en el mercado de Liupanshui, en la provincia de Guizhou, según informó el domingo el South China Morning Post.
Un criador de cerdos se prepara para inyectar vacunas a los cerdos en una granja porcina el 30 de mayo de 2005 en Xining, provincia de Qinghai, China.
Según se informa, el miércoles viajó con su primo desde la provincia vecina de Yunnan para vender 15 cerdos en el mercado.
A la mañana siguiente, su primo lo encontró muerto y descubrió que la puerta de una pocilga vecina estaba abierta.
Dijo que en el corral había un cerdo macho grande con sangre en la boca.
Según el informe, un examen forense confirmó que el cerdo de 250 kilos había atacado mortalmente al granjero.
"Las piernas de mi primo estaban ensangrentadas y destrozadas", dijo el primo, identificado por su apellido "Wu", según recoge el Guiyang Evening News.
Las imágenes de las cámaras de seguridad mostraron a Yuan entrando al mercado a las 4:40 de la madrugada del jueves para alimentar a sus cerdos.
Su cuerpo fue encontrado aproximadamente una hora después.
El animal que mató al hombre no pertenecía a Yuan ni a su primo.
El gerente del mercado declaró al Evening News que el cerdo había sido encerrado para evitar que atacara a nadie más, mientras la policía recababa pruebas en el lugar de los hechos.
Según se informa, la familia de Yuan y las autoridades del mercado están negociando una indemnización por su muerte.
Aunque son raros, se han registrado casos de cerdos que atacan a humanos.
En 2016, un cerdo atacó a una mujer y a su marido en su granja en Massachusetts, dejando al hombre con heridas graves.
Diez años antes, un cerdo de 295 kilos inmovilizó a un granjero galés contra su tractor hasta que su esposa ahuyentó al animal.
Después de que un granjero de Oregón fuera devorado por sus cerdos en 2012, un granjero de Manitoba declaró a CBC News que los cerdos no suelen ser agresivos, pero que el sabor de la sangre puede actuar como un "detonante".
"Solo están bromeando."
Son unos pequeñitos, muy curiosos... no tienen intención de hacerte daño.
"Simplemente hay que mostrarles el debido respeto", dijo.
Los remanentes del huracán Rosa provocarán fuertes lluvias generalizadas en el suroeste de Estados Unidos.
Tal como se había pronosticado, el huracán Rosa se está debilitando a medida que avanza sobre las aguas más frías de la costa norte de México.
Sin embargo, Rosa provocará lluvias torrenciales que causarán inundaciones en el norte de México y el suroeste de Estados Unidos durante los próximos días.
A las 5 de la mañana, Rosa presentaba vientos de 137 km/h, lo que la convierte en un huracán de categoría 1. El domingo, hora del este, se encontraba a 385 millas al suroeste de Punta Eugenia, México.
Se espera que Rosa se desplace hacia el norte el domingo.
Mientras tanto, Una vaguada comienza a formarse sobre el Océano Pacífico y se desplaza hacia el este, en dirección a la costa oeste de Estados Unidos. A medida que Rosa se acerque a la península de Baja California el lunes como tormenta tropical, comenzará a empujar la humedad tropical profunda hacia el norte, hacia el suroeste de Estados Unidos.
Rosa provocará hasta 25 centímetros de lluvia en algunas zonas de México el lunes.
Posteriormente, la humedad tropical, al interactuar con la vaguada que se aproxima, provocará fuertes lluvias generalizadas en el suroeste durante los próximos días.
En la zona, entre 2,5 y 10 centímetros de lluvia provocarán peligrosas inundaciones repentinas, flujos de lodo y posibles deslizamientos de tierra en el desierto.
La intensa humedad tropical provocará que las precipitaciones alcancen entre 2 y 3 pulgadas por hora en algunas zonas, especialmente en partes del sur de Nevada y Arizona.
Se esperan entre 2 y 4 pulgadas de lluvia en algunas zonas del suroeste, especialmente en gran parte de Arizona.
Debido a la naturaleza dispersa de las lluvias tropicales, es posible que se produzcan inundaciones repentinas ante un rápido deterioro de las condiciones meteorológicas.
Sería sumamente imprudente aventurarse a pie en el desierto con la amenaza de lluvias tropicales.
Las fuertes lluvias podrían convertir los cañones en ríos embravecidos, y las tormentas eléctricas traerán consigo vientos localmente fuertes y polvo en suspensión.
La vaguada que se aproxima provocará lluvias localmente intensas en algunas zonas de la costa del sur de California.
Es posible que se registren precipitaciones superiores a media pulgada, lo que podría provocar pequeños deslizamientos de tierra y carreteras resbaladizas.
Esta sería la primera lluvia de la temporada de lluvias en la región.
Algunas lluvias tropicales dispersas comenzarán a acercarse a Arizona a última hora del domingo y a primera hora del lunes, antes de que la lluvia se generalice a última hora del lunes y el martes.
Las fuertes lluvias se extenderán a la región de las Cuatro Esquinas el martes y durarán hasta el miércoles.
En octubre se pueden producir intensas fluctuaciones de temperatura en Estados Unidos, ya que el Ártico se enfría, pero los trópicos permanecen bastante cálidos.
En ocasiones, esto provoca cambios drásticos de temperatura en distancias cortas.
El domingo se pudo observar un claro ejemplo de las drásticas diferencias de temperatura que se registraron en el centro de Estados Unidos.
Existe una diferencia de temperatura de casi 20 grados entre Kansas City, Missouri, y Omaha, Nebraska, y entre St. Louis y Des Moines, Iowa.
Durante los próximos días, el calor veraniego persistente intentará intensificarse y expandirse de nuevo.
Se espera que gran parte del centro y el este de Estados Unidos experimenten un comienzo de octubre cálido, con temperaturas que rondarán los 80 grados Fahrenheit (aproximadamente 27 grados Celsius) desde las Grandes Llanuras del Sur hasta algunas zonas del Noreste.
La ciudad de Nueva York podría alcanzar los 80 grados el martes, lo que supondría aproximadamente 10 grados por encima de la media.
Nuestro pronóstico climático a largo plazo indica altas probabilidades de que las temperaturas en el este de Estados Unidos se mantengan por encima del promedio durante la primera quincena de octubre.
Más de 20 millones de personas vieron la audiencia de Brett Kavanaugh.
Más de 20 millones de personas vieron el impactante testimonio del jueves del candidato a la Corte Suprema, Brett Kavanaugh, y de la mujer que lo acusó de una agresión sexual que supuestamente ocurrió en la década de 1980, Christine Blasey Ford, en seis cadenas de televisión.
Mientras tanto, el enfrentamiento político continuó, con las cadenas de televisión interrumpiendo su programación habitual para dar paso al giro de última hora del viernes: un acuerdo orquestado por el senador de Arizona, Jeff Flake, para que el FBI llevara a cabo una investigación de una semana sobre los cargos.
Ford declaró ante el Comité Judicial del Senado que está 100% segura de que Kavanaugh la manoseó estando borracho e intentó quitarle la ropa en una fiesta de la escuela secundaria.
En un apasionado testimonio, Kavanaugh afirmó estar 100% seguro de que no sucedió.
Es probable que más de los 20,4 millones de personas que Nielsen reportó el viernes lo hayan visto.
La empresa estaba contabilizando la audiencia media de CBS, ABC, NBC, CNN, Fox News Channel y MSNBC.
Las cifras no estaban disponibles de inmediato para otras cadenas que lo emitieron, incluidas PBS, C-SPAN y Fox Business Network.
Y Nielsen suele tener problemas para medir a las personas que ven la televisión en oficinas.
Para ponerlo en perspectiva, se trata de una audiencia similar a la de un partido de fútbol americano de playoffs o a la de los Premios Óscar.
Según Nielsen, Fox News Channel, cuyos presentadores de opinión han respaldado firmemente el nombramiento de Kavanaugh, lideró la audiencia con un promedio de 5,69 millones de espectadores durante la audiencia que duró todo el día.
ABC ocupó el segundo lugar con 3,26 millones de espectadores.
Según Nielsen, CBS tuvo 3,1 millones de espectadores, NBC 2,94 millones, MSNBC 2,89 millones y CNN 2,52 millones.
El interés se mantuvo elevado tras la audiencia.
Flake fue la figura central del drama del viernes.
Después de que la oficina del republicano moderado emitiera un comunicado anunciando que votaría a favor de Kavanaugh, las cámaras de CNN y CBS lo captaron el viernes por la mañana mientras manifestantes le gritaban al intentar subir en ascensor a una audiencia del Comité Judicial.
Permaneció con la mirada baja durante varios minutos mientras era reprendido, todo ello televisado en directo por CNN.
"Estoy aquí mismo, delante de usted", dijo una mujer.
¿Crees que le está diciendo la verdad al país?
Le dijeron: "Tienes poder cuando tantas mujeres no lo tienen".
Flake dijo que su oficina había emitido un comunicado y que, antes de que se cerrara el ascensor, diría que tendría más que decir en la audiencia del comité.
Las cadenas de cable y de televisión abierta estaban cubriendo en directo horas después, cuando el Comité Judicial iba a votar para que la nominación de Kavanaugh pasara al pleno del Senado para su votación.
Pero Flake dijo que solo lo haría con la condición de que el FBI investigara las acusaciones contra el nominado durante la próxima semana, algo que los demócratas de la minoría han estado solicitando.
Flake se convenció en parte gracias a las conversaciones que mantuvo con su amigo, el senador demócrata Chris Coons.
Tras una conversación posterior con Coons y varios senadores, Flake tomó su decisión.
La elección de Flake tenía peso, porque era evidente que los republicanos no tendrían los votos necesarios para aprobar a Kavanaugh sin la investigación.
El presidente Trump ha abierto una investigación del FBI sobre las acusaciones contra Kavanaugh.
La primera ministra británica, May, acusa a sus críticos de "hacer política" con el Brexit.
En una entrevista con el periódico Sunday Times, la primera ministra Theresa May acusó a los críticos de sus planes para abandonar la Unión Europea de "hacer política" con el futuro de Gran Bretaña y de socavar el interés nacional.
La primera ministra británica, Theresa May, llega a la conferencia del Partido Conservador en Birmingham, Gran Bretaña, el 29 de septiembre de 2018.
En otra entrevista junto a la que le hicieron en la portada del periódico, Su exministro de Asuntos Exteriores, Boris Johnson, insistió en sus críticas al llamado plan de Chequers para el Brexit, afirmando que la propuesta de que Gran Bretaña y la UE se recauden mutuamente los aranceles era "totalmente absurda".
Tiroteo de Wayde Sims: La policía arresta al sospechoso Dyteon Simpson por la muerte del jugador de LSU.
La policía ha arrestado a un sospechoso del asesinato a tiros de Wayde Sims, un jugador de baloncesto de 20 años de la Universidad Estatal de Luisiana (LSU).
Dyteon Simpson, de 20 años, ha sido arrestado e ingresado en prisión acusado de asesinato en segundo grado, según informó el Departamento de Policía de Baton Rouge.
Las autoridades publicaron un vídeo del enfrentamiento entre Sims y Simpson, y la policía dijo que Sims perdió sus gafas durante la pelea.
La policía recuperó las gafas del lugar de los hechos y declaró haber encontrado ADN de Simpson en ellas, según informa WAFB, filial de CBS.
Tras interrogar a Simpson, la policía informó que este admitió haber disparado mortalmente a Wayde.
Según informa el diario The Advocate, su fianza se ha fijado en 350.000 dólares.
La oficina forense de la parroquia de East Baton Rouge publicó un informe preliminar el viernes, en el que indica que la causa de la muerte es una herida de bala en la cabeza que se alojó en el cuello.
El departamento agradece al grupo especial de búsqueda de fugitivos de la Policía Estatal de Luisiana, al laboratorio forense de la policía estatal, a la policía de la Universidad del Sur y a los ciudadanos de la zona por su ayuda en la investigación que condujo al arresto.
El director deportivo de LSU, Joe Alleva, agradeció a las fuerzas del orden locales por su "diligencia y búsqueda de justicia".
Sims tenía 20 años.
El alero de 1,98 metros creció en Baton Rouge, donde su padre, Wayne, también jugó al baloncesto para la LSU.
La temporada pasada promedió 5,6 puntos y 2,6 rebotes por partido.
El viernes por la mañana, el entrenador de baloncesto de LSU, Will Wade, dijo que el equipo está "devastado" y "en estado de shock" por la muerte de Wade.
"Esto es lo que te preocupa en todo momento", dijo Wade.
Un volcán arroja ceniza sobre la Ciudad de México.
Las cenizas que emanan del volcán Popocatépetl han llegado a los barrios del sur de la capital de México.
El Centro Nacional de Prevención de Desastres advirtió el sábado a los mexicanos que se mantuvieran alejados del volcán luego de que aumentara la actividad en el cráter y se registraran 183 emisiones de gas y ceniza en 24 horas.
El centro estaba monitoreando múltiples estruendos y temblores.
En las redes sociales circularon imágenes que mostraban finas capas de ceniza cubriendo los parabrisas de los automóviles en barrios de la Ciudad de México, como Xochimilco.
Los geofísicos han observado un aumento de la actividad en el volcán situado a 72 kilómetros (45 millas) al sureste de la capital desde que un terremoto de magnitud 7,1 sacudiera el centro de México en septiembre de 2017.
El volcán conocido como "Don Goyo" ha estado activo desde 1994.
La policía se enfrenta a separatistas catalanes antes del aniversario del voto de independencia.
Seis personas fueron arrestadas en Barcelona el sábado después de que manifestantes independentistas se enfrentaran con la policía antidisturbios, mientras miles de personas se unían a manifestaciones rivales para conmemorar el primer aniversario de la controvertida votación de secesión de Cataluña.
Un grupo de separatistas enmascarados, retenidos por la policía antidisturbios, les arrojaron huevos y pintura en polvo, creando densas nubes de polvo en calles que normalmente estarían repletas de turistas.
Más tarde, ese mismo día, se produjeron altercados en los que la policía utilizó sus porras para contener la pelea.
Durante varias horas, grupos independentistas que coreaban "Ni olvidar, ni perdonar" se enfrentaron a manifestantes unionistas que gritaban "¡Viva España!".
Catorce personas recibieron tratamiento por heridas leves sufridas durante las protestas, según informaron los medios locales.
La tensión sigue siendo alta en la región independentista un año después del referéndum del 1 de octubre, considerado ilegal por Madrid pero celebrado por los separatistas catalanes.
Los votantes optaron mayoritariamente por la independencia, aunque la participación fue baja, ya que quienes se oponían a la secesión boicotearon en gran medida la votación.
Según las autoridades catalanas, casi 1000 personas resultaron heridas el año pasado después de que la policía intentara impedir que se celebraran las elecciones en los colegios electorales de toda la región, en violentos enfrentamientos.
Grupos independentistas acamparon durante la noche del viernes para impedir una manifestación en apoyo de la policía nacional.
La manifestación siguió adelante, pero se vio obligada a tomar una ruta diferente.
Narcis Termes, de 68 años, electricista que asistía a la protesta separatista con su esposa, dijo que ya no tenía esperanzas en las perspectivas de que Cataluña consiga la independencia.
"El año pasado vivimos uno de nuestros mejores momentos."
"Vi a mis padres llorar de alegría al poder votar, pero ahora estamos atrapados", dijo.
A pesar de haber logrado una victoria vital, aunque ajustada, en las elecciones regionales del pasado diciembre, Los partidos independentistas catalanes han tenido dificultades para mantener el impulso este año, ya que muchos de sus líderes más conocidos se encuentran en el exilio autoimpuesto o detenidos a la espera de juicio por su papel en la organización del referéndum y la posterior declaración de independencia.
Joan Puig, un mecánico de 42 años que grababa con su teléfono la protesta en apoyo a la policía, dijo que el conflicto había sido avivado por políticos de ambos bandos.
"La situación se está volviendo cada vez más tensa", dijo.
El sábado, Oriol Junqueras, uno de los nueve líderes catalanes en prisión preventiva desde finales del año pasado, anunció que se presentará a las elecciones al Parlamento Europeo del próximo año.
"Presentarme como candidato a las elecciones europeas es la mejor manera de denunciar el retroceso en los valores democráticos y la represión que hemos visto por parte del gobierno español", afirmó.
Londonderry: Detienen a varios hombres tras el impacto de un coche contra una casa.
Tres hombres, de 33, 34 y 39 años, han sido arrestados después de que un coche se estrellara repetidamente contra una casa en Londonderry.
El incidente tuvo lugar en Ballynagard Crescent el jueves alrededor de las 19:30 BST.
El inspector Bob Blemmings declaró que los daños se produjeron tanto en las puertas como en el propio edificio.
También es posible que en algún momento se haya disparado una ballesta contra el coche.
Un gol de Menga le da la victoria al Livingston por 1-0 sobre el Rangers.
El primer gol de Dolly Menga para el Livingston aseguró la victoria.
El recién ascendido Livingston sorprendió al Rangers y le propinó a Steven Gerrard su segunda derrota en 18 partidos como entrenador del club de Ibrox.
El gol de Dolly Menga marcó la diferencia y el equipo de Gary Holt igualó al Hibernian en la segunda posición.
El equipo de Gerrard sigue sin conseguir una victoria fuera de casa en la Premiership esta temporada y se enfrentará al líder Hearts, al que le siguen a ocho puntos, el próximo domingo.
Antes de eso, el Rangers recibirá al Rapid de Viena en la Europa League el jueves.
Mientras tanto, el Livingston extiende su racha invicta en la división a seis partidos, y el entrenador Holt aún no conoce la derrota desde que reemplazó a Kenny Miller el mes pasado.
El Livingston desaprovecha sus oportunidades ante unos visitantes poco convincentes.
El equipo de Holt debería haber estado por delante mucho antes de marcar, ya que su juego directo causó todo tipo de problemas al Rangers.
Scott Robinson logró abrirse paso, pero su disparo se fue desviado por poco, y luego Alan Lithgow solo pudo enviar su remate fuera tras deslizarse para conectar con el cabezazo de Craig Halkett.
Los anfitriones se contentaron con dejar que el Rangers jugara frente a ellos, sabiendo que podían poner en aprietos a los visitantes en las jugadas a balón parado.
Y así fue como se logró el gol decisivo.
Los Rangers concedieron un tiro libre y el Livingston creó una oportunidad; Declan Gallagher y Robinson se combinaron para habilitar a Menga, quien controló el balón y marcó desde el centro del área.
Para entonces, los Rangers habían dominado la posesión, pero se habían encontrado con una defensa local impenetrable y el portero Liam Kelly no tuvo mayores problemas.
Esa tónica se mantuvo en la segunda mitad, aunque Alfredo Morelos obligó a Kelly a realizar una parada.
Scott Pittman vio cómo el portero del Rangers, Allan McGregor, le negaba el gol con los pies, y Lithgow remató desviado en otra jugada a balón parado del Livingston.
Los centros llegaban continuamente al área del Livingston y eran despejados una y otra vez, mientras que dos reclamaciones de penalti —una tras una entrada de Halkett sobre el suplente Glenn Middleton y otra por mano— fueron desestimadas.
'Fenomenal' de Livingston - análisis
Alasdair Lamont de BBC Scotland en el Tony Macaroni Arena.
Una actuación y un resultado fenomenales para Livingston.
Todos ellos fueron excelentes, y continuaron superando las expectativas en esta trayectoria ascendente.
Su estilo de juego y su plantilla apenas han cambiado desde su regreso a la máxima categoría, pero hay que reconocer el gran mérito de Holt por la forma en que ha revitalizado al equipo desde su llegada.
Tenía tantos héroes.
El capitán Halkett estuvo inmenso, dirigiendo una defensa magníficamente organizada, mientras que Menga mantuvo a Connor Goldson y Joe Worrall en alerta constante.
Sin embargo, a los Rangers les faltó inspiración.
Por muy buenos que hayan sido en ocasiones bajo la dirección de Gerrard, se quedaron muy lejos de alcanzar esos estándares.
Les faltó precisión en el último pase (solo una vez lograron superar la defensa local), lo que supone una especie de llamada de atención para los Rangers, que se encuentran en la mitad de la tabla.
Erdogan recibe una acogida dispar en Colonia.
El sábado 29 de septiembre reinaron las sonrisas y el cielo azul cuando los líderes de Turquía y Alemania se reunieron para desayunar en Berlín.
Hoy es el último día de la polémica visita del presidente Erdogan a Alemania, cuyo objetivo es recomponer las relaciones entre los aliados de la OTAN.
Han tenido diferencias por cuestiones como los derechos humanos, la libertad de prensa y la adhesión de Turquía a la UE.
Posteriormente, Erdogan se dirigió a Colonia para inaugurar una nueva y gigantesca mezquita.
La ciudad alberga la mayor población turca fuera de Turquía.
La policía alegó motivos de seguridad para impedir que una multitud de 25.000 personas se congregara frente a la mezquita, pero muchos simpatizantes se presentaron en las inmediaciones para ver a su presidente.
Cientos de manifestantes anti-Erdogan, muchos de ellos kurdos, también hicieron oír su voz, condenando tanto las políticas de Erdogan como la decisión del gobierno alemán de darle la bienvenida al país.
Las protestas contrapuestas reflejan la división que suscita un visitante aclamado como un héroe por algunos turcos alemanes y vilipendiado como un autócrata por otros.
Accidente de tráfico en Deptford: Un ciclista muere en colisión con un coche.
Un ciclista ha fallecido en una colisión con un coche en Londres.
El accidente tuvo lugar cerca del cruce de Bestwood Street y Evelyn Street, una calle muy transitada en Deptford, en el sureste de la ciudad, alrededor de las 10:15 BST.
El conductor del coche se detuvo y llegaron los paramédicos, pero el hombre falleció en el lugar del accidente.
El accidente se produce meses después de que otro ciclista muriera en un atropello con fuga en Childers Street, a aproximadamente una milla del lugar del accidente del sábado.
La Policía Metropolitana informó que los agentes están trabajando para identificar al hombre e informar a sus familiares.
Se han cortado carreteras y se han desviado las rutas de los autobuses, por lo que se recomienda a los conductores que eviten la zona.
Prisión de Long Lartin: Seis agentes heridos en disturbios.
Seis funcionarios de prisiones resultaron heridos en un altercado en una cárcel de alta seguridad para hombres, según informó la Oficina de Prisiones.
El domingo, alrededor de las 09:30 BST, se produjeron disturbios en la prisión HMP Long Lartin, en Worcestershire, y la situación aún continúa.
Se ha desplegado a agentes especializados del programa "Tornado" para controlar el disturbio, en el que están implicados ocho reclusos y que se limita a un ala del edificio.
Los agentes recibieron atención médica en el lugar de los hechos por heridas faciales leves.
Un portavoz del Servicio Penitenciario declaró: "Se ha desplegado personal penitenciario especialmente capacitado para hacer frente a un incidente en curso en la prisión de HMP Long Lartin."
Seis miembros del personal han recibido tratamiento por las lesiones sufridas.
No toleramos la violencia en nuestras cárceles y dejamos claro que los responsables serán entregados a la policía y podrían pasar más tiempo entre rejas.
La prisión de HMP Long Lartin alberga a más de 500 reclusos, entre ellos algunos de los delincuentes más peligrosos del país.
En junio se informó de que el director de la prisión recibió tratamiento hospitalario tras ser atacado por un preso.
Y en octubre del año pasado, se llamó a agentes antidisturbios a la prisión para hacer frente a un grave disturbio en el que el personal fue atacado con bolas de billar.
El huracán Rosa amenaza a Phoenix, Las Vegas y Salt Lake City con inundaciones repentinas (las zonas afectadas por la sequía podrían beneficiarse).
Es raro que una depresión tropical azote Arizona, pero eso es precisamente lo que probablemente ocurra a principios de la próxima semana, cuando la energía restante del huracán Rosa se desplace por el suroeste del desierto, generando riesgos de inundaciones repentinas.
El Servicio Meteorológico Nacional ya ha emitido avisos de inundaciones repentinas para el lunes y el martes en el oeste de Arizona, el sur y el este de Nevada, el sureste de California y Utah, incluyendo las ciudades de Phoenix, Flagstaff, Las Vegas y Salt Lake City.
Se prevé que Rosa siga una trayectoria directa sobre Phoenix el martes, acercándose a última hora del lunes con lluvias.
El Servicio Meteorológico Nacional en Phoenix señaló en un tuit que "¡solo diez ciclones tropicales han mantenido el estatus de tormenta tropical o depresión tropical dentro de un radio de 200 millas de Phoenix desde 1950!"
Katrina (1967) fue un huracán que pasó a menos de 64 kilómetros de la frontera con Arizona.
Los últimos modelos del Centro Nacional de Huracanes predicen entre 2 y 4 pulgadas de lluvia, con cantidades aisladas de hasta 6 pulgadas en la Meseta de Mogollón de Arizona.
Es probable que otras zonas del suroeste desértico, incluidas las Montañas Rocosas centrales y la Gran Cuenca, reciban entre 1 y 2 pulgadas de lluvia, con acumulaciones aisladas de hasta 4 pulgadas.
Para quienes se encuentran fuera del riesgo de inundaciones repentinas, las lluvias de Rosa pueden ser una bendición, ya que la región está azotada por la sequía.
Si bien las inundaciones son una preocupación muy seria, es probable que parte de estas lluvias sean beneficiosas, ya que el suroeste del país está experimentando actualmente condiciones de sequía.
Según el Monitor de Sequía de EE. UU., poco más del 40 por ciento de Arizona está experimentando al menos una sequía extrema, la segunda categoría más alta", informó weather.com.
En primer lugar, la trayectoria del huracán Rosa conduce a que toque tierra en la península de Baja California, en México.
Rosa, que el domingo por la mañana aún mantenía la fuerza de huracán con vientos máximos de 85 millas por hora, se encontraba a 385 millas al sur de Punta Eugenia, México, y se desplazaba hacia el norte a 12 millas por hora.
La tormenta está encontrando aguas más frías en el Pacífico y, por lo tanto, está perdiendo fuerza.
Por lo tanto, se espera que toque tierra en México con fuerza de tormenta tropical en la tarde o noche del lunes.
Las lluvias en algunas zonas de México podrían ser intensas, lo que supone un riesgo significativo de inundaciones.
Según informó weather.com, se esperan acumulaciones de lluvia de entre 3 y 6 pulgadas desde Baja California hasta el noroeste de Sonora, con la posibilidad de que lleguen hasta las 10 pulgadas.
Posteriormente, Rosa se desplazará hacia el norte a través de México como tormenta tropical antes de llegar a la frontera de Arizona en la madrugada del martes como depresión tropical, que luego se desplazará hacia el norte a través de Arizona y llegará al sur de Utah a última hora de la noche del martes.
"El principal peligro que se espera de Rosa o sus remanentes son lluvias muy intensas en Baja California, el noroeste de Sonora y el suroeste desértico de Estados Unidos", dijo el Centro Nacional de Huracanes.
Se prevé que estas lluvias provoquen inundaciones repentinas y aludes de lodo potencialmente mortales en los desiertos, así como deslizamientos de tierra en las zonas montañosas.
Ataque en Midsomer Norton: Cuatro arrestos por intento de asesinato
Tres adolescentes y un hombre de 20 años han sido arrestados bajo sospecha de intento de asesinato después de que un joven de 16 años fuera encontrado con heridas de arma blanca en Somerset.
El adolescente fue encontrado herido en la zona de Excelsior Terrace de Midsomer Norton, alrededor de las 04:00 BST del sábado.
Fue trasladado al hospital, donde permanece en estado "estable".
Un joven de 17 años, dos de 18 y un hombre de 20 fueron arrestados durante la noche en la zona de Radstock, según informó la policía de Avon y Somerset.
Los agentes han hecho un llamamiento a cualquier persona que pueda tener grabaciones de lo sucedido con su teléfono móvil para que se ponga en contacto con ellos.
Trump dice que Kavanaugh "sufrió la mezquindad y la ira" del Partido Demócrata.
"Votar por el juez Kavanaugh es votar para rechazar las tácticas despiadadas e indignantes del Partido Demócrata", dijo Trump en un mitin en Wheeling, Virginia Occidental.
Trump afirmó que Kavanaugh ha "sufrido la mezquindad y la ira" del Partido Demócrata a lo largo de todo su proceso de nominación.
Kavanaugh testificó ante el Congreso el jueves, negando con vehemencia y emoción la acusación de Christine Blasey Ford de que la agredió sexualmente hace décadas, cuando eran adolescentes.
Ford también testificó en la audiencia sobre su acusación.
El presidente afirmó el sábado que "el pueblo estadounidense pudo apreciar la brillantez, la calidad y el coraje" de Kavanaugh ese día.
"Votar a favor de la confirmación del juez Kavanaugh es votar a favor de la confirmación de una de las mentes jurídicas más brillantes de nuestro tiempo, un jurista con una trayectoria impecable en el servicio público", dijo a la multitud de simpatizantes de Virginia Occidental.
El presidente hizo una referencia indirecta a la nominación de Kavanaugh al hablar de la importancia de la participación republicana en las elecciones de mitad de mandato.
"A cinco semanas de una de las elecciones más importantes de nuestras vidas."
"No estoy corriendo, pero en realidad estoy corriendo", dijo.
"Por eso estoy por todas partes luchando por los mejores candidatos."
Trump argumentó que los demócratas tienen la misión de "resistir y obstruir".
Se espera que la primera votación clave de procedimiento en el pleno del Senado sobre la nominación de Kavanaugh tenga lugar a más tardar el viernes, según ha declarado a CNN un alto asesor del liderazgo republicano.
Cientos de muertos por el terremoto y el tsunami en Indonesia, y se prevé que la cifra de víctimas aumente.
Al menos 384 personas murieron, muchas de ellas arrastradas por las olas gigantes que azotaron las playas, cuando un fuerte terremoto y un tsunami sacudieron la isla indonesia de Sulawesi, según informaron las autoridades el sábado.
Cientos de personas se habían reunido el viernes para un festival en la playa de la ciudad de Palu cuando, al anochecer, olas de hasta seis metros (18 pies) de altura azotaron la costa, arrastrando a muchos a la muerte y destruyendo todo a su paso.
El tsunami se produjo tras un terremoto de magnitud 7,5.
"Cuando surgió la amenaza de tsunami ayer, la gente seguía realizando sus actividades en la playa y no corrió de inmediato, convirtiéndose así en víctimas", declaró Sutopo Purwo Nugroho, portavoz de la agencia indonesia de mitigación de desastres BNPB, en una rueda de prensa en Yakarta.
"El tsunami no llegó por sí solo, arrastró coches, troncos, casas, golpeó todo lo que había en tierra", dijo Nugroho, y añadió que el tsunami había viajado por mar abierto a velocidades de 800 km/h (497 mph) antes de llegar a la costa.
Según él, algunas personas se subieron a los árboles para escapar del tsunami y sobrevivieron.
Alrededor de 16.700 personas fueron evacuadas a 24 centros en Palu.
Las fotografías aéreas difundidas por la agencia de gestión de desastres mostraron numerosos edificios y tiendas destruidos, puentes retorcidos y derrumbados, y una mezquita rodeada de agua.
Las réplicas continuaron sacudiendo la ciudad costera el sábado.
La serie de terremotos se sintieron en una zona con 2,4 millones de habitantes.
La Agencia Indonesia para la Evaluación y Aplicación de la Tecnología (BPPT) declaró que la energía liberada por el fuerte terremoto del viernes fue aproximadamente 200 veces superior a la potencia de la bomba atómica lanzada sobre Hiroshima durante la Segunda Guerra Mundial.
Según el informe, la geografía de la ciudad, situada al final de una bahía larga y estrecha, podría haber magnificado la magnitud del tsunami.
Nugroho describió los daños como "extensos" y dijo que miles de casas, hospitales, centros comerciales y hoteles se habían derrumbado.
Según declaró, se encontraron los cuerpos de algunas víctimas atrapados bajo los escombros de los edificios derrumbados, y añadió que 540 personas resultaron heridas y 29 están desaparecidas.
Nugroho afirmó que las víctimas y los daños podrían ser mayores a lo largo de la costa, a 300 km (190 millas) al norte de Palu, en una zona llamada Donggala, que está más cerca del epicentro del terremoto.
Según Nugroho, las comunicaciones "estaban totalmente interrumpidas y no se recibía ninguna información" desde Donggala.
"Allí viven más de 300.000 personas", declaró la Cruz Roja en un comunicado, añadiendo que su personal y voluntarios se dirigían a las zonas afectadas.
"Esto ya es una tragedia, pero podría empeorar mucho más", decía el comunicado.
La agencia fue duramente criticada el sábado por no informar de que un tsunami había azotado Palu, aunque los funcionarios afirmaron que las olas llegaron dentro del tiempo en que se emitió la alerta.
En un vídeo grabado por un aficionado y compartido en las redes sociales, se puede oír a un hombre en el piso superior de un edificio gritando advertencias desesperadas sobre el inminente tsunami a la gente que se encuentra en la calle.
En cuestión de minutos, una pared de agua se estrella contra la orilla, arrasando edificios y coches.
Reuters no pudo autenticar las imágenes de inmediato.
El terremoto y el tsunami provocaron un importante apagón que interrumpió las comunicaciones en los alrededores de Palu, dificultando así la coordinación de las labores de rescate por parte de las autoridades.
Las autoridades han informado que el ejército ha comenzado a enviar aviones de carga con ayuda desde Yakarta y otras ciudades, pero los evacuados siguen necesitando urgentemente alimentos y otros artículos de primera necesidad.
El aeropuerto de la ciudad se ha reabierto únicamente para labores de socorro y permanecerá cerrado hasta octubre.
El presidente Joko Widodo tenía previsto visitar los centros de evacuación en Palu el domingo.
El número de víctimas del tsunami en Indonesia supera las 800.
Es muy malo.
Aunque el personal de World Vision procedente de Donggala ha llegado sano y salvo a la ciudad de Palu, donde los empleados se refugian en lonas instaladas en el patio de su oficina, en el camino se encontraron con escenas de devastación, según declaró el Sr. Doseba.
"Me dijeron que vieron muchas casas destruidas", dijo.
Es muy malo.
Incluso cuando los grupos de ayuda comenzaron los arduos preparativos para poner en marcha la maquinaria de socorro tras el desastre, algunos se quejaron de que se estaba impidiendo que trabajadores humanitarios extranjeros con amplia experiencia viajaran a Palu.
Según la normativa indonesia, la financiación, los suministros y el personal procedentes del extranjero solo pueden empezar a llegar si la zona afectada por la catástrofe es declarada zona de desastre nacional.
Esto aún no ha sucedido.
"Sigue siendo un desastre a nivel provincial", dijo Aulia Arriani, portavoz de la Cruz Roja Indonesia.
"Una vez que el gobierno diga: 'De acuerdo, esto es un desastre nacional', podremos abrir la puerta a la asistencia internacional, pero aún no hay un estatus definido."
Al caer la segunda noche en Palu tras el terremoto y el tsunami del viernes, los amigos y familiares de los desaparecidos aún mantenían la esperanza de que sus seres queridos fueran los milagros que aligeraran las sombrías historias de los desastres naturales.
El sábado, un niño pequeño fue rescatado de una alcantarilla.
El domingo, los rescatistas liberaron a una mujer que había permanecido atrapada bajo los escombros durante dos días, con el cuerpo de su madre a su lado.
Gendon Subandono, entrenador del equipo nacional indonesio de parapente, había entrenado a dos de los parapentistas desaparecidos para los Juegos Asiáticos, que concluyeron a principios de este mes en Indonesia.
Entre las personas atrapadas en el Hotel Roa Roa, incluido el Sr. Mandagi, se encontraban sus alumnos.
"Como veterano en el mundo del parapente, tengo mi propia carga emocional", dijo.
El Sr. Gendon relató cómo, en las horas posteriores a que la noticia del derrumbe del Hotel Roa Roa circulara entre la comunidad de parapentistas, envió desesperadamente mensajes de WhatsApp a los competidores de Palu, que participaban en el festival de playa.
Sin embargo, sus mensajes solo obtuvieron una marca de verificación gris, en lugar de un par de marcas de verificación azules.
"Creo que eso significa que los mensajes no fueron entregados", dijo.
Ladrones roban 26.750 dólares durante una recarga de cajero automático en Newport on the Levee.
Según un comunicado de prensa del Departamento de Policía de Newport, el viernes por la mañana unos ladrones robaron 26.750 dólares a un empleado de Brink's que estaba reabasteciendo un cajero automático en Newport on the Levee.
El conductor del coche había estado vaciando un cajero automático en el complejo de ocio y se preparaba para entregar más dinero, según el detective. Dennis McCarthy escribió en el comunicado.
Mientras estaba distraído, otro hombre "se acercó corriendo por detrás del empleado de Brink's" y robó una bolsa de dinero destinada a ser entregada.
Según el comunicado, los testigos vieron a varios sospechosos huyendo del lugar, pero la policía no especificó el número de personas implicadas en el incidente.
Cualquier persona que tenga información sobre sus identidades debe comunicarse con la policía de Newport al 859-292-3680.
Kanye West: El rapero cambia su nombre a Ye
El rapero Kanye West va a cambiarse el nombre a Ye.
Al anunciar el cambio en Twitter el sábado, escribió: "El ser conocido formalmente como Kanye West".
West, de 41 años, ha sido apodado Ye desde hace algún tiempo y utilizó ese apodo como título para su octavo álbum, que fue lanzado en junio.
Este cambio se produce antes de su aparición en Saturday Night Live, donde se espera que presente su nuevo álbum, Yandhi.
Él reemplaza a la cantante Ariana Grande en el programa, quien canceló su participación por "razones emocionales", según dijo el creador del programa.
Además de ser una abreviatura de su nombre artístico actual, West ha dicho anteriormente que la palabra tiene un significado religioso para él.
"Creo que 'ye' es la palabra más utilizada en la Biblia, y en la Biblia significa 'tú'", dijo West a principios de este año, al hablar del título de su álbum con el presentador de radio Big Boy.
"Entonces yo soy tú, yo somos nosotros, somos nosotros."
Pasó de Kanye, que significa el único, a simplemente Ye, siendo simplemente un reflejo de lo bueno, lo malo, lo confundido, de todo.
El álbum es más bien un reflejo de quiénes somos."
Es uno de los muchos raperos famosos que han cambiado de nombre.
Sean Combs ha sido conocido con diversos nombres, como Puff Daddy, P. Diddy o Diddy, pero este año anunció su preferencia por los nombres Love y Brother Love.
JAY-Z, antiguo colaborador de West, también ha sabido usar o no guion y mayúsculas.
AMLO, presidente de México, promete no usar al ejército contra civiles.
El presidente electo de México, Andrés Manuel López Obrador, ha prometido no volver a usar la fuerza militar contra civiles, al acercarse el país al 50 aniversario de una sangrienta represalia contra estudiantes.
López Obrador prometió el sábado en la Plaza Tlatelolco que "jamás jamás utilizará a las fuerzas armadas para reprimir al pueblo mexicano".
El 2 de octubre de 1968, las tropas abrieron fuego contra una manifestación pacífica en la plaza, matando a unas 300 personas en un momento en que los movimientos estudiantiles de izquierda estaban echando raíces en toda América Latina.
López Obrador se ha comprometido a apoyar a los jóvenes mexicanos otorgando subsidios mensuales a quienes estudian y abriendo más universidades públicas gratuitas.
Ha afirmado que el desempleo y la falta de oportunidades educativas atraen a los jóvenes a las bandas criminales.
Estados Unidos debería duplicar la financiación para la inteligencia artificial.
A medida que China se involucra más en la inteligencia artificial, Estados Unidos debería duplicar la cantidad que gasta en investigación en este campo, afirma el inversor y experto en IA Kai-Fu Lee, que ha trabajado para Google, Microsoft y Apple.
Estos comentarios surgen después de que varias partes del gobierno estadounidense hayan hecho anuncios sobre inteligencia artificial, a pesar de que Estados Unidos en su conjunto carece de una estrategia formal de IA.
Mientras tanto, China presentó su plan el año pasado: aspira a ser el número uno en innovación de IA para 2030.
"Duplicar el presupuesto para la investigación en IA sería un buen comienzo, dado que todos los demás países están mucho más rezagados que Estados Unidos, y estamos buscando el próximo gran avance en IA", dijo Lee.
Según declaró Lee a CNBC en una entrevista esta semana, duplicar la financiación podría duplicar las posibilidades de que el próximo gran logro en inteligencia artificial se produzca en Estados Unidos.
Lee, cuyo libro "AI Superpowers: China, Silicon Valley and the New World Order" fue publicado este mes por Houghton Mifflin Harcourt, es el director ejecutivo de Sinovation Ventures, que ha invertido en una de las empresas de IA más destacadas de China, Face++.
En la década de 1980, en la Universidad Carnegie Mellon, trabajó en un sistema de inteligencia artificial que venció al jugador de Otelo estadounidense mejor clasificado, y más tarde fue ejecutivo en Microsoft Research y presidente de la filial china de Google.
Lee reconoció la existencia de concursos tecnológicos anteriores del gobierno estadounidense, como el Desafío de Robótica de la Agencia de Proyectos de Investigación Avanzada de Defensa (DARPA), y preguntó cuándo se celebraría el próximo, con el fin de ayudar a identificar a los próximos visionarios.
Según Lee, los investigadores en Estados Unidos a menudo tienen que esforzarse mucho para conseguir subvenciones gubernamentales.
"No es China la que se está llevando a los líderes académicos; son las grandes empresas", dijo Lee.
En los últimos años, Facebook, Google y otras empresas tecnológicas han contratado a figuras destacadas de las universidades para trabajar en inteligencia artificial.
Lee afirmó que los cambios en la política de inmigración también podrían ayudar a Estados Unidos a reforzar sus esfuerzos en el campo de la inteligencia artificial.
"Creo que las tarjetas de residencia deberían ofrecerse automáticamente a los doctores en inteligencia artificial", afirmó.
El Consejo de Estado de China publicó su Plan de Desarrollo de Inteligencia Artificial de Próxima Generación en julio de 2017.
La Fundación Nacional de Ciencias Naturales de China proporciona financiación a personas en instituciones académicas de manera similar a como la Fundación Nacional de Ciencias y otras organizaciones gubernamentales distribuyen dinero a los investigadores estadounidenses. Pero la calidad del trabajo académico es inferior en China, dijo Lee.
A principios de este año, el Departamento de Defensa de Estados Unidos creó un Centro Conjunto de Inteligencia Artificial, cuyo objetivo es involucrar a socios de la industria y el mundo académico, y la Casa Blanca anunció la formación de un Comité Selecto sobre Inteligencia Artificial.
Y este mes, DARPA anunció una inversión de 2.000 millones de dólares en una iniciativa llamada AI Next.
En cuanto a la NSF, actualmente invierte más de 100 millones de dólares al año en investigación sobre inteligencia artificial.
Mientras tanto, la legislación estadounidense que pretendía crear una Comisión Nacional de Seguridad sobre Inteligencia Artificial lleva meses sin avanzar.
Los macedonios votan en referéndum sobre si cambiar o no el nombre del país.
El domingo, el pueblo de Macedonia votó en referéndum sobre si cambiar su nombre a "República de Macedonia del Norte", una medida que resolvería una disputa de décadas con Grecia, que había bloqueado sus solicitudes de adhesión a la Unión Europea y la OTAN.
Grecia, que tiene una provincia llamada Macedonia, sostiene que el nombre de su vecino del norte representa una reivindicación sobre su territorio y ha vetado su entrada en la OTAN y la UE.
Los dos gobiernos llegaron a un acuerdo en junio basado en el nuevo nombre propuesto, pero los opositores nacionalistas argumentan que el cambio socavaría la identidad étnica de la población eslava mayoritaria de Macedonia.
El presidente Gjorge Ivanov ha declarado que no votará en el referéndum y una campaña de boicot ha sembrado dudas sobre si la participación alcanzará el mínimo del 50 por ciento necesario para que el referéndum sea válido.
La pregunta que figuraba en la papeleta del referéndum decía: "¿Está usted a favor de la pertenencia a la OTAN y a la UE, aceptando el acuerdo con Grecia?".
Los partidarios del cambio de nombre, entre ellos el primer ministro Zoran Zaev, argumentan que es un precio que vale la pena pagar para que Macedonia, uno de los países surgidos tras el colapso de Yugoslavia, pueda ingresar en organismos como la UE y la OTAN.
"Hoy he venido a votar por el futuro del país, por los jóvenes de Macedonia, para que puedan vivir libremente bajo el amparo de la Unión Europea, porque eso significa una vida más segura para todos nosotros", dijo Olivera Georgijevska, de 79 años, en Skopje.
Aunque no es jurídicamente vinculante, suficientes miembros del parlamento han manifestado que acatarán el resultado de la votación como para que sea decisivo.
El cambio de nombre requeriría una mayoría de dos tercios en el parlamento.
La comisión electoral estatal informó que hasta la 1 p.m. no se habían registrado denuncias de irregularidades.
Sin embargo, la participación fue de tan solo el 16 por ciento, en comparación con el 34 por ciento de las últimas elecciones parlamentarias de 2016, cuando el 66 por ciento de los votantes registrados emitieron su voto.
"Salí a votar por mis hijos; nuestro lugar está en Europa", dijo Gjose Tanevski, de 62 años, votante en la capital, Skopje.
El primer ministro de Macedonia, Zoran Zaev, su esposa Zorica y su hijo Dushko emitieron su voto en el referéndum celebrado en Macedonia para cambiar el nombre del país, lo que abriría el camino para su adhesión a la OTAN y la Unión Europea, en Strumica, Macedonia, el 30 de septiembre de 2018.
Frente al parlamento en Skopje, Vladimir Kavardarkov, de 54 años, preparaba un pequeño escenario y colocaba sillas delante de las carpas instaladas por quienes boicotearán el referéndum.
"Apoyamos a la OTAN y a la UE, pero queremos unirnos con la frente en alto, no por la puerta de los servicios militares", dijo Kavadarkov.
"Somos un país pobre, pero tenemos dignidad."
Si no quieren aceptarnos como Macedonia, podemos recurrir a otros como China y Rusia y formar parte de la integración euroasiática."
El primer ministro Zaev afirma que la pertenencia a la OTAN traerá inversiones muy necesarias a Macedonia, que tiene una tasa de desempleo superior al 20 por ciento.
"Creo que la gran mayoría estará a favor porque más del 80 por ciento de nuestros ciudadanos están a favor de la UE y la OTAN", dijo Zaev después de emitir su voto.
Dijo que un resultado afirmativo sería "la confirmación de nuestro futuro".
Según una encuesta publicada el lunes pasado por el Instituto de Investigación Política de Macedonia, entre el 30 y el 43 por ciento de los votantes participarían en el referéndum, una cifra inferior a la participación requerida.
Otra encuesta, realizada por la cadena de televisión macedonia Telma TV, reveló que el 57 por ciento de los encuestados planeaba votar el domingo.
De ellos, el 70 por ciento dijo que votaría que sí.
Para que el referéndum tenga éxito, la participación debe ser del 50 por ciento más un voto.
Un fracaso en el referéndum representaría el primer golpe serio a la política del gobierno prooccidental desde que asumió el poder en mayo del año pasado.
Vídeo: Sergio Agüero, del Manchester City, se abre paso entre toda la defensa del Brighton para marcar un gol.
Sergio Agüero y Raheem Sterling desmantelaron la defensa del Brighton en la victoria del Manchester City por 2-0 el sábado en el Etihad Stadium de Manchester, Inglaterra.
Agüero hizo que pareciera ridículamente fácil marcar en el minuto 65.
El delantero argentino recibió un pase en el mediocampo al inicio de la jugada.
Corrió entre tres defensores del Brighton antes de internarse en campo abierto.
Agüero se vio entonces rodeado por cuatro camisetas verdes.
Apartó a un defensor con facilidad antes de dejar atrás a varios más en el borde del área del Brighton.
Luego, lanzó un pase hacia su izquierda, encontrando a Sterling.
El delantero inglés utilizó su primer toque dentro del área para devolverle el balón a Agüero, quien con su bota derecha batió al portero del Brighton, Mathew Ryan, con un disparo al lado derecho de la portería.
"Agüero está teniendo algunos problemas en los pies", dijo a los periodistas el entrenador del City, Pep Guardiola.
"Hablamos de que jugara 55 o 60 minutos."
Eso fue lo que pasó.
Tuvimos suerte de que marcara un gol en ese momento.
Pero fue Sterling quien dio a los Sky Blues la ventaja inicial en la contienda de la Premier League.
Ese gol llegó en el minuto 29.
En esa jugada, Agüero recibió el balón en lo profundo del territorio del Brighton.
Envió un magnífico pase en profundidad por la banda izquierda a Leroy Sané.
Sané controló el balón varias veces antes de cederle el balón a Sterling hacia el segundo palo.
El delantero del Sky Blues empujó el balón a la red justo antes de deslizarse fuera de los límites del campo.
El City se enfrentará al Hoffenheim en la fase de grupos de la Liga de Campeones el martes a las 12:55 en el Rhein-Neckar-Arena de Sinsheim, Alemania.
Scherzer quiere jugar de aguafiestas contra los Rockies.
Con los Nationals eliminados de la contienda por los playoffs, no había muchas razones para forzar otro inicio de temporada.
Pero el siempre competitivo Scherzer espera subir al montículo el domingo contra los Colorado Rockies, pero solo si aún hay posibilidades de que los Rockies lleguen a los playoffs, ya que tienen una ventaja de un juego sobre los Los Angeles Dodgers en la División Oeste de la Liga Nacional.
Los Rockies se aseguraron al menos un puesto de comodín con una victoria de 5-2 sobre los Nationals el viernes por la noche, pero aún buscan asegurar su primer título de división.
"Aunque no nos jugemos nada, al menos podemos subir al montículo sabiendo que el ambiente aquí en Denver, con el público y el otro equipo, estará jugando probablemente al nivel más alto de cualquier otro momento al que me enfrente este año."
¿Por qué no querría competir en eso?
Los Nationals aún no han anunciado al lanzador abridor para el domingo, pero según los informes, están inclinados a dejar que Scherzer lance en tal situación.
Scherzer, que haría su 34ª apertura, realizó una sesión de bullpen el jueves y lanzaría el domingo con su descanso habitual.
El lanzador derecho de Washington tiene un récord de 18-7 con una efectividad de 2.53 y 300 ponches en 220 2/3 entradas esta temporada.
Trump celebra mítines en Virginia Occidental
El presidente se refirió indirectamente a la situación que rodea a su nominado para la Corte Suprema, Brett Kavanaugh, al hablar de la importancia de la participación republicana en las elecciones de mitad de mandato.
"Todo lo que hemos hecho está en juego en noviembre."
Faltan cinco semanas para una de las elecciones más importantes de nuestras vidas.
"Esta es una de las cosas más importantes... No me estoy postulando, pero en realidad estoy compitiendo, por eso estoy por todas partes luchando por los mejores candidatos", dijo.
Trump continuó: "Ustedes ven a este horrible, horrible grupo radical de demócratas, lo ven sucediendo ahora mismo.
Y están decididos a recuperar el poder utilizando cualquier medio necesario; ya ven la mezquindad, la maldad.
No les importa a quién lastiman, a quién tienen que pisotear para obtener poder y control; lo que quieren es poder y control, y no se lo vamos a dar.
Según afirmó, los demócratas tienen la misión de "resistir y obstruir".
"Y eso se ha visto en los últimos cuatro días", dijo, calificando a los demócratas de "enojados, mezquinos, desagradables y mentirosos".
Hizo referencia a la clasificación que el Comité Judicial del Senado hizo de la senadora demócrata Dianne Feinstein, mencionándola por su nombre, lo que provocó fuertes abucheos del público.
"¿Recuerdas su respuesta?"
¿Filtraste el documento?
Eh, eh, ¿qué?
No, eh, no, espera un momento... ese fue un lenguaje corporal realmente malo, el peor lenguaje corporal que he visto en mi vida.
El movimiento obrero ya no es un grupo homogéneo.
Es intolerante con quienes expresan sus opiniones.
Cuando los activistas de Momentum en mi partido local votaron a favor de censurarme, no fue ninguna sorpresa.
Al fin y al cabo, soy el último de una larga lista de diputados laboristas a los que se les ha dicho que no somos bienvenidos, todo por expresar nuestras opiniones.
Mi colega parlamentaria Joan Ryan recibió un trato similar porque se opuso firmemente al antisemitismo.
En mi caso, la moción de censura me criticó por estar en desacuerdo con Jeremy Corbyn.
Sobre la importancia de una política económica responsable, sobre la seguridad nacional, sobre Europa, irónicamente cuestiones similares en las que Jeremy discrepó con líderes anteriores.
En la convocatoria para la reunión del Partido Laborista de Nottingham East del viernes se indicaba que "queremos que las reuniones sean inclusivas y productivas".
Durante la mayor parte de mis ocho años como diputado laborista local, las reuniones del Comité General de los viernes por la noche han sido exactamente eso.
Lamentablemente, hoy en día ese no es el tono que predomina en muchas reuniones, y la promesa de una política "más amable y conciliadora" ha quedado en el olvido, si es que alguna vez llegó a existir.
Cada vez resulta más evidente que en el Partido Laborista no se toleran las opiniones diferentes y que cada opinión se juzga en función de si es aceptable para la dirección del partido.
Esto comenzó poco después de que Jeremy se convirtiera en líder, A medida que mis colegas, con quienes antes creía compartir una visión política similar, empezaron a esperar que diera un giro de 180 grados y adoptara posturas con las que nunca habría estado de acuerdo, ya fuera en materia de seguridad nacional o del mercado único de la UE.
Cada vez que hablo en público, y realmente no importa lo que diga, le sigue una andanada de insultos en las redes sociales que piden mi destitución, denuncian la política de centro y me dicen que no debería estar en el Partido Laborista.
Y esa no es solo mi experiencia.
De hecho, sé que soy más afortunado que algunos de mis colegas, ya que los comentarios dirigidos hacia mí suelen ser políticos.
Me impresiona profundamente la profesionalidad y la determinación de aquellos compañeros que se enfrentan a un torrente de insultos sexistas o racistas a diario, pero que nunca se acobardan.
Uno de los aspectos más decepcionantes de esta era política es cómo se han normalizado los niveles de abuso.
Jeremy Corbyn afirmó la semana pasada que el Partido Laborista debería fomentar una cultura de tolerancia.
La realidad es que ya no somos ese partido tan inclusivo y con cada moción de censura o cambio en las reglas de selección, el partido se va reduciendo.
En los últimos dos años he recibido muchos consejos que me instaban a mantener un perfil bajo, a no ser tan expresiva y que entonces "todo estaría bien".
Pero no entré en política para eso.
Desde que me uní al Partido Laborista hace 32 años cuando era estudiante, Impulsado por la negligencia del gobierno de Thatcher, que dejó mi aula de la escuela pública literalmente en ruinas, he intentado defender mejores servicios públicos para quienes más los necesitan, ya sea como concejal local o como ministro del gobierno.
Nunca he ocultado mis ideas políticas, ni siquiera en las últimas elecciones.
Nadie en Nottingham East podría haber tenido dudas sobre mis posturas políticas y los puntos de desacuerdo con el liderazgo actual.
A quienes promovieron la moción el viernes, Lo único que diría es que, cuando el país avanza a pasos agigantados hacia un Brexit que perjudicará a los hogares, las empresas y nuestros servicios públicos, no entiendo el deseo de malgastar tiempo y energía en mi lealtad al líder del Partido Laborista.
Pero en realidad, mi mensaje no va dirigido a Nottingham Momentum, sino a mis electores, sean o no miembros del Partido Laborista: Me enorgullece servirles y les prometo que ninguna amenaza de destitución ni conveniencia política me disuadirá de actuar en lo que creo que son los mejores intereses de todos ustedes.
Chris Leslie es diputado por Nottingham East.
Ayr 38 - 17 Melrose: El invicto Ayr se coloca líder.
Puede que dos ensayos en los últimos minutos hayan alterado un poco el resultado final, pero no hay duda de que Ayr mereció triunfar en este partido tan entretenido de la Tennent's Premiership.
Ahora lideran la tabla, siendo el único equipo invicto de los diez.
Al final, fue su defensa superior, tanto como su mejor aprovechamiento de las oportunidades, lo que impulsó al equipo local a la victoria, y el entrenador Peter Murchie tenía todo el derecho a estar satisfecho.
"Nos han puesto a prueba en todos los partidos hasta ahora, y seguimos invictos, así que tengo que estar contento", dijo.
Robyn Christie, de Melrose, dijo: "Hay que reconocer el mérito de Ayr, aprovecharon mejor sus oportunidades que nosotros".
El ensayo de Grant Anderson en el minuto 14, convertido por Frazier Climo, puso a Ayr por delante, pero una tarjeta amarilla para el internacional escocés Rory Hughes, cedido para el partido por los Warriors, permitió a Melrose imponerse numéricamente y Jason Baggot anotó un ensayo que no fue convertido.
Climo amplió la ventaja de Ayr con un penal, y justo antes del descanso, anotó y transformó un try individual para dejar el marcador en 17-5 a favor de Ayr al final de la primera parte.
Pero Melrose comenzó bien la segunda mitad y el ensayo de Patrick Anderson, convertido por Baggot, redujo la diferencia a cinco puntos.
A continuación, se produjo una larga interrupción debido a una grave lesión de Ruaridh Knott, que tuvo que ser retirado en camilla, y tras la reanudación, Ayr amplió su ventaja gracias a un ensayo de Stafford McDowall, transformado por Climo.
El capitán interino de Ayr, Blair Macpherson, recibió entonces una tarjeta amarilla, y una vez más, Melrose aprovechó la superioridad numérica con un ensayo de Bruce Colvine que no fue transformado, al final de un periodo de intensa presión.
Sin embargo, el equipo local reaccionó y, cuando Struan Hutchinson recibió una tarjeta amarilla por placar a Climo sin el balón, en el saque de banda de penalización, MacPherson anotó un ensayo en la parte trasera del maul de Ayr que avanzaba.
Climo convirtió el ensayo, como lo hizo de nuevo casi inmediatamente después del reinicio, después de que Kyle Rowe recogiera la patada alta de David Armstrong y habilitara al flanker Gregor Henry para que anotara el quinto ensayo del equipo local.
La estrella de Still Game parece encaminarse hacia una nueva carrera en la industria de la restauración.
Ford Kieran, estrella de la serie Still Game, parece dispuesto a adentrarse en el sector de la hostelería tras descubrirse que ha sido nombrado director de una empresa de restaurantes con licencia.
El actor de 56 años interpreta a Jack Jarvis en la popular serie de la BBC, que él mismo escribe y coprotagoniza junto a su compañero cómico de toda la vida, Greg Hemphill.
El dúo ha anunciado que la próxima novena temporada será la última de la serie, y parece que Kiernan está haciendo planes para la vida después de Craiglang.
Según los registros oficiales, es el director de Adriftmorn Limited.
El actor declinó hacer comentarios sobre la noticia, aunque una fuente del Scottish Sun insinuó que Kiernan estaba buscando involucrarse en el "próspero sector de la restauración" de Glasgow.
'El mar es nuestro': Bolivia, país sin salida al mar, espera que un tribunal reabra el camino hacia el Pacífico.
Marineros patrullan un cuartel general naval revestido de aparejos en La Paz.
Los edificios públicos ondean una bandera azul océano.
Las bases navales desde el lago Titicaca hasta el Amazonas están adornadas con el lema: "El mar es nuestro por derecho".
Recuperarlo es un deber."
En toda Bolivia, país sin salida al mar, el recuerdo de una costa perdida a manos de Chile en un sangriento conflicto por los recursos del siglo XIX sigue muy vivo, al igual que el anhelo de navegar de nuevo por el Océano Pacífico.
Esas esperanzas se encuentran quizás en su punto más alto en décadas, mientras Bolivia espera el fallo de la Corte Internacional de Justicia el 1 de octubre, tras cinco años de deliberaciones.
"Bolivia tiene el impulso, un espíritu de unidad y serenidad, y por supuesto espera el resultado con optimismo", dijo Roberto Calzadilla, diplomático boliviano.
Muchos bolivianos seguirán el fallo de la CIJ en pantallas gigantes por todo el país, con la esperanza de que el tribunal de La Haya falle a favor de la demanda de Bolivia de que, después de décadas de conversaciones intermitentes, Chile está obligado a negociar la concesión a Bolivia de una salida soberana al mar.
Evo Morales, el carismático presidente indígena de Bolivia, que se enfrenta a una polémica batalla por la reelección el próximo año, también tiene mucho en juego con el fallo del lunes.
"Estamos muy cerca de regresar al Océano Pacífico", prometió a finales de agosto.
Pero algunos analistas creen que es poco probable que el tribunal falle a favor de Bolivia, y que poco cambiaría si lo hiciera.
El organismo de la ONU con sede en los Países Bajos no tiene potestad para adjudicar territorio chileno y ha estipulado que no determinará el resultado de posibles conversaciones.
El hecho de que el fallo de la CIJ se produzca tan solo seis meses después de que se escucharan los alegatos finales indica que el caso "no fue complicado", afirmó Paz Zárate, experta chilena en derecho internacional.
Lejos de impulsar la causa de Bolivia, los últimos cuatro años podrían haberla hecho retroceder.
"El tema del acceso al mar ha sido secuestrado por la actual administración boliviana", dijo Zárate.
La retórica beligerante de Morales ha agotado cualquier atisbo de buena voluntad que pudiera quedar en Chile, sugirió.
Bolivia y Chile retomarán el diálogo en algún momento, pero será extremadamente difícil mantener conversaciones después de esto.
Los dos países no han intercambiado embajadores desde 1962.
El expresidente Eduardo Rodríguez Veltzé, representante de Bolivia ante La Haya, rechazó la idea de que la toma de decisiones del tribunal fuera inusualmente rápida.
El lunes, Bolivia tendrá "una oportunidad extraordinaria para abrir una nueva era de relaciones con Chile" y la posibilidad de "poner fin a 139 años de desacuerdos en beneficio mutuo", afirmó.
Calzadilla también negó que Morales, que sigue siendo uno de los presidentes más populares de América Latina, estuviera utilizando la cuestión marítima como una muleta política.
"Bolivia jamás renunciará a su derecho a tener acceso al Océano Pacífico", añadió.
"El fallo es una oportunidad para darnos cuenta de que necesitamos superar el pasado."
Corea del Norte afirma que el desarme nuclear no se producirá a menos que pueda confiar en Estados Unidos.
El ministro de Asuntos Exteriores de Corea del Norte, Ri Yong Ho, afirma que su país nunca desarmará primero sus armas nucleares si no puede confiar en Washington.
Ri intervino el sábado en la Asamblea General de las Naciones Unidas.
Hizo un llamamiento a Estados Unidos para que cumpliera las promesas hechas durante la cumbre celebrada en Singapur entre los líderes de ambos países.
Sus comentarios llegan en Estados Unidos. El secretario de Estado, Mike Pompeo, parece estar a punto de reactivar la estancada diplomacia nuclear, más de tres meses después de la reunión de Singapur con Kim Jong Un de Corea del Norte.
Ri afirma que es una "ilusión" pensar que las continuas sanciones y la objeción de Estados Unidos a una declaración que ponga fin a la guerra de Corea lograrán alguna vez doblegar a Corea del Norte.
Washington se muestra reticente a aceptar la declaración sin que Pyongyang dé primero pasos significativos en materia de desarme.
Tanto Kim como el presidente estadounidense Donald Trump desean una segunda cumbre.
Sin embargo, existe un escepticismo generalizado sobre la intención de Pyongyang de renunciar seriamente a un arsenal que probablemente considera la única forma de garantizar su seguridad.
Pompeo tiene previsto visitar Pyongyang el próximo mes para preparar una segunda cumbre entre Kim y Trump.
Los desfiles de moda de París revelan la última línea de sombreros gigantes que pronto llegará a las tiendas de tu zona.
Si quieres ampliar tu colección de sombreros o protegerte completamente del sol, no busques más.
Los diseñadores Valentino y Thom Browne presentaron en la pasarela una serie de extravagantes tocados de gran tamaño para su colección Primavera/Verano 2019, que deslumbraron a los amantes de la moda en la Semana de la Moda de París.
Los sombreros sumamente poco prácticos han arrasado en Instagram este verano, y estos diseñadores han presentado sus llamativas creaciones en la pasarela.
La pieza estrella de Valentino fue un extravagante sombrero beige adornado con un ala ancha que parecía una pluma y que cubría por completo las cabezas de las modelos.
Entre los demás accesorios de gran tamaño se encontraban sandías adornadas con joyas, un sombrero de mago e incluso una piña, pero no están diseñados para mantener la cabeza caliente.
Thom Browne también reveló una selección de máscaras extravagantes, justo a tiempo para Halloween.
Muchas de las coloridas máscaras tenían los labios cosidos y se parecían más a Hannibal Lecter que a la alta costura.
Una de las creaciones se parecía a un equipo de buceo completo con tubo y gafas, mientras que otra parecía un cono de helado derretido.
Y si continúas con esa declaración de estilo tan llamativa, estás de suerte.
Los expertos en moda predicen que los enormes capós podrían llegar pronto a las calles principales de tu zona.
Estos sombreros de gran tamaño llegan justo después de "La Bomba", el sombrero de paja con un ala de sesenta centímetros de ancho que se ha visto en todo el mundo, desde Rihanna hasta Emily Ratajkowski.
La marca de culto responsable del sombrero tan poco práctico que causó furor en las redes sociales presentó otra gran creación en la pasarela: un bolso de playa de paja casi tan grande como la modelo en traje de baño que lo portaba.
El bolso de rafia color naranja quemado, adornado con flecos de rafia y rematado con un asa de cuero blanco, fue la pieza estrella de la colección La Riviera SS19 de Jacquemus en la Semana de la Moda de París.
El estilista de famosos Luke Armitage declaró a FEMAIL: "Espero ver sombreros grandes y bolsos de playa en las tiendas el próximo verano; dado el gran impacto que ha tenido el diseñador, sería difícil ignorar la demanda de estos accesorios de gran tamaño".
John Edward: Las habilidades lingüísticas son esenciales para los ciudadanos globales.
Los colegios independientes de Escocia mantienen un historial de excelencia académica, Y esto ha continuado en 2018 con otro conjunto de resultados sobresalientes en los exámenes, lo cual se ve reforzado por el éxito individual y colectivo en los deportes, el arte, la música y otras actividades comunitarias.
Con más de 30.000 alumnos en toda Escocia, estas escuelas, representadas por el Consejo Escocés de Escuelas Independientes (SCIS), se esfuerzan por ofrecer el mejor nivel de servicio a sus alumnos y padres.
Los colegios privados tienen como objetivo preparar a sus alumnos para la educación superior, la carrera profesional que elijan y su papel como ciudadanos globales.
Como sector educativo capaz de diseñar e implementar un currículo escolar a medida, observamos que las lenguas modernas siguen siendo una asignatura popular y muy solicitada en los centros educativos.
Nelson Mandela dijo: "Si le hablas a un hombre en un idioma que entiende, eso se le sube a la cabeza."
Si le hablas en su propio idioma, eso le llega al corazón.
Esto nos recuerda con fuerza que no podemos depender únicamente del inglés cuando queremos entablar relaciones y generar confianza con personas de otros países.
Según los resultados de los exámenes de este año, podemos observar que los idiomas encabezan las clasificaciones con los índices de aprobados más altos en los colegios privados.
Un total del 68 por ciento de los alumnos que estudiaron lenguas extranjeras obtuvieron una calificación A en el nivel superior.
Los datos, recopilados de las 74 escuelas miembros de SCIS, mostraron que el 72 por ciento de los estudiantes obtuvieron una calificación A superior en mandarín, mientras que el 72 por ciento de los que estudiaban alemán, el 69 por ciento de los que estudiaban francés y el 63 por ciento de los que estudiaban español también obtuvieron una A.
Esto demuestra que los colegios privados de Escocia están apoyando el aprendizaje de idiomas extranjeros como una habilidad vital que los niños y jóvenes sin duda necesitarán en el futuro.
Actualmente, los idiomas, como opción de asignatura, gozan del mismo prestigio que las asignaturas STEM (ciencia, tecnología, ingeniería y matemáticas) en los planes de estudio de los colegios privados y en otros ámbitos.
Una encuesta realizada en 2014 por la Comisión del Reino Unido para el Empleo y las Habilidades reveló que, de las razones que esgrimieron los empleadores para explicar sus dificultades a la hora de cubrir las vacantes, el 17 por ciento se atribuyó a la escasez de conocimientos lingüísticos.
Por lo tanto, cada vez más, las habilidades lingüísticas se están volviendo imprescindibles para preparar a los jóvenes para sus futuras carreras profesionales.
Dado que cada vez hay más oportunidades laborales que requieren idiomas, estas habilidades son esenciales en un mundo globalizado.
Independientemente de la carrera que elija una persona, si ha aprendido un segundo idioma, tendrá una gran ventaja en el futuro al poseer una habilidad como esta que le servirá para toda la vida.
La capacidad de comunicarse directamente con personas de otros países automáticamente coloca a una persona multilingüe por delante de la competencia.
Según una encuesta de YouGov realizada en 2013 a más de 4.000 adultos del Reino Unido, el 75 por ciento no era capaz de hablar un idioma extranjero con la suficiente fluidez como para mantener una conversación, siendo el francés el único idioma hablado por un porcentaje de dos dígitos, el 15 por ciento.
Por eso, invertir ahora en la enseñanza de idiomas es importante para los niños de hoy.
Dominar varios idiomas, especialmente los de las economías en desarrollo, brindará a los niños mayores posibilidades de encontrar un empleo digno.
En Escocia, cada escuela imparte clases de idiomas diferentes.
Varias escuelas se centrarán en los idiomas modernos más clásicos, mientras que otras enseñarán idiomas que se consideran más importantes para el Reino Unido de cara a 2020, como el mandarín o el japonés.
Sean cuales sean los intereses de su hijo, siempre habrá varios idiomas para elegir en los colegios privados, con profesorado especializado en esa materia.
Los colegios independientes escoceses se dedican a proporcionar un entorno de aprendizaje que prepare a los niños y les proporcione las habilidades necesarias para tener éxito, sea cual sea el futuro.
En el contexto empresarial global actual, es innegable que los idiomas siguen siendo de vital importancia para el futuro del país, por lo que esto debe reflejarse en la educación.
De hecho, las lenguas modernas deberían considerarse "habilidades de comunicación internacional".
Los colegios privados seguirán ofreciendo esta libertad de elección, diversidad y excelencia para los jóvenes de Escocia.
Hay que hacerlo correctamente.
John Edward es el director del Consejo Escocés de Escuelas Independientes.
LeBron hará su debut con los Lakers el domingo en San Diego.
La espera está a punto de terminar para los aficionados que desean ver a LeBron James debutar como titular con Los Angeles Lakers.
El entrenador de los Lakers, Luke Walton, ha anunciado que James jugará el domingo en el primer partido de pretemporada contra los Denver Nuggets en San Diego.
Pero aún no se ha determinado cuántos minutos jugará.
"Serán más de uno y menos de 48", dijo Walton en el sitio web oficial de los Lakers.
El reportero de los Lakers, Mike Trudell, tuiteó que James probablemente jugará pocos minutos.
Tras el entrenamiento de principios de esta semana, le preguntaron a James sobre sus planes para el calendario de seis partidos de pretemporada de los Lakers.
"No necesito partidos de pretemporada en esta etapa de mi carrera para prepararme", dijo.
Hora del mitin de Trump en Virginia Occidental, canal de YouTube
El presidente Donald Trump inicia esta noche una serie de mítines de campaña en Wheeling, Virginia Occidental.
Este es el primero de los cinco mítines que Trump tiene programados para la próxima semana, incluyendo paradas en lugares afines como Tennessee y Mississippi.
Con la votación de confirmación en suspenso para su candidato a cubrir la vacante en la Corte Suprema, Trump busca obtener apoyo para las próximas elecciones de mitad de período, ya que los republicanos corren el riesgo de perder el control del Congreso cuando se emitan los votos en noviembre.
¿A qué hora es el mitin de Trump en Virginia Occidental esta noche y cómo se puede ver en línea?
El mitin de Trump en Wheeling, Virginia Occidental, está programado para las 7 p.m. Esta noche, sábado 29 de septiembre de 2018, hora del este.
Puedes ver el mitin de Trump en Virginia Occidental en línea a través de la transmisión en vivo de YouTube que encontrarás a continuación.
Es probable que Trump se refiera a las audiencias de esta semana para el nominado a la Corte Suprema, Brett Kavanaugh, que se tornaron tensas debido a las acusaciones de conducta sexual inapropiada, y cuya esperada votación de confirmación en el Senado quedó en suspenso hasta por una semana mientras el FBI investiga.
Pero el objetivo principal de esta serie de mítines es ayudar a los republicanos que se enfrentan a unas reñidas elecciones en noviembre a ganar impulso.
Así, la campaña del presidente Trump afirmó que estos cinco mítines de la próxima semana tienen como objetivo "motivar a los voluntarios y simpatizantes mientras los republicanos intentan proteger y ampliar las mayorías que ostentan en el Senado y la Cámara de Representantes", según Reuters.
"El control del Congreso es tan crucial para su agenda que el presidente viajará a tantos estados como sea posible a medida que nos adentramos en la ajetreada temporada de campaña", dijo a Reuters un portavoz de la campaña de Trump que prefirió permanecer en el anonimato.
Según el West Virginia Metro News, la concentración de esta noche, programada para el Wesbanco Arena en Wheeling, podría atraer a simpatizantes de "Ohio y Pensilvania y obtener cobertura de los medios de comunicación de Pittsburgh".
El sábado será la segunda vez en el último mes que Trump visita Virginia Occidental, el estado que ganó por más de 40 puntos porcentuales en 2016.
Trump está tratando de ayudar al candidato republicano al Senado por Virginia Occidental, Patrick Morrisey, quien va por detrás en las encuestas.
"No es una buena señal para Morrisey que el presidente tenga que venir a intentar darle un impulso en las encuestas", dijo Simon Haeder, politólogo de la Universidad de Virginia Occidental, según Reuters.
Ryder Cup 2018: El equipo de EE. UU. demuestra su garra para luchar y mantener vivas sus esperanzas de cara a los partidos individuales del domingo.
Tras tres sesiones con resultados muy desiguales, los partidos de parejas del sábado por la tarde podrían haber sido justo lo que necesitaba esta Ryder Cup.
El péndulo oscilante del impulso es un concepto deportivo completamente inventado, pero en el que los jugadores creen firmemente, y nunca tanto como en competiciones como estas.
Entonces, ¿dónde dirían que está el impulso ahora?
"Tenían una ventaja de seis puntos y ahora es de cuatro, así que supongo que eso nos da un poco de impulso", dijo Jordan Spieth mientras se retiraba al final del día.
Europa tiene la ventaja, por supuesto, con cuatro puntos de ventaja y doce más en juego.
Como dice Spieth, los estadounidenses sienten que tienen un poco de viento a su favor y tienen muchos motivos para estar animados, sobre todo por el buen momento de forma de Spieth y Justin Thomas, que jugaron juntos todo el día y cada uno suma tres puntos de cuatro posibles.
Spieth ha sido letal desde el tee hasta el green y está dando ejemplo.
Esos gritos guturales de celebración se hicieron más fuertes a medida que avanzaba su ronda, embocando un putt crucial para empatar el cuarto partido cuando él y Thomas iban dos abajo después de dos hoyos.
Su putt que les dio la victoria en el hoyo 15 fue recibido con un grito similar, del tipo que te dice que cree que el equipo estadounidense no está fuera de la contienda.
"Realmente tienes que esforzarte al máximo y preocuparte por tu propio partido", dijo Spieth.
Es todo lo que les queda a cada uno de estos jugadores.
18 hoyos para dejar huella.
Los únicos jugadores con más puntos que Spieth y Thomas en los últimos dos días son Francesco Molinari y Tommy Fleetwood, la indiscutible historia de la Ryder Cup.
Esta peculiar pero adorable pareja europea lleva cuatro victorias en cuatro intentos y no puede equivocarse.
La pareja "Moliwood" fue la única que no logró hacer bogey el sábado por la tarde, pero también evitó los bogeys el sábado por la mañana, el viernes por la tarde y en los últimos nueve hoyos del viernes por la mañana.
Esa carrera, y la forma en que su energía parece fluir tanto hacia como desde esta bulliciosa multitud confirma que son los jugadores a vencer el domingo, Y no habría jugador más popular para sellar una posible victoria europea al atardecer en Le Golf National que Fleetwood o Molinari.
Preferiblemente ambos simultáneamente en agujeros diferentes.
Sin embargo, hablar de gloria europea aún es prematuro.
Bubba Watson y Webb Simpson derrotaron rápidamente a Sergio García, el héroe de la jornada en la modalidad de parejas, cuando este formó pareja con Alex Noren.
Un bogey y dos doble bogeys en los primeros nueve hoyos metieron al español y al sueco en un aprieto del que nunca estuvieron cerca de salir.
Sin embargo, el domingo no habrá nadie que te ayude a salir del apuro.
Los partidos de fourball y foursome son fascinantes de observar de cerca debido a las interacciones entre las parejas, los consejos que se dan, los que no se dan y la forma en que una estrategia puede cambiar en un instante.
Europa ha jugado mejor como equipo hasta ahora y llega al último día con una ventaja significativa, pero esta sesión de foursomes también demostró que el equipo de EE. UU. tiene la garra para la lucha que algunos, especialmente en Estados Unidos, habían puesto en duda.
Europa llega a la jornada final de la Ryder Cup con una ventaja de 10-6.
Europa llega a la última jornada de la Ryder Cup con una clara ventaja tras imponerse a Estados Unidos por 10-6 en los partidos de fourballs y foursomes del sábado.
La inspirada dupla formada por Tommy Fleetwood y Francesco Molinari lideró la ofensiva con dos victorias sobre un Tiger Woods en apuros, elevando su cuenta en Le Golf National a cuatro puntos hasta el momento.
El equipo europeo de Thomas Bjorn, que aspiraba a retener el trofeo que perdió en Hazeltine hace dos años, dominó a un equipo estadounidense que no estuvo a la altura en los partidos de dobles matutinos, llevándose la serie por 3-1.
Estados Unidos ofreció mayor resistencia en los partidos de dobles, ganando dos encuentros, pero no pudo reducir la desventaja.
El equipo de Jim Furyk necesita ocho puntos en los 12 partidos individuales del domingo para retener el trofeo.
Fleetwood es el primer novato europeo en ganar cuatro puntos consecutivos, mientras que él y Molinari, apodados "Molliwood" tras un fin de semana sensacional, son solo la segunda pareja en ganar cuatro puntos en sus primeros cuatro partidos en la historia de la Ryder Cup.
Tras haber aplastado a Woods y Patrick Reed en los partidos de parejas, se compenetraron a la perfección para vencer a un desmoralizado Woods y al novato estadounidense Bryson DeChambeau por un contundente 5&4.
Woods, que se las arregló para superar dos partidos el sábado, mostró destellos de brillantez ocasionales, pero ahora ha perdido 19 de sus 29 partidos en fourballs y foursomes, y siete de forma consecutiva.
Justin Rose, que descansó en los partidos de fourball de la mañana, volvió a formar pareja con Henrik Stenson en los foursomes para derrotar por 2&1 a Dustin Johnson y Brooks Koepka, clasificados primero y tercero del mundo.
Sin embargo, Europa no lo tuvo todo a su favor en un día agradable y ventoso al suroeste de París.
Jordan Spieth, tres veces ganador de torneos importantes, y Justin Thomas marcaron la pauta para los estadounidenses con dos puntos el sábado.
Consiguieron una reñida victoria por 2&1 sobre los españoles Jon Rahm e Ian Poulter en la modalidad fourballs y, posteriormente, tras perder los dos primeros hoyos, lograron vencer a Poulter y Rory McIlroy por 4&3 en la modalidad foursomes.
Solo en dos ocasiones en la historia de la Ryder Cup un equipo ha remontado una desventaja de cuatro puntos antes de los partidos individuales, aunque, como vigentes campeones, el equipo de Furyk solo necesita un empate para retener el trofeo.
Sin embargo, tras haber sido segundos durante dos días, un contraataque el domingo parece estar fuera de su alcance.
Corea del Norte afirma que "de ninguna manera" se desarmará unilateralmente sin confianza.
El ministro de Asuntos Exteriores de Corea del Norte declaró el sábado ante las Naciones Unidas que las continuas sanciones estaban profundizando su desconfianza hacia Estados Unidos y que, en tales circunstancias, el país no renunciaría unilateralmente a sus armas nucleares.
Ri Yong Ho declaró ante la Asamblea General anual del organismo mundial que Corea del Norte había tomado "medidas significativas de buena voluntad" durante el último año. tales como detener las pruebas nucleares y de misiles, desmantelar el sitio de pruebas nucleares y comprometerse a no proliferar las armas nucleares ni la tecnología nuclear.
"Sin embargo, no vemos ninguna respuesta correspondiente por parte de Estados Unidos", dijo.
"Sin ninguna confianza en Estados Unidos, no habrá confianza en nuestra seguridad nacional y, en tales circunstancias, no hay manera de que nos desarmemos unilateralmente primero."
Mientras Ri repetía las quejas habituales de Corea del Norte sobre la resistencia de Washington a un enfoque "por fases" para la desnuclearización, según el cual Corea del Norte sería recompensada a medida que diera pasos graduales, Su declaración resultó significativa porque no rechazó de plano la desnuclearización unilateral, como Pyongyang lo ha hecho en el pasado.
Ri se refirió a una declaración conjunta emitida por Kim Jong Un y Donald Trump en la primera cumbre entre un presidente estadounidense en ejercicio y un líder norcoreano, celebrada en Singapur el 12 de junio. mientras que Kim se comprometió a trabajar por la "desnuclearización de la península coreana" y Trump prometió garantías para la seguridad de Corea del Norte.
Corea del Norte ha estado buscando una solución formal a la Guerra de Corea de 1950-53, pero Estados Unidos ha dicho que Pyongyang primero debe renunciar a sus armas nucleares.
Washington también se ha resistido a las peticiones de suavizar las duras sanciones internacionales contra Corea del Norte.
"Estados Unidos insiste en la 'desnuclearización primero' y aumenta el nivel de presión mediante sanciones para lograr su propósito de manera coercitiva, llegando incluso a oponerse a la 'declaración del fin de la guerra'", dijo Ri.
"La idea de que las sanciones pueden doblegarnos es una quimera de quienes nos desconocen."
Pero el problema es que las continuas sanciones están profundizando nuestra desconfianza."
Ri no hizo mención alguna de los planes para una segunda cumbre entre Kim y Trump que el líder estadounidense destacó en las Naciones Unidas a principios de semana.
En cambio, el ministro destacó tres reuniones entre Kim y el líder surcoreano Moon Jae-in en los últimos cinco meses y añadió: "Si la parte involucrada en este tema de la desnuclearización fuera Corea del Sur y no Estados Unidos, la desnuclearización de la península coreana no habría llegado a tal punto muerto."
Aun así, el tono del discurso de Ri fue radicalmente diferente al del año pasado, cuando declaró ante la Asamblea General de la ONU que atacar el territorio continental estadounidense con los cohetes de Corea del Norte era inevitable después de que el "Señor Presidente Malvado" Trump llamara a Kim "hombre cohete" en una misión suicida.
Este año, en las Naciones Unidas, Trump, quien el año pasado amenazó con "destruir por completo" a Corea del Norte, elogió efusivamente a Kim por su valentía al tomar medidas para el desarme, pero dijo que aún quedaba mucho trabajo por hacer y que las sanciones debían mantenerse hasta que Corea del Norte se desnuclearizara.
El miércoles, Trump dijo que no tenía un plazo fijo para esto, y agregó: "Si toma dos años, tres años o cinco meses, no importa".
China y Rusia argumentan que el Consejo de Seguridad de la ONU debería recompensar a Pyongyang por las medidas adoptadas.
Sin embargo, el secretario de Estado estadounidense, Mike Pompeo, declaró el jueves ante el Consejo de Seguridad de la ONU: "La aplicación de las sanciones del Consejo de Seguridad debe continuar con rigor y sin falta hasta que logremos la desnuclearización completa, definitiva y verificada".
Desde 2006, el Consejo de Seguridad ha reforzado por unanimidad las sanciones contra Corea del Norte en un intento por cortar la financiación de los programas nucleares y de misiles balísticos de Pyongyang.
Pompeo se reunió con Ri en el marco de la Asamblea General de la ONU y, posteriormente, declaró que volvería a visitar Pyongyang el mes que viene para preparar una segunda cumbre.
Pompeo ya ha visitado Corea del Norte tres veces este año, pero su último viaje no salió bien.
Abandonó Pyongyang en julio afirmando que se habían logrado avances, pero pocas horas después Corea del Norte lo denunció por hacer "exigencias propias de gánsteres".
Corea del Norte se comprometió en una reunión con Moon este mes a desmantelar una base de misiles y también un complejo nuclear si Estados Unidos tomaba "medidas correspondientes".
Según declaró, Kim le había dicho que las "medidas correspondientes" que solicitaba eran las garantías de seguridad que Trump prometió en Singapur y los pasos hacia la normalización de las relaciones con Washington.
Los estudiantes de Harvard toman un curso sobre cómo descansar lo suficiente.
Un nuevo curso impartido este año en la Universidad de Harvard ha conseguido que todos sus estudiantes de pregrado duerman más, en un intento por combatir la creciente cultura machista de estudiar a base de "noches en vela" impulsadas por la cafeína.
Un académico descubrió que los estudiantes de la universidad número uno del mundo a menudo no tienen ni idea de las cosas más básicas sobre cómo cuidarse a sí mismos.
Charles Czeisler, profesor de medicina del sueño en la Facultad de Medicina de Harvard y especialista del Hospital Brigham and Women's, diseñó el curso, que según él es el primero de su tipo en los Estados Unidos.
Se inspiró para comenzar el curso después de dar una charla sobre el impacto que la privación del sueño tiene en el aprendizaje.
'Al final, una chica se me acercó y me dijo: "¿Por qué me están contando esto ahora, en mi último año de instituto?"
"Me dijo que nadie le había hablado nunca de la importancia del sueño, lo cual me sorprendió", declaró a The Telegraph.
El curso, que se imparte por primera vez este año, explica a los estudiantes los aspectos esenciales de cómo los buenos hábitos de sueño contribuyen al rendimiento académico y deportivo, además de mejorar su bienestar general.
Paul Barreira, profesor de psiquiatría en la Facultad de Medicina de Harvard y director ejecutivo de los servicios de salud de la universidad, dijo que la universidad decidió introducir el curso después de descubrir que los estudiantes sufrían una grave falta de sueño durante la semana.
El curso, de una hora de duración, incluye una serie de tareas interactivas.
En una sección hay una imagen de una habitación de residencia estudiantil, donde los alumnos hacen clic en tazas de café, cortinas, zapatillas deportivas y libros para obtener información sobre los efectos de la cafeína y la luz, cómo la falta de sueño afecta al rendimiento deportivo y la importancia de una rutina antes de acostarse.
En otra sección, se explica a los participantes cómo la privación de sueño a largo plazo puede aumentar el riesgo de sufrir ataques cardíacos, accidentes cerebrovasculares, depresión y cáncer.
A continuación, un mapa del campus, con iconos interactivos, anima a los participantes a reflexionar sobre su rutina diaria.
Sabemos que no cambiará el comportamiento de los estudiantes de forma instantánea.
Pero creemos que tienen derecho a saberlo, al igual que usted tiene derecho a conocer los efectos en la salud de elegir fumar cigarrillos', añadió el profesor Czeisler.
Según afirmó, la cultura del orgullo por "pasar la noche en vela" aún existe, y añadió que la tecnología moderna y la creciente presión sobre los estudiantes hacen que la privación del sueño sea un problema cada vez mayor.
Según él, garantizar un sueño suficiente y de buena calidad debería ser el "arma secreta" de un estudiante para combatir el estrés, el agotamiento y la ansiedad, incluso para evitar subir de peso, ya que la falta de sueño pone al cerebro en modo de inanición, lo que provoca una sensación constante de hambre.
Raymond So, un californiano de 19 años que estudia biología química y física, ayudó al profesor Czeisler a diseñar el curso, tras haber cursado una de sus clases el año pasado durante su primer año en Harvard.
Dijo que el curso le había abierto los ojos y le había inspirado para impulsar un curso similar en todo el campus.
El siguiente paso, según espera, es pedir a todos los estudiantes de posgrado que completen un programa de estudios similar antes de incorporarse a la prestigiosa institución.
El profesor Czeisler recomendó que los estudiantes consideraran poner una alarma para saber cuándo irse a la cama. Además, es importante saber cuándo despertarse y ser consciente de los efectos nocivos de la "luz azul" emitida por las pantallas electrónicas y la iluminación LED, que puede desajustar el ritmo circadiano y provocar problemas para conciliar el sueño.
Livingston 1 - 0 Rangers: El gol de Menga derrota al equipo de Gerrard.
Los Rangers sufrieron otro revés como visitantes, ya que el gol de Dolly Menga condenó al desorganizado equipo de Steven Gerrard a una derrota por 1-0 ante el Livingston.
El equipo de Ibrox buscaba registrar su primera victoria como visitante desde el triunfo por 4-1 en St Johnstone en febrero. Pero el equipo de Gary Holt le infligió a Gerrard su segunda derrota en 18 partidos como entrenador, dejando a su equipo a ocho puntos del líder indiscutible de la Ladbrokes Premiership, el Hearts.
Menga marcó siete minutos antes del descanso y un equipo del Rangers falto de inspiración nunca pareció capaz de empatar.
Mientras que el Rangers cae ahora al sexto puesto, el Livingston asciende al tercero y solo está por detrás del Hibernian por diferencia de goles.
Y los Rangers podrían enfrentarse a más problemas después de que el juez de línea Calum Spence tuviera que ser atendido por una herida en la cabeza tras ser aparentemente lanzado un objeto desde la grada visitante.
Gerrard realizó ocho cambios en el equipo que superó con facilidad al Ayr y se clasificó para las semifinales de la Copa Betfred.
Holt, por otro lado, optó por el mismo once inicial del Livi que le arrebató un punto al Hearts la semana pasada, y seguramente quedó encantado con la forma en que su equipo, bien entrenado, asfixió a sus rivales en todo momento.
Puede que los Rangers dominaran la posesión del balón, pero el Livingston hizo más con él.
Deberían haber marcado a los dos minutos, cuando un pase de Menga al primer toque dejó a Scott Pittman solo frente a la portería de Allan McGregor, pero el centrocampista falló su gran oportunidad.
Un potente tiro libre de Keaghan Jacobs encontró al capitán Craig Halkett, pero su compañero en la defensa, Alan Lithgow, solo pudo rematar desviado en el segundo palo.
Los Rangers lograron tomar el control, pero en el último tercio del campo parecía haber más esperanza que convicción en su juego.
Alfredo Morelos sin duda creía que debería haber recibido un penalti a los quince minutos de juego, cuando él y Steven Lawless chocaron, pero el árbitro Steven Thomson desestimó las protestas del colombiano.
Los Rangers solo lograron dos disparos a puerta en la primera mitad, pero el ex portero del Ibrox, Liam Kelly, apenas tuvo que intervenir ante el cabezazo de Lassana Coulibaly y un flojo disparo de Ovie Ejaria.
Si bien el gol del Livi en el minuto 34 pudo haber sido inesperado, nadie puede negar que se lo merecían por su gran esfuerzo.
Una vez más, los Rangers no lograron neutralizar una jugada a balón parado de Jacobs desde la distancia.
Scott Arfield no reaccionó cuando Declan Gallagher le pasó el balón a Scott Robinson, quien mantuvo la calma para habilitar a Menga, que solo tuvo que empujarlo a la red.
Gerrard actuó en el descanso, sustituyendo a Coulibaly por Ryan Kent, y el cambio casi tuvo un impacto inmediato, ya que el extremo habilitó a Morelos, pero el impresionante Kelly salió corriendo de su portería para bloquear el disparo.
Pero el Livingston siguió atrayendo a los visitantes a jugar exactamente el tipo de partido que les gusta, con Lithgow y Halkett interceptando un balón largo tras otro.
El equipo de Holt pudo haber ampliado su ventaja en los minutos finales, pero McGregor se mantuvo firme para evitar el gol de Jacobs antes de que Lithgow rematara de cabeza fuera tras un saque de esquina.
El suplente de los Rangers, Glenn Middleton, reclamó otro penalti en los últimos minutos tras un forcejeo con Jacobs, pero una vez más Thomson desvió la mirada.
Almanaque: El inventor del contador Geiger
Y ahora una página de nuestro almanaque "Domingo por la mañana": 30 de septiembre de 1882, hace 136 años, y CONTANDO... el día en que nació en Alemania el futuro físico Johannes Wilhelm "Hans" Geiger.
Geiger desarrolló un método para detectar y medir la radiactividad, un invento que finalmente dio lugar al dispositivo conocido como contador Geiger.
El contador Geiger, un elemento fundamental de la ciencia desde sus inicios, también se convirtió en un elemento básico de la cultura popular, como en la película de 1950 "Las campanas de Coronado", protagonizada por los aparentemente improbables científicos vaqueros Roy Rogers y Dale Evans:
Hombre: "¿Qué demonios es eso?"
Rogers: "Es un contador Geiger, que se utiliza para localizar minerales radiactivos, como el uranio."
Al ponerse estos auriculares, se pueden oír los efectos de los átomos emitidos por la radiactividad de los minerales.
Evans: "¡Vaya, sí que está de moda ahora!"
"Hans" Geiger falleció en 1945, pocos días antes de cumplir 63 años.
Pero el invento que lleva su nombre perdura.
Una nueva vacuna contra el cáncer puede enseñar al sistema inmunitario a "ver" las células anómalas.
Una nueva vacuna contra el cáncer puede enseñar al sistema inmunitario a "ver" las células dañinas y eliminarlas.
La vacuna enseña al sistema inmunitario a reconocer las células anómalas como parte del tratamiento.
El método consiste en extraer células inmunitarias de un paciente y modificarlas en el laboratorio.
Luego pueden "ver" una proteína común a muchos tipos de cáncer y luego volver a inyectarla.
Una vacuna experimental está mostrando resultados prometedores en pacientes con diversos tipos de cáncer.
Una mujer tratada con la vacuna, que enseña al sistema inmunitario a reconocer las células anómalas, vio desaparecer su cáncer de ovario durante más de 18 meses.
El método consiste en extraer células inmunitarias de un paciente, modificarlas en el laboratorio para que puedan "ver" una proteína común a muchos tipos de cáncer llamada HER2, y luego volver a inyectar las células.
El profesor Jay Berzofsky, del Instituto Nacional del Cáncer de Estados Unidos en Bethesda, Maryland, dijo: "Nuestros resultados sugieren que tenemos una vacuna muy prometedora".
El gen HER2 "impulsa el crecimiento de varios tipos de cáncer", incluidos el de mama, ovario, pulmón y colorrectal, explicó el profesor Berzofsky.
Un enfoque similar, que consiste en extraer células inmunitarias de los pacientes y "enseñarles" a atacar las células cancerosas, ha dado resultado en el tratamiento de un tipo de leucemia.
Tras su aparición en SNL, Kanye West se lanzó a una diatriba a favor de Trump, luciendo una gorra de MAGA.
No salió bien
Kanye West fue abucheado en el estudio durante una emisión de Saturday Night Live tras una actuación divagante en la que elogió al presidente estadounidense Donald Trump y dijo que se presentaría a las elecciones de 2020.
Tras interpretar su tercera canción de la noche, titulada Ghost Town, en la que llevaba una gorra de Make America Great, arremetió contra los demócratas y reiteró su apoyo a Trump.
"Muchas veces hablo con una persona blanca y me dice: '¿Cómo te puede gustar Trump? ¡Es racista!'"
"Bueno, si me preocupara el racismo, me habría marchado de Estados Unidos hace mucho tiempo", dijo.
SNL comenzó el programa con un sketch protagonizado por Matt Damon en el que la estrella de Hollywood se burlaba del testimonio de Brett Kavanaugh ante el Comité Judicial del Senado sobre las acusaciones de agresión sexual presentadas por Christine Blasey Ford.
Aunque no fue emitido, el vídeo del arrebato de West fue subido a las redes sociales por el comediante Chris Rock.
No está claro si Rock intentaba burlarse de West con esa publicación.
Además, West se quejó ante el público de que había tenido problemas entre bastidores por su tocado.
"Me acosaron entre bastidores."
Me dijeron: "No salgas ahí con ese sombrero puesto".
¡Me acosaron!
"Y luego dicen que estoy en un pozo sin fondo", dijo, según el Washington Examiner.
West continuó: "¿Quieres ver el lugar hundido?" diciendo que se "pondría mi capa de Superman, porque eso significa que no puedes decirme qué hacer". ¿Quieres que el mundo avance?
Prueba el amor."
Sus comentarios provocaron abucheos del público al menos dos veces y los miembros del elenco de SNL parecían avergonzados, según informó Variety, y una persona presente declaró a la publicación: "Todo el estudio se quedó en absoluto silencio".
West había sido contratado como reemplazo de última hora de la cantante Ariana Grande, cuyo exnovio, el rapero Mac Miller, había fallecido hacía unos días.
West desconcertó a muchos con una interpretación de la canción "I Love It", vestido como una botella de Perrier.
West recibió el apoyo de la líder del grupo conservador TPUSA, Candace Turner, quien tuiteó: "A uno de los espíritus más valientes: GRACIAS POR ENFRENTARTE A LA TURBA".
Pero la presentadora de programas de entrevistas Karen Hunter tuiteó que West simplemente estaba "siendo quien es y eso es absolutamente maravilloso".
"Pero decidí NO recompensar a alguien (comprando su música o ropa o apoyando su "arte") que creo que está adoptando y difundiendo una ideología que es dañina para mi comunidad."
Él es libre.
"Nosotros también", añadió.
Antes del espectáculo, el rapero anunció en Twitter que había cambiado su nombre, diciendo que ahora era "el ser conocido formalmente como Kanye West".
No es el primer artista en cambiarse el nombre y sigue los pasos de Diddy, también conocido como Puff Daddy, Puffy y P Diddy.
El también rapero Snoop Dogg ha tenido el nombre de Snoop Lion y, por supuesto, la difunta leyenda de la música Prince, cambió su nombre por un símbolo y luego el artista anteriormente conocido como Prince.
Acusación de intento de asesinato por apuñalamiento en un restaurante de Belfast.
Un hombre de 45 años ha sido acusado de intento de asesinato después de que un hombre fuera apuñalado en un restaurante en el este de Belfast el viernes.
El incidente tuvo lugar en Ballyhackamore, según informó la policía.
Se espera que el acusado comparezca ante el Tribunal de Magistrados de Belfast el lunes.
Los cargos serán revisados ​​por la Fiscalía.
Kit Harington, estrella de Juego de Tronos, critica la masculinidad tóxica.
Kit Harington es conocido por su papel de Jon Snow, un espadachín, en la violenta serie de fantasía medieval de HBO, Juego de Tronos.
Pero el actor, de 31 años, ha criticado el estereotipo del héroe machista, afirmando que esos papeles en la pantalla hacen que los niños a menudo sientan que tienen que ser duros para ser respetados.
En declaraciones a The Sunday Times Culture, Kit afirmó creer que "algo ha fallado" y cuestionó cómo abordar el problema de la masculinidad tóxica en la era del #MeToo.
Kit, quien recientemente se casó con su compañera de reparto de Juego de Tronos, Rose Leslie, también de 31 años, admitió que siente una gran necesidad de abordar el tema.
"Personalmente, me pregunto con mucha fuerza en este momento: ¿en qué nos hemos equivocado con la masculinidad?", dijo.
¿Qué les hemos estado enseñando a los hombres durante su infancia y adolescencia, en relación con el problema que vemos ahora?
Kit cree que la televisión puede ser en parte responsable del aumento de la masculinidad tóxica debido a sus personajes tan masculinos.
Continuó: '¿Qué es innato y qué se aprende?'
¿Qué se enseña en la televisión y en las calles que hace que los jóvenes sientan que tienen que encajar en cierta manera en lo que se supone que deben ser los hombres?
Creo que esa es una de las grandes preguntas de nuestro tiempo: ¿cómo cambiamos eso?
Porque claramente algo ha salido mal para los jóvenes.
En la entrevista también admitió que no participaría en ninguna precuela ni secuela de Juego de Tronos cuando la serie llegue a su fin el próximo verano, diciendo que ya está "harto de los campos de batalla y los caballos".
A partir de noviembre, Kit protagonizará una nueva versión de True West, de Sam Shepard, que narra la historia de un productor de cine y su hermano, que es un ladrón.
El actor reveló recientemente que considera que conocer a su esposa Rose es lo mejor que le ha salido de Juego de Tronos.
"Conocí a mi esposa en este programa, así que, en ese sentido, me dio a mi futura familia y mi vida de ahora en adelante", dijo.
Rose interpretó a Ygritte, el interés amoroso del personaje de Kit, Jon Snow, en la serie de fantasía ganadora del premio Emmy.
La pareja contrajo matrimonio en junio de 2018 en los terrenos de la finca familiar de Leslie en Escocia.
VIH/SIDA: China reporta un aumento del 14% en los nuevos casos.
China ha anunciado un aumento del 14% en el número de sus ciudadanos que viven con el VIH y el sida.
Según las autoridades sanitarias, más de 820.000 personas se han visto afectadas en el país.
Solo en el segundo trimestre de 2018 se notificaron alrededor de 40.000 casos nuevos.
La gran mayoría de los nuevos casos se transmitieron por vía sexual, lo que supone un cambio con respecto al pasado.
Tradicionalmente, el VIH se propagó rápidamente por algunas partes de China como resultado de transfusiones de sangre infectada.
Sin embargo, el número de personas que contraen el VIH de esta manera se ha reducido prácticamente a cero, según declararon funcionarios de salud chinos en una conferencia celebrada en la provincia de Yunnan.
Sin embargo, año tras año, el número de personas que viven con el VIH y el sida en China ha aumentado en 100.000 personas.
La transmisión del VIH a través de las relaciones sexuales es un problema grave en la comunidad LGBT de China.
La homosexualidad fue despenalizada en China en 1997, pero se dice que la discriminación contra las personas LGBT está muy extendida.
Debido a los valores conservadores del país, algunos estudios han estimado que entre el 70% y el 90% de los hombres que tienen relaciones sexuales con otros hombres terminarán casándose con mujeres.
Muchos de los contagios de estas enfermedades se deben a la falta de protección sexual adecuada en estas relaciones.
Desde 2003, el gobierno chino ha prometido el acceso universal a los medicamentos contra el VIH como parte de un esfuerzo por abordar este problema.
Maxine Waters niega que un miembro de su equipo filtrara datos de senadores republicanos y critica duramente las "mentiras peligrosas" y las "teorías de la conspiración".
La representante estadounidense Maxine Waters denunció el sábado las acusaciones de que un miembro de su personal había publicado información personal de tres senadores republicanos en las páginas de Wikipedia de los legisladores.
El demócrata de Los Ángeles afirmó que esas afirmaciones estaban siendo difundidas por comentaristas y sitios web de "ultraderecha".
"Mentiras, mentiras y más mentiras despreciables", dijo Waters en un comunicado en Twitter.
Según se informa, la información publicada incluía las direcciones particulares y los números de teléfono de los senadores estadounidenses. Lindsey Graham, de Carolina del Sur, y Mike Lee y Orrin Hatch, ambos de Utah.
La información apareció en internet el jueves, publicada por una persona desconocida en el Capitolio durante una audiencia del comité del Senado sobre las acusaciones de conducta sexual inapropiada contra el nominado a la Corte Suprema, Brett Kavanaugh.
La filtración se produjo algún tiempo después de que los tres senadores interrogaran a Kavanaugh.
Sitios web conservadores como Gateway Pundit y RedState informaron que la dirección IP que identifica el origen de las publicaciones estaba asociada con la oficina de Waters y divulgaron la información de un miembro del personal de Waters, según informó The Hill.
"Esta acusación infundada es completamente falsa y una mentira absoluta", continuó Waters.
"El miembro de mi personal, cuya identidad, información personal y seguridad se han visto comprometidas como resultado de estas acusaciones fraudulentas y falsas, no fue en modo alguno responsable de la filtración de esta información."
Esta acusación infundada es completamente falsa y una mentira absoluta.
Las declaraciones de Waters provocaron rápidamente críticas en internet, incluso del exsecretario de prensa de la Casa Blanca, Ari Fleischer.
"Esta negación es indignante", escribió Fleischer.
"Esto sugiere que no tiene el temperamento necesario para ser miembro del Congreso."
Cuando alguien es acusado de algo que no hizo, no debe enfadarse.
No deben ser desafiantes.
No deben cuestionar los motivos del acusador.
Deben estar tranquilos y serenos."
Fleischer parecía comparar la reacción de Waters con las críticas de los demócratas al juez Kavanaugh, a quien sus críticos acusaron de mostrarse demasiado enojado durante la audiencia del jueves.
Omar Navarro, candidato republicano que aspira a desbancar a Waters en las elecciones de mitad de mandato, también expresó su opinión en Twitter.
"Sería genial si fuera cierto", tuiteó.
En su declaración, Waters afirmó que su oficina había alertado a "las autoridades competentes y a los organismos encargados de hacer cumplir la ley sobre estas reclamaciones fraudulentas".
"Nos aseguraremos de que se revele la identidad de los responsables", continuó, "y de que rindan cuentas ante la ley por todas sus acciones, que resultan destructivas y peligrosas para todos y cada uno de los miembros de mi personal".
Reseña de Johnny English Strikes Again: una parodia de espías de Rowan Atkinson con poca fuerza.
Actualmente es tradición buscar referencias al Brexit en cualquier película nueva con un toque británico, y eso parece aplicable a este resurgimiento de la franquicia de parodias de acción y comedia de Johnny English, que comenzó en 2003 con Johnny English y resurgió con dificultad en 2011 con Johnny English Reborn.
¿Será la autosátira irónica sobre lo obviamente patéticos que somos la nueva oportunidad de exportación del país?
De todos modos, El incompetente Johnny English, de ojos saltones y rostro de goma, ha visto renovada su licencia para meter la pata por segunda vez; ese nombre suyo indica, más que nada, que es una creación cómica exagerada diseñada para territorios cinematográficos de habla no inglesa.
Es, por supuesto, el agente secreto tonto que, a pesar de sus extrañas pretensiones de glamour sofisticado, tiene algo de Clouseau. Una pizca de Mr. Bean y una pizca de ese tipo que contribuyó con una sola nota al tema musical de Carros de Fuego en la ceremonia de apertura de los Juegos Olímpicos de Londres 2012.
También está basado originalmente en el viajero y misterioso personaje internacional que Atkinson interpretó en los ahora olvidados anuncios de televisión de Barclaycard, dejando un rastro de caos a su paso.
Hay uno o dos momentos agradables en esta última entrega de JE.
Me encantó la escena en la que Johnny English se acerca a un helicóptero vestido con una armadura medieval y las aspas del rotor golpean brevemente contra su casco.
El talento de Atkinson para la comedia física queda patente, pero el humor resulta bastante flojo y extrañamente superfluo, sobre todo teniendo en cuenta que franquicias cinematográficas "serias" como James Bond y Misión Imposible ofrecen ahora con confianza la comedia como ingrediente.
El humor da la impresión de estar dirigido a niños en lugar de adultos, y para mí, las disparatadas desventuras de Johnny English no son tan ingeniosas ni están tan bien pensadas como los gags de cine mudo de Atkinson en el personaje de Bean.
La premisa que siempre está de actualidad es que Gran Bretaña se encuentra en serios problemas.
Un ciberdelincuente se ha infiltrado en la red web ultrasecreta de espías británicos, revelando las identidades de todos los agentes británicos sobre el terreno, para consternación del agente de guardia, un papel lamentablemente pequeño para Kevin Eldon.
Es la gota que colma el vaso para una primera ministra pomposa y acosada por las críticas, que ya sufre un colapso total debido a su impopularidad política: Emma Thompson hace todo lo posible con este personaje que recuerda a Teresa May, pero el guion no ofrece mucho material con el que trabajar.
Sus asesores de inteligencia le informan de que, dado que todos los espías en activo han sido descubiertos, tendrá que sacar a alguien de su retiro.
Y eso significa que el mismísimo y torpe Johnny English, ahora empleado como maestro en algún establecimiento elegante, imparte lecciones extraoficiales sobre cómo ser un agente encubierto: aquí hay algunos chistes divertidos, ya que English ofrece una academia de espionaje al estilo de Escuela de Rock.
English es trasladado rápidamente de vuelta a Whitehall para una reunión informativa de emergencia y se reencuentra con su antiguo y sufrido compañero Bough, interpretado de nuevo por Ben Miller.
Bough ahora es un hombre casado, esposo de un comandante de submarino, un papel secundario en el que Vicki Pepperdine está un poco desaprovechada.
Así pues, el Batman y el Robin de los desastres en el Servicio Secreto de Su Majestad vuelven a la acción, encontrándose con la bella femme fatale Ophelia Bulletova, interpretada por Olga Kurylenko.
Mientras tanto, el primer ministro está cayendo peligrosamente bajo el influjo del carismático multimillonario tecnológico que afirma poder resolver los problemas informáticos de Gran Bretaña: el siniestro Jason Volta, interpretado por Jake Lacy.
English y Bough comienzan su odisea de disparatadas peripecias: disfrazados de camareros, prenden fuego a un elegante restaurante francés; Crean un caos al colarse a bordo del yate de lujo de Volta; y English desata la anarquía total cuando intenta usar un casco de realidad virtual para familiarizarse con el interior de la casa de Volta.
Sin duda, se ha puesto todo el empeño en esa última secuencia, pero por muy simpática y bulliciosa que sea, tiene bastante de programa de televisión infantil.
Cosas bastante normales.
Y al igual que con las otras películas de Johnny English, no pude evitar pensar: ¿no podría la industria cinematográfica británica darle a Rowan Atkinson un papel que realmente haga justicia a su talento?
El Partido Laborista niega estar ideando un plan para que los británicos trabajen cuatro días a la semana pero cobren por cinco.
El Partido Laborista de Jeremy Corbyn estudiará un plan radical que supondría que los británicos trabajaran cuatro días a la semana, pero cobraran por cinco.
Según se informa, el partido quiere que los directivos de las empresas trasladen a los trabajadores los ahorros generados gracias a la revolución de la inteligencia artificial (IA), concediéndoles un día libre adicional.
Esto permitiría a los empleados disfrutar de un fin de semana de tres días, pero seguirían percibiendo el mismo salario.
Según las fuentes, la idea encajaría con la agenda económica del partido y sus planes para orientar el país a favor de los trabajadores.
El cambio a una semana laboral de cuatro días ha sido respaldado por el Congreso de Sindicatos Británicos como una forma de que los trabajadores aprovechen los cambios en la economía.
Una fuente de alto rango del Partido Laborista declaró a The Sunday Times: "Se espera que se anuncie una revisión de la política antes de que finalice el año".
«No sucederá de la noche a la mañana, pero una semana laboral de cuatro días es una aspiración que encaja con el enfoque del partido para reequilibrar la economía a favor del trabajador, así como con la estrategia industrial general del partido».
El Partido Laborista no sería el primero en respaldar tal idea, ya que el Partido Verde prometió una semana laboral de cuatro días durante su campaña para las elecciones generales de 2017.
Sin embargo, esta aspiración no cuenta actualmente con el respaldo del Partido Laborista en su conjunto.
Un portavoz del Partido Laborista declaró: «La semana laboral de cuatro días no es política del partido y no está siendo considerada por el mismo».
El portavoz de Hacienda del Partido Laborista, John McDonnell, aprovechó la conferencia laborista de la semana pasada para desarrollar su visión de una revolución socialista en la economía.
El señor McDonnell afirmó estar decidido a recuperar el poder de manos de los "directores anónimos" y los "aprovechadores" de las empresas de servicios públicos.
Los planes del portavoz de Hacienda de la oposición también implican que los actuales accionistas de las compañías de agua podrían no recuperar la totalidad de su participación, ya que un gobierno laborista podría realizar "deducciones" por presuntas irregularidades.
También confirmó los planes para incorporar a los trabajadores a los consejos de administración de las empresas y crear Fondos de Propiedad Inclusiva para entregar el 10 por ciento del capital de las empresas del sector privado a los empleados, quienes podrían embolsarse dividendos anuales de hasta 500 libras esterlinas.
Lindsey Graham y John Kennedy declaran en el programa "60 Minutes" si la investigación del FBI sobre Kavanaugh podría hacerles cambiar de opinión.
La investigación del FBI sobre las acusaciones contra el juez Brett Kavanaugh ha retrasado al menos una semana la votación final sobre su nominación a la Corte Suprema. y plantea la cuestión de si las conclusiones de la oficina podrían influir en algún senador republicano para que retire su apoyo.
En una entrevista que se emitirá el domingo, el corresponsal de "60 Minutes", Scott Pelley, preguntó a los senadores republicanos. John Kennedy y Lindsey Graham se preguntaban si el FBI podría descubrir algo que les hiciera cambiar de opinión.
Kennedy se mostró más abierto que su colega de Carolina del Sur.
"Claro que sí", dijo Kennedy.
"Antes de entrar en la audiencia, dije que había hablado con el juez Kavanaugh."
Lo llamé después de que esto sucediera, cuando salió a la luz esa acusación, y le pregunté: "¿Lo hiciste tú?".
Era resuelto, decidido e inequívoco.
Sin embargo, el voto de Graham parece estar decidido de antemano.
"Ya he tomado una decisión sobre Brett Kavanaugh y haría falta una acusación explosiva", dijo.
"Doctora Ford, no sé qué pasó, pero sé esto: Brett lo negó rotundamente", añadió Graham, refiriéndose a Christine Blasey Ford.
"Y ninguna de las personas que ella menciona pudo verificarlo."
Tiene 36 años.
No veo que vaya a cambiar nada nuevo."
¿Qué es el Festival Global Citizen y ha contribuido en algo a reducir la pobreza?
Este sábado, Nueva York acogerá el Global Citizen Festival, un evento musical anual que cuenta con un impresionante cartel de estrellas y una misión igualmente impresionante: acabar con la pobreza mundial.
Ahora en su séptimo año, El Festival Global Citizen congregará a decenas de miles de personas en el Great Lawn de Central Park no solo para disfrutar de actuaciones de artistas como Janet Jackson, Cardi B y Shawn Mendes, sino también para concienciar sobre el verdadero objetivo del evento: acabar con la pobreza extrema para 2030.
El Festival Global Citizen, que se inauguró en 2012, es una extensión del Proyecto Global contra la Pobreza, un grupo de defensa internacional que busca acabar con la pobreza aumentando el número de personas que luchan activamente contra ella.
Para recibir una entrada gratuita para el evento (a menos que estuviera dispuesto a pagar por una entrada VIP), Los asistentes al concierto debían completar una serie de tareas o "acciones", como ser voluntarios, enviar un correo electrónico a un líder mundial, hacer una llamada telefónica o cualquier otra forma significativa de ayudar a crear conciencia sobre su objetivo de acabar con la pobreza.
Pero, ¿hasta qué punto ha tenido éxito Global Citizen a falta de 12 años para alcanzar su objetivo?
¿La idea de premiar a la gente con un concierto gratuito es una forma genuina de persuadirlos para que exijan una llamada a la acción, o es simplemente otro caso del llamado "activismo de clics", donde la gente siente que está marcando una verdadera diferencia al firmar una petición en línea o enviar un tuit?
Desde 2011, Global Citizen afirma haber registrado más de 19 millones de "acciones" por parte de sus seguidores, impulsando una gran variedad de objetivos.
El informe señala que estas acciones han contribuido a impulsar a los líderes mundiales a anunciar compromisos y políticas por un valor superior a los 37.000 millones de dólares, que afectarán la vida de más de 2.250 millones de personas para 2030.
A principios de 2018, el grupo citó 390 compromisos y anuncios derivados de sus acciones, de los cuales al menos 10.000 millones de dólares ya se han desembolsado o recaudado.
El grupo estima que los fondos obtenidos hasta la fecha han tenido un impacto directo en casi 649 millones de personas en todo el mundo.
Algunos de los compromisos clave incluyen El poder de la nutrición, Una alianza de inversores y ejecutores con sede en el Reino Unido, comprometida con "ayudar a los niños a desarrollar todo su potencial", prometió proporcionar a Ruanda 35 millones de dólares para ayudar a acabar con la desnutrición en el país tras recibir más de 4.700 tuits de ciudadanos globales.
"Con el apoyo del gobierno del Reino Unido, "Donantes, gobiernos nacionales y ciudadanos globales como ustedes, podemos lograr que la injusticia social de la desnutrición sea solo una nota a pie de página en la historia", dijo Tracey Ullman, embajadora de The Power of Nutrition, al público durante un concierto en vivo en Londres en abril de 2018.
El grupo también dijo que después de más de 5,Se llevaron a cabo 000 acciones para instar al Reino Unido a mejorar la nutrición de madres e hijos, y el gobierno anunció la financiación de un proyecto, El Poder de la Nutrición, que llegará a 5 millones de mujeres y niños con intervenciones nutricionales.
En respuesta a una de las preguntas frecuentes en su sitio web que pregunta "¿qué les hace pensar que podemos acabar con la pobreza extrema?"
El ciudadano global respondió: "Será un camino largo y difícil; a veces caeremos y fracasaremos."
Pero, al igual que los grandes movimientos por los derechos civiles y contra el apartheid que nos precedieron, triunfaremos, porque juntos somos más fuertes.
Janet Jackson, The Weeknd, Shawn Mendes, Cardi B y Janelle Monáe son algunos de los artistas que actuarán en el evento de este año en Nueva York, que será presentado por Deborra-Lee Furness y Hugh Jackman.
Estados Unidos podría usar la Armada para un "bloqueo" con el fin de obstaculizar las exportaciones de energía rusas, según el secretario del Interior.
Washington puede recurrir, "si fuera necesario", a su Armada para impedir que la energía rusa llegue a los mercados, incluso en Oriente Medio, según reveló el secretario del Interior estadounidense, Ryan Zinke, citado por el Washington Examiner.
Zinke alegó que la participación de Rusia en Siria —en particular, donde opera por invitación del gobierno legítimo— es un pretexto para explorar nuevos mercados energéticos.
Según se informa, ha dicho: "Creo que la razón por la que están en Oriente Medio es que quieren intermediar en el suministro de energía, igual que lo hacen en Europa del Este, en el corazón del sur de Europa".
Y, según el funcionario, existen maneras de abordarlo.
"Estados Unidos tiene la capacidad, gracias a su Armada, de garantizar que las rutas marítimas permanezcan abiertas y, si es necesario, de bloquearlas para asegurarse de que su energía no llegue al mercado", afirmó.
Zinke se dirigía a los asistentes al evento organizado por la Consumer Energy Alliance, un grupo sin ánimo de lucro que se autodenomina la "voz del consumidor de energía" en Estados Unidos.
Procedió a comparar los enfoques de Washington para tratar con Rusia e Irán, señalando que, en la práctica, son los mismos.
"La opción económica con respecto a Irán y Rusia consiste, más o menos, en aprovechar y sustituir los combustibles", dijo, refiriéndose a Rusia como un país que solo sabe aprovechar los combustibles fósiles.
Estas declaraciones se producen en un momento en que la administración Trump se ha propuesto impulsar la exportación de su gas natural licuado a Europa, sustituyendo a Rusia, la opción mucho más barata para los consumidores europeos.
Con ese fin, los funcionarios de la administración Trump, incluido el propio presidente estadounidense Donald Trump, intentan persuadir a Alemania para que se retire del proyecto "inapropiado" del gasoducto Nord Stream 2, que, según Trump, convirtió a Berlín en "cautiva" de Moscú.
Moscú ha insistido repetidamente en que el gasoducto Nord Stream 2, valorado en 11.000 millones de dólares y que duplicará la capacidad de los gasoductos existentes hasta alcanzar los 110.000 millones de metros cúbicos, es un proyecto puramente económico.
El Kremlin argumenta que la ferviente oposición de Washington al proyecto se debe simplemente a razones económicas y es un ejemplo de competencia desleal.
"Creo que compartimos la opinión de que la energía no puede ser una herramienta para ejercer presión y que los consumidores deberían poder elegir a los proveedores", dijo el ministro de Energía ruso, Aleksandr Novak, tras una reunión con el secretario de Energía estadounidense, Rick Perry, en Moscú en septiembre.
La postura estadounidense ha provocado el rechazo de Alemania, que ha reafirmado su compromiso con el proyecto.
La principal organización industrial de Alemania, la Federación de Industrias Alemanas (BDI), ha pedido a Estados Unidos que se mantenga al margen de la política energética de la UE y de los acuerdos bilaterales entre Berlín y Moscú.
"Me preocupa mucho que un tercer Estado interfiera en nuestro suministro energético", declaró Dieter Kempf, presidente de la Federación de Industrias Alemanas (BDI), tras una reciente reunión entre la canciller alemana Angela Merkel y el presidente ruso Vladimir Putin.
La senadora de Massachusetts afirma que Elizabeth Warren estudiará detenidamente la posibilidad de presentarse a la presidencia en 2020.
La senadora de Massachusetts, Elizabeth Warren, dijo el sábado que consideraría seriamente la posibilidad de presentarse a la presidencia tras las elecciones de mitad de mandato.
Durante un encuentro con los ciudadanos en Holyoke, Massachusetts, Warren confirmó que consideraría presentarse como candidata.
"Es hora de que las mujeres vayan a Washington y arreglen nuestro gobierno disfuncional, y eso incluye a una mujer al frente", dijo, según The Hill.
"Después del 6 de noviembre, consideraré seriamente la posibilidad de presentarme a la presidencia."
Durante el encuentro con los ciudadanos, Warren dio su opinión sobre el presidente Donald Trump, diciendo que estaba "llevando a este condado en la dirección equivocada".
"Me preocupa muchísimo lo que Donald Trump le está haciendo a nuestra democracia", dijo.
Warren se ha mostrado muy crítica con Trump y con su nominado a la Corte Suprema, Brett Kavanaugh.
En un tuit publicado el viernes, Warren dijo: "Por supuesto que necesitamos una investigación del FBI antes de votar".
Sin embargo, una encuesta publicada el jueves mostró que la mayoría de los propios electores de Warren no creen que deba presentarse a las elecciones de 2020.
Según una encuesta del Centro de Investigación Política de la Universidad de Suffolk/Boston Globe, el 58% de los votantes "probables" de Massachusetts opinaron que el senador no debería presentarse a las elecciones.
El treinta y dos por ciento apoyó esa candidatura.
La encuesta mostró un mayor apoyo a la candidatura del exgobernador Deval Patrick, con un 38 por ciento a favor de una posible candidatura y un 48 por ciento en contra.
Otros nombres destacados del Partido Demócrata que se barajan como posibles candidatos para las elecciones de 2020 incluyen al exvicepresidente Joe Biden y al senador de Vermont, Bernie Sanders.
Biden dijo que tomaría una decisión oficial en enero, según informó Associated Press.
Sarah Palin menciona el trastorno de estrés postraumático de Palin en un mitin de Donald Trump.
Track Palin, de 26 años, pasó un año en Irak tras alistarse en septiembre.
Fue arrestado y acusado en relación con un incidente de violencia doméstica el lunes por la noche.
"Lo que está pasando mi propio hijo, lo que está viviendo al regresar, me hace comprender a otras familias que sufren las consecuencias del trastorno de estrés postraumático y algunas de las heridas con las que regresan nuestros soldados", dijo a la audiencia en un mitin a favor de Donald Trump en Tulsa, Oklahoma.
Palin calificó su arresto como "el elefante en la habitación" y dijo sobre su hijo y otros veteranos de guerra: "Regresan un poco diferentes, regresan endurecidos, regresan preguntándose si existe ese respeto por lo que sus compañeros soldados y aviadores, y todos los demás miembros de las fuerzas armadas, han dado al país."
Fue arrestado el lunes en Wasilla, Alaska, y acusado de agresión por violencia doméstica contra una mujer, obstrucción a la justicia en un caso de violencia doméstica y posesión de un arma en estado de embriaguez, según Dan Bennett, portavoz del Departamento de Policía de Wasilla.
Dieciocho estados y el Distrito de Columbia respaldan la impugnación de la nueva política de asilo.
Dieciocho estados y el Distrito de Columbia respaldan una impugnación legal contra una nueva política estadounidense que niega el asilo a las víctimas que huyen de la violencia de pandillas o la violencia doméstica.
Según informó NBC News, representantes de los 18 estados y del distrito presentaron el viernes en Washington un escrito de amicus curiae en apoyo de un solicitante de asilo que impugna la política.
El nombre completo del demandante en el caso Grace v. No se ha revelado la demanda que la Unión Estadounidense por las Libertades Civiles (ACLU) interpuso en agosto contra la política federal por parte de Sessions.
Según su testimonio, su pareja, "y sus hijos, miembros de una pandilla violenta", abusaron de ella, pero las autoridades estadounidenses le negaron su solicitud de asilo el 20 de julio.
Fue detenida en Texas.
Los fiscales estatales que apoyaban a Grace describieron a El Salvador, Honduras y Guatemala, países que generan un gran número de solicitantes de asilo en Estados Unidos, como naciones que enfrentan problemas generalizados con pandillas y violencia doméstica.
La nueva política de asilo de Estados Unidos revirtió una decisión de 2014 de la Junta de Apelaciones de Inmigración que permitía a los inmigrantes indocumentados que huían de la violencia doméstica solicitar asilo.
El fiscal general del Distrito de Columbia, Karl Racine, declaró el viernes que la nueva política "ignora décadas de legislación estatal, federal e internacional".
"La ley federal exige que todas las solicitudes de asilo se resuelvan en función de los hechos y circunstancias particulares de cada caso, y tal prohibición viola ese principio", decía el escrito presentado ante el tribunal.
Los abogados argumentaron además en el escrito que la política de negar la entrada a los inmigrantes perjudica a la economía estadounidense, afirmando que estos tienen más probabilidades de convertirse en empresarios y "proporcionar la mano de obra necesaria".
En junio, el fiscal general Jeff Sessions ordenó a los jueces de inmigración que dejaran de conceder asilo a las víctimas que huyen de la violencia doméstica y la violencia de pandillas.
"El asilo está disponible para aquellos que abandonan su país de origen debido a la persecución o el temor por motivos de raza, religión, nacionalidad o pertenencia a un grupo social particular u opinión política", dijo Sessions en su anuncio del 11 de junio sobre esta política.
El asilo nunca tuvo como objetivo aliviar todos los problemas, ni siquiera todos los problemas graves, a los que se enfrentan las personas a diario en todo el mundo.
Intensos esfuerzos de rescate en Palu mientras el número de muertos se duplica en la carrera por encontrar supervivientes.
Para los supervivientes, la situación era cada vez más desesperada.
"Se respira mucha tensión", dijo Risa Kusuma, una madre de 35 años, mientras consolaba a su bebé con fiebre en un centro de evacuación en la devastada ciudad de Palu.
"Cada minuto llega un cadáver en ambulancia."
El agua potable escasea.
Se pudo ver a los residentes regresando a sus casas destruidas, rebuscando entre sus pertenencias empapadas, intentando rescatar todo lo que pudieran encontrar.
Cientos de personas resultaron heridas y los hospitales, dañados por el terremoto de magnitud 7,5, se vieron desbordados.
Algunos de los heridos, entre ellos Dwi Haris, que sufrió fracturas de espalda y hombro, descansaban a las afueras del hospital militar de Palu, donde los pacientes estaban siendo atendidos al aire libre debido a las continuas y fuertes réplicas.
Las lágrimas le llenaron los ojos mientras relataba cómo sintió el violento terremoto sacudir la habitación del hotel del quinto piso que compartía con su esposa y su hija.
"No había tiempo para salvarnos."
"Creo que me metieron entre las ruinas de la muralla", declaró Haris a Associated Press, añadiendo que su familia estaba en la ciudad para una boda.
"Oí a mi esposa pedir ayuda a gritos, pero luego silencio."
No sé qué les pasó a ella y a mi hijo.
Espero que estén a salvo.
El embajador de Estados Unidos acusa a China de "intimidación" con "anuncios de propaganda".
Una semana después de que un periódico oficial chino publicara un anuncio de cuatro páginas en un diario estadounidense ensalzando los beneficios mutuos del comercio entre Estados Unidos y China, el embajador estadounidense en China acusó a Pekín de utilizar la prensa estadounidense para difundir propaganda.
El presidente estadounidense Donald Trump se refirió el miércoles pasado al suplemento pagado del China Daily en el Des Moines Register, el periódico de mayor circulación del estado de Iowa, después de acusar a China de intentar interferir en las elecciones al Congreso de Estados Unidos del 6 de noviembre. una acusación que China niega.
La acusación de Trump de que Pekín estaba intentando interferir en las elecciones estadounidenses marcó, según declararon funcionarios estadounidenses a Reuters, una nueva fase en la creciente campaña de Washington para presionar a China.
Si bien es normal que los gobiernos extranjeros publiquen anuncios para promover el comercio, Pekín y Washington se encuentran actualmente inmersos en una escalada de guerra comercial que los ha llevado a imponerse mutuamente varias rondas de aranceles a las importaciones.
Según expertos chinos y estadounidenses, los aranceles de represalia impuestos por China al comienzo de la guerra comercial estaban diseñados para perjudicar a los exportadores de estados como Iowa, que apoyaban al Partido Republicano de Trump.
Terry Branstad, embajador de Estados Unidos en China y antiguo gobernador de Iowa, un importante exportador de productos agrícolas a China, afirmó que Pekín había perjudicado a los trabajadores, agricultores y empresas estadounidenses.
China, escribió Branstad en un artículo de opinión publicado el domingo en el Des Moines Register, "está redoblando sus esfuerzos por intimidar a la gente publicando anuncios de propaganda en nuestra propia prensa libre".
"Al difundir su propaganda, el gobierno chino se está valiendo de la preciada tradición estadounidense de libertad de expresión y de prensa libre al colocar un anuncio pagado en el Des Moines Register", escribió Branstad.
"Por el contrario, en el quiosco de periódicos de la calle de al lado aquí en Pekín, "Encontrarás pocas voces disidentes y no verás ningún reflejo fiel de las diversas opiniones que el pueblo chino pueda tener sobre la preocupante trayectoria económica de China, dado que los medios de comunicación están bajo el firme control del Partido Comunista Chino", escribió.
Añadió que "uno de los periódicos más importantes de China eludió la oferta de publicar" su artículo, aunque no especificó qué periódico era.
Los republicanos están alejando a las votantes antes de las elecciones de mitad de mandato con el fiasco de Kavanaugh, advierten los analistas.
Mientras muchos republicanos de alto rango mantienen su postura y defienden al nominado a la Corte Suprema, Brett Kavanaugh, frente a varias acusaciones de agresión sexual, los analistas han advertido que se producirá una reacción adversa, en particular por parte de las mujeres, durante las próximas elecciones de mitad de mandato.
Las emociones que rodean este tema han sido extremadamente intensas, y la mayoría de los republicanos ya han manifestado públicamente su deseo de seguir adelante con la votación.
"Esas cosas no se pueden revertir", declaró Grant Reeher, profesor de ciencias políticas en la Escuela Maxwell de la Universidad de Syracuse, a The Hill para un artículo publicado el sábado.
Reeher expresó sus dudas de que la iniciativa de última hora del senador Jeff Flake (republicano por Arizona) para que el FBI inicie una investigación sea suficiente para apaciguar a los votantes enfadados.
"Las mujeres no van a olvidar lo que pasó ayer, no lo van a olvidar mañana ni en noviembre.""Así lo afirmó Karine Jean-Pierre, asesora principal y portavoz nacional del grupo progresista MoveOn, el viernes, según informó un periódico de Washington, D.C.
El viernes por la mañana, Según informó Mic, los manifestantes corearon "¡Noviembre se acerca!" mientras protestaban en el pasillo del Senado, después de que los republicanos que controlan el Comité Judicial decidieran seguir adelante con la nominación de Kavanaugh a pesar del testimonio de la Dra. Christine Blasey Ford.
"El entusiasmo y la motivación demócratas van a ser extraordinarios", declaró Stu Rothenberg, analista político independiente, al sitio web de noticias.
"La gente dice que ya ha estado alto; eso es cierto."
Pero podría ser más alta, sobre todo entre las mujeres votantes indecisas de los suburbios y los votantes más jóvenes, de entre 18 y 29 años, que, aunque no les guste el presidente, a menudo no votan.
Incluso antes del testimonio público de Ford, en el que detalló sus acusaciones de agresión sexual contra el candidato a la Corte Suprema, los analistas sugirieron que podría producirse una reacción adversa si los republicanos seguían adelante con la confirmación.
"Esto se ha convertido en un auténtico lío para el Partido Republicano", declaró Michael Steele, expresidente del Comité Nacional Republicano, a principios de la semana pasada, según informó NBC News.
"No se trata solo de la votación del comité o la votación final o si Kavanaugh es puesto en el tribunal, "También se trata de la forma en que los republicanos han manejado esto y cómo la han tratado", señaló Guy Cecil, director de Priorities USA, un grupo que ayuda a elegir a los demócratas, al canal de noticias.
Sin embargo, los estadounidenses parecen estar algo divididos sobre a quién creer tras los testimonios de Ford y Kavanaugh, con una ligera mayoría inclinándose por este último.
Una nueva encuesta de YouGov muestra que el 41 por ciento de los encuestados creían, de forma definitiva o probable, el testimonio de Ford, mientras que el 35 por ciento dijo creer, de forma definitiva o probable, el de Kavanaugh.
Además, el 38 por ciento dijo creer que Kavanaugh probablemente o definitivamente mintió durante su testimonio, mientras que solo el 30 por ciento dijo lo mismo sobre Ford.
Tras la presión ejercida por Flake, el FBI está investigando actualmente las acusaciones presentadas por Ford, así como las de al menos otra denunciante, Deborah Ramirez, según informó The Guardian.
La semana pasada, Ford testificó bajo juramento ante el Comité Judicial del Senado que Kavanaugh la agredió sexualmente estando ebrio cuando tenía 17 años.
Ramírez alega que el candidato a la Corte Suprema le mostró sus genitales durante una fiesta a la que asistieron mientras estudiaban en Yale en la década de 1980.
El inventor de la World Wide Web planea crear una nueva Internet para competir con Google y Facebook.
Tim Berners-Lee, el inventor de la World Wide Web, está lanzando una empresa emergente que busca competir con Facebook, Amazon y Google.
El último proyecto de esta leyenda de la tecnología, Inrupt, es una empresa que se basa en la plataforma de código abierto Solid de Berners-Lee.
Solid permite a los usuarios elegir dónde se almacenan sus datos y qué personas tienen acceso a qué información.
En una entrevista exclusiva con Fast Company, Berners-Lee bromeó diciendo que la intención detrás de Inrupt es "la dominación mundial".
"Tenemos que hacerlo ahora", dijo refiriéndose a la empresa emergente.
"Es un momento histórico."
La aplicación utiliza la tecnología de Solid para permitir a los usuarios crear su propio "almacén de datos personal en línea" o POD.
Puede contener listas de contactos, listas de tareas pendientes, calendario, biblioteca musical y otras herramientas personales y profesionales.
Es como si Google Drive, Microsoft Outlook, Slack y Spotify estuvieran disponibles en un solo navegador y al mismo tiempo.
Lo que hace único al almacenamiento de datos personales en línea es que depende completamente del usuario quién puede acceder a qué tipo de información.
La empresa lo denomina "empoderamiento personal a través de los datos".
Según John Bruce, director ejecutivo de Inrupt, la idea es que la empresa aporte los recursos, los procesos y las habilidades adecuadas para que Solid esté al alcance de todos.
Actualmente, la empresa está formada por Berners-Lee, Bruce, una plataforma de seguridad adquirida por IBM, algunos desarrolladores de plantilla contratados para trabajar en el proyecto y una comunidad de programadores voluntarios.
A partir de esta semana, los desarrolladores de tecnología de todo el mundo podrán crear sus propias aplicaciones descentralizadas utilizando las herramientas disponibles en el sitio web de Inrupt.
Berners-Lee afirmó que ni él ni su equipo están hablando con "Facebook y Google sobre si deben o no introducir un cambio radical que trastoque por completo todos sus modelos de negocio de la noche a la mañana".
"No les estamos pidiendo permiso."
En una publicación en Medium difundida el sábado, Berners-Lee escribió que la misión de Inrupt es "proporcionar energía comercial y un ecosistema para ayudar a proteger la integridad y la calidad de la nueva web construida sobre Solid".
En 1994, Berners-Lee transformó Internet al fundar el Consorcio World Wide Web en el Instituto Tecnológico de Massachusetts (MIT).
En los últimos meses, Berners-Lee ha sido una voz influyente en el debate sobre la neutralidad de la red.
Incluso durante el lanzamiento de Inrupt, Berners-Lee seguirá siendo el fundador y director del World Wide Web Consortium, la Web Foundation y el Open Data Institute.
"Soy increíblemente optimista respecto a esta próxima era de la web", añadió Berners-Lee.
Bernard Vann: Clérigo condecorado con la Cruz Victoria en la Primera Guerra Mundial.
El único clérigo de la Iglesia de Inglaterra que ganó la Cruz Victoria durante la Primera Guerra Mundial como combatiente ha sido homenajeado en su ciudad natal cien años después.
El teniente coronel reverendo Bernard Vann ganó el premio el 29 de septiembre de 1918 por su participación en el ataque a Bellenglise y Lehaucourt.
Sin embargo, cuatro días después murió a manos de un francotirador y nunca supo que había recibido la máxima condecoración militar británica.
El sábado, sus dos nietos develaron una placa conmemorativa durante un desfile en Rushden, Northamptonshire.
Uno de sus nietos, Michael Vann, dijo que era "brillantemente simbólico" que la piedra se descubriera exactamente 100 años después de la hazaña galardonada de su abuelo.
Según la London Gazette, el 29 de septiembre de 1918, el teniente coronel Vann condujo a su batallón a través del Canal de Saint-Quentin "en medio de una niebla muy espesa y bajo un intenso fuego de artillería de campaña y ametralladoras".
Posteriormente, se precipitó hasta la línea de fuego y, con la "mayor valentía", dirigió la línea hacia adelante antes de cargar él solo contra un cañón de campaña y abatir a tres miembros del destacamento.
El teniente coronel Vann murió a manos de un francotirador alemán el 4 de octubre de 1918, poco más de un mes antes de que terminara la guerra.
Michael Vann, de 72 años, dijo que las acciones de su abuelo eran "algo que sé que nunca podré igualar, pero algo que me llena de humildad".
Él y su hermano, el Dr. James Vann, también depositaron una corona de flores tras el desfile, que estuvo encabezado por la Banda Juvenil Imperial de Brentwood.
Michael Vann dijo sentirse "muy honrado de participar en el desfile" y añadió que "el valor de un verdadero héroe se está demostrando con el apoyo que recibirá de mucha gente".
Los fanáticos de las MMA se quedaron despiertos toda la noche para ver Bellator 206, pero en su lugar vieron Peppa Pig.
Imagínate esto: te has quedado despierto toda la noche para ver un Bellator 206 con entradas agotadas, solo para que te impidan ver el evento principal.
El evento de San José incluyó 13 combates, seis de ellos en la cartelera principal, y se transmitió en directo durante toda la noche en el Reino Unido por el Canal 5.
A las 6 de la mañana, justo cuando Gegard Mousasi y Rory MacDonald se preparaban para enfrentarse, los telespectadores del Reino Unido quedaron atónitos cuando la retransmisión cambió a Peppa Pig.
Algunos no quedaron impresionados después de haber permanecido despiertos hasta altas horas de la madrugada, especialmente para ver la pelea.
Un fan en Twitter describió el cambio a la serie de dibujos animados infantiles como "una especie de broma macabra".
"Es una normativa gubernamental que a las 6 de la mañana ese contenido no era apropiado, así que tuvieron que cambiar a programación infantil", dijo Dave Schwartz, vicepresidente sénior de marketing y comunicación de Bellator, cuando se le preguntó sobre la transmisión.
"Peppa la cerdita", sí.
El presidente de la compañía Bellator, Scott Coker, dijo que van a trabajar en su programación para incluir a los espectadores del Reino Unido en el futuro.
"Creo que, al pensar en la repetición, probablemente podamos resolverlo", dijo Coker.
"Pero allí son las seis de la mañana de un domingo y no podremos resolver esto hasta el domingo, hora nuestra, que será el lunes, hora de ellos."
Pero estamos trabajando en ello.
Créeme, cuando se produjo el cambio hubo un montón de mensajes de texto de ida y vuelta, y ninguno era amistoso.
Estábamos intentando solucionarlo, pensábamos que era un fallo técnico.
Pero no fue así, fue un asunto gubernamental.
Te puedo prometer que la próxima vez no volverá a suceder.
Lo limitaremos a cinco peleas en lugar de seis, como solemos hacer, e intentamos superar las expectativas de los aficionados, pero lo conseguimos.
Es una situación lamentable.
Discos para una isla desierta: Tom Daley se sintió "inferior" en lo que respecta a su sexualidad.
El clavadista olímpico Tom Daley dice que creció sintiéndose inferior a todos debido a su sexualidad, pero eso le dio la motivación para alcanzar el éxito.
El joven de 24 años dijo que no se dio cuenta hasta que fue a la escuela secundaria de que "no todos son como yo".
En su intervención en el primer programa de Radio 4, Desert Island Discs, presentado por Lauren Laverne, dijo que se pronunció a favor de los derechos de los homosexuales para dar "esperanza" a los demás.
También dijo que convertirse en padre hizo que le importara menos ganar los Juegos Olímpicos.
La presentadora habitual del programa de larga duración, Kirsty Young, se ha tomado varios meses de baja por enfermedad.
En su aparición como náufrago en el primer programa de Laverne, Daley dijo que se sentía "inferior" a los demás durante su infancia porque "no era socialmente aceptable que te gustaran los chicos y las chicas".
Dijo: "Hasta el día de hoy, esos sentimientos de inferioridad y de ser diferente han sido los que realmente me han dado el poder y la fuerza para poder triunfar".
Quería demostrar que era "alguien", dijo, para no decepcionar a todos cuando finalmente descubrieran su orientación sexual.
El dos veces medallista de bronce olímpico se ha convertido en un destacado activista LGBT y aprovechó su participación en los Juegos de la Commonwealth de este año en Australia para pedir a más países que despenalicen la homosexualidad.
Dijo que decidió hablar públicamente porque se sentía afortunado de poder vivir abiertamente sin consecuencias y quería dar "esperanza" a los demás.
El tres veces campeón del mundo dijo que enamorarse de un hombre, el cineasta estadounidense Dustin Lance Black, a quien conoció en 2013, "lo tomó por sorpresa".
Daley se casó el año pasado con la ganadora del Oscar, que es 20 años mayor que él, pero afirmó que la diferencia de edad nunca había sido un problema.
"Cuando uno pasa por tantas cosas a una edad tan temprana" —participó en sus primeros Juegos Olímpicos a los 14 años y su padre murió de cáncer tres años después—, dijo que era difícil encontrar a alguien de la misma edad que hubiera experimentado altibajos similares.
La pareja se convirtió en padres en junio, con un hijo llamado Robert Ray Black-Daley, y Daley dijo que su "perspectiva por completo" había cambiado.
"Si me lo hubieras preguntado el año pasado, todo se reducía a 'Necesito ganar una medalla de oro'", dijo.
"Sabes qué, hay cosas más importantes que las medallas de oro olímpicas."
Mi medalla de oro olímpica es Robbie."
Su hijo se llama igual que su padre, Robert, quien falleció en 2011 a los 40 años tras ser diagnosticado con cáncer cerebral.
Daley contó que su padre no aceptaba que iba a morir y que una de las últimas cosas que preguntó fue si ya tenían las entradas para los Juegos Olímpicos de Londres 2012, ya que quería estar en primera fila.
"No podía decirle: 'Papá, no vas a estar aquí para sentarte en primera fila'", dijo.
"Le estaba sujetando la mano cuando dejó de respirar, y no fue hasta que dejó de respirar y murió que finalmente reconocí que no era invencible", dijo.
Al año siguiente, Daley compitió en los Juegos Olímpicos de 2012 y ganó la medalla de bronce.
"Sabía que esto era con lo que había soñado toda mi vida: saltar al agua frente a mi público en unos Juegos Olímpicos. No había mejor sensación", dijo.
También inspiró su primera elección musical, "Proud" de Heather Small, que le había impactado durante la preparación para los Juegos Olímpicos y que aún le ponía la piel de gallina.
El programa Desert Island Discs se emite en BBC Radio 4 el domingo a las 11:15 BST.
Mickelson, fuera de forma, fue suplente el sábado de la Ryder Cup.
El estadounidense Phil Mickelson establecerá un récord el domingo cuando dispute su partido número 47 de la Ryder Cup, pero tendrá que mejorar su rendimiento para evitar que se convierta en un hito desafortunado.
Mickelson, que participaba en este evento bienal por duodécima vez, un récord histórico, fue suplente por decisión del capitán Jim Furyk para los partidos de fourballs y foursomes del sábado.
En lugar de estar en el centro de la acción, como tantas veces lo ha estado para Estados Unidos, el cinco veces ganador de torneos importantes dividió su día entre animar a su equipo y practicar en el campo de prácticas con la esperanza de corregir sus problemas.
Ni siquiera en la cima de su carrera se caracterizó por ser un jugador especialmente preciso al golpear la bola, por lo que este golfista de 48 años no encaja a la perfección en el exigente campo de Le Golf National, donde el rough, de gran longitud, castiga sistemáticamente los golpes desviados.
Y por si el campo de golf en sí no fuera ya lo suficientemente intimidante, Mickelson, en el noveno partido del domingo, se enfrenta al preciso campeón del Abierto Británico, Francesco Molinari, quien se ha aliado con el novato Tommy Fleetwood para ganar sus cuatro partidos esta semana.
Si los estadounidenses, que comienzan los 12 partidos individuales con cuatro puntos de desventaja, tienen un buen comienzo, el partido de Mickelson podría resultar absolutamente crucial.
Furyk expresó su confianza en su hombre, aunque no pudo decir mucho más.
"Él comprendió perfectamente el papel que tenía hoy, me dio una palmada en la espalda, me rodeó con el brazo y me dijo que estaría listo mañana", dijo Furyk.
"Tiene mucha confianza en sí mismo."
Es un miembro del Salón de la Fama y ha aportado muchísimo a estos equipos en el pasado, y también esta semana.
Probablemente no me imaginaba que jugaría dos partidos.
Tenía una visión más ambiciosa, pero así resultaron las cosas y así es como pensamos que debíamos proceder.
Él quiere estar ahí fuera, como todos los demás.
Mickelson superará el domingo el récord de Nick Faldo de mayor número de partidos disputados en la Ryder Cup.
Esto podría marcar el final de una carrera en la Ryder Cup que nunca ha estado a la altura de su récord individual.
Mickelson suma 18 victorias, 20 derrotas y siete medios partidos, aunque Furyk afirmó que su presencia aportaba algunos aspectos intangibles al equipo.
"Es gracioso, sarcástico, ingenioso, le gusta burlarse de la gente y es un tipo estupendo para tener en el vestuario", explicó.
"Creo que los jugadores más jóvenes también se divirtieron enfrentándose a él esta semana, lo cual fue entretenido de ver."
Él ofrece mucho más que solo jugar."
El capitán de Europa, Thomas Bjorn, sabe que una gran ventaja puede desaparecer pronto.
Thomas Bjorn, el capitán europeo, sabe por experiencia que una ventaja considerable al comenzar los partidos individuales del último día en la Ryder Cup puede convertirse fácilmente en una situación incómoda.
El danés debutó en el partido de 1997 en Valderrama, donde un equipo capitaneado por Seve Ballesteros tenía una ventaja de cinco puntos sobre los estadounidenses, pero apenas logró cruzar la línea de meta por delante por un margen mínimo, ganando 14½-13½.
"No dejas de recordarte a ti mismo que teníamos una gran ventaja en Valderrama; "Teníamos una gran ventaja en Brookline, donde perdimos, y en Valderrama, donde ganamos, pero por muy poco", dijo Bjorn, en la foto, después de ver a la Clase de 2018 ganar 5-3 tanto el viernes como ayer para liderar 10-6 en Le Golf National.
Así que la historia nos demostrará a mí y a todos los que formamos parte de ese equipo que esto no ha terminado.
Mañana irás a toda máquina.
Sal ahí fuera y haz todo lo correcto.
Esto no termina hasta que hayas conseguido los puntos en el marcador.
Tenemos un objetivo, y es intentar ganar este trofeo, y ahí es donde mantenemos la concentración.
Siempre he dicho que me centro en los 12 jugadores de nuestro equipo, pero somos muy conscientes de lo que nos espera al otro lado: los mejores jugadores del mundo.
Encantado con el rendimiento de sus jugadores en un campo de golf difícil, Bjorn añadió: "Nunca me confiaría demasiado en este asunto".
Mañana será otra historia.
Mañana se presentarán las actuaciones individuales, y eso es algo diferente.
Es fantástico estar ahí con un compañero cuando las cosas van bien, pero cuando estás ahí solo, se pone a prueba al máximo tu capacidad como golfista.
Ese es el mensaje que hay que transmitir a los jugadores: den lo mejor de sí mismos mañana.
Ahora, dejas atrás a tu pareja y él también tiene que esforzarse por dar lo mejor de sí mismo.
A diferencia de Bjorn, su homólogo Jim Furyk esperará que sus jugadores rindan mejor individualmente que como compañeros, con la excepción de Jordan Spieth y Justin Thomas, que consiguieron tres puntos de cuatro posibles.
El propio Furyk ha vivido en carne propia esas grandes remontadas de última hora, ya que formó parte del equipo ganador en Brookline antes de acabar perdiendo cuando Europa protagonizó el "Milagro de Medinah".
"Recuerdo cada maldita palabra", dijo en respuesta a la pregunta de cómo Ben Crenshaw, el capitán en 1999, había motivado a sus jugadores de cara al último día.
"Mañana tenemos 12 partidos importantes, pero nos gustaría empezar con buen pie, como vimos en Brookline, como vimos en Medinah."
Cuando ese impulso se dirige hacia una dirección, ejerce mucha presión sobre los partidos intermedios.
Preparamos nuestra alineación en consecuencia y colocamos a los jugadores de la manera que sentíamos que, ya sabes, íbamos a intentar hacer algo mágico mañana."
A Thomas se le ha encomendado la tarea de intentar liderar la remontada y se enfrenta a Rory McIlroy en el combate estelar, con Paul Casey, Justin Rose, Jon Rahm, Tommy Fleetwood e Ian Poulter como los otros europeos en la primera mitad del orden.
"Elegí a este grupo de chicos en este orden porque creo que abarca todo el espectro", dijo Bjorn sobre su selección de individuales.
El lanzamiento del nuevo buque de guerra alemán se pospone una vez más.
La fragata más nueva de la Armada alemana debería haber entrado en servicio en 2014 para reemplazar a los buques de guerra obsoletos de la Guerra Fría, pero no estará lista hasta al menos el año que viene debido a fallos en los sistemas y al aumento descontrolado de los costes, según informaron los medios locales.
Según el diario Die Zeit, que cita a un portavoz militar, la puesta en servicio del "Rheinland-Pfalz", el buque insignia de la nueva clase de fragatas Baden-Württemberg, se ha pospuesto hasta el primer semestre de 2019.
El buque debería haberse incorporado a la Armada en 2014, pero los preocupantes problemas posteriores a la entrega empañaron el destino de este ambicioso proyecto.
Los cuatro buques de la clase Baden-Württemberg que la Armada encargó en 2007 sustituirán a las antiguas fragatas de la clase Bremen.
Se entiende que contarán con un potente cañón, una variedad de misiles antiaéreos y antibuque, así como algunas tecnologías furtivas, como la reducción de las firmas de radar, infrarrojas y acústicas.
Otras características importantes incluyen períodos de mantenimiento más prolongados: debería ser posible desplegar las fragatas más modernas hasta dos años fuera de sus puertos de origen.
Sin embargo, los continuos retrasos implican que los buques de guerra de última generación, que supuestamente permitirán a Alemania proyectar su poder en el extranjero, ya estarán obsoletos cuando entren en servicio, señala Die Zeit.
La desafortunada fragata F125 fue noticia el año pasado, cuando la Armada alemana se negó oficialmente a ponerla en servicio y la devolvió al astillero Blohm & Voss en Hamburgo.
Esta fue la primera vez que la Armada devolvió un buque a un astillero después de su entrega.
Se sabía poco sobre los motivos de la devolución, pero los medios alemanes citaron una serie de "defectos de software y hardware" cruciales que hacían que el buque de guerra fuera inútil si se desplegaba en una misión de combate.
Las deficiencias del software eran especialmente importantes, ya que los buques de la clase Baden-Württemberg serán operados por una tripulación de unos 120 marineros, apenas la mitad de la plantilla de las fragatas más antiguas de la clase Bremen.
Además, se descubrió que el buque tiene un sobrepeso considerable, lo que reduce su rendimiento y limita la capacidad de la Armada para incorporar futuras mejoras.
Se cree que el "Rheinland-Pfalz", de 7.000 toneladas, pesa el doble que los buques de clase similar utilizados por los alemanes en la Segunda Guerra Mundial.
Además de los fallos en el hardware, el coste total del proyecto, incluida la formación del equipo, también se está convirtiendo en un problema.
Se dice que alcanzó la asombrosa cifra de 3.100 millones de euros (3.600 millones de dólares), frente a los 2.200 millones de euros iniciales.
Los problemas que afectan a las fragatas más modernas cobran especial importancia a la luz de las recientes advertencias de que el poder naval de Alemania está disminuyendo.
A principios de este año, Hans-Peter Bartels, jefe del comité de defensa del parlamento alemán, reconoció que la Armada se está quedando "sin buques con capacidad de despliegue".
El funcionario afirmó que el problema se ha agravado con el tiempo, debido a que los barcos antiguos fueron dados de baja pero no se proporcionaron buques de reemplazo.
Lamentó que ninguna de las fragatas de la clase Baden-Württemberg hubiera podido incorporarse a la Armada.
El National Trust espía la vida secreta de los murciélagos.
Una nueva investigación que se está llevando a cabo en una finca de las Tierras Altas escocesas tiene como objetivo revelar cómo los murciélagos utilizan el paisaje en su búsqueda de alimento.
Se espera que los hallazgos arrojen nueva luz sobre el comportamiento de estos singulares mamíferos voladores y ayuden a orientar futuras actividades de conservación.
El estudio, a cargo de científicos del National Trust for Scotland, realizará un seguimiento de los murciélagos pipistrelos comunes y enanos, así como de los murciélagos orejudos marrones y de Daubenton, en los jardines de Inverewe, en Wester Ross.
Se colocarán grabadoras especiales en puntos clave de la propiedad para monitorear la actividad de los murciélagos durante toda la temporada.
El personal y los voluntarios del NHS también realizarán encuestas móviles utilizando detectores portátiles.
Un análisis de sonido experto de todas las grabaciones permitirá determinar la frecuencia de los llamados de los murciélagos y qué especies están haciendo qué.
Posteriormente se elaborará un mapa y un informe sobre el hábitat para crear una imagen detallada de su comportamiento a escala del paisaje.
Rob Dewar, asesor de conservación de la naturaleza de NTS, espera que los resultados revelen qué áreas de hábitat son más importantes para los murciélagos y cómo las utiliza cada una de las especies.
Esta información ayudará a determinar los beneficios de las labores de gestión del hábitat, como la creación de prados, y la mejor manera de mantener los bosques para los murciélagos y otras especies asociadas.
Las poblaciones de murciélagos en Escocia y en todo el Reino Unido han disminuido considerablemente durante el último siglo.
Se ven amenazadas por las obras de construcción y desarrollo que afectan a sus dormideros y por la pérdida de hábitat.
Las turbinas eólicas y la iluminación también pueden suponer un riesgo, al igual que las trampas para matamoscas y algunos tratamientos químicos de los materiales de construcción, así como los ataques de gatos domésticos.
Los murciélagos no son ciegos.
Sin embargo, debido a sus hábitos de caza nocturna, sus oídos son más útiles que sus ojos a la hora de atrapar presas.
Utilizan una sofisticada técnica de ecolocalización para detectar insectos y obstáculos en su trayectoria de vuelo.
El NTS, responsable del cuidado de más de 270 edificios históricos, 38 jardines importantes y 76.000 hectáreas de terreno en todo el país, se toma muy en serio la situación de los murciélagos.
Cuenta con diez expertos capacitados que realizan periódicamente estudios, inspecciones de gallineros y, en ocasiones, rescates.
La organización incluso ha creado la primera y única reserva de murciélagos de Escocia en la finca de Threave, en Dumfries y Galloway, que alberga ocho de las diez especies de murciélagos de Escocia.
El administrador de la finca, David Thompson, afirma que la propiedad es el territorio ideal para ellos.
"Aquí en Threave tenemos una zona estupenda para los murciélagos", dijo.
"Tenemos los edificios antiguos, muchos árboles centenarios y un hábitat ideal."
Pero aún se desconocen muchas cosas sobre los murciélagos, por lo que el trabajo que realizamos aquí y en otras propiedades nos ayudará a comprender mejor lo que necesitan para prosperar."
Hace hincapié en la importancia de comprobar si hay murciélagos antes de realizar tareas de mantenimiento en las propiedades, ya que la destrucción involuntaria de un solo nido de cría podría matar hasta 400 hembras y crías, y posiblemente acabar con toda una población local.
Los murciélagos están protegidos y es ilegal matarlos, acosarlos, molestarlos o destruir sus refugios.
Elisabeth Ferrell, responsable en Escocia del Bat Conservation Trust, ha animado al público a colaborar para ayudar.
Ella dijo: "Todavía tenemos mucho que aprender sobre nuestros murciélagos y, en el caso de muchas de nuestras especies, simplemente no sabemos cómo les va a sus poblaciones".
Ronaldo desmiente las acusaciones de violación mientras sus abogados se preparan para demandar a una revista alemana.
Cristiano Ronaldo ha calificado las acusaciones de violación en su contra de "noticias falsas", afirmando que la gente "quiere promocionarse" utilizando su nombre.
Sus abogados tienen previsto demandar a la revista de noticias alemana Der Spiegel, que publicó las acusaciones.
El delantero portugués de la Juventus ha sido acusado de violar a una mujer estadounidense, identificada como Kathryn Mayorga, en una habitación de hotel de Las Vegas en 2009.
Según informó Der Spiegel el viernes, él supuestamente le pagó 375.000 dólares para que guardara silencio sobre el incidente.
En un vídeo en directo de Instagram dirigido a sus 142 millones de seguidores horas después de que se publicaran las acusaciones, Ronaldo, de 33 años, calificó los informes de "noticias falsas".
"No, no, no, no , no.
"Lo que dijeron hoy son noticias falsas", dice el cinco veces ganador del Balón de Oro mirando a la cámara.
"Quieren promocionarse utilizando mi nombre."
Es normal.
Quieren ser famosos para poder decir mi nombre, pero es parte del trabajo.
"Soy un hombre feliz y todo va bien", añadió el jugador sonriendo.
Según Reuters, los abogados de Ronaldo se preparan para demandar a Der Spiegel por las acusaciones, que han calificado de "información inadmisible sobre sospechas en el ámbito de la privacidad".
El abogado Christian Schertz declaró que el jugador solicitaría una indemnización por "daños morales por un monto proporcional a la gravedad de la infracción, que probablemente sea una de las violaciones más graves de los derechos personales de los últimos años".
Se alega que el incidente tuvo lugar en junio de 2009 en una suite del hotel y casino Palms en Las Vegas.
Tras conocerse en una discoteca, Ronaldo y Mayorga regresaron a la habitación del jugador, donde supuestamente él la violó analmente, según consta en los documentos presentados ante el Tribunal de Distrito del Condado de Clark en Nevada.
Mayorga afirma que Ronaldo cayó de rodillas tras el presunto incidente y le dijo que era "un buen tipo" al 99 por ciento, decepcionado por el "uno por ciento".
Los documentos afirman que Ronaldo confirmó que ambos mantuvieron relaciones sexuales, pero que fueron consensuales.
Mayorga también afirma que acudió a la policía y que le tomaron fotografías de sus heridas en un hospital, pero que posteriormente aceptó un acuerdo extrajudicial porque sentía "temor de represalias" y le preocupaba "ser humillada públicamente".
La mujer de 34 años afirma que ahora busca anular el acuerdo, ya que sigue traumatizada por el presunto incidente.
En el momento de la supuesta agresión, Ronaldo estaba a punto de fichar por el Real Madrid procedente del Manchester United, y este verano se trasladó al gigante italiano Juve en una operación de 100 millones de euros.
Brexit: El Reino Unido "lamentaría para siempre" la pérdida de los fabricantes de automóviles.
El secretario de Estado de Comercio, Greg Clark, ha declarado que el Reino Unido "lo lamentaría para siempre" si perdiera su estatus de líder mundial en la fabricación de automóviles tras el Brexit.
Añadió que era "preocupante" que Toyota Reino Unido hubiera comunicado a la BBC que, si Gran Bretaña abandonaba la UE sin un acuerdo, detendría temporalmente la producción en su fábrica de Burnaston, cerca de Derby.
"Necesitamos un acuerdo", dijo el señor Clark.
El fabricante de automóviles japonés afirmó que el impacto de los retrasos en la frontera en caso de un Brexit sin acuerdo podría costar puestos de trabajo.
La planta de Burnaston, donde se fabrican los modelos Auris y Avensis de Toyota, produjo cerca de 150.000 coches el año pasado, de los cuales el 90% se exportaron al resto de la Unión Europea.
"En mi opinión, si Gran Bretaña abandona la UE sin acuerdo a finales de marzo, veremos paradas de producción en nuestra fábrica", dijo Marvin Cooke, director general de Toyota en Burnaston.
Otros fabricantes de automóviles británicos, como Honda, BMW y Jaguar Land Rover, han expresado su preocupación por abandonar la UE sin un acuerdo sobre cómo funcionará el comercio transfronterizo.
BMW, por ejemplo, ha anunciado que cerrará su planta de Mini en Oxford durante un mes tras el Brexit.
Las principales preocupaciones se refieren a lo que los fabricantes de automóviles consideran riesgos para la cadena de suministro en caso de un Brexit sin acuerdo.
La línea de producción de Toyota funciona bajo el sistema "justo a tiempo", con piezas que llegan cada 37 minutos procedentes de proveedores tanto del Reino Unido como de la UE para los coches fabricados bajo pedido.
Si el Reino Unido abandona la UE sin un acuerdo el 29 de marzo, podría haber interrupciones en la frontera que, según el sector, podrían provocar retrasos y escasez de piezas.
Según la empresa, a Toyota le sería imposible mantener en su planta de Derbyshire un inventario superior al de un día, por lo que se detendría la producción.
El señor Clark afirmó que el plan de Chequers de Theresa May para las futuras relaciones con la UE está "calibrado con precisión para evitar esos controles en la frontera".
"Necesitamos llegar a un acuerdo." "Queremos conseguir el mejor acuerdo posible que nos permita, como ya he dicho, no solo disfrutar del éxito actual, sino también aprovechar esta oportunidad", declaró al programa Today de BBC Radio 4.
"Las pruebas, no solo de Toyota sino también de otros fabricantes, demuestran que necesitamos absolutamente poder continuar con lo que ha sido un conjunto de cadenas de suministro altamente exitosas."
Toyota no pudo precisar cuánto tiempo se detendría la producción, pero advirtió a largo plazo que los costes adicionales reducirían la competitividad de la planta y, en última instancia, provocarían la pérdida de puestos de trabajo.
Peter Tsouvallaris, que lleva 24 años trabajando en Burnaston y es el coordinador del sindicato Unite en la planta, dijo que sus miembros están cada vez más preocupados: "Según mi experiencia, una vez que se pierden estos puestos de trabajo, nunca vuelven."
Un portavoz del gobierno declaró: "Hemos presentado un plan preciso y creíble para nuestra futura relación con la UE".
La Casa Blanca afirma que la reunión de Trump con Rosenstein podría retrasarse de nuevo.
La crucial reunión de Donald Trump con el subsecretario de Justicia, Rod Rosenstein, podría "posponerse otra semana" mientras continúa la disputa por el nombramiento de Brett Kavanaugh para la Corte Suprema, informó la Casa Blanca el domingo.
Rosenstein supervisa el trabajo del fiscal especial Robert Mueller, quien investiga la injerencia rusa en las elecciones, los vínculos entre los asesores de Trump y Rusia, y la posible obstrucción a la justicia por parte del presidente.
La cuestión de si Trump despedirá o no al subsecretario de Justicia, poniendo así en peligro la independencia de Mueller, ha alimentado los rumores en Washington durante meses.
A principios de este mes, el New York Times informó que Rosenstein había hablado sobre la posibilidad de llevar un micrófono oculto para grabar conversaciones con Trump y sobre la posibilidad de destituir al presidente mediante la enmienda número 25.
Rosenstein negó la información.
Pero el lunes pasado acudió a la Casa Blanca, en medio de rumores de que estaba a punto de dimitir.
En cambio, se anunció una reunión con Trump, que en ese momento se encontraba en las Naciones Unidas en Nueva York, para el jueves.
Trump dijo que "preferiría no" despedir a Rosenstein, pero luego la reunión se retrasó para evitar un conflicto con la audiencia del comité judicial del Senado en la que testificaron Kavanaugh y una de las mujeres que lo han acusado de conducta sexual inapropiada, la Dra. Christine Blasey Ford.
El viernes, Trump ordenó una investigación del FBI de una semana sobre las acusaciones contra Kavanaugh, lo que retrasó aún más la votación en el pleno del Senado.
La secretaria de prensa de Trump, Sarah Sanders, apareció en Fox News el domingo.
Al ser preguntada sobre la reunión con Rosenstein, dijo: "Aún no se ha fijado una fecha, podría ser esta semana, o podría posponerse otra semana dadas todas las demás cosas que están sucediendo con la Corte Suprema."
Pero ya veremos, y siempre me gusta mantener informada a la prensa.
Algunos periodistas refutarían esa afirmación: Sanders no ha ofrecido una rueda de prensa en la Casa Blanca desde el 10 de septiembre.
El presentador Chris Wallace preguntó por qué.
Sanders afirmó que la escasez de ruedas de prensa no se debía a una aversión hacia los "protagonismos" de los reporteros de televisión, aunque añadió: "No voy a negar que busquen protagonismo".
A continuación, sugirió que aumentará el contacto directo entre Trump y la prensa.
"El presidente realiza más sesiones de preguntas y respuestas que cualquier presidente anterior", dijo, y agregó sin citar pruebas: "Hemos analizado esas cifras".
Sanders afirmó que las ruedas de prensa seguirán celebrándose, pero que "si la prensa tiene la oportunidad de hacerle preguntas directamente al presidente de los Estados Unidos, eso es infinitamente mejor que hablar conmigo".
Intentamos hacerlo mucho, y lo han visto hacer mucho en las últimas semanas, y eso va a sustituir a una rueda de prensa en la que se puede hablar con el presidente de los Estados Unidos."
Trump suele responder preguntas al salir de la Casa Blanca o al participar en sesiones abiertas o conferencias de prensa con dignatarios visitantes.
Las ruedas de prensa en solitario son poco frecuentes.
Esta semana, en Nueva York, el presidente quizás demostró por qué, haciendo una aparición espontánea y por momentos extravagante ante los periodistas allí reunidos.
El secretario de salud escribe a los trabajadores de la UE en el NHS Scotland sobre los temores relacionados con el Brexit.
El Secretario de Salud ha escrito al personal de la UE que trabaja en el Servicio Nacional de Salud de Escocia para expresar la gratitud del país y el deseo de que permanezcan en sus puestos tras el Brexit.
Jeane Freeman, miembro del Parlamento escocés, envió una carta a menos de seis meses de que el Reino Unido se retire de la UE.
El Gobierno escocés ya se ha comprometido a sufragar el coste de las solicitudes de residencia permanente para los ciudadanos de la UE que trabajan en sus servicios públicos descentralizados.
En su carta, la Sra. Freeman escribió: "Durante el verano, las negociaciones entre el Reino Unido y la UE sobre la retirada han continuado, encaminándose hacia las decisiones previstas para este otoño."
Pero el Gobierno británico también ha intensificado sus preparativos ante un posible escenario sin acuerdo.
Sé que este debe ser un momento muy inquietante para todos ustedes.
Por eso quería reiterar ahora lo mucho que valoro la contribución de cada miembro del personal, independientemente de su nacionalidad.
Los compañeros procedentes de toda la UE, y de otros países, aportan una valiosa experiencia y habilidades que fortalecen y mejoran el trabajo del servicio de salud, y que benefician a los pacientes y a las comunidades a las que servimos.
Escocia es sin duda tu hogar y nos encantaría que te quedaras aquí.
Christion Abercrombie es sometido a una cirugía de emergencia tras sufrir una lesión en la cabeza.
El linebacker de los Tennessee State Tigers, Christion Abercrombie, fue sometido a una cirugía de emergencia tras sufrir una lesión en la cabeza en la derrota del sábado por 31-27 ante los Vanderbilt Commodores, según informó Mike Organ del Tennessean.
El entrenador de Tennessee State, Rod Reed, declaró a los periodistas que la lesión se produjo poco antes del descanso.
"Se acercó a la banda y simplemente se desplomó allí", dijo Reed.
Los entrenadores y el personal médico le administraron oxígeno a Abercrombie en la banda antes de colocarlo en una camilla y llevarlo de vuelta para una evaluación más exhaustiva.
Un funcionario de la Universidad Estatal de Tennessee le dijo a Chris Harris de WSMV en Nashville, Tennessee, que Abercrombie ya había salido de la cirugía en el Centro Médico Vanderbilt.
Harris añadió que "aún no hay detalles sobre el tipo o la gravedad de la lesión" y que la Universidad Estatal de Tennessee está tratando de averiguar cuándo se produjo la lesión.
Abercrombie, estudiante de segundo año con estatus de "redshirt" (jugador que no compite en su primer año universitario), está en su primera temporada con Tennessee State tras su transferencia desde Illinois.
El sábado realizó un total de cinco placajes antes de abandonar el partido, lo que elevó su total de placajes en la temporada a 18.
Los compradores extranjeros deberán pagar un impuesto de timbre más alto al comprar una propiedad en el Reino Unido.
Los compradores extranjeros pagarán un impuesto de timbre más alto cuando compren una propiedad en el Reino Unido, y el dinero extra se utilizará para ayudar a las personas sin hogar según los nuevos planes de los conservadores.
Esta medida neutralizará el éxito de la campaña de Corbyn para atraer a los votantes jóvenes.
El aumento del impuesto de timbre se aplicará a quienes no paguen impuestos en el Reino Unido.
El Tesoro prevé recaudar hasta 120 millones de libras esterlinas al año para ayudar a las personas sin hogar.
Los compradores extranjeros tendrán que pagar un impuesto de timbre más alto al comprar propiedades en el Reino Unido, y el dinero extra se destinará a ayudar a las personas sin hogar, según anunciará hoy Theresa May.
Esta medida será vista como un intento de neutralizar el éxito de la campaña de Jeremy Corbyn para atraer a los votantes jóvenes con promesas de proporcionar viviendas más asequibles y dirigirse a las personas con mayores ingresos.
El aumento del impuesto de timbre se aplicará a las personas físicas y jurídicas que no paguen impuestos en el Reino Unido, y el dinero adicional reforzará la campaña del Gobierno para combatir la indigencia.
El recargo, que se suma al impuesto de timbre actual, incluidos los niveles más altos introducidos hace dos años para las segundas residencias y las propiedades destinadas al alquiler, podría llegar a ser de hasta un tres por ciento.
El Tesoro prevé que esta medida genere hasta 120 millones de libras esterlinas al año.
Se estima que el 13% de las propiedades de nueva construcción en Londres son adquiridas por personas que no residen en el Reino Unido, lo que eleva los precios y dificulta que los compradores primerizos puedan acceder al mercado inmobiliario.
Muchas zonas acomodadas del país, especialmente en la capital, se han convertido en "ciudades fantasma" debido a la gran cantidad de compradores extranjeros que pasan la mayor parte del tiempo fuera del país.
La nueva política llega apenas unas semanas después de que Boris Johnson pidiera una reducción del impuesto de timbre para ayudar a más jóvenes a comprar su primera vivienda.
Acusó a las grandes constructoras de mantener altos los precios de la vivienda acaparando terrenos sin utilizarlos, e instó a la Sra. May a abandonar las cuotas de viviendas asequibles para solucionar la "vergüenza de la vivienda" en Gran Bretaña.
El señor Corbyn ha anunciado una serie de llamativas propuestas de reforma de la vivienda, que incluyen el control de los alquileres y el fin de los desahucios "sin causa justificada".
También quiere otorgar mayores poderes a los ayuntamientos para construir nuevas viviendas.
La señora May dijo: "El año pasado dije que dedicaría mi mandato como primera ministra a restaurar el sueño británico: que la vida sea mejor para cada nueva generación."
Y eso significa arreglar nuestro mercado inmobiliario disfuncional.
Gran Bretaña siempre estará abierta a las personas que deseen vivir, trabajar y construir una vida aquí.
Sin embargo, no puede ser justo que a las personas que no viven en el Reino Unido, así como a las empresas extranjeras, les resulte tan fácil comprar una vivienda como a los residentes británicos que trabajan duro.
Para demasiadas personas, el sueño de tener una vivienda propia se ha vuelto demasiado lejano, y la indignidad de dormir en la calle sigue siendo una realidad innegable.
Jack Ross: "Mi máxima ambición es dirigir a Escocia".
El técnico del Sunderland, Jack Ross, afirma que su "máxima ambición" es convertirse en seleccionador de Escocia en algún momento.
El escocés, de 42 años, afronta con entusiasmo el reto de revitalizar al club del noreste, que actualmente ocupa el tercer puesto en la League One, a tres puntos del líder.
Se trasladó al Stadium of Light este verano tras haber guiado al St Mirren de vuelta a la Premiership escocesa la temporada pasada.
"Quería jugar para mi país como futbolista."
"Obtuve una calificación B y eso fue todo", dijo Ross a Sportsound de la BBC Escocia.
"Pero de niño, cuando era pequeño, veía mucho a Escocia en Hampden con mi padre, y siempre ha sido algo que me ha atraído de nuevo."
Sin embargo, esa oportunidad solo se presentaría si tuviera éxito en la gestión del club.
Entre los predecesores de Ross como entrenador del Sunderland se encuentran Dick Advocaat, David Moyes, Sam Allardyce, Martin O'Neill, Roy Keane, Gus Poyet y Paulo Di Canio.
El exentrenador del Alloa Athletic afirma que no sintió ninguna aprensión al suceder a nombres tan consagrados en un club tan grande, tras haber rechazado previamente ofertas del Barnsley y del Ipswich Town.
"Para mí, el éxito en este momento se medirá por la pregunta: '¿Podré devolver a este club a la Premier League?'"
"Por la estructura y las instalaciones de este club, sin duda pertenece a la Premier League", afirmó.
"No es tarea fácil lograrlo, pero probablemente solo me consideraría exitoso aquí si consigo que el club vuelva a estar en la cima."
Ross lleva tan solo tres años como entrenador, tras un periodo como segundo entrenador en el Dumbarton y una etapa de 15 meses en el cuerpo técnico del Hearts.
Posteriormente, ayudó al Alloa a recuperarse del descenso a la tercera división y, la temporada siguiente, transformó al St Mirren, que estaba al borde del descenso, en campeón de la Championship.
Ross afirma sentirse más cómodo ahora que nunca durante su carrera como jugador en Clyde, Hartlepool, Falkirk, St Mirren y Hamilton Academical.
"Probablemente fue una verdadera encrucijada", recordó al hablar de hacerse cargo de Alloa.
"Sinceramente creía que la gestión era lo que mejor me convenía, más que jugar."
Suena extraño porque me fue bien, me gané la vida decentemente con ello y disfruté de momentos de euforia.
Pero jugar puede ser difícil.
Hay muchas cosas que tienes que superar cada semana.
Todavía experimento ese estrés y presión en el trabajo, pero la gestión me parece la adecuada.
Siempre quise ser directora y ahora lo estoy siendo; me siento más cómoda conmigo misma que nunca en toda mi vida adulta."
Podrás escuchar la entrevista completa en Sportsound el domingo 30 de septiembre, en Radio Scotland, entre las 12:00 y las 13:00 BST.
Según una encuesta, el momento perfecto para tomar una pinta es a las 17:30 del sábado.
La ola de calor veraniega ha impulsado la recaudación de los pubs británicos, que atraviesan dificultades, pero ha ejercido aún más presión sobre las cadenas de restaurantes.
Las ventas de los grupos de pubs y bares aumentaron un 2,7 por ciento en julio, pero la facturación de los restaurantes cayó un 4,8 por ciento, según revelan las cifras.
Peter Martin, de la consultora empresarial CGA, que recopiló las cifras, dijo: "El sol persistente y la participación de Inglaterra en la Copa del Mundo, más prolongada de lo esperado, hicieron que julio siguiera un patrón similar al del mes anterior, junio, cuando los pubs registraron un aumento del 2,8 por ciento, con la excepción de que los restaurantes se vieron aún más afectados."
La caída del 1,8 por ciento en la actividad de los restaurantes durante junio no hizo más que empeorar en julio.
Los pubs y bares centrados en la venta de bebidas registraron, con diferencia, los mejores resultados, con un aumento en las ventas comparables superior al descenso de los restaurantes.
Los pubs centrados en la comida también sufrieron las consecuencias del sol, aunque no de forma tan drástica como los restaurantes.
Parece que la gente solo quería salir a tomar algo.
En los pubs y bares gestionados, las ventas de bebidas aumentaron un 6,6 por ciento durante el mes, mientras que las de comida disminuyeron un tres por ciento.
Paul Newman, de la firma de análisis de ocio y hostelería RSM, dijo: "Estos resultados continúan la tendencia que hemos visto desde finales de abril."
El clima y el impacto de los grandes eventos sociales o deportivos siguen siendo los factores más importantes a la hora de influir en las ventas en el mercado de la publicidad exterior.
No sorprende que los grupos de restauración sigan teniendo dificultades, si bien una caída de las ventas del 4,8 por ciento interanual será especialmente dolorosa, sumada a las continuas presiones de costes.
El largo y caluroso verano no podría haber llegado en peor momento para los negocios del sector de la alimentación, y solo el tiempo dirá si las temperaturas más moderadas que hemos experimentado en agosto proporcionarán un respiro muy necesario.
El crecimiento total de las ventas en pubs y restaurantes, incluidas las nuevas aperturas, fue del 2,7 por ciento en julio, lo que refleja la desaceleración en el lanzamiento de nuevas marcas.
El Coffer Peach Tracker, el monitor de ventas del sector de pubs, bares y restaurantes del Reino Unido, recopila y analiza datos de rendimiento de 47 grupos operativos, con una facturación combinada de más de 9.000 millones de libras esterlinas, y es el referente establecido del sector.
Uno de cada cinco niños tiene cuentas secretas en redes sociales que oculta a sus padres.
Una encuesta revela que uno de cada cinco niños, algunos de tan solo 11 años, tiene cuentas secretas en redes sociales que ocultan a sus padres y profesores.
Una encuesta realizada a 20.000 alumnos de secundaria reveló un aumento en las páginas de "Instagram falsas".
La noticia ha aumentado los temores de que se esté publicando contenido sexual.
El veinte por ciento de los alumnos dijo tener una cuenta "principal" para mostrar a sus padres.
Uno de cada cinco niños, algunos de tan solo 11 años, crea cuentas en redes sociales que mantiene en secreto para los adultos.
Una encuesta realizada a 20.000 alumnos de secundaria reveló un rápido crecimiento de las cuentas "falsas de Insta", en referencia a la plataforma para compartir fotos Instagram.
La noticia ha aumentado los temores de que se esté publicando contenido sexual.
El veinte por ciento de los alumnos afirmó utilizar una cuenta "principal" ficticia para mostrar a sus padres, además de tener cuentas privadas.
Una madre que se topó con el sitio web secreto de su hija de 13 años encontró a una adolescente incitando a otros a "violarla".
La investigación, realizada por Digital Awareness UK y la Conferencia de Directores y Directoras de Colegios Independientes (HMC, por sus siglas en inglés), reveló que el 40 por ciento de los jóvenes de entre 11 y 18 años tenían dos perfiles, y la mitad de ellos admitió tener cuentas privadas.
El director de HMC, Mike Buchanan, dijo: "Es preocupante que tantos adolescentes se vean tentados a crear espacios en línea donde sus padres y profesores no puedan encontrarlos".
Eilidh Doyle será la "voz de los atletas" en la junta directiva de Scottish Athletics.
Eilidh Doyle ha sido elegida miembro del consejo de administración de Scottish Athletics como consejera no ejecutiva en la asamblea general anual del organismo rector.
Doyle es la atleta escocesa más laureada en atletismo, y el presidente Ian Beattie describió este cambio como una gran oportunidad para que quienes dirigen este deporte se beneficien de su amplia experiencia a nivel internacional durante la última década.
"Eilidh goza de un enorme respeto en la comunidad atlética escocesa, británica y mundial, y estamos seguros de que el atletismo en Escocia se beneficiaría enormemente con su incorporación a la junta directiva", dijo Beattie.
Doyle declaró: "Tengo muchas ganas de ser la voz de los atletas y espero poder contribuir de verdad y ayudar a guiar este deporte en Escocia".
El estadounidense, que ganó los 200 y 400 metros en los Juegos Olímpicos de Atlanta 1996, entre sus cuatro medallas de oro olímpicas, y que ahora es comentarista habitual de la BBC, quedó incapacitado para caminar tras sufrir un ataque isquémico transitorio.
Escribió en Twitter: "Hoy hace un mes sufrí un derrame cerebral.
No podía caminar.
Los médicos dijeron que solo el tiempo dirá si me recuperaré y en qué medida.
Ha sido un trabajo agotador, pero me he recuperado por completo, he vuelto a aprender a caminar y hoy estoy haciendo ejercicios de agilidad.
¡Gracias por los mensajes de ánimo!
Un anuncio de un extractor de leche que compara a las madres con vacas genera controversia en internet.
Una empresa de extractores de leche materna ha generado controversia en internet con un anuncio que compara a las madres lactantes con vacas que están siendo ordeñadas.
Para conmemorar el lanzamiento de lo que se considera "el primer extractor de leche portátil y silencioso del mundo", la empresa de tecnología de consumo Elvie publicó un anuncio irónico inspirado en un videoclip musical para mostrar la libertad que el nuevo extractor ofrece a las madres que se extraen leche.
Cuatro madres reales bailan en un establo lleno de heno y vacas al ritmo de una canción con letras como: "Sí, me ordeño a mí misma, pero no ves mi cola" y "Por si no te habías dado cuenta, estas no son ubres, son mis tetas".
El estribillo continúa: "Explóralo, explóralo, estoy alimentando a esos bebés, explóralo, explóralo, estoy ordeñando a mis damas".
Sin embargo, el anuncio, que ha sido publicado en la página de Facebook de la empresa, ha causado polémica en internet.
Con 77.000 visualizaciones y cientos de comentarios, el vídeo ha recibido reacciones encontradas por parte de los espectadores, muchos de los cuales afirman que trivializa los "horrores" de la industria láctea.
"Una decisión muy desacertada usar vacas para publicitar este producto."
"Al igual que nosotras, necesitan quedar embarazadas y dar a luz para producir leche, solo que les roban a sus bebés a los pocos días de nacer", escribió una persona.
El extractor de leche Elvie se adapta discretamente al interior de un sujetador de lactancia (Elvie/Mother).
Otro comentó: "Es comprensible que haya sido traumático tanto para la madre como para el bebé".
Pero sí, ¿por qué no usarlos para anunciar un sacaleches para madres que pueden quedarse con sus bebés?
Otra persona añadió: "Un anuncio totalmente fuera de lugar".
Otros defendieron el anuncio, y una mujer admitió que la canción le pareció "divertidísima".
"Creo que esta es una idea genial."
Me habría hecho uno si todavía estuviera dando el pecho.
La extracción me hizo sentir exactamente como una vaca.
El anuncio es un poco descabellado, pero lo tomé como lo que era.
"Este es un producto genial", escribió alguien.
Otro comentó: "Este es un anuncio divertido dirigido a las madres que se extraen leche (a menudo en sus lugares de trabajo o baños) y se sienten como "vacas".
Esto no es un anuncio que elogie ni que juzgue a la industria láctea.
Al final del vídeo, el grupo de mujeres revela que todas han estado bailando con los discretos zapatos de tacón metidos en sus sujetadores.
El concepto que hay detrás de la campaña se basa en la idea de que muchas mujeres que se extraen leche materna dicen sentirse como vacas.
Sin embargo, el extractor de leche Elvie Pump es completamente silencioso, no tiene cables ni tubos y se ajusta discretamente dentro de un sujetador de lactancia, lo que brinda a las mujeres la libertad de moverse, sostener a sus bebés e incluso salir mientras se extraen leche.
Ana Balarin, socia y directora creativa ejecutiva de Mother, comentó: "El extractor de leche Elvie es un producto tan revolucionario que merecía un lanzamiento audaz y provocador."
Al establecer un paralelismo entre la extracción de leche materna y las vacas lecheras, quisimos poner en el punto de mira la extracción de leche y todos sus retos, al tiempo que demostrábamos de una manera entretenida y cercana la increíble sensación de libertad que aportará el nuevo extractor.
Esta no es la primera vez que la bomba Elvie aparece en los titulares.
Durante la Semana de la Moda de Londres, una madre de dos hijos desfiló para la diseñadora Marta Jakubowski utilizando el producto.
Cientos de niños migrantes fueron trasladados discretamente a un campamento de tiendas de campaña en la frontera de Texas.
El número de niños migrantes detenidos se ha disparado a pesar de que los cruces fronterizos mensuales se han mantenido relativamente sin cambios, en parte porque la dura retórica y las políticas introducidas por la administración Trump han dificultado la colocación de niños con patrocinadores.
Tradicionalmente, la mayoría de los patrocinadores han sido inmigrantes indocumentados y temían poner en peligro su propia capacidad de permanecer en el país al presentarse como beneficiarios de un niño.
El riesgo aumentó en junio, cuando las autoridades federales anunciaron que los posibles patrocinadores y otros miembros adultos de sus hogares tendrían que presentar sus huellas dactilares, y que esos datos se compartirían con las autoridades de inmigración.
La semana pasada, Matthew Albence, un alto funcionario del Servicio de Inmigración y Control de Aduanas, testificó ante el Congreso que la agencia había arrestado a decenas de personas que solicitaron patrocinar a menores no acompañados.
Posteriormente, la agencia confirmó que el 70 por ciento de los arrestados no tenían antecedentes penales.
"Cerca del 80 por ciento de las personas que son patrocinadores o miembros del hogar de los patrocinadores se encuentran en el país de forma ilegal, y una gran parte de ellos son inmigrantes con antecedentes penales."
"Así que seguimos investigando a esas personas", dijo el Sr. Albence.
Con el objetivo de agilizar los trámites para los niños, las autoridades introdujeron nuevas normas que obligarán a algunos de ellos a comparecer ante el tribunal en el plazo de un mes desde su detención, en lugar de después de 60 días, que era el plazo habitual, según informaron los trabajadores del centro de acogida.
Muchos comparecerán por videoconferencia, en lugar de en persona, para exponer su caso ante un juez de inmigración y solicitar así su estatus legal.
Quienes sean considerados no aptos para recibir ayuda serán deportados de inmediato.
Cuanto más tiempo permanecen los niños bajo custodia, mayor es la probabilidad de que desarrollen ansiedad o depresión, lo que puede provocar arrebatos violentos o intentos de fuga, según los trabajadores de los albergues y los informes que han surgido del sistema en los últimos meses.
Los defensores afirman que esas preocupaciones se acentúan en un centro más grande como Tornillo, donde, debido a su tamaño, es más probable que se pasen por alto las señales de que un niño está teniendo dificultades.
Añadieron que trasladar a los niños al campamento de tiendas de campaña sin darles tiempo suficiente para prepararlos emocionalmente o para despedirse de sus amigos podría agravar el trauma con el que muchos ya están lidiando.
Siria exige a las "fuerzas de ocupación" estadounidenses, francesas y turcas que se retiren de inmediato.
En su intervención ante la Asamblea General de la ONU, el ministro de Asuntos Exteriores, Walid al-Moualem, también hizo un llamamiento a los refugiados sirios para que regresen a casa, a pesar de que la guerra en el país ya lleva ocho años.
Moualem, quien también funge como viceprimer ministro, dijo que las fuerzas extranjeras se encontraban ilegalmente en territorio sirio, con el pretexto de luchar contra el terrorismo, y que "se actuará en consecuencia".
"Deben retirarse de inmediato y sin condiciones", declaró ante la asamblea.
Moualem insistió en que la "guerra contra el terror está casi terminada" en Siria, donde más de 360.000 personas han muerto desde 2011 y millones más han sido desplazadas de sus hogares.
Dijo que Damasco continuaría "librando esta batalla sagrada hasta que purguemos todos los territorios sirios" de grupos terroristas y de "cualquier presencia extranjera ilegal".
Estados Unidos tiene unos 2.000 soldados en Siria, que se dedican principalmente a entrenar y asesorar tanto a las fuerzas kurdas como a los árabes sirios que se oponen al presidente Bashar al-Assad.
Francia tiene más de 1.000 soldados desplegados sobre el terreno en el país asolado por la guerra.
Sobre el tema de los refugiados, Moualem dijo que las condiciones eran adecuadas para que regresaran, y culpó a "algunos países occidentales" de "sembrar temores irracionales" que provocaron que los refugiados se mantuvieran alejados.
"Hemos hecho un llamamiento a la comunidad internacional y a las organizaciones humanitarias para que faciliten estos retornos", declaró.
"Están politizando lo que debería ser una cuestión puramente humanitaria."
Estados Unidos y la Unión Europea han advertido que no habrá ayuda para la reconstrucción de Siria hasta que se alcance un acuerdo político entre Assad y la oposición para poner fin a la guerra.
Según diplomáticos de la ONU, un reciente acuerdo entre Rusia y Turquía para establecer una zona de amortiguación en Idlib, el último gran bastión rebelde, ha creado una oportunidad para impulsar las conversaciones políticas.
El acuerdo ruso-turco evitó un ataque a gran escala por parte de las fuerzas sirias respaldadas por Rusia contra la provincia, donde viven tres millones de personas.
Sin embargo, Moualem recalcó que el acuerdo tenía "plazos claros" y expresó su esperanza de que la acción militar se dirija contra los yihadistas, incluidos los combatientes del Frente Nusra, vinculado a Al-Qaeda, que "serán erradicados".
El enviado de la ONU, Staffan de Mistura, espera convocar próximamente las primeras reuniones de un nuevo comité integrado por miembros del gobierno y de la oposición para redactar una constitución de posguerra para Siria y allanar el camino hacia las elecciones.
Moualem estableció las condiciones para la participación del gobierno sirio en el comité, afirmando que el trabajo del panel debería limitarse a "revisar los artículos de la constitución vigente" y advirtió contra cualquier injerencia.
Por qué Trump ganará un segundo mandato
Según esa lógica, el Sr. Trump ganaría la reelección en 2020 a menos que, como muchos espectadores liberales probablemente esperan, el juicio político y el escándalo pongan fin prematuramente a su presidencia.
¡En lo que sin duda sería "¡El final más dramático de una presidencia de todos los tiempos!"
Hasta el momento, no hay señales de cansancio por parte de los espectadores.
Desde 2014, los índices de audiencia en horario estelar se han duplicado con creces, alcanzando los 1,05 millones de espectadores en CNN, y casi se han triplicado, llegando a los 1,6 millones en MSNBC.
Fox News tiene un promedio de 2,4 millones de espectadores en horario estelar, frente a los 1,7 millones de hace cuatro años, según Nielsen, y "The Rachel Maddow Show" de MSNBC ha liderado las audiencias de la televisión por cable con hasta 3,5 millones de espectadores en las principales noches de noticias.
"Este es un incendio que atrae a la gente porque no es algo que entendamos", dijo Neal Baer, ​​productor ejecutivo del drama de ABC "Designated Survivor", sobre un secretario del gabinete que se convierte en presidente después de que un ataque destruye el Capitolio.
Nell Scovell, guionista de comedia veterana y autora de "Just the Funny Parts: And a Few Hard Truths About Sneaking Into the Hollywood Boys Club", tiene otra teoría.
Recuerda un viaje en taxi por Boston antes de las elecciones de 2016.
El conductor le dijo que votaría por el señor Trump.
¿Por qué? Ella preguntó.
"Él dijo: 'Porque me hace reír'", me contó la Sra. Scovell.
El caos tiene su encanto.
Por supuesto, a diferencia de cualquier otra cosa en la televisión, las historias que surgen de Washington podrían determinar el futuro de Roe v. Wade, si las familias inmigrantes pueden reunirse y la salud de la economía global.
Desconectarse es un lujo que solo los espectadores más privilegiados pueden permitirse.
Y sin embargo, va más allá de ser un ciudadano informado cuando te encuentras en la sexta hora viendo a un panel de expertos debatir el uso que hace Bob Woodward de fuentes de "fondo profundo" para su libro "Miedo,"La chaqueta bomber de piel de avestruz de 15.000 dólares de Paul Manafort ("una prenda rebosante de arrogancia", dijo The Washington Post) y las implicaciones de las escabrosas descripciones de Stormy Daniels sobre la, ejem, anatomía del Sr. Trump."
Por mi parte, nunca volveré a ver a Super Mario de la misma manera.
"Parte de lo que está haciendo y que hace que parezca un reality show es que te está dando algo nuevo cada noche,"dijo Brent Montgomery, director ejecutivo de Wheelhouse Entertainment y creador de "Pawn Stars", refiriéndose al elenco rotativo del programa de Trump y a los giros argumentales diarios (como pelearse con la NFL o elogiar a Kim Jong-un).
No puedes permitirte perderte ni un solo episodio o te quedarás atrás.
Cuando contacté con el Sr. Fleiss esta semana, hacía un sol radiante y una temperatura de 27 grados centígrados fuera de su casa en la costa norte de Kauai, pero él estaba encerrado dentro viendo MSNBC mientras grababa CNN.
No podía apartarse del asunto, no con Brett Kavanaugh a punto de comparecer ante el Comité Judicial del Senado y el futuro de la Corte Suprema en juego.
"Recuerdo cuando hacíamos todos esos espectáculos locos hace tiempo y la gente decía: 'Este es el principio del fin de la civilización occidental'", me contó el Sr. Fleiss.
"Pensé que era una especie de broma, pero resulta que tenían razón."
Amy Chozick, columnista habitual de The Times especializada en negocios, política y medios de comunicación, es la autora de las memorias "Chasing Hillary".
El dinero externo inunda las reñidas elecciones de mitad de mandato para la Cámara de Representantes.
No es de extrañar que el distrito 17 de Pensilvania esté recibiendo una avalancha de dinero, gracias a una redistribución de los distritos congresionales que ha provocado que dos legisladores en ejercicio se enfrenten por el mismo escaño.
Este distrito suburbano de Pittsburg, recientemente rediseñado, enfrenta al representante demócrata Conor Lamb, quien ganó su escaño en otro distrito en una elección especial la primavera pasada.
Lamb se enfrenta a otro titular, el republicano Keith Rothfus, que actualmente representa al antiguo distrito 12 de Pensilvania, que se superpone en gran medida con el nuevo distrito 17.
Los mapas se rediseñaron después de que la Corte Suprema de Pensilvania dictaminara en enero que los antiguos distritos habían sido manipulados inconstitucionalmente a favor de los republicanos.
La contienda en el nuevo distrito 17 ha desatado una dura batalla por la financiación de las campañas electorales entre los principales organismos financieros de los partidos, el Comité de Campaña Demócrata del Congreso (DCCC) y el Comité Nacional de Campaña Republicana (NRCC).
Lamb se convirtió en un nombre conocido en Pensilvania tras una ajustada victoria en unas elecciones especiales muy seguidas celebradas en marzo para el 18º distrito congresional de Pensilvania.
Ese escaño había estado en manos de un republicano durante más de una década, y el presidente Donald Trump ganó el distrito por 20 puntos.
Los analistas políticos han otorgado una ligera ventaja a los demócratas.
Estados Unidos sopesó sancionar a El Salvador por su apoyo a China, pero finalmente dio marcha atrás.
Los diplomáticos señalaron que la República Dominicana y Panamá ya habían reconocido a Pekín, con escasa resistencia por parte de Washington.
El Sr. Trump mantuvo una cordial reunión con el presidente de Panamá, Juan Carlos Varela, en junio de 2017 y se alojó en un hotel de Panamá hasta que sus socios desalojaron al equipo directivo de la Organización Trump.
Los funcionarios del Departamento de Estado decidieron llamar de vuelta a los jefes de las misiones diplomáticas estadounidenses en El Salvador. Heather Nauert, portavoz del departamento, declaró a principios de este mes que la República Dominicana y Panamá se han visto envueltas en una disputa por las "recientes decisiones de dejar de reconocer a Taiwán".
Pero las sanciones solo se consideraron contra El Salvador, que recibió aproximadamente 140 millones de dólares en ayuda estadounidense en 2017, incluyendo fondos para el control de narcóticos, el desarrollo y el apoyo económico.
Las sanciones propuestas, que incluían recortes a la ayuda financiera y restricciones selectivas de visados, habrían sido muy dolorosas para el país centroamericano y sus altas tasas de desempleo y homicidios.
A medida que avanzaban las reuniones internas, Funcionarios de Norteamérica y Centroamérica aplazaron una conferencia de alto nivel centrada en la seguridad y la prosperidad económica para dar seguimiento a una reunión similar celebrada el año pasado, que fue vista como un paso adelante en los esfuerzos para impedir que los migrantes se dirijan a Estados Unidos.
Pero a mediados de septiembre, altos funcionarios del gobierno dejaron claro que querían que la conferencia siguiera adelante, poniendo fin de facto a cualquier consideración de sanciones para El Salvador.
Según fuentes diplomáticas, el vicepresidente Mike Pence tiene previsto intervenir en la conferencia, programada para mediados de octubre, lo que demuestra la importancia que la administración otorga a este encuentro.
Y los tres enviados estadounidenses regresaron discretamente a El Salvador, Panamá y la República Dominicana sin nuevos mensajes duros ni castigos por parte de Washington.
Un portavoz de la Casa Blanca en representación del Sr. Bolton declinó hacer comentarios sobre los detalles del debate descritos por los tres funcionarios estadounidenses, incluidos dos diplomáticos, que accedieron a hablar sobre las deliberaciones internas bajo condición de anonimato.
Sus testimonios fueron corroborados por un analista externo cercano a la administración, quien también habló bajo condición de anonimato.
Historia de los estudios
El siguiente paso podría ser la publicación del informe del fiscal especial Robert Mueller sobre la posible obstrucción a la justicia por parte del Sr. Trump, de la cual ya existen pruebas muy sustanciales en los registros públicos.
Según se informa, el Sr. Mueller también está centrando su investigación en si la campaña del Sr. Trump conspiró con Rusia en su ataque contra nuestras elecciones.
Si el Congreso cambia de manos, el Sr. Trump se verá obligado a rendir cuentas ante ese organismo, justo cuando se prepara para comparecer de nuevo ante los votantes, y quizás eventualmente ante un jurado de sus pares.
Son muchas incógnitas, y no pretendo sugerir que la caída del Sr. Trump sea inevitable, ni la de sus homólogos en Europa.
Todos, a ambos lados del Atlántico, debemos tomar decisiones que influirán en la duración de esta lucha.
En 1938, los oficiales alemanes estaban dispuestos a dar un golpe de Estado contra Hitler, si Occidente se hubiera resistido y hubiera apoyado a los checoslovacos en Múnich.
Fracasamos y perdimos la oportunidad de evitar los años de devastación que siguieron.
El curso de la historia gira en torno a esos puntos de inflexión, y la marcha inexorable de la democracia se acelera o se retrasa.
Los estadounidenses se enfrentan ahora a varios de estos puntos de inflexión.
¿Qué haremos si el Sr. Trump despide al Fiscal General Adjunto Rod Rosenstein, el hombre que controla el destino de la investigación del Sr. Mueller?
Rosenstein ha estado en el ojo del huracán desde que este periódico informó que, el año pasado, sugirió grabar en secreto al presidente y especuló sobre su supuesta incapacidad para el cargo.
El señor Rosenstein afirma que la información publicada por The Times es inexacta.
¿Cómo responderemos si la investigación del FBI recientemente solicitada sobre Brett Kavanaugh no es completa ni justa, o si es confirmado para la Corte Suprema a pesar de las acusaciones creíbles de agresión sexual y testimonio deshonesto?
Y, sobre todo, ¿votaremos en las elecciones de mitad de mandato por un Congreso que exija responsabilidades al Sr. Trump?
Si no superamos esas pruebas, la democracia se enfrentará a un largo invierno.
Pero creo que no fracasaremos, gracias a la lección que aprendí en Praga.
Mi madre era una judía checoslovaca que fue deportada a Auschwitz por el mismo régimen nazi que una vez ocupó la residencia de mi embajador.
Sobrevivió, emigró a Estados Unidos y, 60 años después, me envió a encender las velas del Sabbat en aquella mesa con la esvástica.
Con esa herencia, ¿cómo no voy a ser optimista sobre nuestro futuro?
Norman Eisen, investigador sénior de la Brookings Institution, es presidente de Citizens for Responsibility and Ethics in Washington y autor de "The Last Palace: Europe's Turbulent Century in Five Lives and One Legendary House".
Graham Dorrans, del Rangers, se muestra optimista de cara al partido contra el Rapid de Viena.
El Rangers recibe al Rapid de Viena el jueves, sabiendo que una victoria sobre los austriacos, tras el impresionante empate en España contra el Villarreal a principios de este mes, los colocará en una buena posición para clasificarse en el Grupo G de la Europa League.
Una lesión de rodilla impidió que el centrocampista Graham Dorrans hiciera su primera aparición de la temporada hasta el empate 2-2 contra el Villarreal, pero cree que el Rangers puede usar ese resultado como trampolín para lograr cosas más grandes.
"Fue un buen punto para nosotros porque el Villarreal es un buen equipo", dijo el jugador de 31 años.
"Entramos al partido creyendo que podíamos conseguir algo y nos llevamos un punto."
Quizás podríamos haber ganado al final, pero, en general, un empate fue probablemente un resultado justo.
Probablemente ellos fueron mejores en la primera mitad y nosotros salimos en la segunda mitad y fuimos el mejor equipo.
El jueves nos espera otra gran noche europea.
Ojalá podamos conseguir los tres puntos, pero será un partido difícil porque ellos obtuvieron un buen resultado en su último encuentro. Sin embargo, con el apoyo de la afición, estoy seguro de que podemos seguir adelante y conseguir un resultado positivo.
El año pasado fue sin duda duro, entre todo lo que pasó con mis lesiones y los cambios en el propio club, pero ahora se respira un ambiente muy positivo.
El equipo es bueno y los chicos lo están disfrutando mucho; el entrenamiento es bueno.
Esperemos que ahora podamos seguir adelante, dejar atrás la temporada pasada y tener éxito."
Las mujeres están perdiendo el sueño por este temor relacionado con sus ahorros para la jubilación.
A pesar de que los participantes en la encuesta tenían una idea clara de cómo querían ser atendidos, pocas personas hablaban de ello con sus familiares.
Aproximadamente la mitad de las personas que participaron en el estudio de Nationwide dijeron que estaban hablando con sus cónyuges sobre el costo de los cuidados a largo plazo.
Solo el 10 por ciento dijo haber hablado con sus hijos sobre ello.
"La gente quiere que un familiar los cuide, pero no se atreven a hablar del tema", dijo Holly Snyder, vicepresidenta del negocio de seguros de vida de Nationwide.
Aquí es donde empezar.
Habla con tu cónyuge y tus hijos: No puedes preparar a tu familia para que te brinden cuidados si no les comunicas tus deseos con suficiente antelación.
Colabore con su asesor y su familia para analizar dónde y cómo recibir atención médica, ya que esas decisiones pueden ser un factor importante para determinar el costo.
Consulta con tu asesor financiero: Tu asesor también puede ayudarte a encontrar la manera de pagar esos gastos.
Sus opciones de financiación para la atención a largo plazo pueden incluir una póliza de seguro de atención a largo plazo tradicional, una póliza de seguro de vida híbrida con valor en efectivo para ayudar a cubrir estos gastos o el autoaseguro con su propio patrimonio, siempre que tenga el dinero.
Redacte sus documentos legales: Evite problemas legales desde el principio.
Designa a una persona de confianza para que te represente en materia de salud y garantice que los profesionales cumplan tus deseos en caso de que no puedas comunicarte.
Considere también la posibilidad de otorgar un poder notarial para la gestión de sus finanzas.
En caso de incapacidad, usted designaría a una persona de confianza para que tome decisiones financieras en su nombre y se asegure de que sus facturas se paguen.
No olvides los pequeños detalles: imagina que tu padre o madre anciano/a tiene una emergencia médica y va camino al hospital.
¿Podría responder preguntas sobre medicamentos y alergias?
Detalla esos aspectos por escrito para que estés preparado.
"No solo están en juego las cuestiones financieras, sino también quiénes son los médicos", preguntó Martin.
"¿Cuáles son los medicamentos?"
¿Quién cuidará del perro?
Tengan ese plan listo.
Un hombre recibió varios disparos con una carabina de aire comprimido en Ilfracombe.
Un hombre recibió varios disparos con una carabina de aire comprimido cuando regresaba a casa después de una noche de fiesta.
La víctima, de unos 40 años, se encontraba en la zona de Oxford Grove, en Ilfracombe, Devon, cuando recibió disparos en el pecho, el abdomen y la mano.
Los agentes describieron el tiroteo, que tuvo lugar alrededor de las 02:30 BST, como un "acto aleatorio".
La víctima no vio a su agresor.
Sus heridas no revisten gravedad y la policía ha hecho un llamamiento a los testigos.
Terremotos y tsunamis en Indonesia
Al menos 384 personas murieron a causa del potente terremoto y tsunami que azotaron la ciudad indonesia de Palu el viernes, según informaron las autoridades, y se espera que la cifra de muertos aumente.
Debido a la interrupción de las comunicaciones, los equipos de ayuda humanitaria no han podido obtener ninguna información de la regencia de Donggala, una zona al norte de Palu que está más cerca del epicentro del terremoto de magnitud 7,5.
En Palu, más de 16.000 personas fueron evacuadas tras el desastre.
Aquí tienes algunos datos clave sobre Palu y Donggala, en la isla de Sulawesi:
Palu es la capital de la provincia de Sulawesi Central, situada al final de una estrecha bahía en la costa oeste de la isla de Sulawesi, con una población estimada de 379.800 habitantes en 2017.
La ciudad celebraba su 40 aniversario cuando se produjo el terremoto y el tsunami.
Donggala es una regencia que se extiende a lo largo de más de 300 km (180 millas) de costa en el noroeste de la isla de Sulawesi.
La regencia, una región administrativa subordinada a una provincia, tenía una población estimada de 299.200 habitantes en 2017.
La pesca y la agricultura son los pilares de la economía de la provincia de Sulawesi Central, especialmente en la región costera de Donggala.
La extracción de níquel también es importante en la provincia, pero se concentra principalmente en Morowali, en la costa opuesta a Sulawesi.
Según la Agencia de Mitigación de Desastres de Indonesia, Palu y Donggala han sido azotadas por tsunamis varias veces en los últimos 100 años.
En 1938, un tsunami mató a más de 200 personas y destruyó cientos de casas en Donggala.
Un tsunami también azotó la zona occidental de Donggala en 1996, causando nueve muertos.
Indonesia se encuentra en el Cinturón de Fuego del Pacífico, una zona de gran actividad sísmica, y sufre terremotos con regularidad.
Estos son algunos de los principales terremotos y tsunamis de los últimos años:
2004: Un fuerte terremoto en la costa occidental de la provincia indonesia de Aceh, en el norte de Sumatra, el 26 de diciembre, provocó un tsunami que azotó 14 países y causó la muerte de 226.000 personas a lo largo de la costa del Océano Índico, más de la mitad de ellas en Aceh.
2005: Una serie de fuertes terremotos sacudieron la costa occidental de Sumatra a finales de marzo y principios de abril.
Cientos de personas murieron en la isla de Nias, frente a la costa de Sumatra.
2006: Un terremoto de magnitud 6,8 ​​azotó el sur de Java, la isla más poblada de Indonesia, provocando un tsunami que arrasó la costa sur y causó la muerte de casi 700 personas.
2009: Un terremoto de magnitud 7,6 sacudió las cercanías de la ciudad de Padang, capital de la provincia de Sumatra Occidental.
Más de 1.100 personas perdieron la vida.
2010: Un terremoto de magnitud 7,5 sacudió una de las islas Mentawai, frente a la costa de Sumatra, provocando un tsunami de hasta 10 metros que destruyó decenas de aldeas y causó la muerte de alrededor de 300 personas.
2016: Un terremoto de poca profundidad sacudió la regencia de Pidie Jaya en Aceh, causando destrucción y pánico, ya que la población recordó la devastación del mortal terremoto y tsunami de 2004.
En esta ocasión no se produjo ningún tsunami, pero más de 100 personas murieron a causa del derrumbe de edificios.
2018: Fuertes terremotos azotaron la isla turística indonesia de Lombok, causando la muerte de más de 500 personas, principalmente en el lado norte de la isla.
El terremoto destruyó miles de edificios y dejó a miles de turistas temporalmente varados.
El hijo mayor de Sarah Palin fue arrestado por cargos de violencia doméstica.
Track Palin, el hijo mayor de la exgobernadora de Alaska y candidata a la vicepresidencia, Sarah Palin, ha sido arrestado por cargos de agresión.
Palin, de 29 años y residente de Wasilla, Alaska, fue arrestada bajo sospecha de violencia doméstica, obstrucción a la justicia en relación con una denuncia de violencia doméstica y resistencia al arresto, según un informe publicado el sábado por la policía estatal de Alaska.
Según el informe policial, cuando una conocida intentó llamar a la policía para denunciar los supuestos delitos, él le arrebató el teléfono.
Palin permanece detenida en el centro de detención preventiva de Mat-Su y se le ha impuesto una fianza no garantizada de 500 dólares, según informó KTUU.
Compareció ante el tribunal el sábado, donde se declaró "inocente, por supuesto" cuando se le preguntó sobre su declaración, según informó la cadena.
Palin se enfrenta a tres delitos menores de clase A, lo que significa que podría ser encarcelado hasta por un año y multado con 250.000 dólares.
También ha sido acusado de un delito menor de clase B, punible con un día de cárcel y una multa de 2.000 dólares.
No es la primera vez que se presentan cargos penales contra Palin.
En diciembre de 2017, fue acusado de agredir a su padre, Todd Palin.
Su madre, Sarah Palin, llamó a la policía para denunciar el presunto ataque.
El caso se encuentra actualmente ante el Tribunal de Veteranos de Alaska.
En enero de 2016 fue acusado de agresión doméstica, obstrucción a la denuncia de un delito de violencia doméstica y posesión de un arma en estado de embriaguez en relación con el incidente.
Su novia había alegado que él la había golpeado en la cara.
Sarah Palin fue criticada por grupos de veteranos en 2016 tras vincular el comportamiento violento de su hijo con el trastorno de estrés postraumático derivado de su servicio en Irak.
Terremoto y tsunami en Indonesia: cientos de muertos
Al menos 384 personas murieron tras el terremoto que sacudió la isla indonesia de Sulawesi el viernes.
El terremoto de magnitud 7,5 provocó un tsunami y ha destruido miles de viviendas.
Las redes de electricidad y comunicación están caídas y se prevé que el número de víctimas mortales aumente en los próximos días.
El terremoto se produjo en las inmediaciones de la región central de Sulawesi, al noreste de la capital indonesia, Yakarta.
En las redes sociales circulan vídeos que muestran el momento del impacto.
Cientos de personas se habían reunido para un festival en la playa en la ciudad de Palu cuando el tsunami azotó la costa.
Fiscales federales solicitan la inusual pena de muerte para el sospechoso del ataque terrorista en Nueva York.
Los fiscales federales de Nueva York solicitan la pena de muerte para Sayfullo Saipov, el sospechoso del ataque terrorista en la ciudad de Nueva York que dejó ocho muertos; un castigo excepcional que no se ha aplicado en el estado por un delito federal desde 1953.
Saipov, de 30 años, presuntamente utilizó una camioneta alquilada de Home Depot para llevar a cabo un ataque en un carril bici a lo largo de la autopista West Side en el Bajo Manhattan, atropellando a peatones y ciclistas en su camino el 2 de octubre.
Para justificar una sentencia de muerte, Según la notificación de intención de solicitar la pena de muerte, presentada en el Distrito Sur de Nueva York, los fiscales tendrán que demostrar que Saipov mató "intencionalmente" a las ocho víctimas y les infligió "intencionalmente" lesiones corporales graves.
Según el documento judicial, ambos cargos conllevan una posible pena de muerte.
Semanas después del ataque, Un gran jurado federal imputó a Saipov 22 cargos, entre ellos ocho de asesinato en el marco de una organización criminal, un delito que suelen utilizar los fiscales federales en casos de crimen organizado, y un cargo de violencia y destrucción de vehículos de motor.
El ataque requirió "una planificación y premeditación sustanciales", dijeron los fiscales, describiendo la manera en que Saipov lo llevó a cabo como "atroz, cruel y depravada".
"Sayfullo Habibullaevic Saipov causó lesión, "Daños y pérdidas para las familias y amigos de Diego Enrique Angelini, Nicholas Cleves, Ann-Laure Decadt, Darren Drake, Ariel Erlij, Hernan Ferruchi, Hernan Diego Mendoza y Alejandro Damian Pagnucco", indica el aviso de intención.
Cinco de las víctimas eran turistas procedentes de Argentina.
Han pasado diez años desde que el Distrito Sur de Nueva York procesó por última vez un caso de pena de muerte.
El acusado, Khalid Barnes, fue declarado culpable del asesinato de dos traficantes de drogas, pero finalmente fue condenado a cadena perpetua en septiembre de 2009.
La última vez que se aplicó la pena de muerte en un caso federal de Nueva York fue en 1953, para Julius y Ethel Rosenberg, un matrimonio ejecutado tras ser declarados culpables de conspiración para cometer espionaje para la Unión Soviética durante la Guerra Fría dos años antes.
Los dos Rosenberg fueron ejecutados en la silla eléctrica el 19 de junio de 1953.
Según los documentos judiciales, Saipov, originario de Uzbekistán, demostró una falta de remordimiento en los días y meses posteriores al ataque.
Según la policía, el hombre declaró a los investigadores que se sentía bien con lo que había hecho.
Según la acusación, Saipov declaró a las autoridades que se inspiró para llevar a cabo el ataque tras ver vídeos del ISIS en su teléfono.
Según la policía, también solicitó exhibir la bandera del ISIS en su habitación del hospital.
Se ha declarado inocente de los 22 cargos que se le imputan.
David Patton, uno de los defensores públicos federales que representan a Saipov, dijo que están "obviamente decepcionados" con la decisión de la fiscalía.
"Creemos que la decisión de solicitar la pena de muerte en lugar de aceptar una declaración de culpabilidad que conlleve cadena perpetua sin posibilidad de libertad condicional solo prolongará el trauma de estos hechos para todos los implicados", declaró Patton.
El equipo de defensa de Saipov había pedido previamente a la fiscalía que no solicitara la pena de muerte.
Un diputado conservador afirma que Nigel Farage debería estar al frente de las negociaciones del Brexit.
Nigel Farage prometió hoy "movilizar al ejército del pueblo" durante una protesta en la conferencia del Partido Conservador.
El exlíder del UKIP afirmó que los políticos tenían que "sentir la presión" de los euroescépticos, mientras que uno de los propios diputados de Theresa May sugirió que él debería estar al frente de las negociaciones con la UE.
El diputado conservador Peter Bone declaró en la manifestación de Birmingham que el Reino Unido "ya habría salido" de la UE si el Sr. Farage hubiera sido Secretario del Brexit.
Sin embargo, el reto al que se enfrenta la Sra. May para reconciliar a sus filas profundamente divididas se ha visto acentuado por la participación de los conservadores partidarios de la permanencia en la UE en una protesta aparte contra el Brexit en la ciudad.
La primera ministra está teniendo dificultades para mantener en marcha su plan de compromiso de Chequers en medio de los ataques de los partidarios del Brexit, los que defienden la permanencia en la UE y la propia Unión Europea.
Sus aliados insistieron en que seguirá adelante con sus intentos de llegar a un acuerdo con Bruselas a pesar de la reacción negativa, y obligará a los euroescépticos y al Partido Laborista a elegir entre su propuesta y el "caos".
El señor Bone declaró en el mitin de Leave Means Leave en Solihull que quería "tirar Chequers por la borda".
Sugirió que el señor Farage debería haber sido nombrado miembro de la Cámara de los Lores y haberle encomendado la responsabilidad de las negociaciones con Bruselas.
«Si él hubiera estado al mando, ya nos habrían echado», dijo.
El diputado de Wellingborough añadió: "Defenderé el Brexit, pero tenemos que deshacernos de Chequers".
Al exponer su oposición a la UE, dijo: "No luchamos en las guerras mundiales para ser sumisos".
Queremos crear nuestras propias leyes en nuestro propio país.
El señor Bone desestimó las insinuaciones de que la opinión pública hubiera cambiado desde la votación de 2016: "La idea de que el pueblo británico haya cambiado de opinión y quiera permanecer en la UE es completamente falsa".
La conservadora partidaria del Brexit, Andrea Jenkyns, también estuvo presente en la marcha y declaró a los periodistas: "Simplemente digo: Primer Ministro, escuche al pueblo".
'Chequers es impopular entre el público en general, la oposición no va a votar a favor, es impopular entre nuestro partido y nuestros activistas, que son quienes recorren las calles y consiguen que salgamos elegidos en primer lugar.
Por favor, deja Cheques y empieza a escuchar.
En un mensaje contundente dirigido a la señora May, añadió: «Los primeros ministros conservan sus puestos cuando cumplen sus promesas».
El señor Farage declaró en el mitin que los políticos debían "sentir la presión" si estaban a punto de traicionar la decisión tomada en el referéndum de 2016.
«Ahora se trata de una cuestión de confianza entre nosotros, el pueblo, y nuestra clase política», dijo.
«Están intentando traicionar el Brexit y hoy estamos aquí para decirles: "No vamos a permitir que se salgan con la suya"».
En un mensaje dirigido a la multitud entusiasta, añadió: "Quiero que hagáis sentir la presión sobre nuestra clase política, que está a punto de traicionar el Brexit".
«Estamos movilizando al ejército popular de este país, el mismo que nos dio la victoria en el Brexit, y no descansaremos hasta que nos hayamos convertido en un Reino Unido independiente, autónomo y orgulloso».
Mientras tanto, los partidarios de la permanencia en la UE marcharon por Birmingham antes de celebrar una concentración de dos horas en el centro de la ciudad.
Un pequeño grupo de activistas ondeó pancartas de "Tories Against Brexit" (Conservadores contra el Brexit) tras la presentación del grupo este fin de semana.
El lord laborista Adonis se burló de los conservadores por los problemas de seguridad que sufrieron con la aplicación del partido al inaugurarse la conferencia.
«Estas son las personas que nos dicen que pueden tener los sistemas informáticos implementados y toda la tecnología necesaria para Canadá, además de una frontera sin fricciones, para el libre comercio sin fronteras en Irlanda», añadió.
Es una farsa total.
"No existe un Brexit bueno", añadió.
Warren planea analizar seriamente la posibilidad de postularse a la presidencia.
La senadora estadounidense Elizabeth Warren afirma que estudiará detenidamente la posibilidad de presentarse a la presidencia después de las elecciones de noviembre.
Según informa el Boston Globe, la demócrata de Massachusetts habló sobre su futuro durante un encuentro con los ciudadanos en el oeste de Massachusetts el sábado.
Warren, una crítica frecuente del presidente Donald Trump, se presenta a la reelección en noviembre contra el representante estatal republicano Geoff Diehl, quien fue copresidente de la campaña de Trump en Massachusetts en 2016.
Ella ha estado en el centro de las especulaciones sobre la posibilidad de que se enfrente a Trump en 2020.
El evento del sábado por la tarde en Holyoke fue su 36ª reunión con los electores utilizando el formato de asamblea pública desde que Trump asumió el cargo.
Una de las asistentes le preguntó si pensaba presentarse como candidata a la presidencia.
Warren respondió que es hora de que "las mujeres vayan a Washington para arreglar nuestro gobierno disfuncional, y eso incluye a una mujer al frente".
Detenido el acusado por el asesinato a tiros de Sims, de la LSU.
La policía de Baton Rouge, Luisiana, anunció el sábado la detención de un sospechoso en relación con el asesinato a tiros del jugador de baloncesto de la LSU, Wayde Sims, ocurrido el viernes.
El Departamento de Policía de Baton Rouge anunció el arresto de Dyteon Simpson, de 20 años, a las 11 de la mañana. Conferencia de prensa de ET.
El viernes publicaron un vídeo del tiroteo y pidieron ayuda para identificar a un hombre que aparecía en las imágenes.
Sims, de 20 años, fue asesinado a tiros cerca del campus de la Universidad del Sur la madrugada del viernes.
"Wayde Sims sufrió una herida de bala en la cabeza y finalmente falleció a consecuencia de ella", declaró el jefe de policía Murphy J. Paul a los medios de comunicación el sábado, según 247sports.
Wayde intervino para defender a su amigo y Simpson le disparó.
Simpson fue interrogado y admitió haber estado en el lugar de los hechos, portar un arma y haber disparado a Wayde Sims.
Simpson fue arrestado sin incidentes y puesto bajo custodia en el Departamento de Policía de la parroquia de East Baton Rouge.
Sims, un estudiante de tercer año de 1,98 metros de altura que creció en Baton Rouge, jugó en 32 partidos, 10 de ellos como titular, la temporada pasada y promedió 17,4 minutos, 5,6 puntos y 2,9 rebotes por partido.
Gran Premio de Rusia: Lewis Hamilton se acerca al título mundial después de que las órdenes de equipo le dieran la victoria sobre Sebastian Vettel.
Desde el momento en que Valtteri Bottas se clasificó por delante de Lewis Hamilton el sábado, quedó claro que las órdenes de equipo de Mercedes desempeñarían un papel importante en la carrera.
Desde la pole, Bottas tuvo una buena salida y casi dejó a Hamilton en una situación comprometida al defender su posición en las dos primeras curvas e invitar a Vettel a atacar a su compañero de equipo.
Vettel entró primero en boxes y dejó que Hamilton se encontrara con el tráfico al final del pelotón, algo que debería haber sido decisivo.
El Mercedes entró en boxes una vuelta más tarde y salió detrás de Vettel, pero Hamilton se puso por delante tras un duelo rueda a rueda en el que el piloto de Ferrari, a regañadientes, dejó libre el interior, arriesgándose a mantener la posición tras una doble maniobra para defenderse en la tercera curva.
Max Verstappen partió desde la última fila de la parrilla y terminó séptimo al final de la primera vuelta, el día de su 21 cumpleaños.
Luego lideró gran parte de la carrera, cuidando sus neumáticos para buscar un final rápido y adelantar a Kimi Raikkonen para colocarse en cuarta posición.
Finalmente entró en boxes en la vuelta 44, pero no pudo aumentar su ritmo en las ocho vueltas restantes, mientras que Raikkonen se hizo con la cuarta posición.
Es un día difícil porque Valtteri hizo un trabajo fantástico todo el fin de semana y fue un verdadero caballero al decirme que lo dejara pasar.
"El equipo ha hecho un trabajo excepcional para lograr un doblete", dijo Hamilton.
Ese fue un lenguaje corporal realmente malo.
El presidente Donald Trump se burló de la senadora Dianne Feinstein en un mitin el sábado por su insistencia en que no filtró la carta de Christine Blasey Ford en la que acusaba al candidato a la Corte Suprema, Brett Kavanaugh, de agresión sexual.
En un mitin celebrado en Virginia Occidental, el presidente no se refirió directamente al testimonio prestado por Ford ante el Comité Judicial del Senado, sino que comentó que lo que estaba sucediendo en el Senado demostraba que la gente era "mezquina, desagradable y mentirosa".
"Lo único que podría suceder, y a la vez lo maravilloso que está ocurriendo en los últimos días en el Senado, es ver la ira, ver a gente enfadada, mezquina, desagradable y mentirosa", dijo.
"Cuando ves los lanzamientos y las filtraciones y luego dicen "oh, yo no lo hice.
Yo no lo hice.
¿Recordar?
Dianne Feinstein, ¿filtraste información?
Recuerda su respuesta... ¿filtraste el documento? - "oh, oh, ¿qué?
Oh, no.
No tuve ninguna fuga.
Bueno, espera un minuto.
¿Hemos tenido una fuga...?"No, no hemos filtrado nada", añadió, imitando al senador.
Feinstein recibió la carta de Ford en julio, donde se detallaban las acusaciones contra Kavanaugh, y esta se filtró a principios de septiembre; sin embargo, Feinstein negó que la filtración proviniera de su oficina.
"No oculté las acusaciones de la Dra. Ford, no filtré su historia", declaró Feinstein ante el comité, según informó The Hill.
"Me pidió que lo mantuviera en secreto y así lo hice, tal como me pidió."
Pero su negación no pareció sentarle bien al presidente, quien comentó durante el mitin del sábado por la noche: "Les diré algo, ese fue un lenguaje corporal realmente malo".
Quizás no lo hizo, pero ese es el peor lenguaje corporal que he visto en mi vida.
Continuando con su defensa del candidato a la Corte Suprema, quien ha sido acusado de conducta sexual inapropiada por tres mujeres, el presidente sugirió que los demócratas estaban utilizando las acusaciones para sus propios fines.
"Están decididos a recuperar el poder por cualquier medio necesario."
"Ya ven la mezquindad, la maldad; no les importa a quién lastiman, a quién tienen que pisotear para obtener poder y control", informó Mediaite citando las palabras del presidente.
Liga Élite: Dundee Stars 5-3 Belfast Giants
Patrick Dwyer anotó dos goles para los Giants contra Dundee.
Los Dundee Stars se resarcieron de la derrota del viernes en la Elite League contra los Belfast Giants al ganar el partido de vuelta por 5-3 en Dundee el sábado.
Los Giants se adelantaron rápidamente con dos goles gracias a los tantos de Patrick Dwyer y Francis Beauvillier.
Mike Sullivan y Jordan Cownie igualaron el marcador para el equipo local antes de que Dwyer devolviera la ventaja a los Giants.
Francois Bouchard empató para el Dundee antes de que dos goles de Lukas Lundvald Nielsen aseguraran la victoria.
Fue la tercera derrota de la temporada en la Elite League para los hombres de Adam Keefe, que habían remontado para vencer al Dundee por 2-1 en Belfast el viernes por la noche.
Era el cuarto encuentro de la temporada entre ambos equipos, y los Giants habían ganado los tres partidos anteriores.
El primer gol de Dwyer llegó en el minuto 4, a las 3:35, tras una asistencia de Kendall McFaull, con David Rutherford proporcionando la asistencia, y Beauvillier amplió su ventaja cuatro minutos después.
En un inicio de partido muy ajetreado, Sullivan volvió a meter al equipo local en el partido a los 13:10, antes de que Matt Marquardt asistiera a Cownie para el gol del empate a los 15:16.
Dwyer se aseguró de que los Giants se fueran al descanso con ventaja al marcar su segundo gol de la noche al final del primer periodo.
El equipo local se reorganizó y Bouchard volvió a igualar el marcador con un gol en superioridad numérica en el minuto 27:37.
Cownie y Charles Corcoran se combinaron para ayudar a Nielsen a darle a Dundee la ventaja por primera vez en el partido al final del segundo período, y él aseguró la victoria con el quinto gol de su equipo a mitad del último período.
Los Giants, que han perdido cuatro de sus últimos cinco partidos, jugarán en casa contra el Milton Keynes el viernes.
Un controlador de tráfico aéreo muere para garantizar que cientos de personas a bordo de un avión puedan escapar del terremoto.
Un controlador de tráfico aéreo en Indonesia está siendo aclamado como un héroe después de que muriera asegurándose de que un avión con cientos de personas a bordo despegara sin problemas.
Más de 800 personas han muerto y muchas están desaparecidas tras el fuerte terremoto que azotó la isla de Sulawesi el viernes, provocando un tsunami.
Las fuertes réplicas siguen azotando la zona y muchas personas se encuentran atrapadas entre los escombros en la ciudad de Palu.
Pero a pesar de que sus compañeros huían para salvar sus vidas, Anthonius Gunawan Agung, de 21 años, se negó a abandonar su puesto en la torre de control que se balanceaba violentamente en el aeropuerto Mutiara Sis Al Jufri de Palu.
Permaneció en su puesto para asegurarse de que el vuelo 6321 de Batik Air, que se encontraba en la pista en ese momento, pudiera despegar sin problemas.
Acto seguido, saltó de la torre de control de tráfico cuando pensó que se estaba derrumbando.
Falleció posteriormente en el hospital.
El portavoz de la Autoridad de Navegación Aérea de Indonesia, Yohannes Sirait, afirmó que la decisión podría haber salvado cientos de vidas, según informó la cadena australiana ABC News.
Preparamos un helicóptero desde Balikpapan, en Kalimantan, para trasladarlo a un hospital más grande en otra ciudad.
Lamentablemente, lo perdimos esta mañana antes de que el helicóptero llegara a Palu.
"Nos duele mucho oír esto", añadió.
Mientras tanto, las autoridades temen que el número de muertos pueda alcanzar los miles, y la agencia nacional de mitigación de desastres afirma que el acceso a las ciudades de Donggala, Sigi y Boutong es limitado.
"Se cree que la cifra de víctimas sigue aumentando, ya que muchos cuerpos aún permanecen bajo los escombros y a muchos otros no se les ha podido dar con el paradero correcto", declaró el portavoz de la agencia, Sutopo Purwo Nugroho.
Las olas, que alcanzaron hasta seis metros de altura, han devastado Palu, donde se celebrará un entierro masivo el domingo.
Aviones militares y comerciales están transportando ayuda y suministros.
Risa Kusuma, una madre de 35 años, declaró a Sky News: "Cada minuto llega un cadáver en ambulancia".
El agua potable escasea.
Los minimercados están saqueados por todas partes.
Jan Gelfand, director de la Cruz Roja Internacional en Indonesia, declaró a CNN: "La Cruz Roja Indonesia está trabajando a contrarreloj para ayudar a los supervivientes, pero no sabemos qué se encontrarán allí".
Esto ya es una tragedia, pero podría empeorar mucho más.
El presidente de Indonesia, Joko Widodo, llegó a Palu el domingo y les dijo a los militares del país: "Les pido a todos que trabajen día y noche para completar todas las tareas relacionadas con la evacuación".
¿Estás listo?" CNN informó.
Indonesia fue azotada a principios de este año por terremotos en Lombok, en los que murieron más de 550 personas.
Accidente aéreo en Micronesia: Air Niugini informa que un hombre está desaparecido tras el accidente aéreo en la laguna.
La aerolínea que operaba el vuelo que se estrelló en una laguna del Pacífico en Micronesia ahora dice que un hombre está desaparecido, después de haber afirmado anteriormente que los 47 pasajeros y la tripulación habían evacuado el avión que se hundía sanos y salvos.
Air Niugini informó en un comunicado que, hasta el sábado por la tarde, no había podido localizar a un pasajero varón.
La aerolínea indicó que estaba colaborando con las autoridades locales, los hospitales y los investigadores para intentar localizar al hombre.
La aerolínea no respondió de inmediato a las solicitudes de más detalles sobre el pasajero, como su edad o nacionalidad.
Las embarcaciones locales ayudaron a rescatar a los demás pasajeros y a la tripulación después de que el avión cayera al agua mientras intentaba aterrizar en el aeropuerto de la isla de Chuuk.
Las autoridades informaron el viernes que siete personas habían sido trasladadas a un hospital.
La aerolínea informó que seis pasajeros permanecían hospitalizados el sábado y que todos ellos se encontraban en condición estable.
Aún no está claro qué causó el accidente ni la secuencia exacta de los hechos.
Tanto la aerolínea como la Armada de los Estados Unidos afirmaron que el avión aterrizó en la laguna, antes de llegar a la pista de aterrizaje.
Algunos testigos opinaron que el avión se pasó de la pista.
El pasajero estadounidense Bill Jaynes dijo que el avión voló muy bajo.
"Eso es algo sumamente bueno", dijo Jaynes.
Jaynes contó que él y otros lograron vadear el agua, que les llegaba hasta la cintura, para llegar a las salidas de emergencia del avión que se estaba hundiendo.
Dijo que los auxiliares de vuelo estaban en pánico y gritando, y que él sufrió una lesión leve en la cabeza.
La Armada de los Estados Unidos informó que los marineros que trabajaban cerca en la mejora de un muelle también ayudaron en el rescate utilizando una lancha neumática para trasladar a las personas a tierra antes de que el avión se hundiera en unos 30 metros (100 pies) de agua.
Según datos de la Red de Seguridad Aérea, 111 personas han fallecido en accidentes de aerolíneas registradas en Papúa Nueva Guinea en las últimas dos décadas, pero ninguno de ellos involucró a Air Niugini.
Un analista detalla la cronología de la noche en que una mujer fue quemada viva.
La fiscalía concluyó el sábado la presentación de sus pruebas en el nuevo juicio contra un hombre acusado de quemar viva a una mujer de Mississippi en 2014.
El analista del Departamento de Justicia de Estados Unidos, Paul Rowlett, testificó durante horas como perito en el campo del análisis de inteligencia.
Explicó al jurado cómo utilizó los registros telefónicos para reconstruir los movimientos del acusado Quinton Tellis, de 29 años, y de la víctima Jessica Chambers, de 19 años, la noche en que falleció.
Rowlett afirmó haber recibido datos de localización de varios teléfonos móviles que demostraban que Tellis estaba con Chambers la noche de su muerte, lo que contradice sus afirmaciones anteriores, según informó The Clarion Ledger.
Cuando los datos demostraron que su teléfono móvil estaba en poder de Chambers durante el tiempo en que dijo que estaba con su amigo Michael Sanford, la policía fue a hablar con Sanford.
Sanford subió al estrado el sábado y testificó que no se encontraba en la ciudad ese día.
Cuando los fiscales le preguntaron a Tellis si decía la verdad cuando afirmó que esa noche estaba en la camioneta de Sanford, Sanford respondió que estaba "mintiendo, porque mi camioneta estaba en Nashville".
Otra inconsistencia fue que Tellis dijo que conocía a Chambers desde hacía aproximadamente dos semanas cuando ella falleció.
Los registros telefónicos indicaban que solo se conocían desde hacía una semana.
Rowlett afirmó que, algún tiempo después de la muerte de Chambers, Tellis borró los mensajes de texto, las llamadas y la información de contacto de Chambers de su teléfono.
"La borró de su vida", dijo Hale.
Está previsto que la defensa comience sus alegatos finales el domingo.
El juez dijo que esperaba que el juicio pasara al jurado más tarde ese mismo día.
The High Breed: ¿Qué es el hip hop consciente?
Un trío de hip hop quiere desafiar la visión negativa del género llenando su música de mensajes positivos.
El grupo The High Breed, originario de Bristol, afirma que el hip hop se ha alejado de sus orígenes, cuando se centraba en mensajes políticos y en abordar problemas sociales.
Quieren volver a sus orígenes y popularizar de nuevo el hip hop con conciencia social.
Artistas como The Fugees y Common han experimentado un resurgimiento reciente en el Reino Unido gracias a artistas como Akala y Lowkey.
¿Otra persona negra?
Una niñera de Nueva York demanda a una pareja por despedirla tras recibir un mensaje de texto "racista".
Una niñera de Nueva York está demandando a una pareja por despido discriminatorio tras recibir un mensaje de texto erróneo de la madre quejándose de que era "otra persona negra".
La pareja niega ser racista y compara la demanda con una "extorsión".
Lynsey Plasco-Flaxman, madre de dos hijos, expresó su consternación al descubrir que la nueva cuidadora, Giselle Maurice, era negra cuando llegó a su primer día de trabajo en 2016.
"¡NOOOOOOOOOOO OTRA PERSONA NEGRA!", escribió la señora Plasco-Flaxman a su marido en un mensaje de texto.
Sin embargo, en lugar de enviársela a su marido, se la envió a la señora Maurice, dos veces.
Tras darse cuenta de su metedura de pata, una "incómoda" Plasco-Flaxman despidió a la Sra. Maurice, alegando que su niñera saliente, que era afroamericana, había hecho un mal trabajo y que, en su lugar, esperaba a una filipina, según el New York Post.
A la Sra. Maurice le pagaron por su único día de trabajo y luego la enviaron a casa a tomar un Uber.
Ahora, Maurice está demandando a la pareja para obtener una indemnización por el despido, y exige una compensación de 350 dólares diarios por el trabajo de seis meses con alojamiento incluido para el que inicialmente había sido contratada, aunque sin contrato.
"Quiero demostrarles que no se hacen ese tipo de cosas", declaró al Post el viernes, y añadió: "Sé que es discriminación".
La pareja ha rechazado las acusaciones de racismo, afirmando que rescindir el contrato laboral de Maurice fue lo más razonable, ya que temían no poder confiar en ella después de haberla ofendido.
"Mi esposa le había enviado algo que no quería decir."
Ella no es racista.
"No somos racistas", declaró Joel Plasco, el esposo de Joel, al Post.
Pero, ¿pondrías a tus hijos en manos de alguien con quien has sido grosero, aunque haya sido por error?
¿Tu bebé recién nacido?
Vamos."
Plasco comparó la demanda con una "extorsión" y dijo que a su esposa le faltaban solo dos meses para dar a luz y que se encontraba en una "situación muy difícil".
"¿Vas a ir tras alguien así?"
"Eso no está muy bien", añadió el banquero de inversiones.
Si bien el caso judicial aún está en curso, la opinión pública no ha tardado en denunciar a la pareja en las redes sociales, criticándolos duramente por su comportamiento y su lógica.
Los editores de Paddington temían que los lectores no conectaran con un oso que habla, según revela una nueva carta.
La hija de Bond, Karen Jankel, que nació poco después de que el libro fuera aceptado, dijo sobre la carta: "Es difícil ponerse en el lugar de alguien que lo lee por primera vez antes de que se publique".
Es muy divertido saber ahora lo que sabemos sobre el enorme éxito de Paddington.
Dijo su padre, Quien había trabajado como camarógrafo de la BBC antes de inspirarse para escribir el libro infantil gracias a un pequeño osito de peluche, habría aceptado con optimismo el rechazo de su obra, añadió. El 60 aniversario de la publicación del libro fue "agridulce" tras su fallecimiento el año pasado.
Sobre Paddington, a quien describe como un "miembro muy importante de nuestra familia", añadió que su padre estaba discretamente orgulloso de su éxito final.
"Era un hombre bastante tranquilo y no era una persona presumida", dijo ella.
"Pero como Paddington era tan real para él, era casi como cuando tienes un hijo que logra algo: te sientes orgulloso de él aunque en realidad no sea mérito tuyo."
Creo que él veía el éxito de Paddington un poco de esa manera.
Aunque fue creación suya y fruto de su imaginación, siempre le atribuía el mérito al propio Paddington.
Mi hija se estaba muriendo y tuve que despedirme de ella por teléfono.
Tras aterrizar, su hija fue trasladada de urgencia al Hospital Louis Pasteur 2 de Niza, donde los médicos trabajaron en vano para salvarle la vida.
"Nad llamaba con frecuencia para decir que la situación era muy grave, que no se esperaba que sobreviviera", dijo la señora Ednan-Laperouse.
"Entonces recibí la llamada de Nad para decirme que iba a morir en los próximos dos minutos y que tenía que despedirme de ella."
Y lo hice.
Le dije: "Tashi, te quiero muchísimo, cariño".
Estaré contigo pronto.
Estaré contigo.
Los fármacos que los médicos le habían administrado para mantener su corazón latiendo estaban desapareciendo lentamente de su organismo.
Ella había fallecido tiempo atrás y esto suponía el fin de todo.
No me quedó más remedio que sentarme allí y esperar, sabiendo que todo esto estaba ocurriendo.
No podía aullar, gritar ni llorar porque me encontraba en una situación rodeada de familias y gente.
Tuve que contenerme mucho.
Finalmente, la señora Ednan-Laperouse, que ya estaba de luto por la pérdida de su hija, subió al avión junto con los demás pasajeros, ajena a la terrible experiencia por la que estaba pasando.
"Nadie lo sabía", dijo.
"Tenía la cabeza gacha y las lágrimas me caían todo el tiempo."
Es difícil de explicar, pero fue durante el vuelo cuando sentí una abrumadora sensación de compasión por Nad.
Que necesitaba mi amor y mi comprensión.
Yo sabía cuánto la quería.
Mujeres afligidas envían postales para prevenir suicidios en un puente.
Dos mujeres que perdieron a seres queridos por suicidio están trabajando para evitar que otros se quiten la vida.
Sharon Davis y Kelly Humphreys han estado colocando tarjetas en un puente galés con mensajes inspiradores y números de teléfono a los que la gente puede llamar para obtener ayuda.
El hijo de la Sra. Davis, Tyler, tenía 13 años cuando comenzó a sufrir depresión y se suicidó a los 18.
"No quiero que ningún padre o madre se sienta como me siento yo todos los días", dijo.
La señora Davis, de 45 años y residente en Lydney, dijo que su hijo era un chef prometedor con una sonrisa contagiosa.
"Todos lo conocían por su sonrisa."
Siempre decían que su sonrisa iluminaba cualquier habitación.
Sin embargo, dejó de trabajar antes de morir, ya que se encontraba "en un momento muy difícil".
En 2014, el hermano de Tyler, que tenía 11 años en ese momento, fue quien encontró a su hermano después de que este se quitara la vida.
La Sra. Davis dijo: "Me preocupa constantemente que esto vaya a tener un efecto dominó".
La Sra. Davis creó las tarjetas "para que la gente sepa que hay personas a las que pueden acudir y con las que pueden hablar, aunque sea un amigo".
No te quedes en silencio, necesitas hablar.
La Sra. Humphreys, que ha sido amiga de la Sra. Davies durante años, perdió a Mark, su pareja durante 15 años, poco después del fallecimiento de su madre.
"No dijo que se sintiera triste o deprimido ni nada por el estilo", dijo ella.
"Un par de días antes de Navidad notamos un cambio en su actitud."
El día de Navidad tocó fondo: cuando los niños abrieron sus regalos, ni siquiera les dirigió la mirada.
Dijo que su muerte fue un trauma enorme para ellos, pero que tienen que superarlo: "Es un golpe muy duro para la familia".
Nos destroza.
Pero todos tenemos que seguir adelante y luchar."
Si tienes dificultades para sobrellevar la situación, puedes llamar a Samaritans gratis al 116 123 (Reino Unido e Irlanda), enviar un correo electrónico a jo@samaritans.org o visitar el sitio web de Samaritans aquí.
El futuro de Brett Kavanaugh pende de un hilo mientras el FBI inicia una investigación.
"Pensé, si pudiéramos conseguir algo como lo que él pedía: una investigación con un plazo limitado, "De alcance limitado, tal vez podríamos lograr un poco de unidad", dijo el Sr. Flake el sábado, y agregó que temía que el comité se estuviera "desmoronando" en medio del arraigado bloqueo partidista.
¿Por qué el señor Kavanaugh y sus partidarios republicanos no querían que el FBI investigara?
Su reticencia se debe únicamente a una cuestión de oportunidad.
Las elecciones de mitad de mandato están a solo cinco semanas, el 6 de noviembre; si, como se espera, a los republicanos les va mal, se verán seriamente debilitados en sus intentos de lograr que el hombre que desean sea elegido para el tribunal más alto del país.
George W. Bush ha estado llamando por teléfono a los senadores para presionarlos a que apoyen al Sr. Kavanaugh, quien trabajó en la Casa Blanca para el Sr. Bush y a través de él conoció a su esposa Ashley, quien era la secretaria personal del Sr. Bush.
¿Qué sucede después de que el FBI publique su informe?
Habrá una votación en el Senado, donde actualmente se encuentran 51 republicanos y 49 demócratas.
Todavía no está claro si el Sr. Kavanaugh podrá obtener al menos 50 votos en el Senado, lo que permitiría a Mike Pence, el vicepresidente, desempatar y confirmarlo para el Tribunal Supremo.
El número de desertores de Corea del Norte "disminuye" bajo el mandato de Kim.
Según un legislador surcoreano, el número de norcoreanos que desertan a Corea del Sur ha disminuido desde que Kim Jong-un llegó al poder hace siete años.
Park Byeong-seug, citando datos del Ministerio de Unificación de Corea del Sur, dijo que hubo 1.127 deserciones el año pasado, en comparación con las 2.706 de 2011.
El señor Park afirmó que el endurecimiento de los controles fronterizos entre Corea del Norte y China, así como las tarifas más elevadas que cobran los traficantes de personas, eran factores clave.
Pyongyang no ha hecho comentarios públicos.
A la gran mayoría de los desertores del Norte se les ofrece finalmente la ciudadanía surcoreana.
Seúl afirma que más de 30.000 norcoreanos han cruzado ilegalmente la frontera desde el final de la Guerra de Corea en 1953.
La mayoría huye a través de China, que tiene la frontera más larga con Corea del Norte y es más fácil de cruzar que la Zona Desmilitarizada (DMZ), fuertemente protegida, entre las dos Coreas.
China considera a los desertores como inmigrantes ilegales en lugar de refugiados y, a menudo, los repatria por la fuerza.
Las relaciones entre el Norte y el Sur, que técnicamente siguen en guerra, han mejorado notablemente en los últimos meses.
A principios de este mes, los líderes de ambos países se reunieron en Pyongyang para mantener conversaciones centradas en las estancadas negociaciones sobre desnuclearización.
Esto se produjo tras la histórica reunión celebrada en junio entre el presidente estadounidense Donald Trump y Kim Jong-un en Singapur, donde acordaron en términos generales trabajar para lograr una península coreana libre de armas nucleares.
Pero el sábado, el ministro de Asuntos Exteriores de Corea del Norte, Ri Yong-ho, culpó a las sanciones estadounidenses de la falta de progreso desde entonces.
"Sin ninguna confianza en Estados Unidos, no habrá confianza en nuestra seguridad nacional y, en tales circunstancias, no hay manera de que nos desarmemos unilateralmente primero", dijo el Sr. Ri en un discurso ante la Asamblea General de la ONU en Nueva York.
Nancy Pelosi califica a Brett Kavanaugh de "histérico" y afirma que no es apto para formar parte del Tribunal Supremo.
La líder de la minoría en la Cámara de Representantes, Nancy Pelosi, calificó de "histérica" ​​a la candidatura de Brett Kavanaugh al Tribunal Supremo y afirmó que su temperamento no era apto para formar parte de dicho tribunal.
Pelosi hizo estas declaraciones en una entrevista el sábado en el Festival del Texas Tribune en Austin, Texas.
"No pude evitar pensar que si una mujer hubiera actuado alguna vez de esa manera, dirían 'histérica'", dijo Pelosi sobre su reacción al testimonio de Kavanaugh ante el Comité Judicial del Senado el jueves.
Kavanaugh negó visiblemente las acusaciones de haber agredido sexualmente a la Dra. Christine Blasey Ford cuando ambos eran adolescentes.
Durante su declaración inicial, Kavanaugh se mostró muy emocionado, llegando incluso a gritar y a tener la voz quebrada en algunos momentos al hablar de su familia y de sus años de instituto.
También condenó explícitamente a los demócratas del comité, calificando las acusaciones en su contra de "ataque de desprestigio grotesco y coordinado" organizado por liberales enfadados porque Hillary Clinton perdió las elecciones presidenciales de 2016.
Pelosi afirmó que creía que el testimonio de Kavanaugh demostraba que no podía formar parte del Tribunal Supremo, porque evidenciaba su parcialidad contra los demócratas.
"Creo que se descalifica a sí mismo con esas declaraciones y la forma en que arremetió contra los Clinton y los demócratas", dijo.
Pelosi se mostró reticente a responder cuando se le preguntó si intentaría destituir a Kavanaugh en caso de que fuera confirmado y si los demócratas obtuvieran la mayoría en la Cámara de Representantes.
"Voy a decir esto: si no está diciendo la verdad al Congreso o al FBI, entonces no es apto no solo para formar parte de la Corte Suprema, sino para estar en el tribunal en el que está ahora mismo", dijo Pelosi.
Actualmente, Kavanaugh es juez del Tribunal de Apelaciones del Circuito de D.C.
Pelosi agregó que, como demócrata, le preocupaban los posibles fallos de Kavanaugh en contra de la Ley de Cuidado de Salud Asequible o Roe v. Wade, ya que se le considera un juez conservador.
En sus audiencias de confirmación, Kavanaugh eludió las preguntas sobre si revocaría ciertas decisiones de la Corte Suprema.
"No es momento para que una persona histérica y parcial acuda a los tribunales y espere que digamos: '¿No es maravilloso?'", dijo Pelosi.
Y las mujeres deben ejercerlo.
Es una diatriba justa, meses y años de furia que se desbordan, y no puede expresarla sin llorar.
"Lloramos cuando nos enfadamos", me dijo la señora Steinem 45 años después.
"No creo que eso sea raro, ¿verdad?"
Ella continuó, "Recibí mucha ayuda de una mujer que era ejecutiva en algún lugar, quien dijo que también lloraba cuando se enojaba, pero desarrolló una técnica que significaba que cuando se enojaba y comenzaba a llorar, le decía a la persona con la que estaba hablando: "Puedes pensar que estoy triste porque estoy llorando.
Estoy enfadado.
Y luego ella simplemente continuó.
Y me pareció brillante."
Se permite llorar como una forma de desahogo de la ira, en parte porque se malinterpreta fundamentalmente.
Uno de mis recuerdos más vívidos de un trabajo temprano, En una oficina dominada por hombres, donde una vez me encontré llorando de rabia indescriptible, fue cuando una mujer mayor, una jefa fría a la que siempre le había tenido un poco de miedo, me agarró por el cuello y me arrastró hasta la escalera.
"Nunca dejes que te vean llorar", me dijo.
"No saben que estás furioso."
Creen que estás triste y se alegrarán porque han conseguido llegar hasta ti.
Patricia Schroeder, por aquel entonces congresista demócrata por Colorado, había trabajado con Gary Hart en sus campañas presidenciales.
En 1987, cuando el Sr. Hart fue descubierto en una aventura extramatrimonial a bordo de un barco llamado Monkey Business y se retiró de la contienda, la Sra. Schroeder, profundamente frustrada, pensó que no había razón para que ella no explorara la idea de postularse a la presidencia.
"No fue una decisión bien meditada", me dijo entre risas 30 años después.
"Ya había otros siete candidatos en la contienda, y lo último que necesitaban era uno más."
Alguien la llamó "Blancanieves y los siete enanitos".
Como ya era tarde en la campaña, iba con retraso en la recaudación de fondos, por lo que prometió que no se presentaría a las elecciones a menos que recaudara 2 millones de dólares.
Fue una batalla perdida.
Descubrió que algunos de sus seguidores que donaban 1.000 dólares a hombres, a ella solo le daban 250 dólares.
"¿Acaso creen que me harán un descuento?", se preguntó.
Cuando pronunció su discurso anunciando que no lanzaría una campaña formal, Estaba tan abrumada por las emociones —gratitud hacia las personas que la habían apoyado, frustración con el sistema que hacía tan difícil recaudar fondos y dirigirse a los votantes en lugar de a los delegados, e ira por el sexismo— que se le hizo un nudo en la garganta.
"Parecía que hubiera sufrido una crisis nerviosa", recordó la Sra. Schroeder sobre la reacción de la prensa.
"Cualquiera pensaría que Kleenex es mi patrocinador corporativo."
Recuerdo haber pensado: ¿qué van a poner en mi lápida?
"¿Ella lloró?"
Cómo la guerra comercial entre Estados Unidos y China podría ser beneficiosa para Pekín
Los primeros ataques de la guerra comercial entre Estados Unidos y China fueron ensordecedores, y aunque la batalla está lejos de terminar, una ruptura entre los países podría ser beneficiosa para Pekín a largo plazo, según los expertos.
Donald Trump, presidente de Estados Unidos, lanzó la primera advertencia a principios de este año al gravar con impuestos exportaciones chinas clave, como paneles solares, acero y aluminio.
La escalada más significativa se produjo esta semana con la imposición de nuevos aranceles que afectan a productos por valor de 200.000 millones de dólares (150.000 millones de libras esterlinas), lo que supone, en la práctica, un impuesto sobre la mitad de todos los productos que entran en Estados Unidos procedentes de China.
Pekín ha respondido cada vez de la misma manera, imponiendo recientemente aranceles de entre el cinco y el diez por ciento a productos estadounidenses por valor de 60.000 millones de dólares.
China se ha comprometido a igualar a Estados Unidos en este aspecto, y es poco probable que la segunda economía más grande del mundo ceda en un futuro próximo.
Lograr que Washington dé marcha atrás implica ceder ante sus exigencias, pero someterse públicamente a Estados Unidos sería demasiado vergonzoso para Xi Jinping, el presidente de China.
Sin embargo, los expertos afirman que si Pekín juega bien sus cartas, las presiones de la guerra comercial estadounidense podrían beneficiar a China a largo plazo al reducir la interdependencia entre ambas economías.
"El hecho de que una decisión política rápida, ya sea en Washington o en Pekín, pueda crear las condiciones que desencadenen una crisis económica en cualquiera de los dos países es, en realidad, mucho más peligroso de lo que los observadores habían reconocido hasta ahora.""dijo Abigail Grace, investigadora asociada especializada en Asia en el Centro para la Nueva Seguridad Estadounidense, un centro de estudios.
Siria está "preparada" para el regreso de los refugiados, afirma el ministro de Asuntos Exteriores.
Siria afirma estar preparada para el retorno voluntario de los refugiados y solicita ayuda para reconstruir el país, devastado por una guerra que dura ya más de siete años.
En su intervención ante la Asamblea General de las Naciones Unidas, el ministro de Asuntos Exteriores, Walid al-Moualem, afirmó que las condiciones en el país están mejorando.
"Hoy la situación sobre el terreno es más estable y segura gracias a los avances logrados en la lucha contra el terrorismo", afirmó.
El gobierno continúa rehabilitando las zonas destruidas por los terroristas para restablecer la normalidad.
Ahora se dan todas las condiciones para el retorno voluntario de los refugiados al país que tuvieron que abandonar a causa del terrorismo y de las medidas económicas unilaterales que atentaron contra su vida cotidiana y sus medios de subsistencia.
La ONU estima que más de 5,5 millones de sirios han huido del país desde que comenzó la guerra en 2011.
Otros seis millones de personas que aún viven en el país necesitan asistencia humanitaria.
Al-Moualem afirmó que el régimen sirio agradecería la ayuda para reconstruir el país devastado.
Pero recalcó que no aceptaría ayuda ni asistencia condicionada de los países que patrocinaron la insurgencia.
Europa se alza con la victoria en la Ryder Cup en París.
El equipo europeo ganó la Ryder Cup 2018 al derrotar al equipo estadounidense por un marcador final de 16,5 a 10,5 en Le Golf National, en las afueras de París, Francia.
Estados Unidos ha perdido seis veces consecutivas en suelo europeo y no ha ganado una Ryder Cup en Europa desde 1993.
Europa recuperó el título cuando el equipo del capitán danés Thomas Bjorn alcanzó los 14,5 puntos que necesitaba para vencer a Estados Unidos.
La estrella estadounidense Phil Mickelson, que tuvo dificultades durante la mayor parte del torneo, mandó su golpe de salida al agua en el hoyo 16, un par 3, cediendo así su partido a Francesco Molinari.
El golfista italiano Molinari brilló en todas sus rondas, convirtiéndose en uno de los cuatro jugadores que han logrado un récord de 5-0-0 desde que se adoptó el formato actual del torneo en 1979.
El estadounidense Jordan Spieth fue derrotado por 5&4 por el jugador de menor ranking del equipo europeo, el danés Thorbjorn Olesen.
El número uno del mundo, Dustin Johnson, cayó derrotado por 2 y 1 ante el inglés Ian Poulter, quien podría haber disputado su última Ryder Cup.
El español Sergio García, veterano de ocho Ryder Cups, se convirtió en el europeo con más victorias en la historia del torneo, con 25,5 puntos en su carrera.
"Normalmente no lloro, pero hoy no puedo evitarlo."
Ha sido un año difícil.
Estoy muy agradecida con Thomas por haberme elegido y haber creído en mí.
Estoy tan feliz, tan feliz de recuperar la copa.
"Se trata del equipo, y estoy feliz de haber podido ayudar", dijo un emocionado García tras la victoria europea.
Le pasa el testigo a su compatriota John Ram, quien derrotó a la leyenda del golf estadounidense Tiger Woods por 2&1 en partidos individuales el domingo.
"El orgullo que siento al vencer a Tiger Woods es increíble; crecí viendo a ese tipo", dijo Rahm, de 23 años.
Woods perdió sus cuatro partidos en Francia y ahora tiene un récord de 13-21-3 en su carrera en la Ryder Cup.
Una estadística curiosa para uno de los mejores jugadores de todos los tiempos, que ha ganado 14 títulos importantes, solo superado por Jack Nicklaus.
El equipo de Estados Unidos tuvo problemas durante todo el fin de semana para encontrar las calles, con la excepción de Patrick Reed, Justin Thomas y Tony Finau, quienes jugaron un golf de alto nivel durante todo el torneo.
El capitán estadounidense Jim Furyk habló tras la decepcionante actuación de su equipo: "Estoy orgulloso de estos chicos, lucharon".
Esta mañana hubo un momento en que pusimos algo de presión sobre Europa.
Lo desechamos.
¡Enhorabuena a Thomas!
Es un gran capitán.
Los doce jugadores que contaba con él jugaron muy bien.
Nos reagruparemos, trabajaré con la PGA de América y nuestro Comité de la Ryder Cup, y seguiremos adelante.
Adoro a estos 12 chicos y estoy orgulloso de ser su capitán.
Hay que quitarse el sombrero.
Nos superaron en el juego."
Actualización sobre la marea roja: Las concentraciones disminuyen en Pinellas, Manatee y Sarasota.
El informe más reciente de la Comisión de Pesca y Vida Silvestre de Florida muestra una disminución general en las concentraciones de marea roja en algunas zonas del área de la Bahía de Tampa.
Según la FWC, se están reportando proliferaciones de algas más irregulares en áreas de los condados de Pinellas, Manatee, Sarasota, Charlotte y Collier, lo que sugiere una disminución en las concentraciones.
La marea roja, un fenómeno conocido como floración de algas, se extiende a lo largo de aproximadamente 130 millas de costa, desde el norte del condado de Pinellas hasta el sur del condado de Lee.
Se pueden encontrar zonas afectadas a unas 10 millas de la costa del condado de Hillsborough, pero en menos lugares que la semana pasada.
También se ha observado la marea roja en el condado de Pasco.
Se han reportado concentraciones medias en el condado de Pinellas o en sus costas durante la última semana. concentraciones bajas a altas en la costa del condado de Hillsborough, Antecedentes de altas concentraciones en el condado de Manatee, concentraciones de fondo a altas en el condado de Sarasota o en sus costas, concentraciones de fondo a medias en el condado de Charlotte, concentraciones de fondo a altas en el condado de Lee o en sus costas, y concentraciones bajas en el condado de Collier.
Se siguen registrando casos de irritación respiratoria en los condados de Pinellas, Manatee, Sarasota, Lee y Collier.
No se reportaron casos de irritación respiratoria en el noroeste de Florida durante la última semana.
