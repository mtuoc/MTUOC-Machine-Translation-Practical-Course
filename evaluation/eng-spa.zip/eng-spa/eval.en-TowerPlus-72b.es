Los miembros de la Asamblea de Gales están preocupados por "parecer tontos"
Hay consternación entre algunos miembros de la Asamblea por la sugerencia de que su título debería cambiarse a MWP (Miembro del Parlamento de Gales).
Se ha producido debido a los planes de cambiar el nombre de la asamblea al Parlamento galés.
Los miembros de la Asamblea de todo el espectro político están preocupados de que esto pueda provocar burlas.
Un miembro de la Asamblea de Gales del Partido Laborista dijo que su grupo estaba preocupado porque "rima con Twp y Pwp".
Para los lectores fuera de Gales: En galés, twp significa tonto y pwp significa caca.
Un miembro del AM de Plaid dijo que el grupo en su conjunto "no estaba contento" y sugirió alternativas.
Un conservador galés dijo que su grupo estaba "abierto" al cambio de nombre, pero señaló que era un salto verbal corto de MWP a Muppet.
En este contexto, la letra w galesa se pronuncia de manera similar a la pronunciación de la letra u en el inglés de Yorkshire.
La Comisión de la Asamblea, que actualmente está redactando la legislación para introducir los cambios de nombre, dijo: "Por supuesto, la decisión final sobre cualquier denominación de los miembros de la Asamblea será responsabilidad de los propios miembros".
La Ley del Gobierno de Gales de 2017 otorgó a la asamblea galesa el poder de cambiar su nombre.
En junio, la Comisión publicó los resultados de una consulta pública sobre las propuestas, que revelaron un amplio apoyo a la denominación de "Parlamento galés" para la asamblea.
En cuanto al título de los AM, la Comisión favoreció la opción de Miembros del Parlamento Galés o WMP, pero la opción MWP fue la que recibió más apoyo en una consulta pública.
Los miembros de la Asamblea aparentemente están sugiriendo opciones alternativas, pero la lucha por alcanzar un consenso podría ser un dolor de cabeza para la presidenta, Elin Jones, quien se espera que presente un proyecto de ley sobre los cambios en las próximas semanas.
La legislación sobre las reformas incluirá otros cambios en el funcionamiento de la asamblea, incluidas las normas sobre la descalificación de los miembros de la asamblea y el diseño del sistema de comités.
Los miembros de la Asamblea tendrán la última palabra sobre cómo deberían llamarse cuando debatan la legislación.
Los macedonios acuden a las urnas en un referéndum sobre el cambio del nombre del país
Los votantes decidirán el domingo si cambian el nombre de su país a "República de Macedonia del Norte".
El voto popular se estableció con el fin de resolver una disputa de décadas con la vecina Grecia, que tiene su propia provincia llamada Macedonia.
Atenas ha insistido durante mucho tiempo en que el nombre de su vecino del norte representa una reclamación sobre su territorio y ha objetado repetidamente sus solicitudes de membresía para la UE y la OTAN.
El presidente macedonio Gjorge Ivanov, opositor al plebiscito sobre el cambio de nombre, ha dicho que no tendrá en cuenta el voto.
Sin embargo, los partidarios del referéndum, incluido el primer ministro Zoran Zaev, argumentan que el cambio de nombre es simplemente el precio que hay que pagar para unirse a la UE y a la OTAN.
Las campanas de San Martín callan mientras las iglesias de Harlem luchan por sobrevivir
"Históricamente, las personas mayores con las que he hablado dicen que había un bar y una iglesia en cada esquina", dijo el Sr. Adams.
"Hoy no hay ninguno de los dos".
Dijo que la desaparición de los bares era comprensible.
"La gente se socializa de una manera diferente" en la actualidad, dijo.
"Los bares ya no son las salas de estar del barrio a las que la gente acude con regularidad".
En cuanto a las iglesias, le preocupa que el dinero obtenido de la venta de activos no dure tanto como los líderes esperan, "y tarde o temprano volverán al punto de partida".
Las iglesias, agregó, podrían ser reemplazadas por edificios de apartamentos con condominios llenos de personas que no ayudarán a los santuarios restantes del vecindario.
“La abrumadora mayoría de las personas que compran apartamentos en estos edificios serán blancas”, dijo, “y, por lo tanto, acelerarán el día en que estas iglesias cierren por completo, porque es poco probable que la mayoría de estas personas que se mudan a estos apartamentos se conviertan en miembros de estas iglesias”.
Ambas iglesias fueron construidas por congregaciones blancas antes de que Harlem se convirtiera en una metrópolis negra: la Comunidad Metropolitana en 1870 y la iglesia de San Martín una década después.
La congregación metodista blanca original se mudó en la década de 1930.
Una congregación negra que había estado celebrando cultos cerca se hizo con la titularidad del edificio.
St. Martin's fue tomada por una congregación negra bajo el reverendo John Howard Johnson, quien lideró un boicot contra los comerciantes de la calle 125, una de las principales calles comerciales de Harlem, que se negaban a contratar o promover a personas negras.
Un incendio en 1939 dejó el edificio gravemente dañado, pero mientras los feligreses del Padre Johnson hacían planes para reconstruirlo, encargaron el carillón.
El reverendo David Johnson, hijo y sucesor del padre Johnson en St. Martin, llamó con orgullo al carillón "las campanas de los pobres".
El experto que tocó el carillón en julio lo describió de otra manera: "Un tesoro cultural" y "un instrumento histórico insustituible".
La experta, Tiffany Ng de la Universidad de Michigan, también señaló que fue el primer carillón del mundo en ser tocado por un músico negro, Dionisio A. Lind, quien se trasladó al carillón más grande de la Iglesia Riverside hace 18 años.
Merriweather dijo que St. Martin's no lo reemplazó.
Lo que ha ocurrido en St. Martin's en los últimos meses ha sido una historia complicada de arquitectos y contratistas, algunos traídos por los líderes laicos de la iglesia, otros por la diócesis episcopal.
La vestry - el órgano rector de la parroquia, compuesto por líderes laicos - escribió a la diócesis en julio expresando su preocupación de que la diócesis "intentara transferir los costos" a la vestry, a pesar de que la vestry no había participado en la contratación de los arquitectos y contratistas enviados por la diócesis.
Algunos feligreses se quejaron de la falta de transparencia por parte de la diócesis.
Un tiburón hiere a un niño de 13 años mientras buceaba en busca de langostas en California
Un tiburón atacó e hirió a un niño de 13 años el sábado mientras buceaba en busca de langostas en California, en el primer día de la temporada de langostas, según las autoridades.
El ataque ocurrió justo antes de las 7 a. m. cerca de Beacon's Beach en Encinitas.
Chad Hammel dijo a KSWB-TV en San Diego que había estado buceando con amigos durante aproximadamente media hora el sábado por la mañana cuando escuchó al niño gritando pidiendo ayuda y luego remó con un grupo para ayudar a sacarlo del agua.
Hammel dijo que al principio pensó que era solo la emoción de haber atrapado una langosta, pero luego se "dio cuenta de que estaba gritando: '¡Me mordió!
¡Me mordió!
"Tenía toda la clavícula destrozada", dijo Hammel que notó cuando llegó al niño.
"Les grité a todos que salieran del agua: '¡Hay un tiburón en el agua!'", agregó Hammel.
El niño fue trasladado en helicóptero al Hospital Infantil Rady en San Diego, donde se encuentra en estado crítico.
La especie de tiburón responsable del ataque era desconocida.
El capitán de salvavidas Larry Giles dijo en una conferencia de prensa que un tiburón había sido avistado en la zona unas semanas antes, pero se determinó que no era una especie peligrosa.
Giles agregó que la víctima sufrió lesiones traumáticas en la zona superior del torso.
Las autoridades cerraron el acceso a la playa desde Ponto Beach en Casablad hasta Swami's en Ecinitas durante 48 horas con fines de investigación y seguridad.
Giles señaló que hay más de 135 especies de tiburones en la zona, pero la mayoría no se consideran peligrosas.
Los planes de Sainsbury's buscan penetrar en el mercado de la cosmética del Reino Unido
Sainsbury's está compitiendo con Boots, Superdrug y Debenhams con pasillos de belleza al estilo de los grandes almacenes, atendidos por asistentes especializados.
Como parte de un importante impulso en el mercado de belleza del Reino Unido, valorado en 2.800 millones de libras, que sigue creciendo mientras las ventas de moda y artículos para el hogar retroceden, los pasillos de belleza más amplios se probarán en 11 tiendas de todo el país y se implementarán en más tiendas el próximo año si tienen éxito.
La inversión en belleza surge en un momento en que los supermercados buscan formas de aprovechar el espacio en los estantes que antes se utilizaba para televisores, microondas y artículos para el hogar.
Sainsbury's anunció que duplicará la oferta de productos de belleza, llegando a los 3000 productos, incluidas marcas como Revlon, Essie, Tweezerman y Dr. PawPaw, por primera vez.
Las gamas existentes de L'Oreal, Maybelline y Burt's Bees también contarán con más espacio en áreas de marca similares a las que se encuentran en tiendas como Boots.
El supermercado también está relanzando su gama de maquillaje Boutique para que la mayoría de los productos sean aptos para veganos, algo que los compradores más jóvenes demandan cada vez más.
Además, la tienda de perfumes Fragrance Shop probará concesiones en dos tiendas de Sainsbury's, la primera de las cuales abrió en Croydon, al sur de Londres, la semana pasada, mientras que la segunda abrirá en Selly Oak, Birmingham, más adelante este año.
Las compras en línea y el cambio hacia la compra de pequeñas cantidades de alimentos diariamente en tiendas locales significan que los supermercados deben esforzarse más para persuadir a la gente a que los visite.
Mike Coupe, director ejecutivo de Sainsbury's, ha dicho que los establecimientos se parecerán cada vez más a los grandes almacenes, ya que la cadena de supermercados intenta competir con los descuentos de Aldi y Lidl ofreciendo más servicios y productos no alimentarios.
Sainsbury's ha instalado tiendas Argos en cientos de sus supermercados y también ha introducido varias tiendas Habitat desde que compró ambas cadenas hace dos años, lo que, según la empresa, ha impulsado las ventas de comestibles y ha hecho que las adquisiciones sean más rentables.
El intento anterior del supermercado de renovar sus departamentos de belleza y farmacia terminó en fracaso.
Sainsbury's probó una empresa conjunta con Boots a principios de la década de 2000, pero la alianza terminó después de una disputa sobre cómo repartir los ingresos de las tiendas de productos químicos en sus supermercados.
La nueva estrategia se produce después de que Sainsbury's vendiera su negocio de farmacias de 281 tiendas a Celesio, el propietario de la cadena de farmacias Lloyds, por 125 millones de libras, hace tres años.
Indicó que Lloyds desempeñaría un papel en el plan, al agregar una amplia gama de marcas de productos de cuidado de la piel de lujo, incluidas La Roche-Posay y Vichy, en cuatro tiendas.
Paul Mills-Hicks, director comercial de Sainsbury's, dijo: "Hemos transformado la apariencia y la sensación de nuestros pasillos de belleza para mejorar el entorno para nuestros clientes".
También hemos invertido en colegas especialmente capacitados que estarán disponibles para ofrecer asesoramiento.
Nuestra gama de marcas está diseñada para satisfacer todas las necesidades, y el atractivo entorno y las ubicaciones convenientes hacen que ahora seamos un destino de belleza irresistible que desafía la forma tradicional de hacer compras".
Peter Jones está "furioso" después de que Holly Willoughby se retire de un acuerdo de 11 millones de libras
Peter Jones, estrella de Dragons Den, se fue "furioso" después de que la presentadora de televisión Holly Willoughby se retirara de un acuerdo de 11 millones de libras con su marca de estilo de vida para centrarse en sus nuevos contratos con Marks and Spencer e ITV.
Willoughby no tiene tiempo para su marca de ropa y accesorios para el hogar, Truly.
El negocio de la pareja había sido comparado con la marca Goop de Gwyneth Paltrow.
La presentadora de This Morning, de 37 años, recurrió a Instagram para anunciar que se va.
Holly Willoughby ha enfurecido al famoso Peter Jones de "Dragons' Den" al retirarse de su lucrativo negocio de marca de estilo de vida en el último momento, para centrarse en sus nuevos y jugosos contratos con Marks & Spencer e ITV.
Según fuentes, Jones estaba "furioso" cuando la chica dorada de la televisión admitió durante una tensa reunión el martes en la sede de su imperio empresarial en Marlow, Buckinghamshire, que sus nuevos contratos, por un valor de hasta 1,5 millones de libras, significaban que ya no tenía suficiente tiempo para dedicar a su marca de ropa y accesorios para el hogar, Truly.
El negocio había sido comparado con la marca Goop de Gwyneth Paltrow y se preveía que duplicaría la fortuna estimada de Willoughby de 11 millones de libras.
Mientras Willoughby, de 37 años, anunciaba en Instagram que dejaba Truly, Jones salía de Gran Bretaña para dirigirse a una de sus casas de vacaciones.
Una fuente dijo: "Truly era, con diferencia, la máxima prioridad de Holly".
Sería su futuro a largo plazo el que la sostendría durante las próximas dos décadas.
Su decisión de retirarse dejó a todos los involucrados absolutamente atónitos.
Nadie podía creer lo que estaba sucediendo el martes, estaba tan cerca del lanzamiento.
Hay un almacén lleno de mercancías en la sede de Marlow que están listas para ser vendidas".
Los expertos creen que la salida de la presentadora de This Morning, una de las estrellas más rentables de Gran Bretaña, podría costarle millones a la empresa debido a la importante inversión en productos que van desde cojines y velas hasta ropa y ropa de casa, y al potencial de más retrasos en su lanzamiento.
Y podría significar el fin de una larga amistad.
Willoughby, madre de tres hijos, y su esposo Dan Baldwin han sido cercanos a Jones y su esposa Tara Capp durante diez años.
Willoughby fundó Truly con Capp en 2016 y Jones, de 52 años, se unió como presidente en marzo.
Las parejas se van de vacaciones juntas y Jones tiene una participación del 40 por ciento en la empresa de producción de televisión de Baldwin.
Willoughby se convertirá en embajadora de la marca M&S y reemplazará a Ant McPartlin como presentadora del programa I'm A Celebrity de ITV.
Una fuente cercana a Jones dijo anoche: "No comentaríamos sobre sus asuntos comerciales".
Palabras duras “y luego nos enamoramos”
Bromeó sobre las críticas que recibiría de los medios de comunicación por hacer un comentario que algunos considerarían "no presidencial" y por ser tan positivo respecto al líder norcoreano.
¿Por qué ha renunciado a tanto el presidente Trump?
Trump dijo con su voz de "presentador de noticias" burlona.
"No renuncié a nada".
Señaló que Kim está interesado en una segunda reunión después de que su encuentro inicial en Singapur en junio fuera calificado por Trump como un gran paso hacia la desnuclearización de Corea del Norte.
Pero las negociaciones de desnuclearización se han estancado.
Más de tres meses después de la cumbre de junio en Singapur, el principal diplomático de Corea del Norte, Ri Yong Ho, dijo a los líderes mundiales en la Asamblea General de la ONU el sábado que Corea del Norte no ve una "respuesta correspondiente" de Estados Unidos a los primeros movimientos de desarme de Corea del Norte.
En cambio, señaló, Estados Unidos está manteniendo las sanciones con el objetivo de seguir ejerciendo presión.
Trump adoptó una postura mucho más optimista en su discurso de campaña.
"Estamos haciendo un gran trabajo con Corea del Norte", dijo.
"Íbamos a la guerra con Corea del Norte.
Millones de personas habrían muerto.
Ahora tenemos esta excelente relación".
Dijo que sus esfuerzos para mejorar las relaciones con Kim han dado resultados positivos: se han detenido las pruebas de misiles, se ha ayudado a liberar rehenes y se han devuelto los restos de los militares estadounidenses a sus hogares.
Y defendió su enfoque inusual al hablar sobre las relaciones con Kim.
“Es muy fácil ser presidencial, pero en lugar de tener 10 000 personas afuera tratando de entrar a este estadio lleno, tendríamos unas 200 personas paradas justo ahí”, dijo Trump, señalando a la multitud que estaba justo frente a él.
Indonesia: tsunami y terremoto devastan una isla, matando a cientos de personas
Por ejemplo, tras el terremoto de Lombok, se informó a las organizaciones no gubernamentales extranjeras que no eran necesarias.
A pesar de que más del 10 por ciento de la población de Lombok había sido desplazada, no se declaró una catástrofe nacional, un requisito previo para catalizar la ayuda internacional.
“En muchos casos, desafortunadamente, han dejado muy claro que no están solicitando asistencia internacional, por lo que es un poco complicado”, dijo la Sra. Sumbung.
Aunque Save the Children está formando un equipo para viajar a Palu, aún no está claro si el personal extranjero podrá trabajar sobre el terreno.
El señor Sutopo, portavoz de la agencia nacional de gestión de desastres, dijo que las autoridades indonesias estaban evaluando la situación en Palu para determinar si se permitiría que las agencias internacionales contribuyeran a los esfuerzos de ayuda.
Dada la constante sacudida que sufre Indonesia, el país sigue estando lamentablemente poco preparado para la ira de la naturaleza.
Aunque se han construido refugios contra tsunamis en Aceh, no son algo común en otras costas.
La aparente falta de una sirena de alerta de tsunami en Palu, a pesar de que había una advertencia en vigor, probablemente contribuyó a la pérdida de vidas.
En el mejor de los casos, viajar entre las numerosas islas de Indonesia es un desafío.
Los desastres naturales complican aún más la logística.
Un barco hospital que había sido enviado a Lombok para tratar a las víctimas del terremoto se dirige a Palu, pero tardará al menos tres días en llegar al lugar de la nueva calamidad.
El presidente Joko Widodo hizo de la mejora de la deteriorada infraestructura de Indonesia el eje central de su campaña electoral y ha invertido grandes sumas de dinero en carreteras y ferrocarriles.
Sin embargo, la administración del señor Joko se ha visto afectada por la falta de financiamiento, ya que enfrenta la reelección el próximo año.
El señor Joko también enfrenta presión debido a las persistentes tensiones sectarias en Indonesia, donde los miembros de la mayoría musulmana han adoptado una forma más conservadora de la fe.
Más de 1000 personas murieron y decenas de miles fueron desplazadas de sus hogares mientras bandas cristianas y musulmanas luchaban en las calles, usando machetes, arcos y flechas, y otras armas rudimentarias.
Mira: El empate de última hora de Daniel Sturridge del Liverpool contra el Chelsea
Daniel Sturridge salvó al Liverpool de una derrota en la Premier League contra el Chelsea con un gol en el minuto 89 el sábado en Stamford Bridge, Londres.
Sturridge recibió un pase de Xherdan Shaqiri a unos 30 metros de la portería del Chelsea, cuando su equipo perdía 1-0.
Golpeó la pelota hacia su izquierda antes de lanzar un tiro hacia el poste lejano.
El intento pasó muy alto sobre el área, mientras se dirigía hacia la esquina superior derecha de la red.
Finalmente, la pelota cayó sobre un saltarín Kepa Arrizabalaga y terminó en la red.
"Solo intentaba llegar a esa posición, acercarme al balón, y jugadores como Shaq siempre juegan hacia adelante tanto como pueden, así que solo intenté darme el mayor tiempo posible", dijo Sturridge a LiverpoolFC.com.
"Vi que Kante se acercaba, hice un control, no lo pensé demasiado y simplemente lancé el tiro."
Chelsea iba ganando 1-0 al descanso después de que el astro belga Eden Hazard anotara un gol en el minuto 25.
El delantero del Chelsea devolvió un pase a Mateo Kovacic en esa jugada, antes de girar cerca del medio campo y correr hacia la mitad del campo del Liverpool.
Kovacic hizo un rápido pase y desmarque en el medio campo.
Luego, lanzó un pase preciso que permitió a Hazard entrar al área.
Hazard superó a la defensa y anotó en el poste lejano con un disparo con el pie izquierdo que superó a Alisson Becker del Liverpool.
El miércoles a las 3 p. m., Liverpool se enfrentará a Napoli en la fase de grupos de la Liga de Campeones en el estadio San Paolo, en Nápoles, Italia.
El Chelsea se enfrenta al Videoton en la UEFA Europa League a las 3 p. m. del jueves en Londres.
El número de muertos por el tsunami en Indonesia asciende a 832
El número de muertos por el terremoto y el tsunami en Indonesia ha aumentado a 832, informó la agencia de gestión de desastres del país a primera hora del domingo.
Se informó que muchas personas quedaron atrapadas entre los escombros de los edificios derribados por el terremoto de magnitud 7,5 que ocurrió el viernes y provocó olas de hasta 20 pies de altura, dijo el portavoz de la agencia Sutopo Purwo Nugroho en una conferencia de prensa.
La ciudad de Palu, que tiene más de 380 000 habitantes, estaba llena de escombros de edificios derrumbados.
La policía arresta a un hombre de 32 años bajo sospecha de asesinato después de que una mujer fuera apuñalada hasta la muerte
Se inició una investigación por asesinato después de que esta mañana se encontrara el cuerpo de una mujer en Birkenhead, Merseyside.
El hombre de 44 años fue encontrado a las 7:55 a. m. con heridas de puñalada en Grayson Mews, en John Street, y un hombre de 32 años fue arrestado bajo sospecha de asesinato.
La policía ha instado a las personas de la zona que hayan visto u oído algo a que se presenten.
El inspector detective Brian O'Hagan dijo: “La investigación está en sus primeras etapas, pero quiero pedirle a cualquier persona que estuviera en las cercanías de John Street en Birkenhead y que haya visto u oído algo sospechoso que se comunique con nosotros.
También hago un llamado a cualquier persona, en particular a los taxistas, que haya capturado algo en las grabaciones de sus cámaras de tablero, para que se comunique con nosotros, ya que podrían tener información vital para nuestra investigación”.
Un portavoz de la policía confirmó que la mujer cuyo cuerpo fue encontrado es oriunda de Birkenhead y que fue hallada dentro de una propiedad.
Esta tarde, amigos que creen conocer a la mujer han llegado al lugar para hacer preguntas sobre dónde fue encontrada esta mañana.
Las investigaciones continúan, ya que la policía ha dicho que están en proceso de informar a los familiares más cercanos de la víctima.
Un taxista que vive en Grayson Mews acaba de intentar volver a entrar en su apartamento, pero la policía le ha dicho que nadie puede entrar ni salir del edificio.
Se quedó sin palabras cuando descubrió lo que había sucedido.
Ahora se les informa a los residentes que pasarán horas antes de que se les permita regresar.
Un agente de policía fue escuchado diciéndole a un hombre que toda el área ahora está siendo tratada como escena del crimen.
Una mujer apareció en la escena llorando.
Ella sigue repitiendo "es tan terrible".
A las 2 p. m., dos furgonetas policiales estaban dentro del cordón y otra furgoneta justo fuera.
Varios agentes se encontraban dentro del cordón, vigilando el bloque de apartamentos.
Cualquiera que tenga información se le pide que envíe un mensaje directo a @MerPolCC, llame al 101 o contacte a Crimestoppers de forma anónima al 0800 555 111, citando el registro 247 del 30 de septiembre.
La estatua de Cromwell en el Parlamento se convierte en el último monumento afectado por la polémica sobre la "reescritura de la historia"
Su destierro sería una justicia poética por la destrucción, a semejanza de los talibanes, de tantos artefactos culturales y religiosos de Inglaterra, llevada a cabo por sus fanáticos seguidores puritanos.
Pero la Sociedad Cromwell describió la sugerencia del señor Crick como una "locura" y un "intento de reescribir la historia".
John Goldsmith, presidente de la Cromwell Society, dijo: "Era inevitable que, en el debate actual sobre la retirada de estatuas, la figura de Oliver Cromwell fuera del Palacio de Westminster se convirtiera en un objetivo".
El iconoclasmo de las guerras civiles inglesas no fue ordenado ni ejecutado por Cromwell.
Tal vez el Cromwell equivocado sería sacrificado por las acciones de su antepasado Thomas en el siglo anterior.
La magnífica representación de Cromwell de Sir William Hamo Thorneycroft es una muestra de la opinión del siglo XIX y forma parte de la historiografía de una figura que muchos creen que aún merece ser celebrada.
El señor Goldsmith dijo a The Sunday Telegraph: "Muchos consideran a Cromwell, quizás más a finales del siglo XIX que hoy en día, como un defensor del parlamento frente a la presión externa, en su caso, por supuesto, la monarquía.
Si esta es una representación completamente precisa es el tema de un debate histórico continuo.
Lo que sí es cierto es que el conflicto de mediados del siglo XVII ha moldeado el desarrollo posterior de nuestra nación, y Cromwell es una figura reconocible que representa un lado de esa división.
Sus logros como Lord Protector también merecen ser celebrados y conmemorados".
Cerdo asesino desgarra a un agricultor chino hasta la muerte
Un agricultor fue atacado y asesinado por un cerdo en un mercado del suroeste de China, según informes de los medios locales.
El hombre, identificado solo por su apellido "Yuan", fue encontrado muerto con una arteria cortada, cubierto de sangre cerca de un chiquero en el mercado de Liupanshui, en la provincia de Guizhou, informó el South China Morning Post el domingo.
Un criador de cerdos se prepara para inyectar vacunas a los cerdos en una granja porcina el 30 de mayo de 2005 en Xining, provincia de Qinghai, China.
Según informes, había viajado con su primo desde la vecina provincia de Yunnan el miércoles para vender 15 cerdos en el mercado.
A la mañana siguiente, su primo lo encontró muerto y descubrió que la puerta de un cercano establo de cerdos estaba abierta.
Dijo que en el establo había un gran cerdo macho con sangre en la boca.
Un examen forense confirmó que el cerdo de 550 libras había despedazado al agricultor hasta causarle la muerte, según el informe.
"Las piernas de mi primo estaban ensangrentadas y destrozadas", dijo el primo, identificado solo por su apellido "Wu", según el Guiyang Evening News.
Las imágenes de las cámaras de seguridad mostraron a Yuan entrando al mercado a las 4:40 a. m. del jueves para alimentar a sus cerdos.
Su cuerpo fue encontrado aproximadamente una hora después.
El animal que mató al hombre no pertenecía a Yuan ni a su primo.
Un gerente del mercado le dijo al Evening News que el cerdo había sido encerrado para evitar que atacara a más personas, mientras la policía recopilaba pruebas en el lugar.
Según informes, la familia de Yuan y las autoridades del mercado están negociando una compensación por su muerte.
Aunque son raros, ya se han registrado casos de cerdos que atacan a humanos.
En 2016, un cerdo atacó a una mujer y a su esposo en su granja en Massachusetts, dejando al hombre con lesiones críticas.
Diez años antes, un cerdo de 650 libras había atrapado a un granjero galés contra su tractor hasta que su esposa ahuyentó al animal.
Después de que un agricultor de Oregón fuera devorado por sus cerdos en 2012, un agricultor de Manitoba le dijo a CBC News que los cerdos normalmente no son agresivos, pero el sabor de la sangre puede actuar como un "disparador".
"Simplemente están jugando.
Son críos, muy curiosos... no quieren hacerte daño.
Solo hay que pagarles la cantidad adecuada de respeto", dijo.
Los remanentes del huracán Rosa traerán lluvias intensas generalizadas al suroeste de EE. UU.
Como se pronosticó, el huracán Rosa se está debilitando mientras se desplaza sobre las aguas más frías de la costa norte de México.
Sin embargo, Rosa traerá lluvias torrenciales a todo el norte de México y al suroeste de Estados Unidos en los próximos días.
A las 5 a. m. del domingo, hora del este, Rosa tenía vientos de 85 mph, lo que la convierte en un huracán de categoría 1, y se encontraba a 385 millas al suroeste de Punta Eugenia, México.
Se espera que Rosa se desplace hacia el norte el domingo.
Mientras tanto, una depresión está comenzando a formarse sobre el océano Pacífico y se mueve hacia el este, en dirección a la costa oeste de EE. UU. A medida que Rosa se acerca a la península de Baja California el lunes como tormenta tropical, comenzará a empujar la humedad tropical hacia el norte, hacia el suroeste de EE. UU.
El lunes, Rosa provocará hasta 10 pulgadas de lluvia en algunas partes de México.
Luego, la humedad tropical, al interactuar con la vaguada que se acerca, generará lluvias intensas generalizadas en el suroeste en los próximos días.
A nivel local, entre 1 y 4 pulgadas de lluvia causarán inundaciones repentinas peligrosas, flujos de escombros y posibles deslizamientos de tierra en el desierto.
La humedad tropical profunda provocará que las tasas de lluvia alcancen entre 2 y 3 pulgadas por hora en algunos lugares, especialmente en partes del sur de Nevada y Arizona.
Se esperan entre 2 y 4 pulgadas de lluvia en partes del suroeste, especialmente en gran parte de Arizona.
Es posible que se produzcan inundaciones repentinas debido a la rápida deterioración de las condiciones, causada por la naturaleza dispersa de las lluvias tropicales.
Sería extremadamente desaconsejable aventurarse a pie en el desierto con la amenaza de lluvias tropicales.
Las fuertes lluvias podrían convertir los cañones en ríos embravecidos, y las tormentas eléctricas provocarán vientos fuertes y levantamiento de polvo en algunas zonas.
El frente que se acerca traerá lluvias intensas localmente a partes de la costa del sur de California.
Es posible que las precipitaciones superen la mitad de una pulgada, lo que podría provocar flujos de escombros menores y carreteras resbaladizas.
Esta sería la primera lluvia de la temporada húmeda en la región.
Algunas lluvias tropicales dispersas comenzarán a acercarse a Arizona a finales del domingo y a principios del lunes, antes de que la lluvia se extienda más ampliamente a finales del lunes y el martes.
Las fuertes lluvias se extenderán a los Cuatro Esquinas el martes y durarán hasta el miércoles.
En octubre, se pueden producir variaciones intensas de temperatura en todo Estados Unidos, ya que el Ártico se enfría, pero los trópicos siguen siendo bastante cálidos.
A veces, esto provoca cambios drásticos de temperatura en distancias cortas.
El domingo hubo un excelente ejemplo de las grandes diferencias de temperatura en el centro de EE. UU.
Existe una diferencia de casi 20 grados entre Kansas City, Misuri, y Omaha, Nebraska, y entre San Luis y Des Moines, Iowa.
Durante los próximos días, el calor persistente del verano intentará aumentar y expandirse nuevamente.
Se espera que gran parte del centro y este de los Estados Unidos tenga un inicio cálido de octubre, con temperaturas generalizadas de 80 °F desde las llanuras del sur hasta partes del noreste.
La ciudad de Nueva York podría alcanzar los 80 grados el martes, lo que estaría aproximadamente 10 grados por encima del promedio.
Nuestro pronóstico climático a largo plazo indica una alta probabilidad de temperaturas superiores al promedio en el este de los Estados Unidos durante la primera mitad de octubre.
Más de 20 millones de personas vieron la audiencia de Brett Kavanaugh
Más de 20 millones de personas vieron el conmovedor testimonio del jueves del candidato a la Corte Suprema Brett Kavanaugh y de la mujer que lo acusó de una agresión sexual que supuestamente ocurrió en la década de 1980, Christine Blasey Ford, en seis cadenas de televisión.
Mientras tanto, el estancamiento político continuó, con las emisoras interrumpiendo la programación regular para el giro de último momento del viernes: un acuerdo diseñado por el senador de Arizona Jeff Flake para que el FBI realice una investigación de una semana sobre los cargos.
Ford le dijo al Comité Judicial del Senado que está 100 % segura de que Kavanaugh la manoseó en estado de ebriedad y trató de quitarle la ropa en una fiesta de la escuela secundaria.
Kavanaugh, en un testimonio apasionado, dijo que está 100 % seguro de que eso no ocurrió.
Es probable que más de los 20,4 millones de personas reportadas por Nielsen el viernes lo hayan visto.
La empresa estaba contabilizando la audiencia promedio en CBS, ABC, NBC, CNN, Fox News Channel y MSNBC.
No se dispuso inmediatamente de cifras para otras cadenas que lo transmitieron, incluidas PBS, C-SPAN y Fox Business Network.
Además, Nielsen suele tener problemas para medir a las personas que ven la televisión en sus oficinas.
Para ponerlo en perspectiva, esa es una audiencia similar a la de un partido de fútbol de playoffs o a la de los Premios de la Academia.
Fox News Channel, cuyos presentadores de opinión han respaldado firmemente la designación de Kavanaugh, lideró todas las cadenas con un promedio de 5,69 millones de espectadores durante la audiencia de todo el día, según Nielsen.
ABC quedó en segundo lugar con 3,26 millones de espectadores.
CBS tuvo 3,1 millones, NBC tuvo 2,94 millones, MSNBC tuvo 2,89 millones y CNN tuvo 2,52 millones, dijo Nielsen.
El interés se mantuvo alto después de la audiencia.
Flake fue la figura central del drama del viernes.
Después de que la oficina del republicano moderado emitió un comunicado en el que afirmaba que votaría a favor de Kavanaugh, fue captado por las cámaras de CNN y CBS el viernes por la mañana mientras los manifestantes le gritaban mientras intentaba subir a un ascensor para asistir a una audiencia del Comité Judicial.
Se quedó de pie con la mirada baja durante varios minutos mientras lo regañaban, transmitido en vivo por CNN.
“Estoy de pie justo aquí, frente a usted”, dijo una mujer.
"¿Crees que está diciendo la verdad al país?
Le dijeron: "Tienes poder cuando tantas mujeres no tienen poder".
Flake dijo que su oficina había emitido un comunicado y, antes de que el ascensor se cerrara, afirmó que tendría más que decir en la audiencia del comité.
Las cadenas de televisión por cable y de emisión estaban cubriendo el evento en vivo horas después, cuando el Comité Judicial iba a votar para avanzar la nominación de Kavanaugh al Senado completo para una votación.
Pero Flake dijo que solo lo haría con la condición de que el FBI investigara las acusaciones contra el candidato la próxima semana, algo que los demócratas de la minoría han estado exigiendo.
Flake se convenció en parte gracias a las conversaciones con su amigo, el senador demócrata Chris Coons.
Después de una conversación con Coons y varios senadores posteriormente, Flake tomó su decisión.
La decisión de Flake tuvo un gran impacto, ya que era evidente que los republicanos no tendrían los votos necesarios para aprobar a Kavanaugh sin la investigación.
El presidente Trump ha iniciado una investigación del FBI sobre las acusaciones contra Kavanaugh.
La primera ministra británica May acusa a los críticos de "hacer política" con el Brexit
La primera ministra Theresa May acusó a los críticos de sus planes para abandonar la Unión Europea de "hacer política" con el futuro de Gran Bretaña y socavar el interés nacional en una entrevista con el periódico Sunday Times.
La primera ministra británica, Theresa May, llega a la conferencia del Partido Conservador en Birmingham, Reino Unido, el 29 de septiembre de 2018.
En otra entrevista publicada junto a la suya en la portada del periódico, su exministro de Asuntos Exteriores, Boris Johnson, intensificó su ataque a su llamado plan Chequers para el Brexit, afirmando que la propuesta de que Gran Bretaña y la UE se cobraran mutuamente los aranceles era "totalmente absurda".
Tiroteo de Wayde Sims: La policía arresta al sospechoso Dyteon Simpson por la muerte del jugador de LSU
La policía ha arrestado a un sospechoso por el homicidio de Wayde Sims, un jugador de baloncesto de 20 años de la LSU.
Dyteon Simpson, de 20 años, fue arrestado y encarcelado bajo cargos de homicidio en segundo grado, informó el Departamento de Policía de Baton Rouge.
Las autoridades publicaron un video de la confrontación entre Sims y Simpson, y la policía dijo que Sims perdió sus gafas durante la pelea.
La policía recuperó las gafas en la escena y dijo que encontraron el ADN de Simpson en ellas, informa WAFB, afiliada a CBS.
Después de interrogar a Simpson, la policía dijo que admitió haber disparado fatalmente a Wayde.
Su fianza se ha fijado en 350 000 dólares, informa el Advocate.
La oficina del forense de la parroquia de East Baton Rouge publicó un informe preliminar el viernes, en el que se indica que la causa de la muerte es una herida de bala en la cabeza que alcanzó el cuello.
El departamento agradece la colaboración del grupo de búsqueda de fugitivos de la Policía Estatal de Luisiana, el laboratorio de criminalística de la policía estatal, la policía de la Universidad del Sur y los ciudadanos de la zona en la investigación que condujo al arresto.
El director de deportes de la LSU, Joe Alleva, agradeció a las fuerzas del orden locales por su "diligencia y búsqueda de la justicia".
Sims tenía 20 años.
El alero de 1,98 metros creció en Baton Rouge, donde su padre, Wayne, también jugó baloncesto para LSU.
La temporada pasada promedió 5,6 puntos y 2,6 rebotes por partido.
El viernes por la mañana, el entrenador de baloncesto de LSU, Will Wade, dijo que el equipo estaba "devastado" y "en estado de shock" por la muerte de Wayde.
“Esto es de lo que te preocupas en todo momento”, dijo Wade.
Volcán arroja ceniza sobre la Ciudad de México
La ceniza expulsada por el volcán Popocatépetl ha llegado a los barrios del sur de la capital de México.
El Centro Nacional de Prevención de Desastres advirtió a los mexicanos el sábado que se mantuvieran alejados del volcán después de que la actividad en el cráter aumentara y se registraran 183 emisiones de gas y ceniza en 24 horas.
El centro estaba monitoreando múltiples rumores y temblores.
Las imágenes en las redes sociales mostraron finas capas de ceniza cubriendo los parabrisas de los automóviles en barrios de la Ciudad de México, como Xochimilco.
Los geofísicos han observado un aumento de la actividad en el volcán, ubicado a 45 millas (72 kilómetros) al sureste de la capital, desde que un terremoto de magnitud 7.1 sacudió el centro de México en septiembre de 2017.
El volcán conocido como "Don Goyo" ha estado activo desde 1994.
La policía se enfrenta a separatistas catalanes antes del aniversario del voto por la independencia
Seis personas fueron arrestadas en Barcelona el sábado después de que manifestantes independentistas se enfrentaran con la policía antidisturbios, mientras que miles de personas se unieron a manifestaciones rivales para conmemorar el primer aniversario del polarizador voto de Cataluña sobre la secesión.
Un grupo de pro-separatistas enmascarados, retenidos por la policía antidisturbios, les lanzaron huevos y pintura en polvo, creando densas nubes de polvo en calles que normalmente estarían llenas de turistas.
Más tarde, también se produjeron altercados, y la policía utilizó sus porras para contener los enfrentamientos.
Durante varias horas, grupos proindependentistas que coreaban "Ni olvido, ni perdón" se enfrentaron a manifestantes unionistas que gritaban "¡Larga vida a España!".
Catorce personas recibieron tratamiento por lesiones menores sufridas durante las protestas, informó la prensa local.
Las tensiones siguen siendo altas en la región independentista un año después del referéndum del 1 de octubre, considerado ilegal por Madrid pero celebrado por los separatistas catalanes.
Los votantes eligieron abrumadoramente la independencia, aunque la participación fue baja, ya que quienes se oponían a la secesión boicotearon en gran medida la votación.
Según las autoridades catalanas, casi 1000 personas resultaron heridas el año pasado después de que la policía intentara impedir la votación en los colegios electorales de toda la región, en violentos enfrentamientos.
Los grupos independentistas habían acampado durante la noche del viernes para evitar una manifestación en apoyo de la policía nacional.
La manifestación se llevó a cabo, pero se vio obligada a tomar una ruta diferente.
Narcis Termes, de 68 años, un electricista que asistió a la protesta separatista con su esposa, dijo que ya no tenía esperanzas sobre las posibilidades de que Cataluña lograra la independencia.
"El año pasado vivimos uno de nuestros mejores momentos.
Vi a mis padres llorar de alegría por poder votar, pero ahora estamos atrapados", dijo.
A pesar de lograr una victoria vital, aunque estrecha, en las elecciones regionales de diciembre pasado, los partidos independentistas catalanes han tenido dificultades para mantener el impulso este año, ya que muchos de sus líderes más conocidos están en exilio autoimpuesto o detenidos a la espera de juicio por su papel en la organización del referéndum y la posterior declaración de independencia.
Joan Puig, un mecánico de 42 años que grababa la protesta en apoyo a la policía en su teléfono, dijo que el conflicto había sido avivado por políticos de ambos bandos.
"Está cada vez más tenso", dijo.
El sábado, Oriol Junqueras, uno de los nueve líderes catalanes en prisión preventiva desde finales del año pasado, anunció que se presentará a las elecciones al Parlamento Europeo el próximo año.
"Presentarse como candidato a las elecciones europeas es la mejor manera de denunciar la regresión en los valores democráticos y la represión que hemos visto por parte del gobierno español", dijo.
Londonderry: Hombres arrestados después de que un automóvil embistiera una casa
Tres hombres, de 33, 34 y 39 años, fueron arrestados después de que un automóvil embistiera repetidamente una casa en Londonderry.
El incidente ocurrió en Ballynagard Crescent el jueves, alrededor de las 19:30 BST.
El detective inspector Bob Blemmings dijo que se causaron daños a las puertas y al propio edificio.
También es posible que en algún momento se haya disparado una ballesta contra el coche.
El gol de Menga le da a Livingston una victoria 1-0 sobre Rangers
El primer gol de Dolly Menga para el Livingston aseguró la victoria
El Livingston, que ascendió de categoría, sorprendió al Rangers y le propinó a Steven Gerrard su segunda derrota en 18 partidos como entrenador del club de Ibrox.
El gol de Dolly Menga resultó ser decisivo y permitió al equipo de Gary Holt igualar con el Hibernian en el segundo puesto.
El equipo de Gerrard sigue sin conseguir una victoria a domicilio en la Premiership esta temporada y se enfrentará al líder Hearts, al que le lleva ocho puntos de ventaja, el próximo domingo.
Antes de eso, los Rangers recibirán al Rapid Vienna en la Liga Europa el jueves.
Mientras tanto, Livingston extendió su racha invicta en la división a seis partidos, y el entrenador principal Holt aún no ha sufrido una derrota desde que reemplazó a Kenny Miller el mes pasado.
Livingston pierde oportunidades ante visitantes poco efectivos
El equipo de Holt debería haber estado adelante mucho antes de que marcaran, ya que su directa actuación causó todo tipo de problemas a los Rangers.
Scott Robinson logró avanzar, pero su esfuerzo se quedó corto frente a la portería, y Alan Lithgow solo pudo desviar su intento fuera después de deslizarse para interceptar el cabezazo de Craig Halkett en el área.
Los anfitriones estaban contentos de dejar que los Rangers jugaran frente a ellos, sabiendo que podrían causar problemas a los visitantes en los tiros libres.
Y así fue como llegó el gol crucial.
Los Rangers concedieron un tiro libre y el Livingston aprovechó la oportunidad. Declan Gallagher y Robinson se combinaron para preparar el tiro de Menga, quien controló el balón y anotó desde el centro del área.
En esa etapa, los Rangers habían dominado la posesión, pero encontraron que la defensa local era impenetrable y el portero Liam Kelly no tuvo mayores problemas.
Ese patrón continuó en la segunda mitad, aunque Alfredo Morelos obligó a Kelly a hacer una parada.
A Scott Pittman le negaron el gol los pies del portero de los Rangers, Allan McGregor, y Lithgow desvió el balón desde otro juego de posición de Livingston.
Los centros al área de Livingston no paraban de llegar y se despejaban constantemente, mientras que dos reclamaciones de penalti, tras la entrada de Halkett sobre el suplente Glenn Middleton y otra por mano, fueron desestimadas.
“Fenomenal” de Livingston - análisis
Alasdair Lamont de BBC Escocia en el Tony Macaroni Arena
Un rendimiento y un resultado fenomenales para Livingston.
Todos y cada uno de ellos fueron excelentes, siguiendo superando las expectativas en esta trayectoria ascendente.
Su estilo de juego y su plantilla apenas han cambiado desde su regreso a la máxima categoría, pero hay que reconocer el gran mérito de Holt por la forma en que ha galvanizado al equipo desde su llegada.
Tenía tantos héroes.
El capitán Halkett fue impresionante, organizando una defensa magníficamente estructurada, mientras que Menga mantuvo a Connor Goldson y Joe Worrall alerta durante todo el partido.
Sin embargo, los Rangers carecían de inspiración.
A pesar de que en ocasiones han sido muy buenos bajo el mando de Gerrard, no han alcanzado esos estándares.
Su juego final fue deficiente; solo una vez lograron superar a los locales, y esto es una llamada de atención para los Rangers, que se encuentran en la mitad de la tabla.
Erdogan recibe una recepción mixta en Colonia
Hubo sonrisas y cielos azules el sábado (29 de septiembre) cuando los líderes de Turquía y Alemania se reunieron para desayunar en Berlín.
Es el último día de la controvertida visita del presidente Erdogan a Alemania, cuyo objetivo es reparar las relaciones entre los aliados de la OTAN.
Han tenido desacuerdos sobre temas como los derechos humanos, la libertad de prensa y la adhesión de Turquía a la UE.
Después, Erdogan se dirigió a Colonia para inaugurar una enorme nueva mezquita.
La ciudad alberga la mayor población turca fuera de Turquía.
La policía citó razones de seguridad para impedir que una multitud de 25 000 personas se reuniera frente a la mezquita, pero muchos simpatizantes se congregaron en las cercanías para ver a su presidente.
Cientos de manifestantes anti-Erdogan, muchos de ellos kurdos, también hicieron oír sus voces, condenando tanto las políticas de Erdogan como la decisión del gobierno alemán de recibirlo en el país.
Las protestas enfrentadas reflejan la división que provoca un visitante aclamado como héroe por algunos turcos alemanes y denigrado como un autócrata por otros.
Accidente de tráfico en Deptford: un ciclista muere al colisionar con un coche
Un ciclista ha muerto en una colisión con un coche en Londres.
El accidente ocurrió cerca de la intersección de Bestwood Street y Evelyn Street, una calle concurrida en Deptford, al sureste de la ciudad, alrededor de las 10:15 BST.
El conductor del automóvil se detuvo y los paramédicos atendieron al hombre, pero este falleció en el lugar.
El accidente ocurrió meses después de que otro ciclista muriera en un atropello y fuga en Childers Street, a aproximadamente una milla de distancia del accidente del sábado.
La Policía Metropolitana informó que los agentes estaban trabajando para identificar al hombre e informar a sus familiares más cercanos.
Se han implementado cierres de carreteras y desvíos de autobuses, y se ha recomendado a los automovilistas que eviten la zona.
Prisión de Long Lartin: Seis oficiales heridos en disturbios
Seis funcionarios de prisiones resultaron heridos en un disturbio en una cárcel de alta seguridad para hombres, según informó la Oficina Penitenciaria.
El desorden estalló en HMP Long Lartin en Worcestershire alrededor de las 09:30 BST del domingo y continúa.
Se ha pedido a los oficiales especialistas del "Tornado" que intervengan para controlar la alteración del orden, que involucra a ocho reclusos y está contenida en un solo pabellón.
Los agentes fueron atendidos por lesiones menores en el rostro en el lugar de los hechos.
Un portavoz del Servicio Penitenciario dijo: “Se ha desplegado al personal penitenciario especialmente entrenado para hacer frente a un incidente en curso en HMP Long Lartin.
Seis miembros del personal fueron atendidos por lesiones.
No toleramos la violencia en nuestras prisiones y es evidente que los responsables serán entregados a la policía y podrían pasar más tiempo tras las rejas".
HMP Long Lartin alberga a más de 500 prisioneros, incluidos algunos de los delincuentes más peligrosos del país.
En junio se informó que el director de la prisión recibió tratamiento hospitalario después de ser atacado por un recluso.
Y en octubre del año pasado, se llamó a los agentes antidisturbios a la prisión para controlar un grave altercado en el que el personal fue atacado con bolas de billar.
El huracán Rosa amenaza a Phoenix, Las Vegas y Salt Lake City con inundaciones repentinas (las áreas afectadas por la sequía podrían beneficiarse)
Es raro que una depresión tropical afecte a Arizona, pero eso es exactamente lo que probablemente suceda a principios de la próxima semana, cuando la energía remanente del huracán Rosa atraviese el suroeste desértico, generando riesgos de inundaciones repentinas.
El Servicio Nacional de Meteorología ya ha emitido alertas de inundaciones repentinas para el lunes y el martes en el oeste de Arizona, el sur y el este de Nevada, el sureste de California y Utah, incluidas las ciudades de Phoenix, Flagstaff, Las Vegas y Salt Lake City.
Se espera que Rosa tome una ruta directa sobre Phoenix el martes, acercándose el lunes por la noche con lluvia.
El Servicio Meteorológico Nacional en Phoenix señaló en un tuit que solo "diez ciclones tropicales han mantenido el estado de tormenta tropical o depresión a menos de 200 millas de Phoenix desde 1950".
Katrina (1967) fue un huracán que se produjo a menos de 40 millas de la frontera de Arizona”.
Los últimos modelos del Centro Nacional de Huracanes predicen de 2 a 4 pulgadas de lluvia, con cantidades aisladas de hasta 6 pulgadas en el Mogollon Rim de Arizona.
Es probable que otras áreas del suroeste desértico, incluidas las Montañas Rocosas centrales y la Gran Cuenca, reciban de 1 a 2 pulgadas, con totales aislados de hasta 4 pulgadas posibles.
Para aquellos que no están en riesgo de inundaciones repentinas, la lluvia de Rosa puede ser una bendición, ya que la región está afectada por la sequía.
Aunque las inundaciones son una preocupación muy seria, es probable que parte de estas lluvias sea beneficiosa, ya que el suroeste actualmente está experimentando condiciones de sequía.
Según el Monitor de Sequía de EE. UU., más del 40 % de Arizona está experimentando al menos sequía extrema, la segunda categoría más alta”, informó weather.com.
En primer lugar, la trayectoria del huracán Rosa conduce a su llegada a tierra en la península de Baja California, en México.
Rosa, que aún tenía fuerza de huracán el domingo por la mañana con vientos máximos de 85 millas por hora, se encontraba a 385 millas al sur de Punta Eugenia, México, y se desplazaba hacia el norte a 12 millas por hora.
La tormenta se está encontrando con aguas más frías en el Pacífico y, por lo tanto, está perdiendo fuerza.
Por lo tanto, se espera que toque tierra en México con la fuerza de una tormenta tropical durante la tarde o la noche del lunes.
Las precipitaciones en algunas partes de México podrían ser intensas, lo que representa un riesgo significativo de inundaciones.
"Se esperan precipitaciones de entre 3 y 6 pulgadas desde Baja California hasta el noroeste de Sonora, con posibilidad de hasta 10 pulgadas", informó weather.com.
Luego, Rosa se desplazará hacia el norte a través de México como una tormenta tropical antes de llegar a la frontera de Arizona en las primeras horas de la mañana del martes como una depresión tropical, que luego se desplazará hacia el norte a través de Arizona y hacia el sur de Utah a última hora de la noche del martes.
"El principal peligro que se espera de Rosa o sus restos es la lluvia muy intensa en Baja California, el noroeste de Sonora y el suroeste desértico de EE. UU.", dijo el Centro Nacional de Huracanes.
Se espera que estas lluvias provoquen inundaciones repentinas y flujos de escombros que pongan en peligro la vida en los desiertos, y deslizamientos de tierra en terrenos montañosos.
Ataque en Midsomer Norton: cuatro arrestos por intento de asesinato
Tres adolescentes y un hombre de 20 años fueron arrestados bajo sospecha de intento de asesinato después de que un joven de 16 años fuera encontrado con heridas de cuchillo en Somerset.
El adolescente fue encontrado herido en la zona de Excelsior Terrace de Midsomer Norton, alrededor de las 04:00 BST del sábado.
Fue trasladado al hospital, donde permanece en estado "estable".
Un joven de 17 años, dos de 18 años y un hombre de 20 años fueron arrestados durante la noche en el área de Radstock, informó la Policía de Avon y Somerset.
Los agentes han pedido a cualquier persona que tenga grabaciones en el móvil de lo sucedido que se ponga en contacto con ellos.
Trump dice que Kavanaugh "sufrió la maldad, el enojo" del Partido Demócrata
“Un voto a favor del juez Kavanaugh es un voto para rechazar las tácticas despiadadas y escandalosas del Partido Demócrata”, dijo Trump en un mitin en Wheeling, West Virginia.
Trump dijo que Kavanaugh ha "sufrido la mezquindad, la ira" del Partido Demócrata durante todo su proceso de nominación.
Kavanaugh testificó ante el Congreso el jueves, negando de manera enérgica y emocional la acusación de Christine Blasey Ford de que la había agredido sexualmente décadas atrás, cuando ambos eran adolescentes.
Ford también testificó en la audiencia sobre su acusación.
El presidente dijo el sábado que "el pueblo estadounidense vio el brillo, la calidad y el coraje" de Kavanaugh ese día.
"Un voto a favor de la confirmación del juez Kavanaugh es un voto a favor de confirmar a uno de los juristas más destacados de nuestro tiempo, un jurista con un historial impecable de servicio público", dijo a la multitud de partidarios en Virginia Occidental.
El presidente hizo referencia indirecta a la nominación de Kavanaugh mientras hablaba sobre la importancia de la participación republicana en las elecciones de mitad de mandato.
“Faltan cinco semanas para una de las elecciones más importantes de nuestras vidas.
No estoy corriendo, pero en realidad sí estoy corriendo", dijo.
“Por eso estoy en todas partes luchando por grandes candidatos”.
Trump argumentó que los demócratas tienen como misión "resistir y obstruir".
Se espera que la primera votación clave sobre el procedimiento en el Senado sobre la nominación de Kavanaugh tenga lugar a más tardar el viernes, según ha informado a CNN un asistente de alto rango del liderazgo del Partido Republicano.
Cientos de muertos por el terremoto y el tsunami en Indonesia, y se espera que la cifra aumente
Al menos 384 personas murieron, muchas de ellas arrastradas por las enormes olas que golpearon las playas, cuando un fuerte terremoto y un tsunami azotaron la isla indonesia de Sulawesi, informaron las autoridades el sábado.
Cientos de personas se habían reunido para un festival en la playa de la ciudad de Palu el viernes cuando olas de hasta seis metros (18 pies) de altura golpearon la costa al anochecer, arrastrando a muchas personas hasta su muerte y destruyendo todo a su paso.
El tsunami siguió a un terremoto de magnitud 7,5.
"Cuando surgió la amenaza del tsunami ayer, la gente seguía realizando sus actividades en la playa y no corrió de inmediato, por lo que se convirtieron en víctimas", dijo Sutopo Purwo Nugroho, portavoz de la agencia de mitigación de desastres de Indonesia, BNPB, en una conferencia de prensa en Yakarta.
"El tsunami no vino solo, arrastró autos, troncos, casas, golpeó todo en tierra", dijo Nugroho, y agregó que el tsunami había viajado a través del mar abierto a velocidades de 800 km/h (497 mph) antes de golpear la costa.
Algunas personas treparon a los árboles para escapar del tsunami y sobrevivieron, dijo.
Alrededor de 16 700 personas fueron evacuadas a 24 centros en Palu.
Las fotografías aéreas publicadas por la agencia de gestión de desastres mostraron muchos edificios y tiendas destruidos, puentes retorcidos y colapsados, y una mezquita rodeada de agua.
Los réplicas continuaron sacudiendo la ciudad costera el sábado.
La serie de terremotos se sintió en una zona con 2,4 millones de personas.
La Agencia de Evaluación y Aplicación de Tecnología de Indonesia (BPPT) dijo en un comunicado que la energía liberada por el terremoto masivo del viernes fue aproximadamente 200 veces la potencia de la bomba atómica lanzada sobre Hiroshima en la Segunda Guerra Mundial.
La geografía de la ciudad, que se encuentra al final de una bahía larga y estrecha, podría haber aumentado el tamaño del tsunami, según se indica.
Nugroho describió los daños como "extensos" y dijo que miles de casas, hospitales, centros comerciales y hoteles se habían derrumbado.
Los cuerpos de algunas víctimas fueron encontrados atrapados bajo los escombros de edificios derrumbados, dijo, y agregó que 540 personas resultaron heridas y 29 estaban desaparecidas.
Nugroho dijo que las víctimas y los daños podrían ser mayores a lo largo de la costa, a 300 km (190 millas) al norte de Palu, en una zona llamada Donggala, que está más cerca del epicentro del terremoto.
Las comunicaciones "estaban totalmente paralizadas y no había información" de Donggala, dijo Nugroho.
Hay más de 300 000 personas viviendo allí”, dijo la Cruz Roja en un comunicado, y agregó que su personal y voluntarios se dirigían a las zonas afectadas.
"Esto ya es una tragedia, pero podría empeorar mucho", dijo.
El sábado, la agencia fue ampliamente criticada por no informar que un tsunami había golpeado Palu, aunque las autoridades dijeron que las olas habían llegado en el momento en que se emitió la alerta.
En un video amateur compartido en las redes sociales, se escucha a un hombre en el piso superior de un edificio gritando advertencias frenéticas sobre el tsunami que se acerca a las personas en la calle abajo.
En cuestión de minutos, una pared de agua choca contra la costa, arrastrando edificios y automóviles.
Reuters no pudo autenticar de inmediato el video.
El terremoto y el tsunami provocaron un gran apagón que cortó las comunicaciones en torno a Palu, lo que dificultó a las autoridades la coordinación de los esfuerzos de rescate.
Las autoridades informaron que el ejército comenzó a enviar aviones de carga con ayuda desde Yakarta y otras ciudades, pero los evacuados aún necesitan desesperadamente alimentos y otros productos básicos.
El aeropuerto de la ciudad ha sido reabierto solo para labores de ayuda y permanecerá cerrado hasta octubre.
El presidente Joko Widodo tenía previsto visitar los centros de evacuación en Palu el domingo.
El número de víctimas del tsunami en Indonesia supera las 800.
Es muy malo.
Aunque el personal de World Vision de Donggala logró llegar sano y salvo a la ciudad de Palu, donde los empleados se refugian en refugios de lona instalados en el patio de su oficina, pasaron por escenas de devastación en el camino, dijo el Sr. Doseba.
"Me dijeron que vieron muchas casas destruidas", dijo.
Es muy malo.
Incluso cuando los grupos de ayuda comenzaron los tristes preparativos para iniciar las labores de asistencia en caso de desastre, algunos se quejaron de que se estaba impidiendo que los trabajadores de ayuda extranjeros con amplia experiencia viajaran a Palu.
Según las normativas indonesias, la financiación, los suministros y el personal procedentes del extranjero solo pueden comenzar a fluir si el lugar de la calamidad se declara zona de desastre nacional.
Eso aún no ha sucedido.
“Todavía es un desastre a nivel provincial”, dijo Aulia Arriani, portavoz de la Cruz Roja de Indonesia.
"Una vez que el gobierno diga: "Está bien, esto es un desastre nacional", podremos abrirnos a la asistencia internacional, pero aún no hay un estatus".
Cuando cayó la segunda noche en Palu después del terremoto y el tsunami del viernes, amigos y familiares de los desaparecidos aún mantenían la esperanza de que sus seres queridos fueran los milagros que alivian las sombrías historias de los desastres naturales.
El sábado, un niño fue rescatado de un alcantarillado.
El domingo, los rescatistas liberaron a una mujer que había quedado atrapada bajo los escombros durante dos días, con el cuerpo de su madre a su lado.
Gendon Subandono, el entrenador del equipo nacional de parapente de Indonesia, había entrenado a dos de los parapentistas desaparecidos para los Juegos Asiáticos, que concluyeron a principios de este mes en Indonesia.
Otros de los atrapados en el Hotel Roa Roa, incluido el Sr. Mandagi, eran sus estudiantes.
"Como veterano en el campo del parapente, tengo mi propia carga emocional", dijo.
Gendon relató cómo, en las horas posteriores a la difusión de la noticia del derrumbe del Hotel Roa Roa entre la comunidad de parapentistas, había enviado desesperadamente mensajes de WhatsApp a los competidores de Palu, que participaban en el festival de playa.
Sin embargo, sus mensajes solo mostraban una marca de verificación gris, en lugar de un par de marcas azules.
“Creo que eso significa que los mensajes no se entregaron”, dijo.
Ladrones se llevan 26 750 dólares durante el reabastecimiento de un cajero automático en Newport on the Levee
El viernes por la mañana, unos ladrones robaron 26 750 dólares a un empleado de Brink's que estaba recargando un cajero automático en Newport on the Levee, según un comunicado de prensa del Departamento de Policía de Newport.
El conductor del automóvil había estado vaciando un cajero automático en el complejo de entretenimiento y preparándose para entregar más dinero, escribió el detective Dennis McCarthy en el comunicado.
Mientras él estaba ocupado, otro hombre "se acercó por detrás del empleado de Brink's" y robó una bolsa de dinero destinada a la entrega.
Según el comunicado, los testigos vieron a varios sospechosos huyendo de la escena, pero la policía no especificó el número de personas involucradas en el incidente.
Cualquier persona que tenga información sobre sus identidades debe ponerse en contacto con la policía de Newport al 859-292-3680.
Kanye West: El rapero cambia su nombre a Ye
El rapero Kanye West está cambiando su nombre, a Ye.
Al anunciar el cambio en Twitter el sábado, escribió: "El ser formalmente conocido como Kanye West".
West, de 41 años, ha sido apodado Ye desde hace algún tiempo y utilizó este apodo como título para su octavo álbum, que se lanzó en junio.
El cambio se produce antes de su aparición en Saturday Night Live, donde se espera que lance su nuevo álbum Yandhi.
Él reemplaza a la cantante Ariana Grande en el programa, quien canceló su participación por "razones emocionales", dijo el creador del programa.
Además de ser una abreviatura de su nombre profesional actual, West ha dicho anteriormente que la palabra tiene un significado religioso para él.
"Creo que 'ye' es la palabra más utilizada en la Biblia, y en la Biblia significa 'tú'", dijo West a principios de este año, mientras discutía el título de su álbum con el presentador de radio Big Boy.
“Entonces yo soy tú, yo soy nosotros, somos nosotros.
Pasó de Kanye, que significa el único, a simplemente Ye, que es simplemente un reflejo de lo bueno, lo malo, lo confuso, de todo.
El álbum es más una reflexión de quiénes somos".
Él es uno de los muchos raperos famosos que cambiaron su nombre.
Sean Combs ha sido conocido con varios nombres, como Puff Daddy, P. Diddy o Diddy, pero este año anunció su preferencia por los nombres Love y Brother Love.
Un antiguo colaborador de West, JAY-Z, también ha utilizado su nombre con o sin guion y mayúsculas.
El presidente de México, AMLO, promete no usar al ejército contra los civiles
El presidente electo de México, Andrés Manuel López Obrador, ha prometido nunca utilizar la fuerza militar contra civiles, mientras el país se acerca al 50.º aniversario de una sangrienta represalia contra estudiantes.
López Obrador prometió el sábado en la Plaza de Tlatelolco que "nunca, jamás, utilizaría al ejército para reprimir al pueblo mexicano".
El 2 de octubre de 1968, las tropas dispararon contra una manifestación pacífica en la plaza, matando a unas 300 personas en un momento en que los movimientos estudiantiles de izquierda estaban tomando fuerza en toda América Latina.
López Obrador se ha comprometido a apoyar a los jóvenes mexicanos otorgando subsidios mensuales a quienes estudian y abriendo más universidades públicas gratuitas.
Ha dicho que el desempleo y la falta de oportunidades educativas atraen a los jóvenes hacia las pandillas criminales.
Estados Unidos debería duplicar la financiación de la inteligencia artificial
A medida que China se vuelve más activo en inteligencia artificial, Estados Unidos debería duplicar la cantidad que gasta en investigación en este campo, dice el inversor y experto en IA Kai-Fu Lee, quien ha trabajado para Google, Microsoft y Apple.
Los comentarios se producen después de que varias partes del gobierno de EE. UU. hayan hecho anuncios sobre IA, incluso cuando EE. UU. en general carece de una estrategia formal de IA.
Mientras tanto, China presentó su plan el año pasado: su objetivo es ser el número uno en innovación de IA para 2030.
“Duplicar el presupuesto de investigación en IA sería un buen comienzo, dado que todos los demás países están mucho más rezagados que Estados Unidos y estamos buscando el próximo avance en IA”, dijo Lee.
Duplicar la financiación podría duplicar las posibilidades de que el próximo gran logro en IA se produzca en Estados Unidos, dijo Lee a CNBC en una entrevista esta semana.
Lee, cuyo libro "AI Superpowers: China, Silicon Valley and the New World Order" fue publicado este mes por Houghton Mifflin Harcourt, es director ejecutivo de Sinovation Ventures, que ha invertido en una de las empresas de IA más destacadas de China, Face++.
En la década de 1980, en la Universidad Carnegie Mellon, trabajó en un sistema de inteligencia artificial que venció al jugador estadounidense de Othello mejor clasificado, y más tarde fue ejecutivo en Microsoft Research y presidente de la filial china de Google.
Lee reconoció las anteriores competiciones tecnológicas del gobierno de EE. UU., como el Desafío de Robótica de la Agencia de Proyectos de Investigación Avanzada de Defensa, y preguntó cuándo sería la siguiente, con el fin de ayudar a identificar a los próximos visionarios.
Los investigadores en EE. UU. a menudo tienen que trabajar duro para obtener subvenciones gubernamentales, dijo Lee.
“No es China la que se está llevando a los líderes académicos; son las corporaciones”, dijo Lee.
En los últimos años, Facebook, Google y otras empresas tecnológicas han contratado a destacados profesionales de universidades para trabajar en inteligencia artificial.
Lee dijo que los cambios en la política de inmigración también podrían ayudar a Estados Unidos a reforzar sus esfuerzos en IA.
“Creo que las tarjetas verdes deberían ofrecerse automáticamente a los doctores en inteligencia artificial”, dijo.
El Consejo de Estado de China publicó su Plan de Desarrollo de Inteligencia Artificial de Nueva Generación en julio de 2017.
La Fundación Nacional de Ciencias Naturales de China proporciona financiación a personas en instituciones académicas de manera similar a como la Fundación Nacional de Ciencias y otras organizaciones gubernamentales distribuyen dinero a investigadores de EE. UU., pero la calidad del trabajo académico es menor en China, dijo Lee.
A principios de este año, el Departamento de Defensa de EE. UU. estableció un Centro Conjunto de Inteligencia Artificial, que pretende involucrar a socios de la industria y la academia, y la Casa Blanca anunció la formación de un Comité Selecto sobre Inteligencia Artificial.
Y este mes, DARPA anunció una inversión de 2000 millones de dólares en una iniciativa llamada AI Next.
En cuanto a la NSF, actualmente invierte más de 100 millones de dólares al año en investigación de IA.
Mientras tanto, la legislación de EE. UU. que buscaba crear una Comisión Nacional de Seguridad sobre Inteligencia Artificial no ha tenido avances en meses.
Los macedonios votan en un referéndum sobre si cambiar el nombre del país
El pueblo de Macedonia votó en un referéndum el domingo sobre si cambiar su nombre a "República de Macedonia del Norte", una medida que resolvería una disputa de décadas con Grecia, que había bloqueado sus solicitudes de membresía en la Unión Europea y la OTAN.
Grecia, que tiene una provincia llamada Macedonia, sostiene que el nombre de su vecino del norte representa una reclamación sobre su territorio y ha vetado su entrada en la OTAN y la UE.
Los dos gobiernos llegaron a un acuerdo en junio basado en el nuevo nombre propuesto, pero los opositores nacionalistas argumentan que el cambio socavaría la identidad étnica de la mayoría eslava de Macedonia.
El presidente Gjorge Ivanov ha dicho que no votará en el referéndum y una campaña de boicot ha generado dudas sobre si la participación alcanzará el mínimo del 50 % requerido para que el referéndum sea válido.
La pregunta en la papeleta del referéndum decía: "¿Está a favor de la adhesión a la OTAN y a la UE con la aceptación del acuerdo con Grecia?"
Los partidarios del cambio de nombre, entre ellos el primer ministro Zoran Zaev, argumentan que es un precio que vale la pena pagar para lograr la admisión de Macedonia, uno de los países que surgieron del colapso de Yugoslavia, en organismos como la UE y la OTAN.
“Vine hoy a votar por el futuro del país, por los jóvenes de Macedonia para que puedan vivir libremente bajo el paraguas de la Unión Europea, porque eso significa una vida más segura para todos nosotros”, dijo Olivera Georgijevska, de 79 años, en Skopie.
Aunque no es jurídicamente vinculante, un número suficiente de miembros del parlamento han dicho que respetarán el resultado de la votación, lo que la hace decisiva.
El cambio de nombre requeriría una mayoría de dos tercios en el parlamento.
La comisión electoral estatal dijo que no había habido informes de irregularidades a la 1 p. m.
Sin embargo, la participación fue de solo el 16 %, en comparación con el 34 % en las últimas elecciones parlamentarias de 2016, cuando el 66 % de los votantes registrados emitieron su voto.
"Vine a votar por mis hijos, nuestro lugar está en Europa", dijo Gjose Tanevski, de 62 años, un votante en la capital, Skopje.
El primer ministro de Macedonia, Zoran Zaev, su esposa Zorica y su hijo Dushko emitieron su voto en el referéndum en Macedonia sobre el cambio del nombre del país, que abriría el camino para su ingreso a la OTAN y la Unión Europea, en Strumica, Macedonia, el 30 de septiembre de 2018.
Frente al parlamento en Skopje, Vladimir Kavardarkov, de 54 años, estaba preparando un pequeño escenario y colocando sillas frente a las tiendas de campaña instaladas por quienes boicotearán el referéndum.
"Estamos a favor de la OTAN y la UE, pero queremos unirnos con la cabeza en alto, no por la puerta de servicio", dijo Kavadarkov.
“Somos un país pobre, pero tenemos dignidad.
Si no quieren aceptarnos como Macedonia, podemos recurrir a otros países como China y Rusia y formar parte de la integración euroasiática".
El primer ministro Zaev afirma que la membresía en la OTAN atraerá las inversiones que Macedonia necesita con urgencia, ya que el país tiene una tasa de desempleo superior al 20 %.
"Creo que la gran mayoría estará a favor, porque más del 80 % de nuestros ciudadanos apoyan a la UE y la OTAN", dijo Zaev después de emitir su voto.
Dijo que un resultado de "sí" sería "una confirmación de nuestro futuro".
Una encuesta publicada el pasado lunes por el Instituto de Investigación de Políticas de Macedonia indicó que entre el 30 y el 43 por ciento de los votantes participarían en el referéndum, lo que está por debajo de la participación requerida.
Otra encuesta, realizada por Telma TV de Macedonia, encontró que el 57 % de los encuestados planeaba votar el domingo.
De ellos, el 70 por ciento dijo que votaría a favor.
Para que el referéndum sea exitoso, la participación debe ser del 50 % más un voto.
Un fracaso en el referéndum representaría el primer golpe serio a la política del gobierno prooccidental desde que asumió el poder en mayo del año pasado.
Vídeo: Sergio Agüero, del Manchester City, supera a toda la defensa del Brighton para marcar un gol
Sergio Agüero y Raheem Sterling superaron a la defensa del Brighton en la victoria del Manchester City por 2-0 el sábado en el Etihad Stadium de Manchester, Inglaterra.
Aguero hizo que pareciera ridículamente fácil al marcar en el minuto 65.
El delantero argentino recibió un pase en el medio campo al inicio de la secuencia.
Corrió entre tres defensores del Brighton antes de adentrarse en campo abierto.
Aguero se encontró rodeado por cuatro camisetas verdes.
Esquivó a un defensa y luego superó a varios más en el borde del área de Brighton.
Luego, hizo un pase a su izquierda, encontrando a Sterling.
El delantero inglés utilizó su primer toque en el área para devolverle el balón a Agüero, quien usó su pie derecho para superar al portero del Brighton, Mathew Ryan, con un disparo al lado derecho de la red.
"Aguero está lidiando con algunos problemas en sus pies", dijo el entrenador del City, Pep Guardiola, a los periodistas.
"Le dijimos que jugara 55, 60 minutos.
Eso fue lo que pasó.
Tuvimos suerte de que marcara un gol en ese momento".
Pero fue Sterling quien le dio a los Sky Blues la ventaja inicial en el enfrentamiento de la Premier League.
Ese gol llegó en el minuto 29.
Aguero recibió el balón en territorio de Brighton en esa jugada.
Envió un pase precioso por el flanco izquierdo a Leroy Sane.
Sane dio unos pocos toques antes de dirigir a Sterling hacia el poste lejano.
El delantero de los Sky Blues tocó el balón y lo metió en la red justo antes de salirse de los límites.
El City se enfrenta al Hoffenheim en la fase de grupos de la Liga de Campeones el martes a las 12:55 p. m. en el Rhein-Neckar-Arena, en Sinsheim, Alemania.
Scherzer quiere ser un estorbo para los Rockies
Con los Nationals eliminados de la contienda por los playoffs, no había mucha razón para forzar otro inicio.
Pero el siempre competitivo Scherzer espera subir al montículo el domingo contra los Rockies de Colorado, pero solo si todavía hay implicaciones para los playoffs para los Rockies, que tienen una ventaja de un juego sobre los Dodgers de Los Ángeles en la División Oeste de la Liga Nacional.
Los Rockies aseguraron al menos un puesto de comodín con una victoria de 5-2 sobre los Nationals el viernes por la noche, pero aún buscan asegurar su primer título de división.
"Aunque estemos jugando sin nada en juego, al menos podemos pisar el terreno de juego sabiendo que el ambiente aquí en Denver, con la multitud y el otro equipo, probablemente sería el de mayor nivel que enfrentaría en todo el año.
¿Por qué no querría competir en eso?"
Los Nationals aún no han anunciado a un lanzador para el domingo, pero, según informes, están inclinados a dejar que Scherzer lance en esa situación.
Scherzer, que estaría haciendo su 34.ª salida, lanzó una sesión de práctica en el bullpen el jueves y estaría lanzando el domingo en su descanso normal.
El lanzador diestro de Washington tiene un récord de 18-7 con una efectividad de 2.53 y 300 ponchados en 220 entradas y 2/3 esta temporada.
Trump se reúne con sus seguidores en Virginia Occidental
El presidente hizo referencia indirecta a la situación que rodea a su candidato para la Corte Suprema, Brett Kavanaugh, mientras hablaba sobre la importancia de la participación republicana en las elecciones de mitad de mandato.
"Todo lo que hemos hecho está en juego en noviembre.
A cinco semanas de una de las elecciones más importantes de nuestras vidas.
“Es una de las grandes, grandes razones por las que no estoy compitiendo, pero en realidad sí estoy compitiendo, y por eso estoy en todas partes luchando por grandes candidatos”, dijo.
Trump continuó: "Vemos este horrible, horrible grupo radical de demócratas, y vemos que está sucediendo ahora mismo.
Están decididos a recuperar el poder utilizando cualquier medio necesario; puedes ver la mezquindad, la maldad.
No les importa a quién lastiman, a quién tienen que atropellar para obtener poder y control, eso es lo que quieren: poder y control, y no se lo vamos a dar".
Los demócratas, dijo, tienen como misión "resistir y obstruir".
“Y eso se ha visto en los últimos cuatro días”, dijo, calificando a los demócratas de “enfadados, malvados, desagradables y falsos”.
Mencionó por su nombre a la senadora demócrata Dianne Feinstein, del Comité Judicial del Senado, lo que provocó fuertes abucheos del público.
"¿Recuerdan su respuesta?
¿Fue usted quien filtró el documento?
Eh, eh, ¿qué?
No, no, yo esperé un momento, ese fue un lenguaje corporal realmente malo, el peor lenguaje corporal que he visto jamás".
El Partido Laborista ya no es un espacio amplio y diverso.
Es intolerante con aquellos que expresan su opinión
Cuando los activistas de Momentum en mi partido local votaron para censurarme, no fue ninguna sorpresa.
Después de todo, soy el último en una larga lista de diputados laboristas a quienes se les ha dicho que no son bienvenidos, todo por expresar nuestra opinión.
Mi colega parlamentaria Joan Ryan recibió un trato similar porque se opuso con firmeza al antisemitismo.
En mi caso, la moción de censura me criticó por no estar de acuerdo con Jeremy Corbyn.
Sobre la importancia de una política económica responsable, sobre la seguridad nacional, sobre Europa, irónicamente temas similares en los que Jeremy discrepaba con los líderes anteriores.
El aviso para la reunión del Partido Laborista de Nottingham East del viernes decía que "queremos que las reuniones sean inclusivas y productivas".
Durante la mayor parte de mis ocho años como diputado local del Partido Laborista, las reuniones del GC los viernes por la noche han sido exactamente eso.
Lamentablemente, hoy en día, no es el tono de muchas reuniones y la promesa de una política "más amable y suave" ha sido olvidada hace mucho tiempo, si es que alguna vez comenzó.
Se ha vuelto cada vez más evidente que las opiniones divergentes no son toleradas en el Partido Laborista y cada opinión es juzgada en función de si es aceptable para la dirección del partido.
Esto comenzó poco después de que Jeremy se convirtiera en líder, cuando colegas con quienes antes pensaba que compartía una visión política similar comenzaron a esperar que hiciera un cambio radical y adoptara posiciones con las que nunca habría estado de acuerdo de otra manera, ya fuera en materia de seguridad nacional o del mercado único de la UE.
Cada vez que hablo en público, y no importa realmente lo que diga, sigue una diatriba de insultos en las redes sociales pidiendo mi exclusión, denunciando la política del centro, diciéndome que no debería estar en el Partido Laborista.
Y eso no es solo mi experiencia.
De hecho, sé que tengo más suerte que algunos de mis colegas, ya que los comentarios dirigidos a mí tienden a ser de naturaleza política.
Admiro la profesionalidad y la determinación de esos colegas que se enfrentan a un torrente de abusos sexistas o racistas todos los días, pero nunca se echan atrás.
Uno de los aspectos más decepcionantes de esta era política es cómo los niveles de abuso se han normalizado.
Jeremy Corbyn afirmó la semana pasada que el Partido Laborista debería fomentar una cultura de tolerancia.
La realidad es que ya no somos ese partido tan diverso y, con cada moción de "no confianza" o cambio en las reglas de selección, el partido se vuelve más estrecho.
En los últimos dos años, he recibido muchos consejos que me instaban a mantener la cabeza baja, a no ser tan expresivo, y entonces "todo estaría bien".
Pero eso no es por lo que entré en política.
Desde que me uní al Partido Laborista hace 32 años, siendo un estudiante de secundaria, provocado por el abandono del gobierno de Thatcher que había dejado mi aula de la escuela secundaria literalmente en ruinas, he buscado defender mejores servicios públicos para aquellos que más los necesitan, ya sea como concejal local o como ministro del gobierno.
Nunca he ocultado mis ideas políticas, ni siquiera en las últimas elecciones.
Nadie en Nottingham East podría haberse confundido en absoluto acerca de mis posturas políticas y áreas de desacuerdo con el liderazgo actual.
A quienes promovieron la moción el viernes, solo diría que, cuando el país se dirige hacia un Brexit que perjudicará a los hogares, las empresas y nuestros servicios públicos, no entiendo el deseo de perder tiempo y energía en mi lealtad al líder del Partido Laborista.
Pero en realidad, el mensaje que quiero transmitir no es para Nottingham Momentum, sino para mis electores, sean o no miembros del Partido Laborista: estoy orgulloso de servirles y prometo que ninguna amenaza de exclusión ni la conveniencia política me impedirán actuar en lo que creo que son los mejores intereses de todos ustedes.
Chris Leslie es diputado por Nottingham East
Ayr 38 - 17 Melrose: Ayr, invicto, se coloca en lo más alto
Dos ensayos tardíos pueden haber alterado un poco el resultado final, pero no cabe duda de que Ayr mereció triunfar en este maravillosamente entretenido partido de la Tennent's Premiership del día.
Ahora lideran la tabla, siendo el único equipo invicto de los diez.
Al final, fue su defensa superior, tanto como su mejor capacidad para aprovechar las oportunidades, lo que llevó al equipo local a la victoria, y el entrenador Peter Murchie tenía todo el derecho a estar satisfecho.
“Hemos sido puestos a prueba en los partidos hasta ahora, y seguimos invictos, así que tengo que estar contento”, dijo.
Robyn Christie de Melrose dijo: "Hay que reconocer que Ayr aprovechó sus oportunidades mejor que nosotros".
El ensayo de Grant Anderson en el minuto 14, convertido por Frazier Climo, puso a Ayr en ventaja, pero una tarjeta amarilla para el capitán de Escocia, Rory Hughes, liberado para el partido por los Warriors, permitió a Melrose aprovechar la superioridad numérica y Jason Baggot anotó un ensayo no convertido.
Climo amplió la ventaja de Ayr con un penal, y justo antes del descanso, anotó y luego convirtió un ensayo en solitario, lo que dejó el marcador en 17-5 a favor de Ayr al término de la primera mitad.
Pero Melrose comenzó bien la segunda mitad y el ensayo de Patrick Anderson, convertido por Baggot, redujo la diferencia a cinco puntos.
Luego hubo una larga interrupción debido a una lesión grave de Ruaridh Knott, quien fue retirado en camilla, y tras el reinicio, Ayr se adelantó aún más gracias a un ensayo de Stafford McDowall, convertido por Climo.
El capitán suplente de Ayr, Blair Macpherson, recibió una tarjeta amarilla, y, una vez más, Melrose aprovechó la ventaja numérica con un ensayo no convertido de Bruce Colvine, al final de un periodo de intensa presión.
Sin embargo, el equipo local reaccionó y, cuando Struan Hutchinson recibió una tarjeta amarilla por derribar a Climo sin balón, desde el lanzamiento de penal, MacPherson anotó en la parte trasera del maul de Ayr que avanzaba.
Climo convirtió el ensayo, como lo hizo de nuevo casi desde el reinicio, después de que Kyle Rowe recogiera el box kick de David Armstrong y enviara al flanker Gregor Henry para el quinto ensayo del equipo local.
La estrella de Still Game parece estar lista para una nueva carrera en la industria de la restauración
El actor de Still Game, Ford Kieran, parece estar listo para entrar en el sector de la hostelería después de que se descubriera que ha sido nombrado director de una empresa de restaurantes con licencia.
El actor de 56 años interpreta a Jack Jarvis en el popular programa de la BBC, que escribe y en el que coprotagoniza junto a su compañero de comedia de toda la vida, Greg Hemphill.
El dúo anunció que la novena temporada, que se estrenará próximamente, será la última de la serie, y parece que Kiernan está planeando su vida después de Craiglang.
Según los registros oficiales, él es el director de Adriftmorn Limited.
El actor se negó a comentar la historia, aunque una fuente de The Scottish Sun insinuó que Kiernan estaba interesado en involucrarse en el "florido negocio de los restaurantes" de Glasgow.
"El mar es nuestro": Bolivia, un país sin litoral, espera que el tribunal reabra el camino hacia el Pacífico
Los marineros patrullan un cuartel general naval cubierto de aparejos en La Paz.
Los edificios públicos ondean una bandera de color azul océano.
Las bases navales, desde el lago Titicaca hasta el Amazonas, están adornadas con el lema: "El mar es nuestro por derecho".
Recuperarlo es un deber".
En toda Bolivia, un país sin litoral, el recuerdo de una costa perdida ante Chile en un sangriento conflicto por recursos en el siglo XIX sigue siendo vívido, al igual que el anhelo de navegar nuevamente por el Océano Pacífico.
Esas esperanzas son quizás las más altas en décadas, ya que Bolivia espera una decisión del Tribunal Internacional de Justicia el 1 de octubre, después de cinco años de deliberaciones.
"Bolivia tiene el impulso, un espíritu de unidad y serenidad, y, por supuesto, espera con una visión positiva el resultado", dijo Roberto Calzadilla, un diplomático boliviano.
Muchos bolivianos verán el fallo de la CIJ en grandes pantallas en todo el país, con la esperanza de que el tribunal de La Haya se pronuncie a favor de la reclamación de Bolivia de que, después de décadas de conversaciones intermitentes, Chile está obligado a negociar y conceder a Bolivia una salida soberana al mar.
Evo Morales, el carismático presidente indígena de Bolivia, que enfrenta una controvertida batalla por su reelección el próximo año, también tiene mucho en juego en la decisión del lunes.
"Estamos muy cerca de regresar al Océano Pacífico", prometió a finales de agosto.
Sin embargo, algunos analistas creen que es poco probable que el tribunal decida a favor de Bolivia y que, incluso si lo hiciera, poco cambiaría.
El organismo de la ONU con sede en los Países Bajos no tiene la potestad de otorgar territorio chileno y ha estipulado que no determinará el resultado de las posibles negociaciones.
El hecho de que la sentencia de la CIJ se produzca solo seis meses después de que se escucharan los alegatos finales indica que el caso "no era complicado", dijo Paz Zárate, una experta chilena en derecho internacional.
Y, lejos de promover la causa de Bolivia, los últimos cuatro años pueden haberla retrasado.
"La cuestión del acceso al mar ha sido secuestrada por la actual administración boliviana", dijo Zárate.
La retórica beligerante de Morales ha socavado cualquier buena voluntad residual de Chile, sugirió.
Bolivia y Chile seguirán hablando en algún momento, pero será extremadamente difícil mantener conversaciones después de esto.
Los dos países no han intercambiado embajadores desde 1962.
El expresidente Eduardo Rodríguez Veltzé, representante de Bolivia en La Haya, rechazó la idea de que la toma de decisiones del tribunal fue inusualmente rápida.
El lunes, Bolivia tendrá "una oportunidad extraordinaria para abrir una nueva era de relaciones con Chile" y la posibilidad de "poner fin a 139 años de desacuerdos con beneficios mutuos", dijo.
Calzadilla también negó que Morales, que sigue siendo uno de los presidentes más populares de América Latina, estuviera utilizando el tema marítimo como un recurso político.
"Bolivia nunca renunciará a su derecho de tener acceso al Océano Pacífico", agregó.
"La sentencia es una oportunidad para ver que necesitamos superar el pasado".
Corea del Norte dice que no habrá desarme nuclear a menos que pueda confiar en EE. UU.
El ministro de Asuntos Exteriores de Corea del Norte, Ri Yong Ho, afirma que su nación nunca desarmará sus armas nucleares primero si no puede confiar en Washington.
Ri habló el sábado en la Asamblea General de las Naciones Unidas.
Pidió a Estados Unidos que cumpla las promesas hechas durante una cumbre en Singapur entre los líderes de ambos países.
Sus comentarios se producen en un momento en que el secretario de Estado de EE. UU., Mike Pompeo, parece estar a punto de reanudar la diplomacia nuclear estancada, más de tres meses después de la cumbre de Singapur con Kim Jong Un de Corea del Norte.
Ri dice que es un "sueño imposible" que las sanciones continuas y la objeción de Estados Unidos a una declaración que ponga fin a la Guerra de Corea logren doblegar al Norte.
Washington es reacio a aceptar la declaración sin que Pyongyang realice primero movimientos significativos de desarme.
Tanto Kim como el presidente de EE. UU., Donald Trump, quieren una segunda cumbre.
Pero existe un escepticismo generalizado sobre si Pyongyang está realmente dispuesta a renunciar a un arsenal que el país probablemente considera como la única forma de garantizar su seguridad.
Pompeo planea visitar Pyongyang el próximo mes para preparar una segunda cumbre entre Kim y Trump.
Los desfiles de moda de París revelan la última línea de sombreros de gran tamaño que pronto estarán disponibles en una tienda de moda cerca de usted.
Si quieres ampliar tu colección de sombreros o bloquear completamente el sol, no busques más.
Los diseñadores Valentino y Thom Browne presentaron una variedad de extravagantes accesorios para la cabeza de gran tamaño en su colección SS19 en la pasarela, que deslumbró al público de la Semana de la Moda de París.
Este verano, los sombreros muy poco prácticos han inundado Instagram, y estos diseñadores han desfilado sus llamativas creaciones por la pasarela.
La pieza destacada de Valentino fue un sombrero beige exagerado, adornado con un ala ancha que parecía una pluma y que cubría por completo la cabeza de las modelos.
Otros accesorios de gran tamaño incluyen sandías engarzadas con joyas, un sombrero de mago e incluso una piña, pero no están diseñados para mantener la cabeza caliente.
Thom Browne también reveló una selección de máscaras extrañas, justo a tiempo para Halloween.
Muchas de las coloridas máscaras tenían los labios cosidos y se parecían más a Hannibal Lecter que a la alta costura.
Una de las creaciones se asemejaba a un equipo de buceo completo con tubo de respiración y gafas, mientras que otra parecía un cono de helado derretido.
Y si sigues la gran tendencia de moda, ¡tienes suerte!
Los expertos en moda predicen que los enormes gorros podrían estar llegando a las calles comerciales de tu ciudad.
Los sombreros de gran tamaño llegan justo después de "La Bomba", el sombrero de paja con un ala de dos pies de ancho que ha sido visto en todo el mundo, desde Rihanna hasta Emily Ratajkowski.
La marca de culto detrás del sombrero altamente poco práctico que inundó las redes sociales presentó otra gran creación en la pasarela: una bolsa de playa de paja casi tan grande como la modelo que la llevaba, vestida con un traje de baño.
El bolso de rafia naranja quemado, adornado con flecos de rafia y rematado con un asa de cuero blanco, fue la pieza destacada de la colección La Riviera SS19 de Jacquemus en la Semana de la Moda de París.
El estilista de celebridades Luke Armitage le dijo a FEMAIL: "Espero ver grandes sombreros y bolsas de playa en las tiendas de alta gama para el próximo verano, ya que el diseñador ha tenido un impacto tan grande que sería difícil ignorar la demanda de accesorios de gran tamaño".
John Edward: Las habilidades lingüísticas son esenciales para los ciudadanos globales
Las escuelas independientes de Escocia mantienen un historial de excelencia académica, y esto ha continuado en 2018 con otro conjunto de resultados excepcionales en los exámenes, lo cual se ve reforzado por el éxito individual y colectivo en deportes, arte, música y otros esfuerzos comunitarios.
Con más de 30 000 alumnos en toda Escocia, estas escuelas, representadas por el Consejo Escocés de Escuelas Independientes (SCIS), se esfuerzan por ofrecer el mejor nivel de servicio a sus alumnos y padres.
Los colegios independientes tienen como objetivo preparar a sus alumnos para la educación superior, la carrera que elijan y su lugar como ciudadanos globales.
Como sector educativo que puede diseñar e implementar un plan de estudios escolar personalizado, observamos que las lenguas modernas siguen siendo una asignatura popular y deseada en las escuelas.
Nelson Mandela dijo: “Si le hablas a un hombre en un idioma que entiende, eso le llega a la cabeza.
Si le hablas en su propio idioma, eso llega a su corazón".
Este es un poderoso recordatorio de que no podemos depender únicamente del inglés cuando queremos construir relaciones y confianza con personas de otros países.
A partir de los resultados de los exámenes recientes de este año, podemos ver que los idiomas encabezan las tablas de clasificación con las tasas de aprobación más altas en las escuelas independientes.
Un total del 68 % de los alumnos que estudiaron idiomas extranjeros obtuvieron una calificación A superior.
Los datos, recopilados de las 74 escuelas miembro de SCIS, mostraron que el 72 % de los estudiantes obtuvieron una calificación A superior en mandarín, mientras que el 72 % de los que estudiaban alemán, el 69 % de los que estudiaban francés y el 63 % de los que estudiaban español también obtuvieron una A.
Esto demuestra que las escuelas independientes en Escocia apoyan los idiomas extranjeros como habilidades vitales que los niños y jóvenes sin duda requerirán en el futuro.
En la actualidad, las lenguas, como opción de asignatura, se consideran tan importantes como las materias STEM (ciencia, tecnología, ingeniería y matemáticas) en los planes de estudio de las escuelas independientes y en otros lugares.
Una encuesta realizada por la Comisión de Empleo y Habilidades del Reino Unido en 2014 reveló que, de las razones que los empleadores dieron para explicar las dificultades para cubrir vacantes, el 17 % se atribuyeron a la escasez de habilidades lingüísticas.
Por lo tanto, cada vez más, las habilidades lingüísticas se están convirtiendo en algo imperativo para preparar a los jóvenes para sus futuras carreras.
Dado que cada vez más oportunidades laborales requieren el conocimiento de idiomas, estas habilidades son esenciales en un mundo globalizado.
Independientemente de la carrera que alguien elija, si ha aprendido un segundo idioma, tendrá una ventaja real en el futuro al poseer una habilidad de por vida como esta.
La capacidad de comunicarse directamente con personas de países extranjeros colocará automáticamente a una persona multilingüe por delante de la competencia.
Según una encuesta de YouGov realizada a más de 4000 adultos del Reino Unido en 2013, el 75 % no podía hablar un idioma extranjero lo suficientemente bien como para mantener una conversación, y el francés era el único idioma hablado por un porcentaje de dos dígitos, el 15 %.
Por eso, invertir en la enseñanza de idiomas ahora es importante para los niños de hoy.
El dominio de varios idiomas, especialmente los de las economías en desarrollo, brindará a los niños una mejor oportunidad de encontrar un empleo significativo.
Dentro de Escocia, cada escuela difiere en los idiomas que enseña.
Varias escuelas se centrarán en los idiomas modernos más clásicos, mientras que otras enseñarán los idiomas que se consideran más importantes para el Reino Unido de cara a 2020, como el mandarín o el japonés.
Sea cual sea el interés de su hijo, siempre habrá una variedad de idiomas para elegir en las escuelas independientes, con personal docente especializado en esta área.
Las escuelas independientes escocesas se dedican a ofrecer un entorno de aprendizaje que prepare a los niños y les brinde las habilidades necesarias para tener éxito, sin importar lo que el futuro les depare.
En este momento, en un entorno empresarial global, no se puede negar que los idiomas siguen siendo de vital importancia para el futuro del país, por lo que esto debe reflejarse en la educación.
De hecho, los idiomas modernos deberían considerarse verdaderamente como "habilidades de comunicación internacional".
Las escuelas independientes seguirán ofreciendo esta opción, diversidad y excelencia para los jóvenes de Escocia.
Hay que hacerlo bien.
John Edward es director del Consejo Escocés de Escuelas Independientes
LeBron debutará con los Lakers el domingo en San Diego
La espera está a punto de terminar para los fanáticos que esperan ver a LeBron James hacer su primer partido como titular con los Los Angeles Lakers.
El entrenador de los Lakers, Luke Walton, anunció que James jugará en el partido de pretemporada del domingo contra los Denver Nuggets en San Diego.
Pero aún no se ha determinado cuántos minutos jugará.
"Será más de uno y menos de 48", dijo Walton en el sitio web oficial de los Lakers.
El reportero de los Lakers, Mike Trudell, tuiteó que es probable que James juegue un número limitado de minutos.
Después de los entrenamientos a principios de esta semana, se le preguntó a James sobre sus planes para el calendario de pretemporada de seis partidos de los Lakers.
"No necesito partidos de pretemporada en esta etapa de mi carrera para prepararme", dijo.
Hora del mitin de Trump en Virginia Occidental, canal de YouTube
El presidente Donald Trump comienza esta noche una serie de mítines de campaña en Wheeling, West Virginia.
Es el primer mitin de Trump de los cinco programados para la próxima semana, incluyendo paradas en lugares favorables como Tennessee y Mississippi.
Con la votación de confirmación en espera para su candidato para cubrir la vacante en la Corte Suprema, Trump busca construir apoyo para las próximas elecciones de mitad de mandato, ya que los republicanos corren el riesgo de perder el control del Congreso cuando se emitan los votos en noviembre.
¿A qué hora es el mitin de Trump en Virginia Occidental esta noche y cómo se puede ver en línea?
El mitin de Trump en Wheeling, West Virginia, está programado para las 7 p. m. ET de esta noche, sábado 29 de septiembre de 2018.
Puede ver el mitin de Trump en West Virginia en línea a continuación, a través de una transmisión en vivo en YouTube.
Es probable que Trump hable sobre las audiencias de esta semana del candidato a la Corte Suprema Brett Kavanaugh, que se volvieron tensas debido a las acusaciones de mala conducta sexual, y el voto de confirmación del Senado se pospuso hasta por una semana mientras el FBI investiga.
Pero el objetivo principal de esta avalancha de mítines es ayudar a los republicanos que enfrentan unas elecciones complicadas en noviembre a ganar algo de impulso.
Por lo tanto, la campaña del presidente Trump afirmó que estos cinco mítines de la próxima semana tienen como objetivo "energizar a los voluntarios y partidarios mientras los republicanos intentan proteger y ampliar las mayorías que tienen en el Senado y la Cámara de Representantes", según Reuters.
“El control del Congreso es tan crucial para su agenda que el presidente viajará a tantos estados como sea posible a medida que nos adentramos en la intensa temporada de campaña”, dijo a Reuters un portavoz de la campaña de Trump que prefirió no ser nombrado.
Programado en el Wesbanco Arena de Wheeling, el mitin de esta noche podría atraer a simpatizantes de "Ohio y Pensilvania y obtener cobertura de los medios de Pittsburgh", según West Virginia Metro News.
El sábado será la segunda vez en el último mes que Trump visita West Virginia, el estado que ganó por más de 40 puntos porcentuales en 2016.
Trump está intentando ayudar al candidato republicano al Senado de Virginia Occidental, Patrick Morrisey, quien está perdiendo en las encuestas.
"No es una buena señal para Morrisey que el presidente tenga que venir a intentar darle un impulso en las encuestas", dijo Simon Haeder, politólogo de la Universidad de West Virginia, según Reuters.
Copa Ryder 2018: El equipo de EE. UU. muestra su capacidad de lucha para mantener vivas las esperanzas de cara a los partidos individuales del domingo
Después de tres sesiones unilaterales, los foursomes del sábado por la tarde podrían haber sido justo lo que esta Ryder Cup necesitaba.
El péndulo oscilante del impulso es un concepto deportivo completamente inventado, pero en el que los jugadores realmente creen, y nunca más que en competiciones como estas.
Entonces, ¿dónde dirían que está el impulso ahora?
"Tenían una ventaja de seis puntos y ahora son cuatro, así que supongo que eso nos da un poco de impulso", dijo Jordan Spieth mientras se retiraba para el día.
Europa tiene la ventaja, por supuesto, con cuatro puntos de ventaja y doce más en juego.
Los estadounidenses, como dice Spieth, sienten que tienen un poco de viento a favor y tienen muchas razones para sentirse animados, especialmente por el rendimiento de Spieth y Justin Thomas, quienes jugaron juntos todo el día y cada uno tiene tres puntos de cuatro.
Spieth ha sido letal desde el tee hasta el green y está liderando con el ejemplo.
Esos gritos guturales de celebración se hicieron más fuertes a medida que avanzaba su ronda, al hundir un putt crucial para empatar el cuarto partido cuando él y Thomas estaban dos abajo después de dos hoyos.
Su putt que les dio la victoria en el hoyo 15 fue recibido con un grito similar, el tipo de grito que te dice que él cree que el equipo estadounidense no está fuera de esto.
“Realmente solo tienes que profundizar y preocuparte por tu propio partido”, dijo Spieth.
Es todo lo que les queda ahora a cada uno de estos jugadores.
18 hoyos para dejar huella.
Los únicos jugadores que han sumado más puntos que Spieth y Thomas en los últimos dos días son Francesco Molinari y Tommy Fleetwood, la historia indiscutible de la Ryder Cup.
La extraña pero adorable pareja de Europa tiene un récord de cuatro victorias en cuatro partidos y no puede equivocarse.
"Moliwood" fue la única pareja que no hizo un bogey el sábado por la tarde, pero también evitaron los bogeys el sábado por la mañana, el viernes por la tarde y en los últimos nueve hoyos el viernes por la mañana.
Esa carrera, y la forma en que su energía parece fluir hacia y desde esta multitud bulliciosa, confirma que son los jugadores a vencer el domingo, y no habría un jugador más popular para sellar una posible victoria europea mientras el sol se pone sobre Le Golf National que Fleetwood o Molinari.
Preferiblemente, ambas al mismo tiempo en diferentes orificios.
Sin embargo, hablar de gloria europea sigue siendo prematuro.
Bubba Watson y Webb Simpson derrotaron fácilmente a Sergio García, el héroe de los fourballs de la mañana, cuando este jugó en pareja con Alex Noren.
Un bogey y dos dobles en los primeros nueve hoyos metieron al español y al sueco en un agujero del que nunca se acercaron a salir.
El domingo, sin embargo, no hay nadie que te ayude a salir de tu agujero.
Los fourballs y los foursomes son fascinantes de ver de cerca debido a las interacciones entre los parejas, los consejos que se dan, los que no se dan y la forma en que una estrategia puede cambiar en un instante.
Hasta ahora, Europa ha jugado mejor como equipo y tiene una ventaja significativa en el último día, pero esta sesión de foursomes también demostró que el equipo de EE. UU. tiene el estómago para la lucha que algunos, especialmente en Estados Unidos, habían estado dudando.
Europa toma una ventaja de 10-6 en el último día de la Ryder Cup
Europa tendrá una ventaja considerable en el último día de la Ryder Cup después de salir de los partidos de fourballs y foursomes del sábado con una ventaja de 10-6 sobre Estados Unidos.
El inspirado dúo formado por Tommy Fleetwood y Francesco Molinari lideró la carga con dos victorias sobre un Tiger Woods en dificultades, lo que elevó su puntuación hasta el momento en Le Golf National a cuatro puntos.
El equipo europeo de Thomas Bjorn, que aspiraba a retener el trofeo que perdió en Hazeltine hace dos años, dominó al equipo estadounidense, que no tuvo un buen desempeño, en los fourballs de la mañana, llevándose la serie por 3-1.
Estados Unidos ofreció más resistencia en los foursomes, ganando dos partidos, pero no pudieron reducir el déficit.
El equipo de Jim Furyk necesita ocho puntos de los 12 partidos individuales del domingo para retener el trofeo.
Fleetwood es el primer debutante europeo en ganar cuatro puntos seguidos, y él y Molinari, apodados "Molliwood" tras un sensacional fin de semana, son la segunda pareja en ganar cuatro puntos en sus primeros cuatro partidos en la historia de la Ryder Cup.
Después de derrotar a Woods y Patrick Reed en los fourballs, lograron una excelente sinergia para vencer a un desanimado Woods y al novato estadounidense Bryson Dechambeau por un marcador aún más contundente de 5&4.
Woods, que se arrastró durante dos partidos el sábado, mostró destellos ocasionales de brillantez, pero ahora ha perdido 19 de sus 29 partidos en cuatro bolas y cuatro bolas y siete consecutivos.
Justin Rose, que descansó durante los fourballs de la mañana, volvió a asociarse con Henrik Stenson en los foursomes y obtuvieron una victoria por 2&1 sobre Dustin Johnson y Brooks Koepka, clasificados como número uno y tres del mundo.
Sin embargo, Europa no lo tuvo todo a su manera en un agradable día ventoso al suroeste de París.
El tres veces ganador de un major, Jordan Spieth, y Justin Thomas marcaron el estándar para los estadounidenses con dos puntos el sábado.
Obtuvieron una dura victoria por 2&1 sobre Jon Rahm e Ian Poulter de España en los fourballs y regresaron más tarde para vencer a Poulter y Rory McIlroy por 4&3 en los foursomes, después de haber perdido los dos primeros hoyos.
Solo en dos ocasiones en la historia de la Ryder Cup un equipo ha remontado un déficit de cuatro puntos en los partidos individuales, aunque como campeones, el equipo de Furyk solo necesita un empate para retener el trofeo.
Sin embargo, después de ser los segundos mejores durante dos días, parece que un contraataque el domingo estará fuera de su alcance.
Corea del Norte dice que "de ninguna manera" se desarmará unilateralmente sin confianza
El ministro de Asuntos Exteriores de Corea del Norte dijo el sábado a las Naciones Unidas que las sanciones continuas estaban profundizando su desconfianza hacia Estados Unidos y que, en tales circunstancias, no había ninguna posibilidad de que el país renunciara unilateralmente a sus armas nucleares.
Ri Yong Ho dijo a la Asamblea General anual del organismo mundial que Corea del Norte había adoptado "medidas significativas de buena voluntad" en el último año, como detener las pruebas nucleares y de misiles, desmantelar el sitio de pruebas nucleares y comprometerse a no proliferar armas nucleares y tecnología nuclear.
"Sin embargo, no vemos ninguna respuesta correspondiente por parte de los Estados Unidos", dijo.
“Sin confianza en los Estados Unidos, no habrá confianza en nuestra seguridad nacional y, en tales circunstancias, no hay forma de que nos desarmemos unilateralmente primero”.
Aunque Ri repitió las quejas habituales de Corea del Norte sobre la resistencia de Washington a un enfoque "faseado" de desnuclearización, según el cual Corea del Norte sería recompensada a medida que tomara medidas graduales, su declaración pareció significativa en el sentido de que no rechazó de plano la desnuclearización unilateral, como lo había hecho Pyongyang en el pasado.
Ri hizo referencia a una declaración conjunta emitida por Kim Jong Un y Donald Trump en la primera cumbre entre un presidente estadounidense en funciones y un líder norcoreano, celebrada en Singapur el 12 de junio, en la que Kim se comprometió a trabajar hacia la "desnuclearización de la península coreana", mientras que Trump prometió garantizar la seguridad de Corea del Norte.
Corea del Norte ha estado buscando un fin formal a la Guerra de Corea de 1950-53, pero Estados Unidos ha dicho que Pyongyang debe renunciar primero a sus armas nucleares.
Washington también se ha resistido a las peticiones de relajar las duras sanciones internacionales contra Corea del Norte.
“Estados Unidos insiste en la ‘desnuclearización primero’ y aumenta el nivel de presión mediante sanciones para lograr su objetivo de manera coercitiva, e incluso se opone a la ‘declaración del fin de la guerra’”, dijo Ri.
"La percepción de que las sanciones pueden ponernos de rodillas es un sueño imposible de las personas que no nos conocen.
Pero el problema es que las sanciones continuas están profundizando nuestra desconfianza".
Ri no mencionó los planes para una segunda cumbre entre Kim y Trump que el líder estadounidense destacó en las Naciones Unidas a principios de la semana.
En cambio, el ministro destacó tres reuniones entre Kim y el líder surcoreano Moon Jae-in en los últimos cinco meses y agregó: "Si la parte involucrada en este tema de desnuclearización fuera Corea del Sur y no Estados Unidos, la desnuclearización de la península coreana no habría llegado a un punto muerto".
Aun así, el tono del discurso de Ri fue drásticamente diferente al del año pasado, cuando dijo ante la Asamblea General de la ONU que apuntar al territorio estadounidense con los cohetes de Corea del Norte era inevitable después de que "el señor presidente malvado" Trump llamara a Kim un "hombre cohete" en una misión suicida.
Este año, en las Naciones Unidas, Trump, quien el año pasado amenazó con "destruir totalmente" a Corea del Norte, elogió a Kim por su valentía al tomar medidas para desarmarse, pero dijo que aún queda mucho por hacer y que las sanciones deben mantenerse hasta que Corea del Norte se desnuclearice.
El miércoles, Trump dijo que no tenía un plazo para esto, y afirmó: "Si tarda dos años, tres años o cinco meses, no importa".
China y Rusia sostienen que el Consejo de Seguridad de la ONU debería recompensar a Pyongyang por las medidas adoptadas.
Sin embargo, el secretario de Estado de EE. UU., Mike Pompeo, dijo al Consejo de Seguridad de la ONU el jueves que: "La aplicación de las sanciones del Consejo de Seguridad debe continuar con vigor y sin fallas hasta que logremos la desnuclearización completa, final y verificada".
El Consejo de Seguridad ha reforzado por unanimidad las sanciones contra Corea del Norte desde 2006 en un intento de cortar el financiamiento de los programas nucleares y de misiles balísticos de Pyongyang.
Pompeo se reunió con Ri al margen de la Asamblea General de la ONU y dijo después que visitaría Pyongyang nuevamente el próximo mes para preparar una segunda cumbre.
Pompeo ya ha visitado Corea del Norte tres veces este año, pero su último viaje no fue bien.
Él dejó Pyongyang en julio diciendo que se habían logrado avances, pero horas después, Corea del Norte lo denunció por hacer "demandas de tipo mafioso".
Corea del Norte se comprometió en una reunión con Moon este mes a desmantelar un sitio de misiles y también un complejo nuclear si Estados Unidos tomaba "medidas correspondientes".
Dijo que Kim le había informado que las "medidas correspondientes" que él buscaba eran las garantías de seguridad que Trump prometió en Singapur y los avances hacia la normalización de las relaciones con Washington.
Estudiantes de Harvard toman un curso sobre la importancia de descansar lo suficiente
Un nuevo curso en la Universidad de Harvard este año ha logrado que todos sus estudiantes universitarios duerman más, en un intento por combatir la creciente cultura machista de estudiar durante toda la noche con cafeína.
Un académico descubrió que los estudiantes de la universidad número uno del mundo a menudo no tienen idea sobre lo más básico de cómo cuidarse a sí mismos.
Charles Czeisler, profesor de medicina del sueño en la Facultad de Medicina de Harvard y especialista en el Hospital Brigham and Women's, diseñó el curso, que considera el primero de su tipo en Estados Unidos.
Se le ocurrió la idea de iniciar el curso después de dar una charla sobre el impacto que la falta de sueño tiene en el aprendizaje.
Al final, una chica se me acercó y me dijo: “¿Por qué me están diciendo esto ahora, en mi último año?”
Ella dijo que nadie le había hablado nunca sobre la importancia del sueño, lo cual me sorprendió”, dijo al periódico The Telegraph.
El curso, que se imparte por primera vez este año, explica a los estudiantes los fundamentos de cómo los buenos hábitos de sueño ayudan al rendimiento académico y deportivo, además de mejorar su bienestar general.
Paul Barreira, profesor de psiquiatría en la Facultad de Medicina de Harvard y director ejecutivo de los servicios de salud de la universidad, dijo que la universidad decidió introducir el curso después de descubrir que los estudiantes estaban gravemente privados de sueño durante la semana.
El curso de una hora de duración incluye una serie de tareas interactivas.
En una sección hay una imagen de una habitación de dormitorio, donde los estudiantes hacen clic en tazas de café, cortinas, zapatillas y libros para obtener información sobre los efectos de la cafeína y la luz, cómo el rendimiento atlético se ve afectado por la falta de sueño y la importancia de una rutina antes de dormir.
En otra sección, se informa a los participantes que la privación de sueño a largo plazo puede aumentar los riesgos de ataques cardíacos, accidentes cerebrovasculares, depresión y cáncer.
Un mapa del campus, con iconos interactivos, anima a los participantes a reflexionar sobre su rutina diaria.
Sabemos que no cambiará el comportamiento de los estudiantes de inmediato.
Pero creemos que tienen derecho a saberlo, al igual que ustedes tienen derecho a conocer los efectos en la salud de fumar cigarrillos", agregó el profesor Czeisler.
Afirmó que aún existe la cultura del orgullo por "hacer una noche en vela" y agregó que la tecnología moderna y la presión cada vez mayor sobre los estudiantes significan que la privación del sueño es un problema en aumento.
Asegurarse de dormir lo suficiente y de buena calidad debería ser el "arma secreta" de los estudiantes para combatir el estrés, el agotamiento y la ansiedad, dijo, e incluso para evitar aumentar de peso, ya que la falta de sueño pone al cerebro en modo de inanición, lo que los hace sentir constantemente hambrientos.
Raymond So, un californiano de 19 años que estudia biología química y física, ayudó al profesor Czeisler a diseñar el curso, después de haber asistido a una de sus clases el año pasado durante su primer año en Harvard.
Dijo que el curso le había abierto los ojos e inspirado a impulsar un curso a nivel de todo el campus.
El siguiente paso, espera, es pedir a todos los estudiantes de posgrado que completen un programa de estudios similar antes de unirse a la institución competitiva.
El profesor Czeisler recomendó que los estudiantes consideren configurar una alarma para irse a la cama, así como para despertarse, y que estén conscientes de los efectos nocivos de la "luz azul" emitida por las pantallas electrónicas y la iluminación LED, que pueden alterar el ritmo circadiano y provocar problemas para conciliar el sueño.
Livingston 1 - 0 Rangers: El gol de Menga derriba a los hombres de Gerrard
Los Rangers sufrieron otro episodio de tristeza en un partido fuera de casa, ya que el gol de Dolly Menga condenó al desorganizado equipo de Steven Gerrard a una derrota por 1-0 ante el Livingston.
El equipo de Ibrox buscaba registrar su primera victoria fuera de casa desde el triunfo 4-1 en St Johnstone en febrero, pero el equipo de Gary Holt infligió la segunda derrota de Gerrard en 18 partidos como entrenador, dejando a su equipo ocho puntos por detrás de los líderes indiscutibles de la Ladbrokes Premiership, Hearts.
Menga marcó siete minutos antes del descanso y un equipo de Rangers con poca inspiración nunca pareció capaz de igualar.
Mientras que los Rangers caen ahora al sexto puesto, Livingston asciende al tercero y solo está por detrás del Hibernian en la diferencia de goles.
Y podría haber más problemas para los Rangers después de que el asistente Calum Spence tuvo que ser atendido por una herida en la cabeza tras aparentemente serle lanzado un objeto desde la grada de los visitantes.
Gerrard realizó ocho cambios en el equipo que superó a Ayr y avanzó a las semifinales de la Betfred Cup.
Por otro lado, Holt optó por el mismo Livi 11 que le quitó un punto a Hearts la semana pasada y habría estado encantado con la forma en que su bien entrenado equipo sofocó a sus oponentes en cada momento.
Aunque los Rangers pudieron haber dominado la posesión, el Livingston hizo más con el balón que tuvo.
Deberían haber marcado a los dos minutos, cuando el pase de Menga permitió a Scott Pittman avanzar hacia la portería de Allan McGregor, pero el mediocampista desaprovechó su gran oportunidad.
Un profundo tiro libre de Keaghan Jacobs encontró al capitán Craig Halkett, pero su compañero defensivo Alan Lithgow solo pudo desviar el balón fuera del poste trasero.
Los Rangers lograron tomar el control, pero parecía haber más esperanza que convicción en su juego en el tercio final.
Alfredo Morelos sin duda sintió que debería haber tenido un penal en el minuto 15 cuando él y Steven Lawless chocaron, pero el árbitro Steven Thomson desestimó los reclamos del colombiano.
Los Rangers lograron solo dos tiros al arco en la primera mitad, pero el ex arquero de Ibrox, Liam Kelly, apenas se vio afectado por el cabezazo de Lassana Coulibaly y un tiro débil de Ovie Ejaria.
Aunque el gol inicial de Livi en el minuto 34 pudo haber sido en contra del curso del juego, nadie puede negar que se lo merecieron por su esfuerzo.
Una vez más, los Rangers no pudieron manejar un tiro libre profundo de Jacobs.
Scott Arfield no reaccionó cuando Declan Gallagher pasó el balón a Scott Robinson, quien mantuvo la calma para pasarle el balón a Menga, quien marcó con facilidad.
Gerrard actuó en el descanso al cambiar a Coulibaly por Ryan Kent y el cambio casi tuvo un impacto inmediato, ya que el extremo colocó a Morelos, pero el impresionante Kelly salió de su línea para bloquear.
Pero Livingston siguió atrayendo a los visitantes para que jugaran exactamente el tipo de juego que les gusta, con Lithgow y Halkett atrapando balones largos uno tras otro.
El equipo de Holt pudo ampliar su ventaja en las etapas finales, pero McGregor se mantuvo firme y evitó que Jacobs marcara, antes de que Lithgow enviara el balón fuera desde el córner.
El suplente de los Rangers, Glenn Middleton, reclamó otro penal en los minutos finales tras enredarse con Jacobs, pero Thomson, una vez más, desvió la mirada.
Almanaque: El inventor del contador Geiger
Y ahora una página de nuestro Almanaque de "Sunday Morning": el 30 de septiembre de 1882, hace 136 años, y CONTANDO... el día en que nació en Alemania el futuro físico Johannes Wilhelm "Hans" Geiger.
Geiger desarrolló un método para detectar y medir la radiactividad, una invención que finalmente dio lugar al dispositivo conocido como contador Geiger.
Desde entonces, el contador Geiger se convirtió en un elemento básico de la ciencia y también en un ícono de la cultura popular, como en la película de 1950 "Las campanas de Coronado", protagonizada por los aparentemente improbables científicos vaqueros Roy Rogers y Dale Evans:
Hombre: "¿Qué diablos es eso?"
Rogers: "Es un contador Geiger, utilizado para localizar minerales radiactivos, como el uranio.
Cuando te pones estos auriculares, realmente puedes escuchar los efectos de los átomos emitidos por la radiactividad de los minerales".
Evans: "¡Vaya, ahora sí que está explotando!"
"Hans" Geiger murió en 1945, a solo unos días de cumplir 63 años.
Pero la invención que lleva su nombre sigue viva.
Una nueva vacuna contra el cáncer puede enseñar al sistema inmunológico a "ver" las células malignas
Una nueva vacuna contra el cáncer puede enseñar al sistema inmunológico a "ver" las células malignas y eliminarlas
La vacuna enseña al sistema inmunológico a reconocer las células malignas como parte del tratamiento
El método consiste en extraer células inmunitarias de un paciente y modificarlas en el laboratorio
Luego pueden “ver” una proteína común en muchos tipos de cáncer y luego volver a inyectarla.
Una vacuna experimental está mostrando resultados prometedores en pacientes con una variedad de cánceres.
Una mujer tratada con la vacuna, que enseña al sistema inmunológico a reconocer las células malignas, vio cómo su cáncer de ovario desaparecía durante más de 18 meses.
El método consiste en extraer células inmunitarias de un paciente, modificarlas en el laboratorio para que puedan "detectar" una proteína común en muchos tipos de cáncer llamada HER2, y luego reinyectar las células.
El profesor Jay Berzofsky, del Instituto Nacional del Cáncer de EE. UU. en Bethesda, Maryland, dijo: "Nuestros resultados sugieren que tenemos una vacuna muy prometedora".
El HER2 "estimula el crecimiento de varios tipos de cáncer", incluidos los de mama, ovario, pulmón y colorrectal, explicó el profesor Berzofsky.
Un enfoque similar, que consiste en extraer células inmunitarias de los pacientes y "enseñarles" a atacar las células cancerosas, ha funcionado en el tratamiento de un tipo de leucemia.
Kanye West se embarcó en una diatriba a favor de Trump, usando una gorra MAGA, después de su aparición en SNL.
No salió bien
Kanye West fue abucheado en el estudio durante un programa de Saturday Night Live después de una actuación desordenada en la que elogió al presidente de Estados Unidos, Donald Trump, y dijo que se presentaría a las elecciones en 2020.
Después de interpretar su tercera canción de la noche, titulada Ghost Town, en la que llevaba una gorra con el lema "Make America Great", se lanzó a una diatriba contra los demócratas y reiteró su apoyo a Trump.
“Muchas veces hablo con una persona blanca y me dice: “¿Cómo puedes simpatizar con Trump, si es racista?”
Bueno, si me preocupara el racismo, me habría mudado de Estados Unidos hace mucho tiempo”, dijo.
SNL comenzó el programa con una escena protagonizada por Matt Damon en la que la estrella de Hollywood se burlaba del testimonio de Brett Kavanaugh ante el Comité Judicial del Senado sobre las acusaciones de agresión sexual realizadas por Christine Blasey Ford.
Aunque no se transmitió, el video de la diatriba de West fue subido a las redes sociales por el comediante Chris Rock.
No está claro si Rock intentaba burlarse de West con la publicación.
Además, West se quejó ante el público de que había tenido problemas en los camerinos por su gorra.
"Me acosaron detrás del escenario.
Dijeron: «No salgas con ese sombrero».
¡Me acosaron!
Y luego dicen que estoy en un lugar hundido”, dijo, según el Washington Examiner.
West continuó: "¿Quieres ver el lugar hundido?" y dijo que "me pondría mi capa de superman, porque esto significa que no puedes decirme qué hacer. ¿Quieres que el mundo avance?
Intenta el amor".
Sus comentarios provocaron abucheos al menos dos veces por parte del público y los miembros del elenco de SNL parecían avergonzados, informó Variety, y una persona presente dijo a la publicación: "Todo el estudio se quedó en silencio".
West había sido contratado como reemplazo de última hora para la cantante Ariana Grande, cuyo ex novio, el rapero Mac Miller, había fallecido unos días antes.
West desconcertó a muchos con una actuación de la canción "I Love it", vestido como una botella de Perrier.
West recibió el apoyo de la líder del grupo conservador TPUSA, Candace Turner, quien tuiteó: "A uno de los espíritus más valientes: GRACIAS POR HACER FRENTE A LA MUCHEDUMBRE".
Pero la presentadora de un programa de entrevistas, Karen Hunter, tuiteó que West simplemente "estaba siendo él mismo y eso es absolutamente maravilloso".
“Pero elegí NO recompensar a alguien (comprando su música o ropa o apoyando su ‘arte’) que creo que está adoptando y difundiendo una ideología que es perjudicial para mi comunidad.
Él está libre.
Nosotras también", agregó.
Antes del espectáculo, el rapero anunció en Twitter que había cambiado su nombre, diciendo que ahora era "el ser formalmente conocido como Kanye West".
No es el primer artista que cambia su nombre y sigue los pasos de Diddy, también conocido como Puff Daddy, Puffy y P Diddy.
El rapero Snoop Dogg también tuvo el nombre de Snoop Lion y, por supuesto, el difunto ícono de la música Prince cambió su nombre por un símbolo y luego se convirtió en el artista anteriormente conocido como Prince.
Cargo de intento de asesinato por apuñalamiento en un restaurante de Belfast
Un hombre de 45 años fue acusado de intento de asesinato después de que un hombre fuera apuñalado en un restaurante en el este de Belfast el viernes.
El incidente ocurrió en Ballyhackamore, según la policía.
Se espera que el acusado comparezca ante el Juzgado de Primera Instancia de Belfast el lunes.
La Fiscalía revisará los cargos.
Kit Harington, estrella de Juego de Tronos, ataca la masculinidad tóxica
Kit Harington es conocido por su papel de Jon Snow, en el que maneja una espada, en la violenta serie de fantasía medieval Juego de Tronos de HBO.
Pero el actor, de 31 años, ha criticado el estereotipo del héroe macho, afirmando que este tipo de papeles en la pantalla hacen que los jóvenes a menudo sientan que tienen que ser duros para ser respetados.
En una entrevista con The Sunday Times Culture, Kit dijo que cree que "algo ha salido mal" y cuestionó cómo abordar el problema de la masculinidad tóxica en la era del #MeToo.
Kit, que recientemente se casó con su compañera de reparto de Juego de Tronos, Rose Leslie, también de 31 años, admitió que siente una "gran preocupación" por abordar este tema.
“En este momento, siento personalmente, con mucha intensidad, que nos hemos equivocado con la masculinidad”, dijo.
¿Qué hemos estado enseñando a los hombres mientras crecían, en términos del problema que vemos ahora?
Kit cree que la televisión puede ser en parte responsable del aumento de la masculinidad tóxica gracias a sus personajes muy masculinos.
Continuó: "¿Qué es innato y qué se enseña?
¿Qué se enseña en la televisión y en las calles que hace que los jóvenes sientan que tienen que ser de una determinada manera para ser hombres?
Creo que esa es una de las grandes preguntas de nuestro tiempo: ¿cómo podemos cambiar eso?
Porque claramente algo ha salido mal para los jóvenes'.
En la entrevista, también admitió que no haría ninguna precuela ni secuela de Juego de Tronos cuando la serie termine el próximo verano, diciendo que ya está "harto de campos de batalla y caballos".
A partir de noviembre, Kit protagonizará una nueva versión de True West, de Sam Shepard, que cuenta la historia de un productor de cine y su hermano, que es un ladrón.
El actor reveló recientemente que considera que conocer a su esposa Rose es lo mejor que le ha pasado gracias a Juego de Tronos.
"Conocí a mi esposa en este programa, así que, en cierto modo, me dio mi futura familia y mi vida a partir de entonces", dijo.
Rose interpretó a Ygritte, el interés amoroso del personaje de Kit, Jon Snow, en la serie de fantasía ganadora del premio Emmy.
La pareja se casó en junio de 2018 en los terrenos de la finca familiar de Leslie en Escocia.
VIH/SIDA: China informa de un aumento del 14 % en los nuevos casos
China ha anunciado un aumento del 14 % en el número de ciudadanos que viven con VIH y sida.
Más de 820 000 personas están afectadas en el país, según las autoridades sanitarias.
Solo en el segundo trimestre de 2018 se reportaron alrededor de 40 000 nuevos casos.
La gran mayoría de los nuevos casos se transmitieron a través del sexo, lo que marca un cambio con respecto al pasado.
Tradicionalmente, el VIH se propagó rápidamente en algunas partes de China como resultado de transfusiones de sangre infectada.
Sin embargo, el número de personas que contraen el VIH de esta manera se había reducido casi a cero, dijeron los funcionarios de salud chinos en una conferencia en la provincia de Yunnan.
Sin embargo, año tras año, el número de personas que viven con VIH y sida en China ha aumentado en 100 000 personas.
La transmisión del VIH a través del sexo es un problema grave en la comunidad LGBT de China.
La homosexualidad fue despenalizada en China en 1997, pero se dice que la discriminación contra las personas LGBT es muy común.
Debido a los valores conservadores del país, los estudios han estimado que entre el 70 y el 90 % de los hombres que tienen relaciones sexuales con otros hombres terminarán casándose con mujeres.
Muchas de las transmisiones de estas enfermedades se deben a la protección sexual inadecuada en estas relaciones.
Desde 2003, el gobierno de China ha prometido acceso universal a los medicamentos contra el VIH como parte de un esfuerzo para abordar el problema.
Maxine Waters niega que un miembro de su personal filtrara datos de senadores del Partido Republicano y denuncia "mentiras peligrosas" y "teorías conspirativas"
La representante de EE. UU. Maxine Waters denunció el sábado las acusaciones de que un miembro de su personal había publicado la información personal de tres senadores republicanos en las páginas de Wikipedia de los legisladores.
El demócrata de Los Ángeles afirmó que las afirmaciones estaban siendo difundidas por expertos y sitios web de "ultraderecha".
"Mentiras, mentiras y más mentiras despreciables", dijo Waters en un comunicado en Twitter.
Según los informes, la información divulgada incluía las direcciones y números de teléfono de los senadores estadounidenses Lindsey Graham de Carolina del Sur, y Mike Lee y Orrin Hatch, ambos de Utah.
La información apareció en línea el jueves, publicada por una persona desconocida en el Capitolio durante una audiencia del panel del Senado sobre las acusaciones de conducta sexual inapropiada contra el candidato a la Corte Suprema, Brett Kavanaugh.
La filtración ocurrió después de que los tres senadores cuestionaran a Kavanaugh.
Sitios conservadores como Gateway Pundit y RedState informaron que la dirección IP que identifica el origen de las publicaciones estaba asociada con la oficina de Waters y publicaron la información de un miembro del personal de Waters, según informó The Hill.
“Esta acusación infundada es completamente falsa y una absoluta mentira”, continuó Waters.
"El miembro de mi personal, cuya identidad, información personal y seguridad se han visto comprometidas como resultado de estas acusaciones fraudulentas y falsas, no fue en absoluto responsable de la filtración de esta información.
Esta acusación infundada es completamente falsa y una absoluta mentira".
La declaración de Waters rápidamente recibió críticas en línea, incluyendo la del ex secretario de prensa de la Casa Blanca, Ari Fleischer.
“Esta negación es enojada”, escribió Fleischer.
"Esto sugiere que no tiene el temperamento para ser miembro del Congreso.
Cuando alguien es acusado de algo que no hizo, no debe enojarse.
No deben ser desafiantes.
No deben cuestionar los motivos del acusador.
Deben estar tranquilos y serenos".
Fleischer parecía comparar la reacción de Waters con la crítica de los demócratas hacia el juez Kavanaugh, a quien los críticos acusaron de parecer demasiado enojado durante la audiencia del jueves.
Omar Navarro, un candidato republicano que aspira a derrotar a Waters en las elecciones de mitad de mandato, también expresó sus opiniones en Twitter.
"Sería un gran avance si fuera cierto", tuiteó.
En su declaración, Waters dijo que su oficina había alertado a "las autoridades competentes y a las entidades encargadas de hacer cumplir la ley sobre estas afirmaciones fraudulentas".
“Nos aseguraremos de que los responsables sean revelados”, continuó, “y de que sean considerados legalmente responsables por todas sus acciones destructivas y peligrosas para cualquier miembro de mi personal”.
Crítica de Johnny English Strikes Again: una parodia de espías con Rowan Atkinson que no llega a su máximo potencial
Es tradicional buscar significados relacionados con el Brexit en cualquier nueva película con un enfoque británico, y esto parece aplicable a esta reedición de la franquicia de parodias de acción y comedia de Johnny English, que comenzó en 2003 con Johnny English y volvió a la vida en 2011 con Johnny English Reborn.
¿Será la autocrítica irónica sobre lo evidentemente malos que somos la nueva oportunidad de exportación del país?
En cualquier caso, el incompetente Johnny English, de ojos saltones y rostro de goma, ha renovado su licencia para estropear las cosas por segunda vez; su nombre, más que nada, indica que es una creación cómica amplia diseñada para territorios cinematográficos que no hablan inglés.
Por supuesto, es el absurdo agente secreto que, a pesar de sus extrañas pretensiones de glamour, tiene un poco de Clouseau, un toque de Mr. Bean y un poco de ese tipo que contribuyó con una sola nota en la melodía de Chariots of Fire durante la ceremonia de apertura de los Juegos Olímpicos de Londres 2012.
También se basa originalmente en el viajero y enigmático hombre internacional que Atkinson interpretó en los ahora olvidados anuncios de Barclaycard para la televisión, dejando el caos a su paso.
Hay uno o dos momentos agradables en esta última salida de JE.
Me encantó la escena en la que Johnny English se acerca a un helicóptero vestido con una armadura medieval y las aspas del rotor golpean brevemente su casco.
El don de Atkinson para la comedia física está a la vista, pero el humor parece bastante débil y extrañamente superfluo, especialmente porque las marcas de películas "serias" como 007 y Misión Imposible ahora ofrecen con confianza la comedia como un ingrediente.
El humor parece estar dirigido a los niños en lugar de a los adultos, y para mí, las desventuras disparatadas de Johnny English no son tan ingeniosas y centradas como las bromas de película muda de Atkinson en el personaje de Bean.
La premisa, siempre de actualidad, es que Gran Bretaña está en serios problemas.
Un ciberhacker se ha infiltrado en la supersecreta red de espías de Gran Bretaña, revelando las identidades de todos los agentes británicos en el campo, para consternación del agente de guardia, un papel lamentablemente pequeño para Kevin Eldon.
Es la gota que colma el vaso para una primera ministra que es una figura pomposa y acorralada, que ya está sufriendo un completo colapso de impopularidad política: Emma Thompson hace lo mejor que puede con este personaje casi idéntico a Theresa May, pero no hay mucho en el guion con lo que trabajar.
Sus asesores de inteligencia le informan que, dado que cada espía activo ha sido comprometido, tendrá que sacar a alguien de la jubilación.
Y eso significa que el torpe Johnny English, ahora empleado como maestro en un prestigioso colegio, imparte lecciones no oficiales sobre cómo ser un agente encubierto: hay algunas buenas escenas, ya que English ofrece una academia de espionaje al estilo de la película Escuela de rock.
English es llevado de vuelta a Whitehall para una reunión de emergencia y se reúne con su antiguo y sufrido compañero Bough, interpretado nuevamente por Ben Miller.
Bough ahora es un hombre casado, unido a una comandante de submarino, un papel de chica alegre y deportista en el que Vicki Pepperdine está un poco desperdiciada.
Así que el Batman y el Robin de hacer las cosas terriblemente mal en el Servicio Secreto de Su Majestad están de vuelta en acción, encontrándose con la hermosa femme fatale Ophelia Bulletova, interpretada por Olga Kurylenko.
Mientras tanto, el primer ministro está cayendo peligrosamente bajo el hechizo del carismático multimillonario de la tecnología que afirma poder resolver los problemas informáticos de Gran Bretaña: el siniestro Jason Volta, interpretado por Jake Lacy.
English y Bough comienzan su odisea de travesuras cómicas: disfrazados de camareros, incendian un elegante restaurante francés; crean el caos al colarse a bordo del lujoso yate de Volta; y English desata la anarquía cuando intenta usar un casco de realidad virtual para familiarizarse con el interior de la casa de Volta.
Sin duda, se hacen todos los esfuerzos posibles para esa última secuencia, pero, por amigable y bulliciosa que sea, hay bastante de televisión infantil en todo esto.
Cosas bastante moderadas.
Y, como en las otras películas de Johnny English, no pude evitar pensar: ¿no puede la industria cinematográfica británica darle a Rowan Atkinson un papel que realmente haga justicia a su talento?
El Partido Laborista niega que esté elaborando un plan para que los británicos trabajen cuatro días a la semana, pero cobren por cinco días.
El Partido Laborista de Jeremy Corbyn está considerando un plan radical que permitirá a los británicos trabajar cuatro días a la semana, pero cobrar por cinco.
Según informes, el partido quiere que los jefes de las empresas transfieran los ahorros generados por la revolución de la inteligencia artificial (IA) a los trabajadores, otorgándoles un día adicional de descanso.
Los empleados disfrutarían de un fin de semana de tres días, pero seguirían cobrando el mismo salario.
Fuentes dijeron que la idea "encajaría" con la agenda económica del partido y con los planes de inclinar el país a favor de los trabajadores.
El Congreso de Sindicatos ha respaldado el cambio a una semana laboral de cuatro días como una forma de que los trabajadores se beneficien de la economía cambiante.
Una fuente importante del Partido Laborista dijo a The Sunday Times: "Se espera que se anuncie una revisión de la política antes de que termine el año.
"No sucederá de la noche a la mañana, pero una semana laboral de cuatro días es una aspiración que se alinea con el enfoque del partido para reequilibrar la economía a favor del trabajador, así como con la estrategia industrial general del partido".
El Partido Laborista no sería el primero en apoyar una idea así, ya que el Partido Verde prometió una semana laboral de cuatro días durante su campaña para las elecciones generales de 2017.
Sin embargo, esta aspiración no cuenta actualmente con el respaldo del Partido Laborista en su conjunto.
Un portavoz del Partido Laborista dijo: “La semana laboral de cuatro días no es una política del partido y no está siendo considerada por el partido”.
El canciller de la sombra, John McDonnell, utilizó la conferencia del Partido Laborista de la semana pasada para desarrollar su visión de una revolución socialista en la economía.
McDonnell dijo que estaba decidido a recuperar el poder de los "directores anónimos" y los "especuladores" de las empresas de servicios públicos.
Los planes del canciller de la sombra también implican que los accionistas actuales de las compañías de agua podrían no recuperar su participación completa, ya que un gobierno laborista podría hacer "deducciones" por presuntas irregularidades.
También confirmó los planes de incluir a los trabajadores en los consejos de administración de las empresas y crear Fondos de Propiedad Inclusiva para entregar el 10 % de las acciones de las empresas del sector privado a los empleados, quienes podrían recibir dividendos anuales de hasta 500 libras.
Lindsey Graham y John Kennedy le dicen a "60 Minutes" si la investigación del FBI sobre Kavanaugh podría cambiar su opinión
La investigación del FBI sobre las acusaciones contra el juez Brett Kavanaugh ha retrasado la votación final sobre su nominación al Tribunal Supremo por al menos una semana, y plantea la pregunta de si los hallazgos de la agencia podrían hacer que algunos senadores republicanos retiren su apoyo.
En una entrevista que se emitirá el domingo, el corresponsal de "60 Minutes", Scott Pelley, preguntó a los senadores republicanos John Kennedy y Lindsey Graham si el FBI podría descubrir algo que los llevara a cambiar de opinión.
Kennedy parecía más abierto que su colega de Carolina del Sur.
"Quiero decir, por supuesto", dijo Kennedy.
“Dije al entrar a la audiencia, dije, he hablado con el juez Kavanaugh.
Lo llamé después de que esto sucediera, cuando salió esa acusación, y le pregunté: '¿Lo hiciste?'
Él era resuelto, decidido, inequívoco".
Sin embargo, el voto de Graham parece estar escrito en piedra.
“Ya he tomado una decisión sobre Brett Kavanaugh y haría falta una acusación explosiva para cambiarla”, dijo.
"Doctora Ford, no sé qué pasó, pero sé esto: Brett lo negó vigorosamente", agregó Graham, refiriéndose a Christine Blasey Ford.
"Y todas las personas que mencionó no pudieron verificarlo.
Tiene 36 años.
No veo que nada nuevo vaya a cambiar".
¿Qué es el Festival Ciudadano Global y ha logrado algo para disminuir la pobreza?
Este sábado, Nueva York será sede del Festival Ciudadano Global, un evento musical anual que cuenta con una impresionante lista de estrellas y una misión igualmente impresionante: poner fin a la pobreza mundial.
Ahora en su séptimo año, el Festival Ciudadano Global verá a decenas de miles de personas acudir al Great Lawn del Central Park no solo para disfrutar de actuaciones como las de Janet Jackson, Cardi B y Shawn Mendes, sino también para concienciar sobre el verdadero objetivo del evento: poner fin a la pobreza extrema para 2030.
El Festival Ciudadano Global, que comenzó en 2012, es una extensión del Proyecto de Pobreza Global, un grupo de defensa internacional que espera poner fin a la pobreza aumentando el número de personas que luchan activamente contra ella.
Para recibir una entrada gratuita para el evento (a menos que estuvieran dispuestos a pagar por una entrada VIP), los asistentes al concierto tenían que completar una serie de tareas, o "acciones", como ser voluntarios, enviar un correo electrónico a un líder mundial, hacer una llamada telefónica o cualquier otra forma significativa de ayudar a crear conciencia sobre su objetivo de erradicar la pobreza.
Pero, ¿qué tan exitoso ha sido Global Citizen con 12 años restantes para alcanzar su objetivo?
¿Es la idea de recompensar a las personas con un concierto gratuito una forma genuina de persuadir a la gente para que exija una llamada a la acción, o simplemente otro caso de lo que se conoce como "clictivismo", es decir, que la gente sienta que está haciendo una verdadera diferencia al firmar una petición en línea o enviar un tuit?
Desde 2011, Global Citizen afirma que ha registrado más de 19 millones de "acciones" de sus seguidores, impulsando una serie de objetivos diferentes.
Señala que estas acciones han ayudado a impulsar a los líderes mundiales a anunciar compromisos y políticas por un monto superior a los 37 000 millones de dólares, que se espera que afecten la vida de más de 2250 millones de personas para 2030.
A principios de 2018, el grupo mencionó 390 compromisos y anuncios derivados de sus acciones, de los cuales al menos 10 000 millones de dólares ya se habían desembolsado o recaudado.
El grupo estima que los fondos asegurados han tenido hasta ahora un impacto directo en casi 649 millones de personas en todo el mundo.
Algunos de los compromisos clave incluyen The Power of Nutrition, una asociación con sede en el Reino Unido de inversores y ejecutores comprometidos a "ayudar a los niños a crecer hasta su máximo potencial", que promete proporcionar a Ruanda 35 millones de dólares para ayudar a erradicar la desnutrición en el país después de recibir más de 4700 tweets de ciudadanos globales.
“Con el apoyo del Gobierno del Reino Unido, de los donantes, de los gobiernos nacionales y de ciudadanos globales como usted, podemos convertir la injusticia social de la desnutrición en una mera nota al pie de la historia”, dijo Tracey Ullman, embajadora de The Power of Nutrition, a la multitud durante un concierto en vivo en Londres en abril de 2018.
El grupo también informó que, tras llevar a cabo más de 5000 acciones para pedir al Reino Unido que mejore la nutrición de madres e hijos, el gobierno anunció la financiación de un proyecto, el Poder de la Nutrición, que beneficiará a 5 millones de mujeres y niños con intervenciones nutricionales.
En respuesta a una de las preguntas frecuentes en su sitio web, que pregunta: “¿Qué te hace pensar que podemos acabar con la pobreza extrema?”.
Ciudadano global respondió: "Será un camino largo y difícil; a veces caeremos y fracasaremos.
Pero, al igual que los grandes movimientos por los derechos civiles y contra el apartheid que nos precedieron, tendremos éxito, porque juntos somos más fuertes.
Janet Jackson, The Weeknd, Shawn Mendes, Cardi B, Janelle Monáe son algunos de los artistas que actuarán en el evento de este año en Nueva York, que será presentado por Deborra-Lee Furness y Hugh Jackman.
EE. UU. podría utilizar la Armada para un “bloqueo” que dificulte las exportaciones energéticas rusas - Secretario del Interior
Washington puede, "si es necesario", recurrir a su Armada para evitar que la energía rusa llegue a los mercados, incluido el Medio Oriente, reveló el Secretario del Interior de EE. UU., Ryan Zinke, según el Washington Examiner.
Zinke afirmó que la participación de Rusia en Siria, especialmente donde opera a invitación del gobierno legítimo, es un pretexto para explorar nuevos mercados energéticos.
“Creo que la razón por la que están en el Medio Oriente es que quieren intermediar en la energía, tal como lo hacen en Europa del Este, en el vientre sur de Europa”, dijo, según informes.
Y, según el funcionario, existen formas y medios para abordar este problema.
“Estados Unidos tiene la capacidad, con nuestra Armada, de asegurarse de que las rutas marítimas estén abiertas y, si es necesario, de bloquearlas para garantizar que su energía no llegue al mercado”, dijo.
Zinke se dirigía a los asistentes al evento organizado por la Consumer Energy Alliance, un grupo sin fines de lucro que se autodenomina la "voz del consumidor de energía" en los Estados Unidos.
Comparó las estrategias de Washington para lidiar con Rusia e Irán, señalando que son, en esencia, las mismas.
“La opción económica con Irán y Rusia consiste, más o menos, en aprovechar y reemplazar los combustibles”, dijo, al tiempo que se refirió a Rusia como un “caballo de una sola pata” con una economía dependiente de los combustibles fósiles.
Las declaraciones se producen en un momento en que la administración de Trump está empeñada en aumentar la exportación de gas natural licuado a Europa, reemplazando a Rusia, que es una opción mucho más barata para los consumidores europeos.
Para ello, los funcionarios de la administración Trump, incluido el propio presidente de EE. UU., Donald Trump, intentan persuadir a Alemania para que se retire del "inapropiado" proyecto de gasoducto Nord Stream 2, que, según Trump, convirtió a Berlín en "prisionero" de Moscú.
Moscú ha insistido en repetidas ocasiones que el gasoducto Nord Stream 2, valorado en 11 000 millones de dólares, que duplicará la capacidad del gasoducto existente hasta los 110 000 millones de metros cúbicos, es un proyecto puramente económico.
El Kremlin sostiene que la ferviente oposición de Washington al proyecto se debe únicamente a razones económicas y es un ejemplo de competencia desleal.
“Creo que compartimos la opinión de que la energía no puede ser una herramienta para ejercer presión y que los consumidores deben poder elegir a sus proveedores”, dijo el ministro de Energía ruso, Aleksandr Novak, tras una reunión con el secretario de Energía de EE. UU., Rick Perry, en Moscú en septiembre.
La postura de Estados Unidos ha generado reacciones negativas en Alemania, que ha reafirmado su compromiso con el proyecto.
La principal organización industrial de Alemania, la Federación de Industrias Alemanas (BDI), ha pedido a Estados Unidos que no interfiera en la política energética de la UE ni en los acuerdos bilaterales entre Berlín y Moscú.
"Tengo un gran problema cuando un tercer Estado interfiere en nuestro suministro energético", dijo Dieter Kempf, presidente de la Federación de Industrias Alemanas (BDI), tras una reciente reunión entre la canciller alemana Angela Merkel y el presidente ruso Vladimir Putin.
Elizabeth Warren analizará "con detenimiento" la posibilidad de presentarse a la presidencia en 2020, según la senadora de Massachusetts
La senadora de Massachusetts, Elizabeth Warren, dijo el sábado que analizaría "con detenimiento" la posibilidad de presentarse a la presidencia tras las elecciones de mitad de mandato.
Durante una asamblea ciudadana en Holyoke, Massachusetts, Warren confirmó que consideraría presentarse como candidata.
"Es hora de que las mujeres vayan a Washington y arreglen nuestro gobierno roto, y eso incluye a una mujer en la cima", dijo, según The Hill.
"Después del 6 de noviembre, analizaré seriamente la posibilidad de presentarme a la presidencia".
Durante la reunión ciudadana, Warren se refirió al presidente Donald Trump, diciendo que él "estaba llevando a este condado en la dirección equivocada".
“Estoy profundamente preocupada por lo que Donald Trump está haciendo con nuestra democracia”, dijo.
Warren ha sido muy clara en su crítica a Trump y a su candidato para el Tribunal Supremo, Brett Kavanaugh.
En un tuit el viernes, Warren dijo: "Por supuesto que necesitamos una investigación del FBI antes de votar".
Sin embargo, una encuesta publicada el jueves mostró que la mayoría de los propios electores de Warren no creen que debería presentarse en 2020.
Según la encuesta del Centro de Investigación Política de la Universidad de Suffolk y el Boston Globe, el 58 % de los votantes "probables" de Massachusetts afirmó que el senador no debería presentarse.
El 32 % apoyó tal candidatura.
La encuesta mostró un mayor apoyo a una candidatura del exgobernador Deval Patrick, con un 38 % a favor de una posible candidatura y un 48 % en contra.
Otros nombres destacados del Partido Demócrata que se han mencionado en relación con una posible candidatura en 2020 incluyen al exvicepresidente Joe Biden y al senador de Vermont, Bernie Sanders.
Biden dijo que tomaría una decisión oficial en enero, informó Associated Press.
Sarah Palin menciona el TEPT de Track Palin en un mitin de Donald Trump
Track Palin, de 26 años, pasó un año en Irak después de alistarse en septiembre.
Fue arrestado y acusado de un incidente de violencia doméstica la noche del lunes.
“Lo que está pasando mi propio hijo, lo que está pasando al volver, puedo relacionarlo con otras familias que sienten las ramificaciones del TEPT y algunas de las heridas con las que nuestros soldados regresan”, dijo a la audiencia en un mitin de Donald Trump en Tulsa, Oklahoma.
Palin calificó su arresto como "el elefante en la habitación" y dijo de su hijo y otros veteranos de guerra: "regresan un poco diferentes, regresan endurecidos, regresan preguntándose si hay ese respeto por lo que sus compañeros soldados y aviadores, y todos los demás miembros de las fuerzas armadas, han dado al país".
Fue arrestado el lunes en Wasilla, Alaska, y acusado de agresión por violencia doméstica contra una mujer, de interferir en un informe de violencia doméstica y de posesión de un arma mientras estaba intoxicado, según Dan Bennett, portavoz del Departamento de Policía de Wasilla.
18 estados y el Distrito de Columbia apoyan el desafío a la nueva política de asilo
Dieciocho estados y el Distrito de Columbia están apoyando un recurso legal contra una nueva política de EE. UU. que niega el asilo a las víctimas que huyen de la violencia de pandillas o doméstica.
Representantes de los 18 estados y el distrito presentaron un escrito de amicus curiae el viernes en Washington para apoyar a un solicitante de asilo que impugna la política, informó NBC News.
El nombre completo del demandante en la demanda Grace contra Sessions, que la Unión Estadounidense por las Libertades Civiles presentó en agosto contra la política federal, no ha sido revelado.
Ella dijo que su pareja "y sus hijos, miembros de una pandilla violenta", la maltrataron, pero las autoridades estadounidenses denegaron su solicitud de asilo el 20 de julio.
Fue detenida en Texas.
Los fiscales estatales que apoyan a Grace describieron a El Salvador, Honduras y Guatemala, que producen un gran número de solicitantes de asilo en Estados Unidos, como naciones que enfrentan problemas generalizados con pandillas y violencia doméstica.
La nueva política de asilo de EE. UU. revirtió una decisión de 2014 del Consejo de Apelaciones de Inmigrantes que permitía a los inmigrantes indocumentados que huían de la violencia doméstica solicitar asilo.
El fiscal general del Distrito de Columbia, Karl Racine, dijo en un comunicado el viernes que la nueva política "ignora décadas de leyes estatales, federales e internacionales".
“La ley federal exige que todas las solicitudes de asilo se resuelvan en función de los hechos y circunstancias particulares de la solicitud, y tal prohibición viola ese principio”, se indicó en el escrito presentado por los amigos del tribunal.
Los abogados argumentaron además en el escrito que la política que niega la entrada a los inmigrantes perjudica a la economía de EE. UU., afirmando que es más probable que se conviertan en empresarios y "proporcionen la mano de obra necesaria".
En junio, el fiscal general Jeff Sessions ordenó a los jueces de inmigración que dejaran de conceder asilo a las víctimas que huían de la violencia doméstica y la violencia de las pandillas.
"El asilo está disponible para aquellos que abandonan su país de origen debido a persecución o temor por motivos de raza, religión, nacionalidad, o pertenencia a un grupo social específico u opinión política", dijo Sessions en su anuncio de la política el 11 de junio.
El asilo nunca estuvo destinado a aliviar todos los problemas, ni siquiera todos los problemas graves, que las personas enfrentan todos los días en todo el mundo.
Esperanzas desesperadas de rescate en Palu mientras el número de muertos se duplica en la carrera por encontrar supervivientes
Para los sobrevivientes, la situación se volvió cada vez más grave.
"Se siente mucha tensión", dijo Risa Kusuma, una madre de 35 años, mientras consolaba a su bebé con fiebre en un centro de evacuación en la devastada ciudad de Palu.
"Cada minuto, una ambulancia trae cuerpos.
El agua limpia es escasa".
Se vio a los residentes regresando a sus hogares destruidos, revisando sus pertenencias empapadas, tratando de rescatar todo lo que podían encontrar.
Cientos de personas resultaron heridas y los hospitales, dañados por el terremoto de magnitud 7,5, se vieron desbordados.
Algunos de los heridos, incluido Dwi Haris, que sufrió una fractura en la espalda y el hombro, descansaban fuera del Hospital Militar de Palu, donde los pacientes eran atendidos al aire libre debido a los fuertes réplicas que continuaban.
Las lágrimas llenaron sus ojos mientras recordaba cómo el violento terremoto sacudía la habitación del quinto piso del hotel que compartía con su esposa e hija.
"No hubo tiempo para salvarnos.
"Creo que quedé atrapado entre los escombros de la pared", dijo Haris a Associated Press, y agregó que su familia estaba en la ciudad para una boda.
"Escuché a mi esposa pedir ayuda, pero luego hubo silencio.
No sé qué le pasó a ella y a mi hijo.
Espero que estén a salvo".
El embajador de EE. UU. acusa a China de "acosar" con "anuncios de propaganda"
Una semana después de que un periódico oficial chino publicara un anuncio de cuatro páginas en un diario estadounidense destacando los beneficios mutuos del comercio entre Estados Unidos y China, el embajador de Estados Unidos en China acusó a Pekín de utilizar la prensa estadounidense para difundir propaganda.
El presidente de Estados Unidos, Donald Trump, se refirió el miércoles pasado al suplemento pagado por China Daily en el Des Moines Register, el periódico de mayor venta en el estado de Iowa, después de acusar a China de intentar interferir en las elecciones al Congreso de Estados Unidos del 6 de noviembre, una acusación que China niega.
La acusación de Trump de que Pekín intentaba interferir en las elecciones estadounidenses marcó lo que funcionarios estadounidenses dijeron a Reuters que era una nueva fase en una campaña en escalada de Washington para presionar a China.
Aunque es normal que los gobiernos extranjeros publiquen anuncios para promover el comercio, Pekín y Washington están actualmente atrapados en una guerra comercial en escalada que ha llevado a ambos a imponer rondas de aranceles sobre las importaciones del otro.
Los aranceles de represalia de China al inicio de la guerra comercial estaban diseñados para afectar a los exportadores en estados como Iowa que apoyaban al Partido Republicano de Trump, según han dicho expertos chinos y estadounidenses.
Terry Branstad, el embajador de Estados Unidos en China y el antiguo gobernador de Iowa, un importante exportador de productos agrícolas a China, dijo que Pekín había perjudicado a los trabajadores, agricultores y empresas estadounidenses.
China, escribió Branstad en un artículo de opinión en el Des Moines Register del domingo, "ahora está redoblando esa intimidación al publicar anuncios propagandísticos en nuestra propia prensa libre".
“Al difundir su propaganda, el gobierno de China se aprovecha de la preciada tradición estadounidense de libertad de expresión y prensa libre al publicar un anuncio pagado en el Des Moines Register”, escribió Branstad.
“En cambio, en el quiosco de la calle aquí en Pekín, encontrará pocas voces disidentes y no verá ningún reflejo real de las diversas opiniones que el pueblo chino pueda tener sobre la preocupante trayectoria económica de China, dado que los medios están bajo el firme control del Partido Comunista Chino”, escribió.
Añadió que "uno de los periódicos más destacados de China evitó la oferta de publicar" su artículo, aunque no dijo cuál era el periódico.
Los republicanos están alienando a las votantes mujeres antes de las elecciones de mitad de mandato con el desastre de Kavanaugh, advierten los analistas
Mientras muchos republicanos de alto rango apoyan y defienden al candidato a la Corte Suprema Brett Kavanaugh ante varias acusaciones de agresión sexual, los analistas han advertido que enfrentarán una reacción negativa, especialmente de las mujeres, durante las próximas elecciones de mitad de mandato.
Las emociones en torno a esto han sido extremadamente intensas, y la mayoría de los republicanos ya han dejado constancia de que querían seguir adelante con la votación.
"Esas cosas no se pueden revertir", dijo Grant Reeher, profesor de ciencias políticas en la Maxwell School de la Universidad de Syracuse, a The Hill para un artículo publicado el sábado.
Reeher dijo que duda que la presión de último momento del senador Jeff Flake (R-Arizona) para una investigación del FBI sea suficiente para calmar a los votantes enojados.
"Las mujeres no van a olvidar lo que sucedió ayer, no lo van a olvidar mañana ni en noviembre", dijo Karine Jean-Pierre, asesora principal y portavoz nacional del grupo progresista MoveOn, el viernes, según el periódico de Washington, D.C.
El viernes por la mañana, los manifestantes coreaban "¡Noviembre está llegando!" mientras protestaban en el pasillo del Senado, mientras que los republicanos que controlan el Comité Judicial decidieron seguir adelante con la nominación de Kavanaugh a pesar del testimonio de la Dra. Christine Blasey Ford, informó Mic.
"El entusiasmo y la motivación democráticos van a ser extraordinarios", dijo Stu Rothenberg, un analista político no partidista, al sitio de noticias.
"La gente dice que ya ha sido alta; eso es cierto.
Pero podría ser mayor, especialmente entre las mujeres indecisas en los suburbios y los votantes más jóvenes, de 18 a 29 años, que, aunque no les gusta el presidente, a menudo no votan".
Incluso antes del testimonio público de Ford, en el que detalló sus acusaciones de agresión sexual contra el candidato a la Corte Suprema, los analistas sugirieron que podría haber una reacción negativa si los republicanos avanzaban con la confirmación.
“Esto se ha convertido en un desastre confuso para el Partido Republicano”, dijo Michael Steele, ex presidente del Comité Nacional Republicano, a principios de la semana pasada, según NBC News.
"No se trata solo del voto del comité o del voto final, o de si Kavanaugh es nombrado juez, sino también de la forma en que los republicanos han manejado esto y de cómo la han tratado", señaló Guy Cecil, director de Priorities USA, un grupo que ayuda a elegir a los demócratas, al canal de noticias.
Sin embargo, los estadounidenses parecen estar algo divididos sobre a quién creer después de los testimonios de Ford y Kavanaugh, con una ligera mayoría que se inclina por este último.
Una nueva encuesta de YouGov muestra que el 41 % de los encuestados creyeron definitivamente o probablemente el testimonio de Ford, mientras que el 35 % dijo que creyeron definitivamente o probablemente a Kavanaugh.
Además, el 38 % dijo que creía que Kavanaugh probablemente o definitivamente mintió durante su testimonio, mientras que solo el 30 % dijo lo mismo sobre Ford.
Después de la presión ejercida por Flake, el FBI está investigando actualmente las acusaciones presentadas por Ford, así como las de al menos otra acusadora, Deborah Ramirez, informó The Guardian.
Ford testificó ante el Comité Judicial del Senado bajo juramento la semana pasada que Kavanaugh la agredió ebrio cuando ella tenía 17 años.
Ramirez alega que el candidato a la Corte Suprema le mostró sus genitales mientras asistían a una fiesta durante su época de estudios en Yale en la década de 1980.
El inventor de la World Wide Web planea iniciar una nueva Internet para competir con Google y Facebook
Tim Berners-Lee, el inventor de la World Wide Web, está lanzando una startup que busca rivalizar con Facebook, Amazon y Google.
El último proyecto de la leyenda tecnológica, Inrupt, es una empresa que se basa en la plataforma de código abierto Solid de Berners-Lee.
Solid permite a los usuarios elegir dónde se almacenan sus datos y qué personas tienen acceso a qué información.
En una entrevista exclusiva con Fast Company, Berners-Lee bromeó diciendo que el objetivo detrás de Inrupt es "dominar el mundo".
"Tenemos que hacerlo ahora", dijo sobre la startup.
"Es un momento histórico".
La aplicación utiliza la tecnología de Solid para permitir a las personas crear su propio "almacén de datos personales en línea" o un POD.
Puede contener listas de contactos, listas de tareas pendientes, un calendario, una biblioteca de música y otras herramientas personales y profesionales.
Es como si Google Drive, Microsoft Outlook, Slack y Spotify estuvieran todos disponibles en un solo navegador y al mismo tiempo.
Lo único que hace único al almacén de datos personales en línea es que el usuario decide completamente quién puede acceder a qué tipo de información.
La empresa lo llama "empoderamiento personal a través de los datos".
La idea de Inrupt, según el director ejecutivo de la empresa, John Bruce, es que la empresa aporte recursos, procesos y las habilidades adecuadas para ayudar a que Solid esté disponible para todos.
La empresa actualmente está compuesta por Berners-Lee, Bruce, una plataforma de seguridad adquirida por IBM, algunos desarrolladores internos contratados para trabajar en el proyecto y una comunidad de programadores voluntarios.
A partir de esta semana, los desarrolladores de tecnología de todo el mundo podrán crear sus propias aplicaciones descentralizadas utilizando las herramientas disponibles en el sitio web de Inrupt.
Berners-Lee dijo que él y su equipo no están hablando con "Facebook y Google sobre si introducir o no un cambio completo que revierta todos sus modelos de negocio de la noche a la mañana.
"No estamos pidiendo su permiso".
En una publicación en Medium el sábado, Berners-Lee escribió que la "misión de Inrupt es aportar energía comercial y un ecosistema para ayudar a proteger la integridad y la calidad de la nueva web construida sobre Solid".
En 1994, Berners-Lee transformó Internet cuando estableció el Consorcio World Wide Web en el Instituto Tecnológico de Massachusetts.
En los últimos meses, Berners-Lee ha sido una voz influyente en el debate sobre la neutralidad de la red.
Aun cuando se lance Inrupt, Berners-Lee seguirá siendo el fundador y director del Consorcio World Wide Web, la Fundación Web y el Instituto de Datos Abiertos.
“Estoy increíblemente optimista respecto a esta nueva era de la web”, agregó Berners-Lee.
Bernard Vann: Celebración del clérigo con la Cruz Victoria de la Primera Guerra Mundial
El único clérigo de la Iglesia de Inglaterra que ganó una Cruz Victoria durante la Primera Guerra Mundial como combatiente fue homenajeado en su ciudad natal 100 años después.
El teniente coronel reverendo Bernard Vann ganó el premio el 29 de septiembre de 1918 durante el ataque en Bellenglise y Lehaucourt.
Sin embargo, fue asesinado por un francotirador cuatro días después y nunca supo que había ganado el más alto honor militar británico.
El sábado, sus dos nietos develaron una piedra conmemorativa durante un desfile en Rushden, Northamptonshire.
Uno de sus nietos, Michael Vann, dijo que era "brillantemente simbólico" que la piedra se revelara exactamente 100 años después de la hazaña galardonada de su abuelo.
Según el London Gazette, el 29 de septiembre de 1918, el teniente coronel Vann dirigió a su batallón a través del Canal de Saint-Quentin "en medio de una niebla muy espesa y bajo un intenso fuego de cañones de campo y ametralladoras".
Más tarde, corrió hacia la línea de fuego y, con la "mayor valentía", lideró la avanzada antes de atacar solo un cañón de campaña y derribar a tres de los miembros del destacamento.
El teniente coronel Vann fue asesinado por un francotirador alemán el 4 de octubre de 1918, poco más de un mes antes de que terminara la guerra.
Michael Vann, de 72 años, dijo que las acciones de su abuelo fueron "algo que sé que nunca podría igualar, pero algo que es humillante".
Él y su hermano, el Dr. James Vann, también depositaron una corona de flores después del desfile, que fue encabezado por la banda juvenil Imperial de Brentwood.
Michael Vann dijo que se sentía "muy honrado de participar en el desfile" y añadió que "el valor de un verdadero héroe se demuestra con el apoyo que le brindarán muchas personas".
Los aficionados al MMA se quedaron despiertos toda la noche para ver Bellator 206, pero en su lugar vieron a Peppa Pig
Imagínese esto: se ha quedado despierto toda la noche para ver un lleno Bellator 206, solo para que le nieguen la posibilidad de ver el evento principal.
La cartelera de San José incluía 13 peleas, de las cuales seis formaban parte de la cartelera principal, y se transmitió en vivo durante toda la noche en el Reino Unido por el canal 5.
A las 6 de la mañana, justo cuando Gegard Mousasi y Rory MacDonald se estaban preparando para enfrentarse, los espectadores en el Reino Unido se quedaron atónitos cuando la cobertura cambió a Peppa Pig.
Algunos no quedaron impresionados después de haberse quedado despiertos hasta altas horas de la madrugada especialmente para la pelea.
Un fanático en Twitter describió el cambio al dibujo animado infantil como "una especie de broma enferma".
"Es una regulación gubernamental que indica que a las 6 a. m. ese contenido no era adecuado, por lo que tuvieron que cambiar a programación infantil", dijo Dave Schwartz, vicepresidente senior de marketing y comunicación de Bellator, cuando se le preguntó sobre la transmisión.
«Peppa la cerdita», sí.
El presidente de la empresa Bellator, Scott Coker, dijo que van a trabajar en su programación para incluir a los espectadores del Reino Unido en el futuro.
“Creo que cuando pienso en la repetición, pienso que probablemente podamos resolverlo”, dijo Coker.
"Pero son las seis de la mañana de un domingo allí, y no podremos resolver esto hasta el domingo en nuestra hora, lunes en su hora.
Pero estamos trabajando en ello.
Créanme, cuando se produjo el cambio, hubo muchos mensajes de texto que iban y venían, y ninguno de ellos era amistoso.
Estábamos intentando arreglarlo, pensamos que era un fallo técnico.
Pero no lo era, era un problema gubernamental.
Puedo prometerles que la próxima vez no va a pasar.
Lo mantendremos en cinco peleas en lugar de seis, como normalmente hacemos, y tratamos de ofrecer más de lo esperado para los aficionados, pero nos pasamos.
Es una situación desafortunada".
Desert Island Discs: Tom Daley se sintió "inferior" por su sexualidad
El clavadista olímpico Tom Daley dice que creció sintiéndose inferior a todos debido a su sexualidad, pero que eso le dio la motivación para tener éxito.
El joven de 24 años dijo que no se dio cuenta hasta que fue a la escuela secundaria de que "no todos son como yo".
En el primer programa de Radio 4 Desert Island Discs presentado por Lauren Laverne, dijo que habló sobre los derechos de los gays para dar "esperanza" a otros.
También dijo que convertirse en padre le hizo preocuparse menos por ganar las Olimpiadas.
La presentadora habitual del programa de larga duración, Kirsty Young, se ha tomado varios meses de descanso debido a una enfermedad.
Al aparecer como náufrago en el primer programa de Laverne, Daley dijo que se sentía "inferior" a todos los demás mientras crecía porque "no era socialmente aceptable gustar de niños y niñas".
Dijo: “Hasta el día de hoy, esos sentimientos de sentirme inferior y diferente han sido las verdaderas cosas que me han dado el poder y la fuerza para poder tener éxito”.
Quería demostrar que era "algo", dijo, para no decepcionar a todos cuando finalmente descubrieran su sexualidad.
El dos veces medallista olímpico de bronce se ha convertido en un destacado defensor de los derechos LGBT y aprovechó su participación en los Juegos de la Mancomunidad de este año en Australia para pedir a más países que despenalicen la homosexualidad.
Dijo que habló porque se sentía afortunado de poder vivir abiertamente sin consecuencias y quería darles "esperanza" a los demás.
El tres veces campeón mundial dijo que enamorarse de un hombre, el cineasta estadounidense Dustin Lance Black, a quien conoció en 2013, "me tomó por sorpresa".
Daley se casó el año pasado con la ganadora del Óscar, que es 20 años mayor que él, pero dijo que la diferencia de edad nunca había sido un problema.
"Cuando uno pasa por tanto a tan temprana edad" - fue a sus primeros Juegos Olímpicos a los 14 años y su padre murió de cáncer tres años después - dijo que era difícil encontrar a alguien de la misma edad que hubiera experimentado altibajos similares.
La pareja se convirtió en padres en junio, de un hijo llamado Robert Ray Black-Daley, y Daley dijo que su "perspectiva entera" había cambiado.
“Si me lo hubieran preguntado el año pasado, habría dicho que lo único que importaba era ‘necesito ganar una medalla de oro’”, dijo.
"Saben qué, hay cosas más importantes que las medallas de oro olímpicas.
Mi medalla de oro olímpica es Robbie".
Su hijo tiene el mismo nombre que su padre, Robert, quien falleció en 2011 a los 40 años tras ser diagnosticado con cáncer cerebral.
Daley dijo que su padre no aceptaba que iba a morir y una de las últimas cosas que le había preguntado era si ya tenían las entradas para Londres 2012, ya que quería estar en la primera fila.
"No podía decirle 'no estarás aquí para estar en la primera fila, papá'", dijo.
“Estaba sosteniendo su mano cuando dejó de respirar y no fue hasta que realmente dejó de respirar y murió que finalmente acepté que no era invencible”, dijo.
Al año siguiente, Daley compitió en las Olimpiadas de 2012 y ganó la medalla de bronce.
“Simplemente sabía que esto era lo que había soñado toda mi vida: sumergirme delante de mi gente en unos Juegos Olímpicos, no había sensación mejor”, dijo.
También lo inspiró para elegir su primera canción: Proud de Heather Small, que le había conmovido durante la preparación para los Juegos Olímpicos y que todavía le provocaba escalofríos.
Desert Island Discs se emite en BBC Radio 4 los domingos a las 11:15 BST.
Mickelson, fuera de forma, se quedó en el banquillo el sábado de la Ryder Cup
El estadounidense Phil Mickelson establecerá un récord el domingo cuando juegue su 47.º partido de la Ryder Cup, pero tendrá que mejorar su forma para evitar que sea un hito desafortunado.
Mickelson, que participaba en el evento bianual por duodécima vez, un récord, fue relegado al banquillo por el capitán Jim Furyk para los fourballs y los foursomes del sábado.
En lugar de estar en el centro de la acción, como tantas veces lo ha estado para los Estados Unidos, el cinco veces ganador de torneos importantes dividió su día entre ser animador y trabajar en su juego en el campo, con la esperanza de corregir lo que le aqueja.
Nunca fue el más recto de los golfistas, ni siquiera en el apogeo de su carrera, y el golfista de 48 años no es el candidato ideal para el estrecho campo de Le Golf National, donde el largo rough castiga rutinariamente los golpes errantes.
Y si el campo por sí solo no es lo suficientemente intimidante, Mickelson, en el noveno partido del domingo, se enfrenta al preciso campeón del British Open Francesco Molinari, quien se ha asociado con el novato Tommy Fleetwood para ganar los cuatro partidos de esta semana.
Si los estadounidenses, que están cuatro puntos abajo al comenzar los 12 partidos de individuales, tienen un buen comienzo, el partido de Mickelson podría resultar absolutamente crucial.
Furyk expresó su confianza en su hombre, aunque tampoco podía decir mucho más.
“Él entendió completamente el papel que tenía hoy, me dio una palmada en la espalda, me puso el brazo alrededor de los hombros y me dijo que estaría listo mañana”, dijo Furyk.
"Tiene mucha confianza en sí mismo.
Es un miembro del Salón de la Fama y ha aportado mucho a estos equipos en el pasado y esta semana.
Probablemente no imaginé que él jugaría dos partidos.
Imaginé algo más, pero así fue como salió y así fue como pensamos que teníamos que hacerlo.
Él quiere estar allí afuera, al igual que todos los demás".
El domingo, Mickelson superará el récord de Nick Faldo de mayor número de partidos de la Ryder Cup jugados.
Podría marcar el final de una carrera en la Ryder Cup que nunca ha alcanzado las alturas de su récord individual.
Mickelson tiene 18 victorias, 20 derrotas y siete empates, aunque Furyk dijo que su presencia aportó algunos factores intangibles al equipo.
"Es gracioso, sarcástico, ingenioso, le gusta burlarse de la gente y es un gran tipo para tener en el vestuario del equipo", explicó.
Creo que los jugadores más jóvenes también se divirtieron intentando superarlo esta semana, lo cual fue divertido de ver.
Él ofrece mucho más que solo juego".
El capitán europeo Thomas Bjorn sabe que una gran ventaja puede desaparecer rápidamente
Thomas Bjorn, el capitán europeo, sabe por experiencia que una ventaja considerable al entrar en los partidos individuales del último día de la Ryder Cup puede convertirse fácilmente en un viaje incómodo.
El danés debutó en el partido de 1997 en Valderrama, donde el equipo capitaneado por Seve Ballesteros tenía una ventaja de cinco puntos sobre los estadounidenses, pero solo logró cruzar la línea de meta por delante por el margen más estrecho, ganando 14½-13½.
"Uno no deja de recordar que teníamos una gran ventaja en Valderrama; teníamos una gran ventaja en Brookline, donde perdimos, y en Valderrama, donde ganamos, pero por muy poco", dijo Bjorn, en la imagen, después de ver cómo la Clase de 2018 ganaba 5-3 tanto el viernes como ayer para liderar 10-6 en Le Golf National.
La historia nos demostrará a mí y a todos los miembros del equipo que esto no ha terminado.
Mañana vas a tope.
Sal y haz todo lo correcto.
Esto no termina hasta que tengas los puntos en el tablero.
Tenemos un objetivo, y es tratar de ganar este trofeo, y ahí es donde se mantiene el enfoque.
Siempre he dicho que me centro en los 12 jugadores de nuestro equipo, pero somos muy conscientes de lo que hay al otro lado: los mejores jugadores del mundo".
Encantado con el rendimiento de sus jugadores en un campo de golf difícil, Bjorn agregó: "Nunca me adelantaré a los acontecimientos en esto".
Mañana es otra historia.
Mañana serán las actuaciones individuales las que se presenten, y eso es algo diferente.
Es genial estar ahí fuera con un compañero cuando las cosas van bien, pero cuando estás solo, entonces se pone a prueba al máximo tu capacidad como golfista.
Ese es el mensaje que debes transmitir a los jugadores: sacar lo mejor de ti mismo mañana.
Ahora, dejas a tu compañero atrás y él tiene que ir y sacar lo mejor de sí mismo, también".
A diferencia de Bjorn, su homólogo Jim Furyk buscará que sus jugadores tengan un mejor rendimiento individual que el que tuvieron como pareja, con la excepción de Jordan Spieth y Justin Thomas, quienes obtuvieron tres puntos de cuatro.
Furyk ha estado en ambos extremos de esos grandes cambios de última hora, habiendo formado parte del equipo ganador en Brookline antes de terminar perdiendo cuando Europa logró el "Milagro de Medinah".
"Recuerdo cada maldita palabra", dijo en respuesta a la pregunta sobre cómo Ben Crenshaw, el capitán en 1999, había animado a sus jugadores antes del último día.
"Mañana tenemos 12 partidos importantes, pero te gustaría empezar con ese ritmo rápido que viste en Brookline, como el que viste en Medinah.
Cuando ese impulso se dirige en una dirección, ejerce mucha presión sobre esos partidos intermedios.
Organizamos nuestro alineamiento en consecuencia y colocamos a los chicos de la manera en que sentimos que, ya saben, estamos tratando de hacer algo mágico mañana".
A Thomas se le ha encomendado la tarea de intentar liderar la contraofensiva y se enfrentará a Rory McIlroy en el partido más importante, mientras que Paul Casey, Justin Rose, Jon Rahm, Tommy Fleetwood e Ian Poulter son los otros europeos en la mitad superior del orden.
"Fui con este grupo de chicos en este orden porque creo que cubre todo el camino", dijo Bjorn sobre sus selecciones de singles.
El nuevo buque de guerra de Alemania se pospone una vez más
La nueva fragata de la Armada alemana debería haber sido puesta en servicio en 2014 para reemplazar a los viejos buques de guerra de la era de la Guerra Fría, pero no estará lista hasta al menos el próximo año debido a sistemas defectuosos y costos que se han ido incrementando, informaron los medios locales.
La puesta en servicio del "Rheinland-Pfalz", el buque insignia de las nuevas fragatas de la clase Baden-Wuerttemberg, se ha pospuesto hasta la primera mitad de 2019, según el periódico Die Zeit, citando a un portavoz militar.
El buque debería haberse incorporado a la Armada en 2014, pero los preocupantes problemas posteriores a la entrega afectaron el destino del ambicioso proyecto.
Los cuatro buques de la clase Baden-Wuerttemberg que la Armada encargó en 2007 reemplazarán a las envejecidas fragatas de la clase Bremen.
Se entiende que contarán con un cañón potente, una serie de misiles antiaéreos y antibuque, así como algunas tecnologías de sigilo, como firmas reducidas de radar, infrarrojo y acústicas.
Otras características importantes incluyen períodos de mantenimiento más largos: debería ser posible desplegar las fragatas más nuevas durante hasta dos años lejos de los puertos de origen.
Sin embargo, los retrasos continuos significan que los buques de guerra de vanguardia, que supuestamente permitirían a Alemania proyectar poder en el extranjero, ya estarán obsoletos para el momento en que entren en servicio, señala Die Zeit.
La desafortunada fragata F125 fue noticia el año pasado, cuando la Armada alemana se negó oficialmente a poner en servicio el buque y lo devolvió al astillero Blohm & Voss en Hamburgo.
Esta fue la primera vez que la Armada devolvió un barco a un astillero después de su entrega.
Se sabía poco sobre las razones detrás del regreso, pero los medios alemanes citaron una serie de "defectos de software y hardware" cruciales que hacían que el buque de guerra fuera inútil si se desplegaba en una misión de combate.
Las deficiencias del software fueron particularmente importantes, ya que los buques de la clase Baden-Wuerttemberg serán operados por una tripulación de unos 120 marineros, lo que representa solo la mitad de la mano de obra de las fragatas de la clase Bremen, más antiguas.
Además, se descubrió que el barco tiene un peso excesivo, lo que reduce su rendimiento y limita la capacidad de la Armada para incorporar mejoras futuras.
Se cree que el "Rheinland-Pfalz", de 7.000 toneladas, es el doble de pesado que los barcos de clase similar utilizados por los alemanes en la Segunda Guerra Mundial.
Además de los problemas de hardware, el costo total del proyecto, incluida la capacitación de la tripulación, también se está convirtiendo en un problema.
Se dice que alcanzó la cifra asombrosa de 3100 millones de euros (3600 millones de dólares), en comparación con los 2200 millones de euros iniciales.
Los problemas que afectan a las fragatas más recientes cobran especial importancia a la luz de las recientes advertencias de que el poder naval de Alemania está disminuyendo.
A principios de este año, Hans-Peter Bartels, jefe del comité de defensa del parlamento alemán, reconoció que la Marina en realidad "se está quedando sin barcos capaces de ser desplegados".
El funcionario dijo que el problema se ha agravado con el tiempo, ya que los barcos antiguos fueron dados de baja, pero no se proporcionaron embarcaciones de reemplazo.
Lamentó que ninguna de las fragatas de la clase Baden-Wuerttemberg pudiera unirse a la Armada.
National Trust espía la vida secreta de los murciélagos
Una nueva investigación que se está llevando a cabo en una finca en las Tierras Altas de Escocia tiene como objetivo revelar cómo los murciélagos utilizan el paisaje en su búsqueda de alimento.
Se espera que los hallazgos arrojen nueva luz sobre el comportamiento de estos únicos mamíferos voladores y ayuden a orientar las actividades de conservación futuras.
El estudio realizado por científicos de la National Trust for Scotland seguirá a los murciélagos pigmeo y soprano, así como a los murciélagos orejudos y de Daubenton en los jardines de Inverewe, en Wester Ross.
Se colocarán grabadoras especiales en ubicaciones clave alrededor de la propiedad para monitorear las actividades de los murciélagos durante toda la temporada.
El personal y los voluntarios del NHS también realizarán encuestas móviles utilizando detectores portátiles.
Un análisis de sonido experto de todas las grabaciones determinará la frecuencia de los llamados de los murciélagos y qué especies están haciendo qué.
A continuación, se elaborará un mapa del hábitat y un informe para obtener una imagen detallada de su comportamiento a escala de paisaje.
Rob Dewar, asesor de conservación de la naturaleza para NTS, espera que los resultados revelen qué áreas del hábitat son las más importantes para los murciélagos y cómo son utilizadas por cada una de las especies.
Esta información ayudará a determinar los beneficios del trabajo de gestión del hábitat, como la creación de prados, y la mejor manera de mantener los bosques para los murciélagos y otras especies asociadas.
Las poblaciones de murciélagos en Escocia y en todo el Reino Unido han disminuido considerablemente en el último siglo.
Están amenazados por la construcción y el desarrollo que afectan a sus refugios y a la pérdida de su hábitat.
Las turbinas eólicas y la iluminación también pueden representar un riesgo, al igual que las trampas para moscas y algunos tratamientos químicos de los materiales de construcción, así como los ataques de gatos domésticos.
Los murciélagos no son realmente ciegos.
Sin embargo, debido a sus hábitos de caza nocturna, sus oídos son más útiles que sus ojos a la hora de capturar presas.
Utilizan una sofisticada técnica de ecolocalización para localizar insectos y obstáculos en su trayectoria de vuelo.
La NTS, que se encarga del cuidado de más de 270 edificios históricos, 38 jardines importantes y 76 000 hectáreas de tierra en todo el país, toma a los murciélagos muy en serio.
Cuenta con diez expertos capacitados, que realizan regularmente encuestas, inspecciones de refugios y, en ocasiones, rescates.
La organización incluso ha establecido la primera y única reserva exclusiva para murciélagos de Escocia en la finca de Threave, en Dumfries y Galloway, que alberga ocho de las diez especies de murciélagos de Escocia.
El administrador de la finca, David Thompson, dice que la finca es el territorio ideal para ellos.
"En Threave tenemos un área excelente para los murciélagos", dijo.
“Tenemos los edificios antiguos, muchos árboles veteranos y todo el buen hábitat.
Pero todavía hay mucho que desconocemos sobre los murciélagos, por lo que el trabajo que realizamos aquí y en otras propiedades nos ayudará a comprender mejor lo que necesitan para prosperar".
Destaca la importancia de verificar la presencia de murciélagos antes de realizar tareas de mantenimiento en las propiedades, ya que la destrucción involuntaria de un solo refugio de maternidad podría matar hasta 400 hembras y crías, lo que podría eliminar toda una población local.
Los murciélagos están protegidos y es ilegal matarlos, hostigarlos o molestarlos, o destruir sus refugios.
Elisabeth Ferrell, oficial escocesa del Bat Conservation Trust, ha animado al público a colaborar para ayudar.
Ella dijo: "Todavía tenemos mucho que aprender sobre nuestros murciélagos y, para muchas de nuestras especies, simplemente no sabemos cómo están evolucionando sus poblaciones".
Ronaldo desmiente las acusaciones de violación mientras sus abogados preparan una demanda contra una revista alemana
Cristiano Ronaldo ha calificado las acusaciones de violación en su contra como "noticias falsas", afirmando que la gente "quiere promocionarse" utilizando su nombre.
Sus abogados tienen previsto demandar a la revista de noticias alemana Der Spiegel, que publicó las acusaciones.
Al delantero de Portugal y Juventus se le acusa de violar a una mujer estadounidense, identificada como Kathryn Mayorga, en una habitación de hotel en Las Vegas en 2009.
Se dice que luego le pagó 375 000 dólares para que guardara silencio sobre el incidente, informó Der Spiegel el viernes.
En un video en vivo de Instagram dirigido a sus 142 millones de seguidores, horas después de que se reportaran las acusaciones, Ronaldo, de 33 años, calificó los informes como "noticias falsas".
"No, no, no, no, no.Given the 
Lo que dijeron hoy son noticias falsas", dice el ganador de cinco Balones de Oro a la cámara.
"Quieren promocionarse usando mi nombre.
Es normal.
Quieren ser famosos para decir mi nombre, pero eso es parte del trabajo.
"Soy un hombre feliz y todo está bien", agregó el jugador, sonriendo.
Los abogados de Ronaldo se están preparando para demandar a Der Spiegel por las acusaciones, a las que han calificado de "una difusión inadmisible de sospechas en el ámbito de la privacidad", según Reuters.
El abogado Christian Schertz dijo que el jugador buscaría una compensación por "daños morales en un monto acorde a la gravedad de la infracción, que probablemente sea una de las violaciones más graves de los derechos personales en los últimos años".
Se dice que el presunto incidente ocurrió en junio de 2009 en una suite del Palms Hotel and Casino en Las Vegas.
Después de conocerse en un club nocturno, Ronaldo y Mayorga supuestamente regresaron a la habitación del jugador, donde él presuntamente la violó analmente, según los documentos presentados en el Tribunal de Distrito del Condado de Clark en Nevada.
Mayorga afirma que Ronaldo se arrodilló después del presunto incidente y le dijo que era un "buen tipo" en un "99 por ciento", pero que el "1 por ciento" lo había defraudado.
Los documentos afirman que Ronaldo confirmó que mantuvieron relaciones sexuales, pero que fue consensuado.
Mayorga también afirma que fue a la policía y que le tomaron fotografías de sus lesiones en un hospital, pero luego aceptó un acuerdo extrajudicial porque se sentía "aterrorizada por la posibilidad de represalias" y estaba preocupada por "ser humillada públicamente".
La mujer de 34 años dice que ahora está intentando anular el acuerdo, ya que sigue traumatizada por el supuesto incidente.
Ronaldo estaba a punto de fichar por el Real Madrid procedente del Manchester United en el momento del supuesto asalto, y este verano se trasladó al gigante italiano Juventus en un acuerdo de 100 millones de euros.
Brexit: Reino Unido "lamentaría para siempre" perder a los fabricantes de automóviles
El Reino Unido "se arrepentiría para siempre" si perdiera su estatus como líder mundial en la fabricación de automóviles después del Brexit, dijo el Secretario de Negocios Greg Clark.
Añadió que era "preocupante" que Toyota UK le hubiera dicho a la BBC que, si Gran Bretaña abandonaba la UE sin un acuerdo, suspendería temporalmente la producción en su fábrica de Burnaston, cerca de Derby.
“Necesitamos un acuerdo”, dijo el Sr. Clark.
El fabricante de automóviles japonés dijo que el impacto de los retrasos en las fronteras en caso de un Brexit sin acuerdo podría costar empleos.
La planta de Burnaston, que fabrica los modelos Auris y Avensis de Toyota, produjo casi 150 000 vehículos el año pasado, de los cuales el 90 % se exportaron al resto de la Unión Europea.
"Mi opinión es que si Gran Bretaña se retira abruptamente de la UE a finales de marzo, veremos paralizaciones de la producción en nuestra fábrica", dijo Marvin Cooke, director general de Toyota en Burnaston.
Otros fabricantes de automóviles del Reino Unido han expresado su preocupación por la posibilidad de que el país abandone la UE sin un acuerdo sobre cómo funcionará el comercio transfronterizo, incluidas Honda, BMW y Jaguar Land Rover.
BMW, por ejemplo, dice que cerrará su planta de Mini en Oxford durante un mes después del Brexit.
Las principales preocupaciones se refieren a lo que los fabricantes de automóviles dicen que son riesgos en la cadena de suministro en caso de un Brexit sin acuerdo.
La línea de producción de Toyota funciona bajo el sistema "justo a tiempo", con piezas que llegan cada 37 minutos de proveedores tanto del Reino Unido como de la UE para los automóviles fabricados por encargo.
Si el Reino Unido abandona la UE sin un acuerdo el 29 de marzo, podría haber interrupciones en la frontera, lo que, según la industria, podría provocar retrasos y escasez de piezas.
Sería imposible para Toyota mantener más de un día de inventario en su planta de Derbyshire, dijo la empresa, por lo que la producción se detendría.
Clark dijo que el plan Chequers de Theresa May para las futuras relaciones con la UE está "calibrado precisamente para evitar esos controles en la frontera".
“Necesitamos llegar a un acuerdo. Queremos llegar al mejor acuerdo que, como he dicho, no solo nos permita disfrutar del éxito actual, sino también aprovechar esta oportunidad”, dijo en el programa Today de BBC Radio 4.
“La evidencia no solo de Toyota, sino también de otros fabricantes, es que necesitamos poder continuar con lo que ha sido un conjunto de cadenas de suministro altamente exitoso”.
Toyota no pudo precisar cuánto tiempo duraría la paralización de la producción, pero advirtió que, a largo plazo, los costos adicionales reducirían la competitividad de la planta y, en última instancia, costarían puestos de trabajo.
Peter Tsouvallaris, quien ha trabajado en Burnaston durante 24 años y es el coordinador del sindicato Unite en la planta, dijo que sus miembros están cada vez más preocupados: "Según mi experiencia, una vez que estos empleos desaparecen, nunca regresan".
Un portavoz del gobierno dijo: "Hemos presentado un plan preciso y creíble para nuestra futura relación con la UE".
La reunión de Trump con Rosenstein podría retrasarse de nuevo, dice la Casa Blanca
La reunión de alto riesgo de Donald Trump con el vicefiscal general Rod Rosenstein podría "posponerse una semana más" mientras continúa la lucha por el nominado al Tribunal Supremo, Brett Kavanaugh, dijo la Casa Blanca el domingo.
Rosenstein supervisa el trabajo del asesor especial Robert Mueller, quien está investigando la interferencia rusa en las elecciones, los vínculos entre los asesores de Trump y Rusia, y la posible obstrucción de la justicia por parte del presidente.
El hecho de que Trump despida o no al fiscal general adjunto, y de esta manera ponga en peligro la independencia de Mueller, ha alimentado los rumores en Washington durante meses.
A principios de este mes, el New York Times informó que Rosenstein había hablado de llevar un micrófono oculto para grabar conversaciones con Trump y de la posibilidad de destituir al presidente mediante la 25.ª enmienda.
Rosenstein negó el informe.
Pero el pasado lunes fue a la Casa Blanca, en medio de informes de que estaba a punto de renunciar.
En cambio, se anunció una reunión con Trump, quien se encontraba en ese momento en las Naciones Unidas en Nueva York, para el jueves.
Trump dijo que "preferiría no" despedir a Rosenstein, pero luego la reunión se pospuso para evitar un choque con la audiencia del comité judicial del Senado en la que tanto Kavanaugh como una de las mujeres que lo acusaron de conducta sexual inapropiada, la Dra. Christine Blasey Ford, testificaron.
El viernes, Trump ordenó una investigación de una semana por parte del FBI sobre las acusaciones contra Kavanaugh, lo que retrasó aún más la votación completa en el Senado.
La secretaria de prensa de Trump, Sarah Sanders, apareció en Fox News el domingo.
Cuando le preguntaron sobre la reunión con Rosenstein, dijo: "No se ha fijado una fecha para eso, podría ser esta semana, pero también podría posponerse una semana más, dada toda la actividad que hay en el Tribunal Supremo".
Pero veremos y siempre me gusta mantener a la prensa informada".
Algunos periodistas cuestionarían esa afirmación: Sanders no ha celebrado una rueda de prensa en la Casa Blanca desde el 10 de septiembre.
El presentador Chris Wallace preguntó por qué.
Sanders dijo que la escasez de ruedas de prensa no se debía a que no le gustara que los reporteros de televisión "dieran espectáculo", aunque comentó: "No voy a negar que lo hagan".
Luego, sugirió que el contacto directo entre Trump y la prensa aumentará.
“El presidente hace más sesiones de preguntas y respuestas que cualquier presidente anterior”, dijo, y agregó sin citar pruebas: “Hemos revisado esos números”.
Las ruedas de prensa seguirán realizándose, dijo Sanders, pero "si la prensa tiene la oportunidad de hacer preguntas directamente al presidente de los Estados Unidos, eso es infinitamente mejor que hablar conmigo".
Intentamos hacerlo mucho y han visto que lo hemos hecho mucho en las últimas semanas, y eso va a reemplazar a una conferencia de prensa cuando puedan hablar con el presidente de los Estados Unidos".
Trump suele responder preguntas cuando sale de la Casa Blanca o participa en sesiones abiertas o conferencias de prensa con dignatarios visitantes.
Las conferencias de prensa individuales son raras.
Esta semana, en Nueva York, el presidente quizás demostró por qué, al hacer una aparición desenfadada y, en ocasiones, extraña ante los periodistas reunidos.
La secretaria de Salud escribe a los trabajadores de la UE en el NHS de Escocia por temores relacionados con el Brexit
El Secretario de Salud ha escrito a los empleados de la UE que trabajan en el NHS de Escocia para expresar la gratitud del país y desearles que permanezcan después del Brexit.
Jeane Freeman MSP envió una carta con menos de seis meses para que el Reino Unido se retire de la UE.
El Gobierno escocés ya se comprometió a cubrir los costos de las solicitudes de estatus establecido para los ciudadanos de la UE que trabajan en sus servicios públicos descentralizados.
En su carta, la Sra. Freeman escribió: "Durante el verano, las negociaciones entre el Reino Unido y la UE sobre la retirada han continuado, con la expectativa de tomar decisiones este otoño.
Pero el Gobierno del Reino Unido también ha estado intensificando sus preparativos para un posible escenario sin acuerdo.
Sé que este debe ser un momento muy inquietante para todos ustedes.
Por eso, quiero reiterar ahora cuánto valoro la contribución de cada miembro del personal, independientemente de su nacionalidad.
Los colegas de toda la UE y de otros países aportan una valiosa experiencia y habilidades que fortalecen y mejoran el trabajo del servicio de salud, y benefician a los pacientes y comunidades a los que servimos.
Escocia es absolutamente su hogar y queremos mucho que se queden aquí".
Christion Abercrombie se somete a una cirugía de emergencia tras sufrir una lesión en la cabeza
El linebacker de los Tigers de Tennessee, Christion Abercrombie, se sometió a una cirugía de emergencia después de sufrir una lesión en la cabeza durante la derrota del sábado por 31-27 ante los Commodores de Vanderbilt, informó Mike Organ del Tennessean.
El entrenador principal de Tennessee State, Rod Reed, informó a los periodistas que la lesión ocurrió poco antes del medio tiempo.
"Vino a la línea de banda y simplemente se desplomó allí", dijo Reed.
Los entrenadores y el personal médico le administraron oxígeno a Abercrombie en la banda antes de colocarlo en una camilla y llevarlo para una evaluación más detallada.
Un funcionario del estado de Tennessee le dijo a Chris Harris de WSMV en Nashville, Tennessee, que Abercrombie había salido de la cirugía en el Centro Médico Vanderbilt.
Harris agregó que aún no hay "detalles sobre el tipo o la gravedad de la lesión" y que el estado de Tennessee está tratando de determinar cuándo ocurrió la lesión.
Abercrombie, un segundo año con un año extra de elegibilidad, está en su primera temporada con Tennessee State después de transferirse de Illinois.
El sábado, antes de abandonar el partido, hizo un total de cinco placajes, lo que elevó su total de la temporada a 18 placajes.
A los compradores extranjeros se les cobrará un impuesto de timbre más alto cuando compren una propiedad en el Reino Unido
A los compradores extranjeros se les cobrará un impuesto de timbre más alto cuando compren una propiedad en el Reino Unido, y el dinero adicional se utilizará para ayudar a las personas sin hogar, según los nuevos planes del Partido Conservador.
Esta medida neutralizará el éxito de la iniciativa de Corbyn para atraer a los jóvenes votantes.
El aumento del impuesto de timbre se aplicará a aquellos que no pagan impuestos en el Reino Unido
El Tesoro espera recaudar hasta 120 millones de libras al año para ayudar a las personas sin hogar.
Se cobrará un tipo impositivo de timbre más elevado a los compradores extranjeros cuando adquieran propiedades en el Reino Unido, y el dinero adicional se utilizará para ayudar a las personas sin hogar, anunció hoy Theresa May.
Esta medida será vista como un intento de neutralizar el éxito de la iniciativa de Jeremy Corbyn para atraer a los jóvenes votantes con promesas de proporcionar viviendas más asequibles y dirigirse a los altos ingresos.
El aumento del impuesto de timbre se aplicará a personas y empresas que no paguen impuestos en el Reino Unido, y el dinero adicional se destinará a impulsar la iniciativa del Gobierno para combatir el problema de las personas que duermen en la calle.
El recargo, que se suma al actual impuesto de timbre, incluidos los niveles más altos introducidos hace dos años para segundas viviendas y alquileres, podría ser de hasta un tres por ciento.
El Tesoro espera que esta medida genere hasta 120 millones de libras al año.
Se estima que el 13 % de las propiedades nuevas en Londres son compradas por personas que no residen en el Reino Unido, lo que hace subir los precios y dificulta que los compradores primerizos puedan acceder al mercado inmobiliario.
Muchas zonas ricas del país, especialmente en la capital, se han convertido en "ciudades fantasma" debido a la gran cantidad de compradores extranjeros que pasan la mayor parte del tiempo fuera del país.
La nueva política se produce solo unas semanas después de que Boris Johnson pidiera una reducción del impuesto de timbre para ayudar a más jóvenes a adquirir su primera vivienda.
Acusó a las grandes empresas de construcción de mantener altos los precios de las propiedades al adquirir terrenos sin utilizarlos, y exhortó a la Sra. May a abandonar las cuotas de viviendas asequibles para solucionar la "vergüenza habitacional" de Gran Bretaña.
Corbyn ha anunciado una llamativa serie de reformas propuestas en materia de vivienda, que incluyen controles de alquiler y el fin de los desalojos "sin culpa".
También quiere otorgar a los consejos mayores poderes para construir nuevas viviendas.
La Sra. May dijo: “El año pasado dije que dedicaría mi mandato a restaurar el sueño británico: que la vida debería ser mejor para cada nueva generación.
Y eso significa arreglar nuestro mercado inmobiliario roto.
Gran Bretaña siempre estará abierta a las personas que quieran vivir, trabajar y construir una vida aquí.
Sin embargo, no puede ser correcto que sea tan fácil para personas que no viven en el Reino Unido, así como para empresas extranjeras, comprar viviendas como para los residentes británicos que trabajan arduamente.
Para demasiadas personas, el sueño de la propiedad de una vivienda se ha vuelto demasiado lejano, y la indignidad de dormir en la calle sigue siendo demasiado real".
Jack Ross: "Mi ambición última es dirigir a Escocia"
El entrenador del Sunderland, Jack Ross, dice que su "ambición última" es convertirse en el entrenador de Escocia en algún momento.
El escocés, de 42 años, está disfrutando del desafío de revitalizar al club del noreste, que actualmente ocupa el tercer lugar en la Liga Uno, a tres puntos del primer puesto.
Se trasladó al Estadio de la Luz este verano después de guiar al St Mirren de vuelta a la Scottish Premiership la temporada pasada.
"Quería jugar para mi país como jugador.
Obtuve una gorra B y eso fue todo", dijo Ross a Sportsound de BBC Scotland.
"Pero de niño crecí viendo a Escocia en Hampden con mi padre, y siempre ha sido algo que me ha atraído.
Esa oportunidad solo llegaría, sin embargo, si tengo éxito en la gestión del club".
Los predecesores de Ross como entrenador del Sunderland incluyen a Dick Advocaat, David Moyes, Sam Allardyce, Martin O'Neill, Roy Keane, Gus Poyet y Paulo Di Canio.
El exentrenador del Alloa Athletic afirma que no sintió ninguna inquietud al seguir a nombres tan establecidos en un club tan grande, habiendo rechazado previamente ofertas del Barnsley y el Ipswich Town.
"En este momento, el éxito para mí se medirá por la pregunta: '¿Puedo devolver a este club a la Premier League?'.
Debido a la estructura y las instalaciones de este club, sin duda pertenece a la Premier League", dijo.
"No es una tarea fácil lograrlo, pero probablemente solo me consideraría exitoso aquí si puedo hacer que el club regrese allí".
Ross lleva solo tres años en su carrera como entrenador, después de un período como asistente en Dumbarton y 15 meses en el cuerpo técnico de Hearts.
Luego ayudó a Alloa a recuperarse del descenso a la tercera división y transformó a St Mirren, que estaba al borde del descenso, en campeón de la Championship la temporada siguiente.
Y Ross dice que se siente más cómodo ahora que en cualquier momento de su carrera como jugador en Clyde, Hartlepool, Falkirk, St Mirren y Hamilton Academical.
"Fue probablemente un verdadero punto de inflexión", recordó, al hacerse cargo de Alloa.
"Realmente creía que la gestión era lo más adecuado para mí, más que jugar.
Suena extraño porque lo hice bien, me ganaba la vida de manera razonable y disfruté de algunos éxitos notables.
Pero jugar puede ser difícil.
Hay muchas cosas que tienes que hacer a diario.
Sigo pasando por eso en términos de estrés y presión del trabajo, pero la gestión simplemente se siente bien.
Siempre quise ser gerente y ahora que lo soy, me siento más cómoda en mi propia piel que en cualquier otro momento de mi vida adulta".
Puede escuchar la entrevista completa en Sportsound el domingo 30 de septiembre, en Radio Escocia, entre las 12:00 y las 13:00 BST.
La hora perfecta para tomarse una pinta es a las 17:30 los sábados, según una encuesta
La ola de calor del verano ha aumentado los ingresos de los pubs británicos, que atraviesan dificultades, pero ha ejercido una mayor presión sobre las cadenas de restaurantes.
Los grupos de pubs y bares vieron un aumento del 2,7 % en las ventas en julio, pero los ingresos de los restaurantes disminuyeron un 4,8 %, según revelaron las cifras.
Peter Martin, de la consultora empresarial CGA, que recopiló los datos, dijo: "El buen tiempo continuado y la participación de Inglaterra en la Copa Mundial, que duró más de lo esperado, hicieron que julio siguiera un patrón similar al del mes anterior, junio, cuando los pubs aumentaron un 2,8 por ciento, excepto que los restaurantes se vieron aún más afectados".
La caída del 1,8 % en las ventas de los restaurantes en junio empeoró aún más en julio.
Los pubs y bares que ofrecen bebidas tuvieron, con diferencia, el mejor desempeño, con un aumento en las ventas comparables, mientras que los restaurantes registraron una disminución.
Los pubs que ofrecen comida también sufrieron con el sol, aunque no de manera tan dramática como los operadores de restaurantes.
Parece que la gente solo quería salir a tomar algo.
En los pubs y bares administrados, las ventas de bebidas aumentaron un 6,6 % durante el mes, mientras que las ventas de comida disminuyeron un 3 %”.
Paul Newman, de RSM, analistas de ocio y hostelería, dijo: "Estos resultados continúan la tendencia que hemos observado desde finales de abril".
El clima y el impacto de los grandes eventos sociales o deportivos siguen siendo los factores más importantes en cuanto a las ventas en el mercado fuera del hogar.
No es sorprendente que los grupos de restaurantes sigan teniendo dificultades, aunque una caída de las ventas del 4,8 % interanual será particularmente dolorosa, además de las presiones de costos continuas.
El largo y caluroso verano no pudo haber llegado en un momento peor para los operadores del sector alimentario, y el tiempo dirá si las temperaturas más moderadas que hemos experimentado en agosto proporcionarán el alivio tan necesario".
El crecimiento total de las ventas en pubs y restaurantes, incluidas las nuevas aperturas, fue del 2,7 % en julio, lo que refleja la desaceleración en el lanzamiento de marcas.
El monitor de ventas de la industria Coffer Peach Tracker para el sector de pubs, bares y restaurantes del Reino Unido recopila y analiza datos de rendimiento de 47 grupos operativos, con un volumen de negocios combinado de más de 9.000 millones de libras, y es el estándar de referencia establecido en la industria.
Uno de cada cinco niños tiene cuentas secretas en las redes sociales que ocultan a sus padres
Una de cada cinco niños, algunos tan jóvenes como 11 años, tienen cuentas secretas en redes sociales que ocultan a sus padres y profesores, revela una encuesta
Una encuesta realizada a 20 000 alumnos de secundaria reveló un aumento en las páginas de «Instagram falso»
La noticia ha aumentado los temores de que se esté publicando contenido sexual
El 20 % de los alumnos dijeron que tienen una cuenta "principal" para mostrar a sus padres
Uno de cada cinco niños, algunos tan jóvenes como de 11 años, están creando cuentas en redes sociales que mantienen en secreto ante los adultos.
Una encuesta realizada a 20 000 alumnos de secundaria reveló un rápido crecimiento de las cuentas de "Insta falso", una referencia al sitio de intercambio de fotos Instagram.
La noticia ha aumentado los temores de que se esté publicando contenido sexual.
El 20 % de los alumnos dijeron que tienen una cuenta "principal" sanitizada para mostrar a sus padres, mientras que también tienen cuentas privadas.
Una madre que se topó con el sitio secreto de su hija de 13 años encontró a una adolescente instando a otros a "violarme".
La investigación, realizada por Digital Awareness UK y la Conferencia de Directores y Directoras de Escuelas Independientes (HMC), descubrió que el 40 % de los jóvenes de entre 11 y 18 años tenían dos perfiles, y la mitad de ellos admitió tener cuentas privadas.
El director de HMC, Mike Buchanan, dijo: "Es preocupante que tantos adolescentes se sientan tentados a crear espacios en línea donde los padres y los profesores no puedan encontrarlos".
Eilidh Doyle será la "voz de los atletas" en la junta de Scottish Athletics
Eilidh Doyle fue elegida para formar parte del consejo de Scottish Athletics como directora no ejecutiva en la asamblea general anual del organismo rector.
Doyle es la atleta de atletismo más condecorada de Escocia, y el presidente Ian Beattie describió el movimiento como una gran oportunidad para que quienes dirigen el deporte se beneficien de su amplia experiencia a nivel internacional durante la última década.
“Eilidh goza de un enorme respeto en la comunidad deportiva escocesa, británica y mundial, y estamos seguros de que el atletismo en Escocia se beneficiaría enormemente con su incorporación al consejo”, dijo Beattie.
Doyle dijo: "Estoy dispuesto a actuar como portavoz de los atletas y espero poder contribuir realmente y ayudar a guiar el deporte en Escocia".
El estadounidense, que ganó los 200 metros y los 400 metros en los Juegos de 1996 en Atlanta, entre sus cuatro medallas de oro olímpicas, y que ahora es un comentarista habitual de la BBC, quedó incapacitado para caminar tras sufrir un accidente isquémico transitorio.
Escribió en Twitter: "Hoy hace un mes que sufrí un accidente cerebrovascular.
No podía caminar.
Los médicos dijeron que solo el tiempo dirá si me recuperaré o hasta qué punto.
¡Ha sido un trabajo agotador, pero logré una recuperación completa, volví a aprender a caminar y hoy estoy haciendo ejercicios de agilidad!
¡Gracias por los mensajes de ánimo!
Un anuncio de una bomba de leche materna que compara a las madres con vacas divide la opinión en línea
Una empresa de extractores de leche ha generado opiniones divididas en línea con un anuncio que compara a las madres lactantes con vacas que están siendo ordeñadas.
Para marcar el lanzamiento de lo que se dice que es el "primer dispositivo silencioso portátil para la extracción de leche materna del mundo", la empresa de tecnología de consumo Elvie lanzó un anuncio inspirado en un video musical con un toque de humor para mostrar la libertad que la nueva bomba brinda a las madres que amamantan.
Cuatro madres reales bailan en un establo lleno de heno y vacas al ritmo de una canción que incluye letras como: "Sí, me ordeño yo misma, pero no ves ninguna cola" y "Por si no te habías dado cuenta, estos no son ubres, son mis tetas".
El coro continúa: “Púmpalo, púmpalo, estoy alimentando a los bebés, púmpalo, púmpalo, estoy ordeñando a mis damas”.
Sin embargo, el anuncio, que se publicó en la página de Facebook de la empresa, ha generado controversia en línea.
Con 77 000 visitas y cientos de comentarios, el video ha recibido reacciones mixtas por parte de los espectadores, muchos de los cuales dicen que se burla de los "horrores" de la industria láctea.
"Muy mala decisión usar vacas para anunciar este producto.
Al igual que nosotras, necesitan quedar embarazadas y dar a luz para producir leche, pero sus crías les son arrebatadas pocos días después del parto", escribió una de ellas.
La bomba de extracción de leche Elvie se adapta discretamente dentro de un sujetador de lactancia (Elvie/Mother)
Otro comentó: “Es comprensible que sea traumático tanto para la madre como para el bebé.
Pero, ¿por qué no usarlas para promocionar una bomba de leche para las madres que pueden quedarse con sus bebés?
Alguien más agregó: “Qué anuncio tan desconectado de la realidad”.
Otros defendieron el anuncio, y una mujer admitió que le parecía la canción "hilarante".
"Creo que esta es una idea genial.
Habría tenido uno si todavía estuviera amamantando.
Bombearme me hacía sentir exactamente como una vaca.
El anuncio es un poco loco, pero lo tomé por lo que era.
"Este es un producto genial", escribió uno.
Otro comentó: "Este es un anuncio divertido dirigido a las madres que se extraen leche (a menudo en sus lugares de trabajo o en baños) y se sienten como 'vacas'".
No se trata de un anuncio que alabe o juzgue a la industria láctea".
Al final del video, el grupo de mujeres revela que todas han estado bailando con los discretos tacones escondidos en sus sostenes.
El concepto detrás de la campaña se basa en la idea de que muchas mujeres que se extraen leche materna dicen sentirse como vacas.
Sin embargo, la Elvie Pump es completamente silenciosa, no tiene cables ni tubos y se adapta discretamente dentro de un sujetador de lactancia, lo que permite a las mujeres moverse, sostener a sus bebés e incluso salir mientras se extrae la leche.
Ana Balarin, socia y directora creativa de Mother, comentó: “El Elvie Pump es un producto tan revolucionario que merecía un lanzamiento audaz y provocador.
Al establecer un paralelismo entre las mujeres que se exprimen y las vacas lecheras, queríamos poner de relieve la extracción de leche materna y todos sus desafíos, al tiempo que demostrábamos de manera entretenida y cercana la increíble sensación de libertad que aportará la nueva bomba.
Esta no es la primera vez que la bomba Elvie ha sido noticia.
Durante la Semana de la Moda de Londres, una madre de dos hijos desfiló por la pasarela para la diseñadora Marta Jakubowski mientras usaba el producto.
Cientos de niños migrantes fueron trasladados discretamente a un campamento de tiendas en la frontera de Texas
El número de niños migrantes detenidos ha aumentado significativamente, a pesar de que los cruces mensuales en la frontera se han mantenido relativamente estables, en parte porque la retórica y las políticas duras introducidas por la administración Trump han dificultado la colocación de los niños con patrocinadores.
Tradicionalmente, la mayoría de los patrocinadores han sido inmigrantes indocumentados y han temido poner en peligro su propia capacidad de permanecer en el país al presentarse para reclamar a un niño.
El riesgo aumentó en junio, cuando las autoridades federales anunciaron que los posibles patrocinadores y otros miembros adultos de sus hogares tendrían que presentar sus huellas dactilares y que los datos se compartirían con las autoridades de inmigración.
La semana pasada, Matthew Albence, un alto funcionario de Inmigración y Aduanas, testificó ante el Congreso que la agencia había arrestado a docenas de personas que solicitaron patrocinar a menores no acompañados.
La agencia confirmó más tarde que el 70 por ciento de los arrestados no tenían antecedentes penales previos.
“Cerca del 80 % de las personas que son patrocinadores o miembros del hogar de los patrocinadores se encuentran en el país de manera ilegal, y una gran parte de ellos son extranjeros criminales.
Por lo tanto, seguimos persiguiendo a esas personas", dijo Albence.
Con el objetivo de procesar a los niños más rápidamente, las autoridades implementaron nuevas reglas que exigirán que algunos de ellos comparezcan ante un tribunal dentro de un mes de ser detenidos, en lugar de después de 60 días, que era el plazo anterior, según los trabajadores de los albergues.
Muchos comparecerán por videoconferencia, en lugar de en persona, para presentar su caso ante un juez de inmigración y solicitar su estatus legal.
Aquellos que se consideren no elegibles para el alivio serán deportados rápidamente.
Cuanto más tiempo permanecen los niños bajo custodia, más probable es que desarrollen ansiedad o depresión, lo que puede provocar arrebatos violentos o intentos de fuga, según los trabajadores de los albergues y los informes que han surgido del sistema en los últimos meses.
Los defensores dijeron que esas preocupaciones se intensifican en una instalación más grande como Tornillo, donde es más probable que se pasen por alto los signos de que un niño está teniendo dificultades, debido a su tamaño.
Añadieron que trasladar a los niños a la ciudad de tiendas sin darles tiempo suficiente para prepararse emocionalmente o para despedirse de sus amigos podría agravar el trauma con el que muchos ya están luchando.
Siria pide a las "fuerzas de ocupación" estadounidenses, francesas y turcas que se retiren de inmediato
En su discurso ante la Asamblea General de la ONU, el ministro de Asuntos Exteriores, Walid al-Moualem, también instó a los refugiados sirios a que regresen a su país, a pesar de que la guerra en Siria ya lleva ocho años.
Moualem, que también es viceprimer ministro, dijo que las fuerzas extranjeras estaban en territorio sirio de manera ilegal, bajo el pretexto de combatir el terrorismo, y que "serán tratadas en consecuencia".
"Deben retirarse de inmediato y sin condiciones", dijo a la asamblea.
Moualem insistió en que la "guerra contra el terrorismo está a punto de terminar" en Siria, donde han muerto más de 360 000 personas desde 2011 y millones más han sido desplazadas de sus hogares.
Dijo que Damasco seguiría "luchando en esta batalla sagrada hasta que purguemos todos los territorios sirios" de ambos grupos terroristas y "cualquier presencia extranjera ilegal".
Estados Unidos tiene alrededor de 2000 soldados en Siria, que principalmente entrenan y asesoran a las fuerzas kurdas y a los árabes sirios que se oponen al presidente Bashar al-Assad.
Francia tiene más de 1000 soldados en el terreno en el país devastado por la guerra.
En cuanto a la cuestión de los refugiados, Moualem dijo que las condiciones eran adecuadas para su regreso y culpó a "algunos países occidentales" de "difundir temores irracionales" que llevaron a los refugiados a mantenerse alejados.
"Hemos pedido a la comunidad internacional y a las organizaciones humanitarias que faciliten estos retornos", dijo.
"Están politizando lo que debería ser un asunto puramente humanitario".
Estados Unidos y la Unión Europea han advertido que no habrá ayuda para la reconstrucción de Siria hasta que haya un acuerdo político entre Assad y la oposición para poner fin a la guerra.
Los diplomáticos de la ONU afirman que un acuerdo reciente entre Rusia y Turquía para establecer una zona de amortiguamiento en el último bastión rebelde importante de Idlib ha creado una oportunidad para avanzar en las conversaciones políticas.
El acuerdo ruso-turco evitó un asalto a gran escala por parte de las fuerzas sirias respaldadas por Rusia en la provincia, donde viven tres millones de personas.
Sin embargo, Moualem subrayó que el acuerdo tenía "plazos claros" y expresó su esperanza de que la acción militar se dirija contra los yihadistas, incluidos los combatientes del Frente Nusra, vinculado a Al-Qaeda, que "serán erradicados".
El enviado de la ONU, Staffan de Mistura, espera convocar pronto las primeras reuniones de un nuevo comité compuesto por miembros del gobierno y de la oposición para redactar una constitución para Siria tras la guerra y allanar el camino hacia las elecciones.
Moualem estableció las condiciones para la participación del gobierno sirio en el comité, afirmando que el trabajo del panel debería limitarse "a revisar los artículos de la constitución actual" y advirtió contra cualquier interferencia.
Por qué Trump ganará un segundo mandato
Según esa lógica, Trump ganaría la reelección en 2020, a menos que, como probablemente esperan muchos espectadores liberales, el juicio político y el escándalo pongan fin a su presidencia de manera prematura.
¡Lo que sin duda sería "el final más dramático de una presidencia de todos los tiempos"!
Por ahora, no hay señales de fatiga en los espectadores.
Desde 2014, las audiencias en horario estelar se han más que duplicado, llegando a 1,05 millones en CNN y casi se han triplicado, alcanzando los 1,6 millones en MSNBC.
Según Nielsen, Fox News tiene un promedio de 2,4 millones de espectadores en horario estelar, frente a los 1,7 millones de hace cuatro años, y el programa "The Rachel Maddow Show" de MSNBC ha encabezado las audiencias de cable con hasta 3,5 millones de espectadores en las noches de noticias importantes.
“Es un fuego que atrae a la gente porque no es algo que comprendamos”, dijo Neal Baer, productor ejecutivo del drama de ABC “Designated Survivor”, sobre un secretario de gabinete que se convierte en presidente después de que un ataque destruye el Capitolio.
Nell Scovell, una veterana escritora de comedia y autora de "Just the Funny Parts: And a Few Hard Truths About Sneaking Into the Hollywood Boys' Club", tiene otra teoría.
Recuerda un viaje en taxi en Boston antes de las elecciones de 2016.
El conductor le dijo que votaría por el Sr. Trump.
¿Por qué? preguntó.
“Dijo: ‘Porque me hace reír’”, me contó la Sra. Scovell.
El caos tiene un valor de entretenimiento.
Por supuesto, a diferencia de cualquier otra cosa en la televisión, las historias que salen de Washington podrían determinar el futuro de Roe v. Wade, si las familias inmigrantes pueden reunirse y la salud de la economía global.
Desconectar es un lujo que solo los espectadores más privilegiados pueden permitirse.
Y, sin embargo, esto va más allá de ser un ciudadano informado cuando te encuentras en la sexta hora viendo a un panel de expertos debatir sobre el uso de fuentes de "fondo profundo" de Bob Woodward para su libro "Miedo", la chaqueta de piloto de piel de avestruz de 15,000 dólares de Paul Manafort ("una prenda llena de arrogancia", dijo The Washington Post) y las implicaciones de las descripciones escabrosas de Stormy Daniels sobre la, um, anatomía del Sr. Trump.
Por mi parte, nunca volveré a ver a Super Mario de la misma manera.
"Parte de lo que hace que parezca un reality show es que te da algo cada noche", dijo Brent Montgomery, director ejecutivo de Wheelhouse Entertainment y creador de "Pawn Stars", sobre el elenco rotativo del programa de Trump y los giros diarios de la trama (iniciando una pelea con la NFL, elogiando a Kim Jong-un).
No puedes permitirte perderte un solo episodio, o te quedarás atrás.
Cuando hablé con el señor Fleiss esta semana, afuera de su casa en la costa norte de Kauai hacía un soleado día de 80 grados, pero él estaba encerrado viendo MSNBC mientras grababa CNN.
No podía apartarse, no con Brett Kavanaugh a punto de enfrentarse al Comité Judicial del Senado y el futuro de la Corte Suprema en juego.
“Recuerdo cuando hacíamos todos esos locos espectáculos en aquel entonces y la gente decía: ‘Este es el comienzo del fin de la civilización occidental’”, me dijo el Sr. Fleiss.
"Pensé que era una especie de broma, pero resulta que tenían razón".
Amy Chozick, escritora independiente del Times que cubre temas de negocios, política y medios de comunicación, es la autora de las memorias "Chasing Hillary".
El dinero externo inunda las carreras más reñidas de la Cámara de Representantes en las elecciones de mitad de mandato
No es sorprendente que el 17.º distrito de Pensilvania esté recibiendo una avalancha de dinero, gracias a un realineamiento de los distritos congresionales que ha llevado a dos titulares a competir por el mismo escaño.
Este distrito suburbano de Pittsburg, recientemente rediseñado, enfrenta al representante demócrata Conor Lamb, quien ganó su escaño en otro distrito en una elección especial la primavera pasada.
Lamb se enfrenta a otro titular, el republicano Keith Rothfus, quien actualmente representa al antiguo 12.º distrito de Pensilvania, que se superpone en gran medida con el nuevo 17.º.
Los mapas se redibujaron después de que la Corte Suprema de Pensilvania dictaminara en enero que los antiguos distritos habían sido manipulados de manera inconstitucional a favor de los republicanos.
La carrera en el nuevo distrito 17 ha desencadenado una feroz batalla financiera entre los brazos financieros de los principales partidos, el Comité de Campaña del Congreso Demócrata (DCCC) y el Comité Nacional de Campaña Republicana (NRCC).
El nombre de Lamb se hizo familiar en Pensilvania después de una ajustada victoria en las elecciones especiales de marzo, muy seguidas, para el 18.º distrito congresional de Pensilvania.
Ese escaño había estado en manos de un republicano durante más de una década, y el presidente Donald Trump ganó en el distrito por 20 puntos.
Los expertos políticos han otorgado una ligera ventaja a los demócratas.
EE. UU. consideró penalizar a El Salvador por su apoyo a China, pero luego dio marcha atrás
Los diplomáticos señalaron que la República Dominicana y Panamá ya habían reconocido a Beijing, con poca oposición por parte de Washington.
En junio de 2017, Trump mantuvo una cálida reunión con el presidente de Panamá, Juan Carlos Varela, y tuvo un hotel en Panamá hasta que los socios desalojaron al equipo de gestión de la Organización Trump.
Los funcionarios del Departamento de Estado decidieron convocar a los jefes de las misiones diplomáticas estadounidenses en El Salvador, la República Dominicana y Panamá debido a las "recientes decisiones de dejar de reconocer a Taiwán", dijo Heather Nauert, portavoz del departamento, en un comunicado a principios de este mes.
Sin embargo, solo se consideraron sanciones contra El Salvador, que recibió aproximadamente 140 millones de dólares en ayuda estadounidense en 2017, incluyendo para controles de narcóticos, desarrollo y apoyo económico.
Las sanciones propuestas, que incluían recortes de ayuda financiera y restricciones de visado específicas, habrían sido dolorosas para el país centroamericano, que ya sufre altas tasas de desempleo y homicidios.
A medida que avanzaban las reuniones internas, los funcionarios de Norteamérica y Centroamérica pospusieron una conferencia de alto nivel centrada en la seguridad y la prosperidad económica, que pretendía ser el seguimiento de una reunión similar del año pasado, considerada un avance en los esfuerzos para evitar que los migrantes se dirigieran a Estados Unidos.
Pero a mediados de septiembre, los altos funcionarios de la administración dejaron claro que querían que la conferencia se llevara a cabo, lo que puso fin efectivamente a cualquier consideración de sanciones para El Salvador.
El vicepresidente Mike Pence está programado para dirigirse a la conferencia, ahora prevista para mediados de octubre, como señal de la importancia que la administración otorga a la reunión, dijeron los diplomáticos.
Y los tres enviados estadounidenses regresaron discretamente a El Salvador, Panamá y la República Dominicana sin nuevos mensajes duros ni castigos de Washington.
Un portavoz de la Casa Blanca para el Sr. Bolton se negó a comentar sobre los detalles del debate que fueron descritos por los tres funcionarios estadounidenses, incluidos dos diplomáticos, que accedieron a discutir las deliberaciones internas bajo la condición de anonimato.
Sus declaraciones fueron corroboradas por un analista externo cercano a la administración, quien también habló bajo condición de anonimato.
Estudia Historia
El siguiente paso podría ser el informe del fiscal especial Robert Mueller sobre la posible obstrucción de la justicia por parte del Sr. Trump, de la cual ahora hay pruebas muy sustanciales en el registro público.
Se informa que el Sr. Mueller también está dirigiendo su investigación para determinar si la campaña del Sr. Trump conspiró con Rusia en su ataque a nuestras elecciones.
Si el Congreso cambia de manos, el Sr. Trump se encontrará con que debe rendir cuentas ante ese organismo, justo cuando se prepara para volver a presentarse ante los votantes y, quizás, eventualmente, ante un jurado de sus pares.
Son muchas condiciones, y no quiero sugerir que la caída del señor Trump sea inevitable, ni la de sus equivalentes en Europa.
Todos nosotros, en ambos lados del Atlántico, debemos tomar decisiones que afectarán la duración de la lucha.
En 1938, los oficiales alemanes estaban dispuestos a organizar un golpe de Estado contra Hitler, si Occidente se hubiera opuesto a él y hubiera apoyado a los checoslovacos en Múnich.
Fallamos y perdimos la oportunidad de evitar los años de carnicería que se sucedieron.
El curso de la historia gira en torno a estos puntos de inflexión, y la marcha inexorable de la democracia se acelera o se retrasa.
Los estadounidenses se enfrentan a varios de estos puntos de inflexión en la actualidad.
¿Qué haremos si el señor Trump despide al vicefiscal general Rod Rosenstein, el hombre que controla el destino de la investigación del señor Mueller?
Rosenstein ha estado en el ojo del huracán desde que este periódico informó que, el año pasado, sugirió grabar en secreto al presidente y especuló sobre su incapacidad para el cargo.
El señor Rosenstein dice que el relato del Times es inexacto.
“¿Cómo responderemos si la recién solicitada investigación del FBI sobre Brett Kavanaugh no es completa o justa, o si es confirmado en la Corte Suprema a pesar de las acusaciones creíbles de agresión sexual y testimonio deshonesto?
Y, sobre todo, ¿votaremos en las elecciones de mitad de mandato por un Congreso que haga rendir cuentas al señor Trump?
Si no superamos esas pruebas, la democracia enfrentará un largo invierno.
Pero creo que no fallaremos, debido a la lección que aprendí en Praga.
Mi madre era una judía checoslovaca que fue deportada a Auschwitz por el mismo régimen nazi que alguna vez ocupó mi residencia de embajador.
Ella sobrevivió, emigró a Estados Unidos y, 60 años después, me envió a encender las velas del Sábado en esa mesa con la esvástica.
Con ese legado, ¿cómo podría no ser optimista sobre nuestro futuro?
Norman Eisen, investigador principal en la Brookings Institution, es presidente de Citizens for Responsibility and Ethics in Washington y autor de "The Last Palace: Europe's Turbulent Century in Five Lives and One Legendary House".
Graham Dorrans de los Rangers se muestra optimista de cara al enfrentamiento contra el Rapid Vienna
Los Rangers reciben al Rapid Vienna el jueves, sabiendo que la victoria sobre los austriacos, tras el impresionante empate en España contra el Villarreal a principios de este mes, los colocará en una posición fuerte para clasificarse del Grupo G de la Liga Europa.
Una lesión en la rodilla impidió que el mediocampista Graham Dorrans hiciera su primera aparición de la temporada hasta el empate 2-2 con el Villarreal, pero él cree que los Rangers pueden usar ese resultado como trampolín para lograr cosas más grandes.
"Fue un buen punto para nosotros porque el Villarreal es un buen equipo", dijo el jugador de 31 años.
"Entramos al partido creyendo que podríamos obtener algo y nos fuimos con un punto.
Tal vez podríamos haberlo ganado al final, pero, en general, un empate probablemente fue un resultado justo.
Probablemente fueron mejores en la primera mitad, pero en la segunda mitad salimos con más fuerza y fuimos el mejor equipo.
Para el jueves, será otra gran noche europea.
Esperemos que podamos conseguir tres puntos, pero será un partido difícil porque obtuvieron un buen resultado en su último partido. Sin embargo, con el apoyo de la afición, estoy seguro de que podemos esforzarnos y lograr un resultado positivo.
El año pasado fue definitivamente difícil, entre todo lo que pasó con mis lesiones y los cambios en el propio club, pero ahora hay un factor de bienestar en el lugar.
El equipo está bien y los chicos lo están disfrutando mucho; el entrenamiento es bueno.
Esperemos que podamos seguir adelante, dejar atrás la última temporada y tener éxito".
Las mujeres están perdiendo el sueño por este temor a los ahorros para la jubilación
A pesar de que los participantes en la encuesta tenían una idea clara de cómo querían ser atendidos, pocas personas hablaban con sus familiares al respecto.
Aproximadamente la mitad de las personas en el estudio a nivel nacional dijeron que hablaban con sus cónyuges sobre el costo de la atención a largo plazo.
Solo el 10 por ciento dijo que habló con sus hijos al respecto.
“La gente quiere que un miembro de la familia se ocupe de ellos, pero no están dando los pasos necesarios para tener esa conversación”, dijo Holly Snyder, vicepresidenta del negocio de seguros de vida de Nationwide.
Aquí es donde debes comenzar.
Hable con su cónyuge y sus hijos: No puede preparar a su familia para brindar cuidados si no comunica sus deseos con suficiente antelación.
Trabaje con su asesor y su familia para discutir dónde y cómo recibir atención, ya que esas decisiones pueden ser un factor importante para determinar el costo.
Consulte a su asesor financiero: Su asesor también puede ayudarle a encontrar una forma de pagar esos gastos.
Sus opciones de financiamiento para la atención a largo plazo pueden incluir una póliza de seguro tradicional de atención a largo plazo, una póliza de seguro de vida híbrida con valor en efectivo para ayudar a cubrir estos gastos o autoasegurarse con su propia riqueza, siempre y cuando tenga el dinero.
Redacte sus documentos legales: Evite las batallas legales.
Obtenga un poder notarial de atención médica para designar a una persona de confianza que supervise su atención médica y se asegure de que los profesionales cumplan con sus deseos en caso de que no pueda comunicarse.
Además, considere otorgar una poder notarial para sus finanzas.
Usted elegiría a una persona de confianza para que tome decisiones financieras en su nombre y se asegure de que sus facturas se paguen si usted está incapacitado.
No olvide los detalles pequeños: Imagine que su padre mayor tiene una emergencia médica y está en camino al hospital.
¿Podría responder preguntas sobre medicamentos y alergias?
Especifique esos detalles en un plan escrito para que esté preparado.
"No solo están en juego las finanzas, sino también quiénes son los médicos", preguntó Martin.
¿Cuáles son los medicamentos?
¿Quién cuidará del perro?
Tener ese plan en marcha".
Hombre disparado varias veces con una carabina en Ilfracombe
Un hombre recibió múltiples disparos con una carabina mientras caminaba a su casa después de salir de noche.
La víctima, de unos 40 años, se encontraba en la zona de Oxford Grove en Ilfracombe, Devon, cuando recibió disparos en el pecho, el abdomen y la mano.
Los agentes describieron el tiroteo, que tuvo lugar alrededor de las 02:30 BST, como un "acto aleatorio".
La víctima no vio a su atacante.
Sus lesiones no ponen en peligro su vida y la policía ha solicitado a los testigos que se presenten.
Terremotos y tsunamis en Indonesia
Al menos 384 personas murieron a causa de un fuerte terremoto y un tsunami que azotaron la ciudad indonesia de Palu el viernes, dijeron las autoridades, y se espera que el número de muertos aumente.
Debido a la interrupción de las comunicaciones, los funcionarios de socorro no han podido obtener ninguna información de la regencia de Donggala, una zona al norte de Palu que está más cerca del epicentro del terremoto de magnitud 7,5.
En Palu, más de 16 000 personas fueron evacuadas después de que ocurriera el desastre.
A continuación, se presentan algunos datos clave sobre Palu y Donggala, en la isla de Sulawesi:
Palu es la capital de la provincia de Sulawesi Central, ubicada al final de una bahía estrecha en la costa oeste de la isla de Sulawesi, con una población estimada de 379 800 habitantes en 2017.
La ciudad estaba celebrando su 40.º aniversario cuando ocurrió el terremoto y el tsunami.
Donggala es una regencia que se extiende a lo largo de más de 300 km (180 millas) de costa en el noroeste de la isla de Sulawesi.
La regencia, una región administrativa de menor jerarquía que una provincia, tenía una población estimada de 299 200 habitantes en 2017.
La pesca y la agricultura son los pilares de la economía de la provincia de Sulawesi Central, especialmente en la región costera de Donggala.
La minería de níquel también es importante en la provincia, pero está mayormente concentrada en Morowali, en la costa opuesta de Sulawesi.
Según la Agencia de Mitigación de Desastres de Indonesia, Palu y Donggala han sido afectadas por tsunamis en varias ocasiones en los últimos 100 años.
En 1938, un tsunami mató a más de 200 personas y destruyó cientos de casas en Donggala.
Un tsunami también golpeó el oeste de Donggala en 1996, matando a nueve personas.
Indonesia se encuentra en el Anillo de Fuego del Pacífico, una zona sísmica, y es azotada regularmente por terremotos.
A continuación, se presentan algunos de los principales terremotos y tsunamis de los últimos años:
2004: Un fuerte terremoto en la costa occidental de la provincia de Aceh, en el norte de Sumatra, Indonesia, el 26 de diciembre, desencadenó un tsunami que afectó a 14 países y mató a 226,000 personas a lo largo de la costa del Océano Índico, más de la mitad de ellas en Aceh.
2005: Una serie de fuertes terremotos sacudió la costa occidental de Sumatra a finales de marzo y principios de abril.
Cientos de personas murieron en la isla de Nias, frente a la costa de Sumatra.
2006: Un terremoto de magnitud 6.8 golpeó al sur de Java, la isla más poblada de Indonesia, desencadenando un tsunami que azotó la costa sur, matando a casi 700 personas.
2009: Un terremoto de magnitud 7.6 sacudió la ciudad de Padang, capital de la provincia de Sumatra Occidental.
Más de 1100 personas murieron.
2010: Un terremoto de magnitud 7.5 golpeó una de las islas Mentawai, frente a Sumatra, desencadenando un tsunami de hasta 10 metros que destruyó docenas de aldeas y mató a unas 300 personas.
2016: Un terremoto superficial golpeó la regencia de Pidie Jaya en Aceh, causando destrucción y pánico, ya que la gente recordó la devastación del mortal terremoto y tsunami de 2004.
En esta ocasión no se desencadenó un tsunami, pero más de 100 personas murieron a causa de los edificios derrumbados.
2018: Terremotos importantes golpean la isla turística de Lombok, en Indonesia, matando a más de 500 personas, la mayoría en el lado norte de la isla.
El terremoto destruyó miles de edificios y dejó a miles de turistas temporalmente varados.
El hijo mayor de Sarah Palin es arrestado por cargos de violencia doméstica
Track Palin, el hijo mayor de la ex gobernadora de Alaska y candidata a vicepresidenta Sarah Palin, fue arrestado por cargos de agresión.
Palin, de 29 años y residente en Wasilla, Alaska, fue arrestada bajo sospecha de violencia doméstica, interferencia en un informe de violencia doméstica y resistencia al arresto, según un informe publicado el sábado por la policía estatal de Alaska.
Según el informe policial, cuando una conocida intentó llamar a la policía para denunciar los presuntos delitos, él le quitó el teléfono.
Palin está detenido en el centro de detención preventiva de Mat-Su y se le mantiene bajo fianza no garantizada de 500 USD, informó KTUU.
El sábado compareció ante el tribunal, donde se declaró "no culpable, sin duda" cuando se le preguntó su declaración, informó la cadena.
Palin enfrenta tres delitos menores de Clase A, lo que significa que podría ser encarcelado por hasta un año y multado con 250 000 dólares.
También se le acusó de un delito menor de Clase B, que se castiga con un día de cárcel y una multa de 2000 dólares.
No es la primera vez que se presentan cargos penales contra Palin.
En diciembre de 2017, fue acusado de agredir a su padre, Todd Palin.
Su madre, Sarah Palin, llamó a la policía para denunciar el supuesto ataque.
El caso está actualmente ante el Tribunal de Veteranos de Alaska.
En enero de 2016, se le acusó de agresión doméstica, de interferir en la denuncia de un delito de violencia doméstica y de poseer un arma mientras estaba intoxicado en relación con el incidente.
Su novia había afirmado que él la golpeó en la cara.
Sarah Palin fue criticada por grupos de veteranos en 2016 después de vincular el comportamiento violento de su hijo con el trastorno de estrés postraumático derivado de su servicio en Irak.
Terremoto y tsunami en Indonesia: cientos de muertos
Al menos 384 personas han muerto después de que un terremoto azotara la isla indonesia de Sulawesi el viernes.
El terremoto de magnitud 7,5 desencadenó un tsunami y destruyó miles de hogares.
Las redes eléctricas y de comunicación están caídas, y se espera que el número de muertes aumente en los próximos días.
El terremoto ocurrió justo frente a Sulawesi central, al noreste de Yakarta, la capital de Indonesia.
En las redes sociales circulan videos que muestran el momento del impacto.
Cientos de personas se habían reunido para un festival en la playa en la ciudad de Palu cuando el tsunami golpeó la costa.
Fiscales federales buscan la rara pena de muerte para el sospechoso del ataque terrorista en la ciudad de Nueva York
Los fiscales federales de Nueva York están solicitando la pena de muerte para Sayfullo Saipov, el sospechoso del ataque terrorista en la ciudad de Nueva York que mató a ocho personas, un castigo poco común que no se ha aplicado en el estado por un crimen federal desde 1953.
Saipov, de 30 años, supuestamente utilizó una camioneta alquilada en Home Depot para llevar a cabo un ataque en una ciclovía a lo largo de la West Side Highway en el Bajo Manhattan, atropellando a peatones y ciclistas en su camino en octubre.
Para justificar una sentencia de muerte, los fiscales tendrán que demostrar que Saipov mató "intencionalmente" a las ocho víctimas y causó "intencionalmente" lesiones corporales graves, según la notificación de intención de solicitar la pena de muerte, presentada en el Distrito Sur de Nueva York.
Ambos cargos conllevan una posible pena de muerte, según el documento judicial.
Semanas después del ataque, un gran jurado federal emitió una acusación de 22 cargos contra Saipov, que incluía ocho cargos de asesinato en apoyo al crimen organizado, típicamente utilizados por los fiscales federales en casos de crimen organizado, y un cargo de violencia y destrucción de vehículos motorizados.
El ataque requirió "una planificación y premeditación sustanciales", dijeron los fiscales, describiendo la forma en que Saipov lo llevó a cabo como "atroz, cruel y depravada".
"Sayfullo Habibullaevic Saipov causó lesiones, daños y pérdidas a las familias y amigos de Diego Enrique Angelini, Nicholas Cleves, Ann-Laure Decadt, Darren Drake, Ariel Erlij, Hernan Ferruchi, Hernan Diego Mendoza y Alejandro Damian Pagnucco", se indica en el aviso de intención.
Cinco de las víctimas eran turistas de Argentina.
Ha pasado una década desde la última vez que el Distrito Sur de Nueva York procesó un caso de pena de muerte.
El acusado, Khalid Barnes, fue declarado culpable de asesinar a dos proveedores de drogas, pero finalmente fue condenado a cadena perpetua en septiembre de 2009.
La última vez que se aplicó la pena de muerte en un caso federal en Nueva York fue en 1953, cuando Julius y Ethel Rosenberg, una pareja casada, fueron ejecutados tras ser declarados culpables de conspiración para cometer espionaje a favor de la Unión Soviética durante la Guerra Fría, dos años antes.
Ambos Rosenberg fueron ejecutados en la silla eléctrica el 19 de junio de 1953.
Saipov, oriundo de Uzbekistán, demostró una falta de remordimiento en los días y meses posteriores al ataque, según los documentos judiciales.
Dijo a los investigadores que se sentía bien por lo que había hecho, informó la policía.
Saipov dijo a las autoridades que se sintió inspirado para llevar a cabo el ataque después de ver videos del ISIS en su teléfono, según la acusación.
También solicitó que se colgara la bandera del ISIS en su habitación del hospital, según la policía.
Se ha declarado inocente de los 22 cargos del acta de acusación.
David Patton, uno de los defensores públicos federales que representan a Saipov, dijo que están "obviamente decepcionados" con la decisión de la fiscalía.
“Creemos que la decisión de solicitar la pena de muerte en lugar de aceptar una declaración de culpabilidad de cadena perpetua sin posibilidad de liberación solo prolongará el trauma de estos eventos para todos los involucrados”, dijo Patton.
El equipo de defensa de Saipov había pedido previamente a los fiscales que no solicitaran la pena de muerte.
Un diputado conservador dice que NIGEL FARAGE debería encargarse de las negociaciones del Brexit
Nigel Farage prometió "movilizar el ejército del pueblo" hoy durante una protesta en la conferencia del Partido Conservador.
El exlíder de Ukip dijo que los políticos tenían que "sentir la presión" de los euroescépticos, ya que uno de los propios diputados de Theresa May sugirió que él debería encargarse de las negociaciones con la UE.
El diputado conservador Peter Bone dijo en la marcha de Birmingham que el Reino Unido "ya se habría ido" si Farage fuera el Secretario de Brexit.
Pero el desafío que enfrenta la Sra. May para reconciliar a sus profundamente divididas filas se ha visto subrayado por el hecho de que los conservadores a favor de la permanencia en la UE se unieran a una protesta separada contra el Brexit en la ciudad.
La primera ministra está luchando por mantener su plan de compromiso de Chequers en marcha, a pesar de los ataques de los partidarios del Brexit, los partidarios de la permanencia y la UE.
Los aliados insistieron en que seguirá adelante con el intento de llegar a un acuerdo con Bruselas a pesar de la reacción negativa, y obligará a los euroescépticos y al Partido Laborista a elegir entre su propuesta y el "caos".
El señor Bone dijo en la manifestación de Leave Means Leave en Solihull que quería "tirar por la borda el plan Chequers".
Sugirió que a Farage se le debería haber otorgado el título de par y se le debería haber dado la responsabilidad de las negociaciones con Bruselas.
"Si él hubiera estado al mando, ya nos habríamos ido", dijo.
El diputado de Wellingborough agregó: “Defenderé el Brexit, pero tenemos que desechar Chequers”.
Al expresar su oposición a la UE, dijo: "No luchamos en las guerras mundiales para ser serviles.
Queremos hacer nuestras propias leyes en nuestro propio país».
El señor Bone desestimó las sugerencias de que la opinión pública había cambiado desde el voto de 2016: "La idea de que el pueblo británico ha cambiado de opinión y quiere quedarse es completamente falsa".
La conservadora partidaria del Brexit Andrea Jenkyns también estuvo en la marcha y dijo a los reporteros: "Simplemente estoy diciendo: Primer Ministro, escuche al pueblo".
“Chequers no es popular entre el público en general, la oposición no va a votar a favor, no es popular entre nuestro partido y nuestros activistas, que son los que realmente recorren las calles y nos hacen ganar las elecciones en primer lugar.
Por favor, abandonen Chequers y empiecen a escuchar».
En un mensaje directo a la Sra. May, agregó: "Los primeros ministros conservan sus puestos cuando cumplen sus promesas".
Farage dijo en el mitin que los políticos deben "sentir el calor" si están a punto de traicionar la decisión tomada en el referéndum de 2016.
"Ahora se trata de una cuestión de confianza entre nosotros, el pueblo, y nuestra clase política", dijo.
“Están intentando traicionar el Brexit y hoy estamos aquí para decirles que ‘no les permitiremos salirse con la suya’”.
En un mensaje dirigido a la entusiasta multitud, agregó: "Quiero que hagan que nuestra clase política, que está al borde de traicionar el Brexit, sienta la presión".
“Estamos movilizando al ejército popular de este país que nos dio la victoria en el Brexit y nunca descansaremos hasta que nos hayamos convertido en un Reino Unido independiente, autónomo y orgulloso”.
Mientras tanto, los partidarios de la permanencia en la Unión Europea marcharon por Birmingham antes de celebrar una concentración de dos horas en el centro de la ciudad.
Un grupo de activistas ondeó pancartas de "Tories Against Brexit" tras el lanzamiento del grupo este fin de semana.
El miembro laborista Lord Adonis se burló de los conservadores por los problemas de seguridad que sufrieron con una aplicación del partido al abrirse la conferencia.
“Son las personas que nos dicen que pueden tener los sistemas de TI y toda la tecnología para Canadá Plus Plus, para una frontera sin fricciones, para el libre comercio sin fronteras en Irlanda”, agregó.
“Es una farsa total.
No existe algo como un buen Brexit", agregó.
Warren planea analizar "con detenimiento" la posibilidad de presentarse a la presidencia
La senadora estadounidense Elizabeth Warren dice que evaluará "seriamente la posibilidad de presentarse a la presidencia" después de las elecciones de noviembre.
El Boston Globe informa que la demócrata de Massachusetts habló sobre su futuro durante una asamblea ciudadana en el oeste de Massachusetts el sábado.
Warren, una crítica frecuente del presidente Donald Trump, se presenta a la reelección en noviembre contra el representante estatal del Partido Republicano Geoff Diehl, quien fue copresidente de la campaña de Trump en Massachusetts en 2016.
Ha estado en el centro de las especulaciones sobre si podría enfrentarse a Trump en 2020.
El evento del sábado por la tarde en Holyoke fue su 36.ª reunión con los electores en formato de asamblea ciudadana desde que Trump asumió el cargo.
Una asistente le preguntó si planeaba presentarse como candidata a la presidencia.
Warren respondió que es hora de que "las mujeres vayan a Washington para arreglar nuestro gobierno roto, y eso incluye a una mujer en la cima".
Se realizó un arresto por el asesinato a tiros de Sims, de LSU
La policía de Baton Rouge, Louisiana, anunció el sábado que un sospechoso fue arrestado por el asesinato a tiros del jugador de baloncesto de LSU, Wayde Sims, ocurrido el viernes.
El Departamento de Policía de Baton Rouge anunció el arresto de Dyteon Simpson, de 20 años, en una conferencia de prensa a las 11 a. m. hora del este.
El viernes, habían publicado un video del tiroteo, pidiendo ayuda para identificar a un hombre que aparecía en las imágenes.
Sims, de 20 años, fue asesinado a tiros cerca del campus de la Universidad del Sur el viernes por la mañana.
"Wayde Sims sufrió una herida de bala en la cabeza y finalmente murió como consecuencia", dijo el jefe de policía Murphy J. Paul a los medios el sábado, según 247sports.
Wayde intervino para defender a su amigo y fue disparado por Simpson.
Se interrogó a Simpson, quien admitió haber estado en el lugar de los hechos, en posesión de un arma, y confesó haber disparado contra Wayde Sims.
Simpson fue arrestado sin incidentes y puesto bajo custodia en el Departamento de Policía de la Parroquia de East Baton Rouge.
Sims, un junior de 1,98 metros que creció en Baton Rouge, jugó en 32 partidos y fue titular en 10 la temporada pasada, promediando 17,4 minutos, 5,6 puntos y 2,9 rebotes por partido.
Gran Premio de Rusia: Lewis Hamilton se acerca al título mundial después de que las órdenes del equipo le otorguen la victoria sobre Sebastian Vettel
Desde el momento en que Valtteri Bottas se clasificó por delante de Lewis Hamilton el sábado, quedó claro que las órdenes del equipo de Mercedes tendrían un papel importante en la carrera.
Desde la pole, Bottas tuvo un buen inicio y casi dejó a Hamilton sin opciones al defender su posición en las dos primeras curvas e invitó a Vettel a atacar a su compañero de equipo.
Vettel entró primero a los pits y dejó a Hamilton atrapado en el tráfico en la cola del pelotón, algo que debería haber sido decisivo.
Mercedes entró a boxes una vuelta después y salió detrás de Vettel, pero Hamilton se adelantó después de una acción rueda con rueda que obligó al piloto de Ferrari a dejar libre el interior a regañadientes, bajo el riesgo de mantenerse en pista después de un doble movimiento para defenderse en la tercera curva.
Max Verstappen comenzó desde la última fila de la parrilla y terminó en séptimo lugar al final de la primera vuelta en su 21 cumpleaños.
Luego lideró gran parte de la carrera, manteniendo sus neumáticos para lograr un final rápido y superar a Kimi Raikkonen en el cuarto puesto.
Finalmente, entró a boxes en la 44.ª vuelta, pero no pudo aumentar su ritmo en las ocho vueltas restantes, mientras que Raikkonen se llevaba el cuarto puesto.
Es un día difícil porque Valtteri hizo un trabajo fantástico durante todo el fin de semana y fue un verdadero caballero al dejarme pasar.
"El equipo ha hecho un trabajo excepcional para lograr un doblete", dijo Hamilton.
Ese fue un lenguaje corporal realmente malo
El presidente Donald Trump se burló de la senadora Dianne Feinstein en un mitin el sábado por su insistencia en que no filtró la carta de Christine Blasey Ford en la que acusaba al candidato a la Corte Suprema Brett Kavanaugh de agresión sexual.
En un mitin en West Virginia, el presidente no abordó directamente el testimonio de Ford ante el Comité Judicial del Senado, sino que comentó que lo que estaba ocurriendo en el Senado demostraba que la gente era "mala, desagradable y falsa".
“Lo que podría suceder y lo hermoso que está ocurriendo en los últimos días en el Senado, cuando ves la ira, cuando ves a personas que están enojadas, malintencionadas, desagradables y falsas”, dijo.
“Cuando ves publicaciones y filtraciones y luego dicen: ‘oh, yo no lo hice’.
Yo no lo hice".
¿Recuerdas?
Dianne Feinstein, ¿usted filtró?
Recuerden su respuesta... ¿usted filtró el documento? - "oh, oh, ¿qué?
Oh, no.
Yo no filtré nada".
Bueno, esperen un minuto.
¿Hicimos una filtración? No, no hicimos una filtración", agregó, imitando al senador.
Feinstein recibió la carta que detallaba las acusaciones contra Kavanaugh por parte de Ford en julio, y se filtró a principios de septiembre, pero Feinstein negó que la filtración proviniera de su oficina.
"No oculté las acusaciones de la Dra. Ford, no filtré su historia", dijo Feinstein al comité, según informó The Hill.
"Ella me pidió que lo mantuviera en secreto y yo lo mantuve en secreto como ella me pidió".
Pero su negativa no pareció ser bien recibida por el presidente, quien comentó durante la concentración del sábado por la noche: "Les diré una cosa, ese fue un lenguaje corporal realmente malo".
Tal vez no lo hizo, pero ese es el peor lenguaje corporal que he visto jamás".
Continuando con su defensa del candidato a la Corte Suprema, quien ha sido acusado de conducta sexual inapropiada por tres mujeres, el presidente sugirió que los demócratas estaban utilizando las acusaciones para sus propios fines.
"Están decididos a recuperar el poder por cualquier medio necesario.
Ves la mezquindad, la maldad, no les importa a quién lastiman, a quién tienen que atropellar para obtener poder y control", dijo el presidente, según informó Mediaite.
Liga Elite: Dundee Stars 5-3 Belfast Giants
Patrick Dwyer marcó dos goles para los Giants contra Dundee
Los Dundee Stars se redimieron de la derrota de la Liga Élite del viernes contra los Belfast Giants al ganar el partido de vuelta 5-3 en Dundee el sábado.
Los Giants obtuvieron una ventaja temprana de dos goles gracias a los goles de Patrick Dwyer y Francis Beauvillier.
Mike Sullivan y Jordan Cownie igualaron el marcador para el equipo local antes de que Dwyer restaurara la ventaja de los Giants.
Francois Bouchard igualó el marcador para Dundee antes de que dos goles de Lukas Lundvald Nielsen aseguraran su victoria.
Fue la tercera derrota de la temporada en la Liga Élite para el equipo de Adam Keefe, que había remontado para vencer a Dundee 2-1 en Belfast el viernes por la noche.
Fue la cuarta reunión de la temporada entre ambos equipos, y los Giants ganaron los tres partidos anteriores.
El gol inicial de Dwyer llegó en el cuarto minuto, a las 3:35, gracias a un pase de Kendall McFaull, y David Rutherford asistió a Beauvillier, que duplicó la ventaja cuatro minutos después.
En un período inicial muy activo, Sullivan devolvió a los locales al juego a los 13:10, antes de que Matt Marquardt asistiera a Cownie en el empate a los 15:16.
Dwyer se aseguró de que los Giants tomaran la delantera en el primer descanso cuando anotó su segundo gol de la noche al final del primer período.
El equipo local se reagrupó y Bouchard volvió a igualar el marcador con un gol en superioridad numérica a los 27:37.
Cownie y Charles Corcoran colaboraron para ayudar a Nielsen a darle a Dundee la ventaja por primera vez en el partido, a finales del segundo período, y aseguró la victoria con el quinto gol de su equipo a mitad del último período.
Los Giants, que han perdido cuatro de sus últimos cinco partidos, recibirán al Milton Keynes en su próximo partido el viernes.
Un controlador de tráfico aéreo muere para asegurar que cientos de personas en un avión puedan escapar de un terremoto
Un controlador de tráfico aéreo en Indonesia es aclamado como héroe después de morir asegurándose de que un avión con cientos de personas a bordo despegara con seguridad.
Más de 800 personas han muerto y muchas están desaparecidas después de que un fuerte terremoto azotara la isla de Sulawesi el viernes, desencadenando un tsunami.
Fuertes réplicas continúan azotando la zona y muchas personas están atrapadas entre los escombros en la ciudad de Palu.
Pero, a pesar de que sus colegas huían para salvar sus vidas, Anthonius Gunawan Agung, de 21 años, se negó a abandonar su puesto en la torre de control que se balanceaba violentamente en el aeropuerto Mutiara Sis Al Jufri de Palu.
Se quedó en su lugar para asegurarse de que el vuelo 6321 de Batik Air, que estaba en la pista en ese momento, pudiera despegar con seguridad.
Luego saltó de la torre de control de tráfico cuando pensó que se estaba derrumbando.
Murió más tarde en el hospital.
El portavoz de Air Navigation Indonesia, Yohannes Sirait, dijo que la decisión pudo haber salvado cientos de vidas, informó ABC News de Australia.
Preparamos un helicóptero desde Balikpapan en Kalimantan para llevarlo a un hospital más grande en otra ciudad.
Desafortunadamente, lo perdimos esta mañana antes de que el helicóptero llegara a Palu.
"Nos rompe el corazón escuchar esto", agregó.
Mientras tanto, las autoridades temen que el número de muertos podría llegar a miles, ya que la agencia nacional de mitigación de desastres informó que el acceso a las ciudades de Donggala, Sigi y Boutong está limitado.
"Se cree que el número de víctimas sigue aumentando, ya que muchos cuerpos aún están bajo los escombros y muchos no han podido ser rescatados", dijo el portavoz de la agencia, Sutopo Purwo Nugroho.
Las olas, que alcanzaron los seis metros, devastaron Palu, donde se realizará un entierro masivo el domingo.
Aviones militares y comerciales están transportando ayuda y suministros.
Risa Kusuma, una madre de 35 años, dijo a Sky News: "Cada minuto, una ambulancia trae cuerpos".
El agua limpia es escasa.
Los minimercados son saqueados por todas partes".
Jan Gelfand, jefe de la Cruz Roja Internacional en Indonesia, dijo a CNN: "La Cruz Roja de Indonesia está haciendo todo lo posible para ayudar a los sobrevivientes, pero no sabemos qué encontrarán allí".
Esto ya es una tragedia, pero podría empeorar mucho más".
El presidente de Indonesia, Joko Widodo, llegó a Palu el domingo y dijo a los militares del país: "Les pido a todos que trabajen día y noche para completar todas las tareas relacionadas con la evacuación".
¿Están listos?", informó CNN.
A principios de este año, Indonesia fue golpeada por terremotos en Lombok, en los que murieron más de 550 personas.
Accidente aéreo en Micronesia: Air Niugini informa ahora que hay un hombre desaparecido tras el accidente del avión en la laguna
La aerolínea que operaba un vuelo que se estrelló en una laguna del Pacífico en Micronesia ahora dice que falta un hombre, después de haber dicho anteriormente que los 47 pasajeros y la tripulación habían evacuado con seguridad el avión que se hundía.
Air Niugini dijo en un comunicado que, a partir del sábado por la tarde, no podía dar cuenta de un pasajero masculino.
La aerolínea dijo que estaba trabajando con las autoridades locales, hospitales e investigadores para tratar de encontrar al hombre.
La aerolínea no respondió de inmediato a las solicitudes de más detalles sobre el pasajero, como su edad o nacionalidad.
Las embarcaciones locales ayudaron a rescatar a los demás pasajeros y a la tripulación después de que el avión cayera al agua mientras intentaba aterrizar en el aeropuerto de la isla de Chuuk.
Las autoridades informaron el viernes que siete personas habían sido trasladadas a un hospital.
La aerolínea informó que seis pasajeros permanecían en el hospital el sábado y que todos se encontraban en estado estable.
Lo que causó el accidente y la secuencia exacta de los hechos aún no está clara.
Tanto la aerolínea como la Armada de los Estados Unidos dijeron que el avión aterrizó en la laguna, sin alcanzar la pista.
Algunos testigos pensaron que el avión se salió de la pista.
El pasajero estadounidense Bill Jaynes dijo que el avión llegó muy bajo.
"Eso es algo extremadamente bueno", dijo Jaynes.
Jaynes dijo que él y otras personas lograron vadear el agua hasta la cintura para llegar a las salidas de emergencia en el avión que se hundía.
Dijo que los asistentes de vuelo estaban en pánico y gritando, y que él sufrió una lesión leve en la cabeza.
La Armada de los Estados Unidos informó que los marineros que trabajaban cerca en la mejora de un muelle también ayudaron en el rescate utilizando un bote inflable para trasladar a las personas a tierra antes de que el avión se hundiera a unos 30 metros (100 pies) de profundidad.
Los datos de la Red de Seguridad de la Aviación indican que 111 personas han muerto en accidentes de aviones registrados en PNG en las últimas dos décadas, pero ninguno de ellos involucró a Air Niugini.
Analista presenta cronología de la noche en que una mujer fue quemada viva
La fiscalía presentó sus conclusiones el sábado en el nuevo juicio de un hombre acusado de quemar viva a una mujer de Mississippi en 2014.
El analista del Departamento de Justicia de EE. UU., Paul Rowlett, testificó durante horas como testigo experto en el campo del análisis de inteligencia.
Explicó al jurado cómo utilizó los registros de teléfonos celulares para reconstruir los movimientos del acusado, Quinton Tellis, de 29 años, y de la víctima, Jessica Chambers, de 19 años, la noche en que ella murió.
Rowlett dijo que recibió datos de ubicación de varios teléfonos celulares que mostraban que Tellis estaba con Chambers la noche de su muerte, contradiciendo sus afirmaciones anteriores, informó The Clarion Ledger.
Cuando los datos mostraron que su teléfono celular estaba con Chambers durante el tiempo en que dijo que estaba con su amigo Michael Sanford, la policía fue a hablar con Sanford.
Sanford declaró el sábado y testificó que no estaba en la ciudad ese día.
Cuando los fiscales preguntaron si Tellis decía la verdad cuando afirmó que estaba en la camioneta de Sanford esa noche, Sanford dijo que estaba "mintiendo, porque mi camioneta estaba en Nashville".
Otra inconsistencia fue que Tellis dijo que había conocido a Chambers aproximadamente dos semanas antes de su muerte.
Los registros telefónicos indicaron que solo se conocían desde hacía una semana.
Rowlett dijo que, en algún momento después de la muerte de Chambers, Tellis eliminó los mensajes de texto, las llamadas y la información de contacto de Chambers de su teléfono.
"La borró de su vida", dijo Hale.
La defensa tiene previsto comenzar sus alegatos finales el domingo.
El juez dijo que esperaba que el juicio fuera a manos del jurado más tarde ese mismo día.
The High Breed: ¿Qué es el hip hop consciente?
Un trío de hip hop quiere desafiar la visión negativa del género llenando su música de mensajes positivos.
The High Breed, de Bristol, afirma que el hip hop se alejó de sus orígenes de mensajes políticos y abordaje de problemas sociales.
Quieren volver a sus raíces y hacer que el hip hop consciente vuelva a ser popular.
Artistas como The Fugees y Common han experimentado un reciente resurgimiento en el Reino Unido gracias a artistas como Akala y Lowkey.
¿Otra persona negra?
Niñera de Nueva York demanda a una pareja por despedirla tras un mensaje de texto "racista"
Una niñera de Nueva York está demandando a una pareja por despido discriminatorio después de recibir un mensaje de texto mal dirigido de la madre quejándose de que ella era "otra persona negra".
La pareja niega ser racista y compara la demanda con "una extorsión".
Lynsey Plasco-Flaxman, madre de dos hijos, expresó su consternación al descubrir que la nueva cuidadora de niños, Giselle Maurice, era negra cuando llegó para su primer día de trabajo en 2016.
"NOOOOOOOOOOO OTRA PERSONA NEGRA", escribió la señora Plasco-Flaxman a su esposo en un mensaje de texto.
Sin embargo, en lugar de enviarla a su esposo, se la envió a la señorita Maurice, dos veces.
Después de darse cuenta de su metedura de pata, una "incómoda" Plasco-Flaxman despidió a la Sra. Maurice, afirmando que su niñera saliente, que era afroamericana, había hecho un mal trabajo y que en su lugar esperaba a una filipina, según el New York Post.
A la señorita Maurice le pagaron por un día de trabajo y luego la enviaron a casa en un Uber.
Ahora, Maurice está demandando a la pareja para obtener una compensación por el despido y busca una indemnización de 350 dólares diarios por el trabajo de seis meses con alojamiento incluido para el que inicialmente había sido contratada, aunque sin contrato.
"Quiero mostrarles que no se hacen cosas así", dijo el viernes al Post, y agregó: "Sé que es discriminación".
La pareja ha respondido a las acusaciones de racismo, afirmando que despedir a Maurice fue lo más razonable, ya que temían no poder confiar en ella después de haberla ofendido.
"Mi esposa le había enviado algo que no quería decir.
Ella no es racista.
"No somos racistas", dijo el esposo Joel Plasco al Post.
"Pero, ¿dejarías a tus hijos en manos de alguien a quien has tratado mal, incluso si fue por error?
¿Su bebé recién nacido?
Vamos".
Al comparar la demanda con "extorsión", Plasco dijo que su esposa estaba a solo dos meses de tener un bebé y se encontraba en una "situación muy difícil".
"¿Vas a ir tras alguien así?
Eso no es algo muy agradable de hacer", agregó el banquero de inversión.
Aunque el caso legal aún está en curso, el tribunal de la opinión pública ha sido rápido para denunciar a la pareja en las redes sociales, criticándolos por su comportamiento y su lógica.
Una nueva carta revela que los editores de Paddington temían que los lectores no se identificaran con un oso que habla
Karen Jankel, la hija de Bond, que nació poco después de que el libro fuera aceptado, dijo sobre la carta: "Es difícil ponerse en el lugar de alguien que lo lee por primera vez antes de que se publicara".
Es muy divertido saber ahora lo que sabemos sobre el enorme éxito de Paddington".
Dijo que su padre, que había trabajado como camarógrafo de la BBC antes de inspirarse para escribir el libro infantil a partir de un pequeño oso de peluche, habría sido optimista ante el rechazo de su trabajo, y agregó que el 60.º aniversario de la publicación del libro fue "agridulce" tras su fallecimiento el año pasado.
Sobre Paddington, a quien describe como un "muy importante miembro de nuestra familia", agregó que su padre estaba silenciosamente orgulloso de su eventual éxito.
“Era un hombre bastante tranquilo y no era una persona presumida”, dijo.
"Pero como Paddington era tan real para él, era casi como si tuvieras un hijo que logra algo: te sientes orgulloso de él, aunque en realidad no sea tu logro.
Creo que él veía el éxito de Paddington de esa manera.
Aunque fue su creación y su imaginación, siempre solía dar el crédito a Paddington mismo".
Mi hija estaba muriendo y tuve que despedirme por teléfono
Al aterrizar, su hija fue trasladada de inmediato al Hospital Louis Pasteur 2 de Niza, donde los médicos intentaron en vano salvarle la vida.
“Nad llamaba regularmente para decir que la situación era realmente mala, que no se esperaba que sobreviviera”, dijo la señora Ednan-Laperouse.
"Después recibí la llamada de Nad para decirme que iba a morir en los próximos dos minutos y que tenía que despedirme de ella.
Y lo hice.
Dije: “Tashi, te quiero mucho, cariño.
Estaré contigo pronto.
Estaré contigo.
Los medicamentos que los médicos le habían dado para mantener su corazón funcionando se estaban agotando lentamente y saliendo de su organismo.
Ella había muerto un tiempo antes y todo se estaba apagando.
Tuve que quedarme allí sentado y esperar, sabiendo que todo esto estaba ocurriendo.
No podía aullar, gritar ni llorar porque estaba en una situación rodeada de familias y personas.
Tenía que mantenerme firme".
Finalmente, la señora Ednan-Laperouse, que en ese momento estaba de luto por la pérdida de su hija, abordó el avión junto con los demás pasajeros, ajenos a la terrible experiencia que estaba viviendo.
“Nadie lo sabía”, dijo.
“Tenía la cabeza gacha y las lágrimas caían todo el tiempo.
Es difícil de explicar, pero fue durante el vuelo cuando sentí una abrumadora sensación de simpatía por Nad.
Que él necesitaba mi amor y comprensión.
Sabía cuánto la amaba".
Mujeres en duelo envían tarjetas para prevenir suicidios en un puente
Dos mujeres que perdieron a seres queridos por suicidio están trabajando para evitar que otras personas se quiten la vida.
Sharon Davis y Kelly Humphreys han estado colocando tarjetas en un puente gales con mensajes inspiradores y números de teléfono a los que la gente puede llamar para recibir apoyo.
El hijo de la Sra. Davis, Tyler, tenía 13 años cuando comenzó a sufrir depresión y se suicidó a los 18.
"No quiero que ningún padre sienta lo que yo tengo que sentir todos los días", dijo.
La Sra. Davis, de 45 años, que vive en Lydney, dijo que su hijo era un chef prometedor con una sonrisa contagiosa.
"Todos lo conocían por su sonrisa.
Siempre decían que su sonrisa iluminaba cualquier habitación".
Sin embargo, dejó de trabajar antes de morir, ya que estaba "en un lugar realmente oscuro".
En 2014, el hermano de Tyler, que tenía 11 años en ese momento, fue quien encontró a su hermano después de que este se quitara la vida.
La Sra. Davis dijo: "Me preocupo constantemente de que pueda haber un efecto dominó".
La Sra. Davis creó las tarjetas "para que la gente sepa que hay personas a las que pueden acudir y con las que pueden hablar, incluso si es un amigo".
No te quedes callado, necesitas hablar".
La señora Humphreys, que ha sido amiga de la señora Davies durante años, perdió a Mark, su compañero de 15 años, poco después de la muerte de su madre.
“Él no dijo que se sentía deprimido o triste o algo así”, dijo.
"Un par de días antes de Navidad notamos un cambio en su actitud.
Estaba en su punto más bajo el día de Navidad; cuando los niños abrieron sus regalos, él no hizo contacto visual con ellos ni nada por el estilo".
Dijo que su muerte fue un gran trauma para ellos, pero que tienen que superarlo: "Destruye a la familia.
Nos desgarra.
Pero todos tenemos que seguir adelante y luchar".
Si tiene dificultades para afrontar la situación, puede llamar a Samaritans gratis al 116 123 (Reino Unido e Irlanda), enviar un correo electrónico a jo@samaritans.org o visitar el sitio web de Samaritans aquí.
El futuro de Brett Kavanaugh está en juego mientras el FBI comienza la investigación
"Pensé que si realmente pudiéramos obtener algo como lo que él pedía, una investigación limitada en tiempo y alcance, podríamos tal vez lograr un poco de unidad", dijo el señor Flake el sábado, añadiendo que temía que el comité se estuviera "desmoronando" en medio de un estancamiento partidista arraigado.
¿Por qué el señor Kavanaugh y sus partidarios republicanos no querían que el FBI investigara?
Su reticencia se debe únicamente al momento.
Las elecciones de mitad de mandato están a solo cinco semanas, el 6 de noviembre; si, como se espera, los republicanos tienen malos resultados, entonces se verán gravemente debilitados en sus intentos de hacer que el hombre que quieren sea elegido para el tribunal más alto del país.
George W. Bush ha estado llamando a los senadores para pedirles que apoyen al señor Kavanaugh, quien trabajó en la Casa Blanca para el señor Bush y, a través de él, conoció a su esposa Ashley, quien fue la secretaria personal del señor Bush.
¿Qué sucede después de que el FBI emita su informe?
Habrá una votación en el Senado, donde actualmente hay 51 republicanos y 49 demócratas.
Todavía no está claro si el Sr. Kavanaugh puede obtener al menos 50 votos en el Senado, lo que permitiría al vicepresidente Mike Pence romper un empate y confirmarlo en la Corte Suprema.
El número de desertores de Corea del Norte "disminuye" bajo el mandato de Kim
El número de desertores norcoreanos a Corea del Sur ha disminuido desde que Kim Jong-un llegó al poder hace siete años, dijo un legislador surcoreano.
Park Byeong-seug, citando datos del Ministerio de Unificación del Sur, dijo que el año pasado hubo 1127 deserciones, en comparación con las 2706 de 2011.
Park dijo que los controles fronterizos más estrictos entre Corea del Norte y China, así como las tarifas más altas cobradas por los traficantes de personas, fueron factores clave.
Pyongyang no ha hecho comentarios públicos.
A la gran mayoría de los desertores del Norte, finalmente se les ofrece la ciudadanía surcoreana.
Seúl afirma que más de 30 000 norcoreanos han cruzado ilegalmente la frontera desde el final de la Guerra de Corea en 1953.
La mayoría huye a través de China, que tiene la frontera más larga con Corea del Norte y es más fácil de cruzar que la fuertemente protegida Zona Desmilitarizada (DMZ) entre las dos Coreas.
China considera a los desertores como inmigrantes ilegales en lugar de refugiados y, a menudo, los repatria por la fuerza.
Las relaciones entre el Norte y el Sur, que técnicamente aún están en guerra, han mejorado notablemente en los últimos meses.
A principios de este mes, los líderes de ambos países se reunieron en Pyongyang para mantener conversaciones centradas en las estancadas negociaciones de desnuclearización.
Esto ocurrió después de la histórica reunión de junio entre el presidente de Estados Unidos, Donald Trump, y Kim Jong-un en Singapur, cuando acordaron en términos generales trabajar para lograr una península de Corea libre de armas nucleares.
Pero el sábado, el ministro de Asuntos Exteriores de Corea del Norte, Ri Yong-ho, culpó a las sanciones estadounidenses por la falta de progreso desde entonces.
"Sin confianza en los Estados Unidos, no habrá confianza en nuestra seguridad nacional y, en tales circunstancias, no hay forma de que nos desarmemos unilateralmente primero", dijo Ri en un discurso ante la Asamblea General de la ONU en Nueva York.
Nancy Pelosi llama a Brett Kavanaugh "histérico" y dice que no está capacitado para servir en el Tribunal Supremo
La líder de la minoría en la Cámara de Representantes, Nancy Pelosi, calificó al candidato al Tribunal Supremo, Brett Kavanaugh, de "histérico" y dijo que no tenía el temperamento adecuado para servir en el Tribunal Supremo.
Pelosi hizo estos comentarios en una entrevista el sábado en el Festival Texas Tribune en Austin, Texas.
"No pude evitar pensar que si una mujer hubiera actuado de esa manera, dirían que es 'histérica'", dijo Pelosi sobre su reacción al testimonio de Kavanaugh ante el Comité Judicial del Senado el jueves.
Kavanaugh negó con emoción las acusaciones de que había agredido sexualmente a la Dra. Christine Blasey Ford cuando ambos eran adolescentes.
Durante su declaración inicial, Kavanaugh se mostró muy emocionado, llegando a gritar y a emocionarse mientras hablaba de su familia y de sus años de instituto.
También condenó explícitamente a los demócratas en el comité, calificando las acusaciones en su contra como un "asesinato de carácter grotesco y coordinado" organizado por liberales enojados porque Hillary Clinton perdió las elecciones presidenciales de 2016.
Pelosi dijo que creía que el testimonio de Kavanaugh demostraba que no podía servir en el Tribunal Supremo, porque mostraba que está sesgado contra los demócratas.
“Creo que él se descalifica a sí mismo con esas declaraciones y la forma en que atacó a los Clinton y a los demócratas”, dijo.
Pelosi se mostró reacia cuando le preguntaron si intentaría destituir a Kavanaugh si es confirmado y si los demócratas obtienen la mayoría en la Cámara de Representantes.
“Diré esto: si no está diciendo la verdad al Congreso o al FBI, entonces no está capacitado no solo para estar en la Corte Suprema, sino para estar en el tribunal en el que está ahora”, dijo Pelosi.
Kavanaugh es actualmente juez en el Tribunal de Apelaciones del Circuito de D.C.
Pelosi agregó que, como demócrata, estaba preocupada por las posibles decisiones de Kavanaugh en contra de la Ley del Cuidado de Salud a Bajo Precio o del caso Roe vs. Wade, ya que se le considera un juez conservador.
En sus audiencias de confirmación, Kavanaugh evitó responder preguntas sobre si anularía ciertas decisiones de la Corte Suprema.
"No es el momento para que una persona histérica y parcial vaya a la corte y espere que digamos: '¡qué maravilla!'", dijo Pelosi.
Y las mujeres necesitan ejercerlo.
Es una diatriba justa, meses y años de furia desbordándose, y no puede expresarla sin llorar.
"Nosotras lloramos cuando nos enojamos", me dijo la Sra. Steinem 45 años después.
"No creo que eso sea inusual, ¿tú qué opinas?"
Ella continuó: “Me ayudó mucho una mujer que era ejecutiva en algún lugar, quien dijo que también lloraba cuando se enojaba, pero desarrolló una técnica que significaba que cuando se enojaba y empezaba a llorar, le decía a la persona con la que estaba hablando: ‘Puede que pienses que estoy triste porque estoy llorando’.
Estoy enojado".
Y luego ella simplemente siguió adelante.
Y pensé que eso era genial".
Las lágrimas están permitidas como una vía de escape para la ira, en parte porque son fundamentalmente malentendidas.
Uno de mis recuerdos más vívidos de un trabajo temprano, en una oficina dominada por hombres, donde una vez me encontré llorando con una ira inefable, fue cuando una mujer mayor, una gerente fría de la que siempre había tenido un poco de miedo, me agarró del cuello y me arrastró a un hueco de escalera.
"Nunca dejes que te vean llorar", me dijo.
"No saben que estás furioso.
Piensan que estás triste y se alegrarán porque te afectaron".
Patricia Schroeder, entonces congresista demócrata de Colorado, había trabajado con Gary Hart en sus campañas presidenciales.
En 1987, cuando el Sr. Hart fue sorprendido en un affaire extramatrimonial a bordo de un barco llamado Monkey Business y se retiró de la carrera, la Sra. Schroeder, profundamente frustrada, pensó que no había razón para que ella no explorara la idea de presentarse a la presidencia.
"No fue una decisión bien pensada", me dijo con una risa 30 años después.
"Ya había otros siete candidatos en la carrera, y lo último que necesitaban era otro más.
Alguien lo llamó "Blancanieves y los siete enanitos".
Como ya era tarde en la campaña, estaba rezagada en la recaudación de fondos, por lo que prometió que no entraría en la carrera a menos que recaudara 2 millones de dólares.
Era una batalla perdida.
Descubrió que algunos de sus partidarios que habían donado 1000 dólares a hombres solo le donaban 250 dólares a ella.
"¿Creen que me dan un descuento?", se preguntó.
Cuando pronunció su discurso anunciando que no lanzaría una campaña formal, se vio tan abrumada por las emociones - gratitud hacia las personas que la habían apoyado, frustración con el sistema que hacía tan difícil recaudar dinero y dirigirse a los votantes en lugar de a los delegados, y enojo por el sexismo - que se le quebró la voz.
"Se podría pensar que había sufrido una crisis nerviosa", recordó la Sra. Schroeder sobre cómo reaccionó la prensa hacia ella.
"Uno pensaría que Kleenex era mi patrocinador corporativo.
Recuerdo que pensé: ¿qué van a poner en mi lápida?
"¿Ella lloró?"
Cómo la guerra comercial entre EE. UU. y China podría ser beneficiosa para Pekín
Los primeros disparos de la guerra comercial entre Estados Unidos y China fueron ensordecedores, y aunque la batalla está lejos de terminar, una ruptura entre los países podría ser beneficiosa para Beijing a largo plazo, dicen los expertos.
El presidente de Estados Unidos, Donald Trump, emitió la primera advertencia a principios de este año al imponer aranceles a las principales exportaciones chinas, incluidos los paneles solares, el acero y el aluminio.
La escalada más significativa se produjo esta semana con nuevos aranceles que afectan a productos por valor de 200 000 millones de dólares (150 000 millones de libras esterlinas), lo que implica gravar la mitad de todos los productos que ingresan a Estados Unidos desde China.
Pekín ha respondido con medidas equivalentes cada vez, y recientemente impuso aranceles del cinco al diez por ciento sobre bienes estadounidenses por valor de 60 000 millones de dólares.
China se ha comprometido a igualar los aranceles estadounidenses, y es poco probable que la segunda economía más grande del mundo retroceda en un futuro cercano.
Hacer que Washington retroceda significa ceder ante las demandas, pero someterse públicamente a Estados Unidos sería demasiado vergonzoso para Xi Jinping, presidente de China.
Aun así, los expertos dicen que, si Pekín juega bien sus cartas, las presiones de la guerra comercial de EE. UU. podrían apoyar positivamente a China a largo plazo al reducir la interdependencia de las dos economías.
“El hecho de que una decisión política rápida en Washington o Pekín podría crear las condiciones para iniciar una caída económica en cualquiera de los dos países es, en realidad, mucho más peligroso de lo que los observadores han reconocido antes”, dijo Abigail Grace, investigadora asociada especializada en Asia en el Centro para la Nueva Seguridad Estadounidense, un grupo de reflexión.
Siria está "preparada" para el regreso de los refugiados, dice el ministro de Asuntos Exteriores
Siria afirma que está lista para el regreso voluntario de los refugiados y pide ayuda para reconstruir el país devastado por una guerra que dura más de siete años.
Al dirigirse a la Asamblea General de las Naciones Unidas, el ministro de Asuntos Exteriores, Walid al-Moualem, dijo que las condiciones en el país están mejorando.
“Hoy la situación sobre el terreno es más estable y segura gracias a los avances logrados en la lucha contra el terrorismo”, dijo.
El gobierno continúa rehabilitando las áreas destruidas por los terroristas para restaurar la normalidad.
Se dan todas las condiciones para el retorno voluntario de los refugiados al país que tuvieron que abandonar debido al terrorismo y las medidas económicas unilaterales que afectaron su vida cotidiana y sus medios de subsistencia.
La ONU estima que más de 5,5 millones de sirios han huido del país desde que comenzó la guerra en 2011.
Otras seis millones de personas que aún viven en el país necesitan asistencia humanitaria.
Al-Moualem dijo que el régimen sirio agradecería la ayuda para reconstruir el devastado país.
Pero subrayó que no aceptaría ayuda condicional ni asistencia de países que apoyaran la insurgencia.
Europa consigue la victoria en la Ryder Cup en París
El equipo de Europa ganó la Ryder Cup 2018 al derrotar al equipo de Estados Unidos con un marcador final de 16.5 a 10.5 en Le Golf National, cerca de París, Francia.
Estados Unidos ha perdido ahora seis veces consecutivas en suelo europeo y no ha ganado una Ryder Cup en Europa desde 1993.
Europa recuperó la corona cuando el equipo del capitán danés Thomas Bjorn alcanzó las 14,5 puntos necesarios para vencer a Estados Unidos.
La estrella estadounidense Phil Mickelson, que tuvo dificultades durante la mayor parte del torneo, metió su golpe de salida en el agua en el hoyo 16, de par 3, cediendo su partido a Francesco Molinari.
El golfista italiano Molinari brilló en todas sus rondas, convirtiéndose en uno de los cuatro jugadores que han logrado un récord de 5-0-0 desde que el torneo adoptó su formato actual en 1979.
El estadounidense Jordan Spieth fue derrotado por 5&4 por el jugador con menor ranking del equipo europeo, Thorbjorn Olesen de Dinamarca.
El mejor jugador del mundo, Dustin Johnson, perdió 2 y 1 ante el inglés Ian Poulter, quien pudo haber jugado su última Ryder Cup.
El español Sergio García, veterano de ocho Ryder Cups, se convirtió en el europeo con más victorias en la historia de los torneos, con 25,5 puntos en su carrera.
"No suelo llorar, pero hoy no puedo evitarlo.
Ha sido un año difícil.
Estoy tan agradecida de que Thomas me eligiera y creyera en mí.
Estoy tan feliz, tan feliz de recuperar la copa.
Se trata del equipo, y estoy feliz de haber podido ayudar", dijo una emocionada García tras la victoria europea.
Le pasa el testigo a su compatriota John Ram, quien derrotó al legendario golfista estadounidense Tiger Woods 2&1 en el partido individual del domingo.
"El increíble orgullo que siento por haber vencido a Tiger Woods, crecí viendo a ese tipo", dijo Rahm, de 23 años.
Woods perdió sus cuatro partidos en Francia y ahora tiene un récord de 13-21-3 en su carrera en la Ryder Cup.
Una estadística extraña para uno de los mejores jugadores de todos los tiempos, que ha ganado 14 títulos importantes, solo superado por Jack Nicklaus.
El equipo de Estados Unidos tuvo dificultades durante todo el fin de semana para encontrar los fairways, con la excepción de Patrick Reed, Justin Thomas y Tony Finau, quienes jugaron un golf de alto nivel durante todo el torneo.
El capitán estadounidense Jim Furyk habló después de una decepcionante actuación de su equipo: "Estoy orgulloso de estos chicos, lucharon.
Esta mañana hubo un momento en el que presionamos a Europa.
Nos deshicimos de él.
Un aplauso para Thomas.
Es un gran capitán.
Todos sus 12 jugadores jugaron muy bien.
Nos reagruparemos, trabajaré con la PGA de América y nuestro Comité de la Ryder Cup, y seguiremos adelante.
Me encantan estos 12 chicos y estoy orgulloso de ser su capitán.
Hay que quitarse el sombrero.
Nos superaron".
Actualización sobre la marea roja: las concentraciones disminuyen en Pinellas, Manatee y Sarasota
El informe más reciente de la Comisión de Pesca y Vida Silvestre de Florida muestra una disminución general en las concentraciones de marea roja en partes del área de la Bahía de Tampa.
Según la FWC, se están reportando condiciones de floración más irregulares en áreas de los condados de Pinellas, Manatee, Sarasota, Charlotte y Collier, lo que sugiere una disminución en las concentraciones.
Una floración de marea roja se extiende aproximadamente 130 millas de costa desde el norte del condado de Pinellas hasta el sur del condado de Lee.
Los parches se pueden encontrar a unos 10 millas de la costa del condado de Hillsborough, pero en menos sitios en comparación con la semana pasada.
También se ha observado marea roja en el condado de Pasco.
En la última semana se han reportado concentraciones medias en o frente a las costas del condado de Pinellas, concentraciones bajas a altas frente a las costas del condado de Hillsborough, concentraciones de fondo a altas en el condado de Manatee, concentraciones de fondo a altas en o frente a las costas del condado de Sarasota, concentraciones de fondo a medias en el condado de Charlotte, concentraciones de fondo a altas en o frente a las costas del condado de Lee y concentraciones bajas en el condado de Collier.
Se siguen reportando irritaciones respiratorias en los condados de Pinellas, Manatee, Sarasota, Lee y Collier.
No se reportó irritación respiratoria en el noroeste de Florida durante la semana pasada.
