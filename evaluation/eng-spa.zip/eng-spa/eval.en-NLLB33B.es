Los AM galeses están preocupados por 'parecer títeres'
Hay consternación entre algunos diputados ante la sugerencia de que su título debería cambiar a MWPs (Miembro del Parlamento de Gales).
Ha surgido debido a los planes para cambiar el nombre de la asamblea al Parlamento de Gales.
Los diputados de todo el espectro político están preocupados de que pueda provocar el ridículo.
Un diputado laborista dijo que a su grupo le preocupaba "que rima con Twp y Pwp".
Para los lectores fuera de Gales: en galés twp significa tonto y pwp significa caca.
Un Plaid AM dijo que el grupo en su conjunto "no estaba contento" y ha sugerido alternativas.
Un conservador galés dijo que su grupo estaba "de mente abierta" sobre el cambio de nombre, pero señaló que era un corto salto verbal de MWP a Muppet.
En este contexto, la letra galesa w se pronuncia de manera similar a la pronunciación inglesa de Yorkshire de la letra u.
La Comisión de la Asamblea, que actualmente está redactando una legislación para introducir los cambios de nombre, dijo: "La decisión final sobre cualquier descriptor de lo que se llama a los miembros de la Asamblea será, por supuesto, un asunto para los propios miembros".
La Ley de Gobierno de Gales de 2017 dio a la asamblea galesa el poder de cambiar su nombre.
En junio, la Comisión publicó los resultados de una consulta pública sobre las propuestas que encontraron un amplio apoyo para llamar a la asamblea un Parlamento de Gales.
En lo que se refiere al título de los AM, la Comisión favoreció a los miembros del Parlamento galés o a los WMP, pero la opción MWP recibió el mayor apoyo en una consulta pública.
Al parecer, los consejeros adjuntos están sugiriendo opciones alternativas, pero la lucha para llegar a un consenso podría ser un dolor de cabeza para la presidenta, Elin Jones, que se espera que presente un proyecto de ley sobre los cambios dentro de unas semanas.
La legislación sobre las reformas incluirá otros cambios en la forma en que funciona la asamblea, incluidas las normas sobre la descalificación de los AM y el diseño del sistema de comités.
Los AMs tendrán la votación final sobre la cuestión de cómo deben ser llamados cuando debatan la legislación.
Los macedonios acuden a las urnas para votar en el referéndum sobre el cambio de nombre del país
Los votantes votarán el domingo si cambian el nombre de su país a "República de Macedonia del Norte".
El voto popular se creó en un intento por resolver una disputa de décadas con la vecina Grecia, que tiene su propia provincia llamada Macedonia.
Atenas ha insistido durante mucho tiempo en que el nombre de su vecino del norte representa un reclamo sobre su territorio y se ha opuesto repetidamente a sus ofertas de membresía en la UE y la OTAN.
El presidente macedonio Gjorge Ivanov, un opositor al plebiscito sobre el cambio de nombre, ha dicho que ignorará la votación.
Sin embargo, los partidarios del referéndum, incluido el primer ministro Zoran Zaev, argumentan que el cambio de nombre es simplemente el precio a pagar para unirse a la UE y la OTAN.
Las campanas de San Martín caen en silencio mientras las iglesias de Harlem luchan
"Históricamente, los ancianos con los que he hablado dicen que había un bar y una iglesia en cada esquina", dijo el Sr. Adams.
"Hoy, no hay ninguno de los dos".
Dijo que la desaparición de las barras era comprensible.
"La gente socializa de una manera diferente" hoy en día, dijo.
"Los bares ya no son salas de estar del vecindario donde la gente va regularmente".
En cuanto a las iglesias, le preocupa que el dinero de la venta de activos no dure tanto como lo esperan los líderes, "y tarde o temprano volverán a donde comenzaron".
Las iglesias, añadió, podrían ser reemplazadas por edificios de apartamentos con condominios llenos del tipo de personas que no ayudarán a los santuarios restantes del vecindario.
"La abrumadora mayoría de las personas que compran condominios en estos edificios serán blancos,"y por lo tanto acelerará el día en que estas iglesias cierren por completo porque es poco probable que la mayoría de estas personas que se mudan a estos condominios se conviertan en miembros de estas iglesias".
Ambas iglesias fueron construidas por congregaciones blancas antes de que Harlem se convirtiera en una metrópolis negra: la Comunidad Metropolitana en 1870, y St. Martin una década después.
La congregación metodista blanca original se mudó en la década de 1930.
Una congregación de negros que había estado adorando cerca tomó el título del edificio.
St. Martin fue tomado por una congregación negra bajo el reverendo John Howard Johnson, quien lideró un boicot a los minoristas en la calle 125, una calle principal para comprar en Harlem, que se resistieron a contratar o promover a los negros.
Un incendio en 1939 dejó el edificio muy dañado, pero cuando los feligreses del padre Johnson hicieron planes para reconstruirlo, encargaron el carillón.
El reverendo David Johnson, hijo y sucesor del padre Johnson en St. Martin, orgullosamente llamó al carillón "las campanas de los pobres".
El experto que tocó el carillón en julio lo llamó algo distinto: "Un tesoro cultural" y "un instrumento histórico insustituible".
La experta, Tiffany Ng, de la Universidad de Michigan, también señaló que fue el primer carillón en el mundo que tocó un músico negro, Dionisio A. Lind, quien se mudó al carillón más grande de la Iglesia de Riverside hace 18 años.
El Sr. Merriweather dijo que St. Martin no lo reemplazó.
Lo que ha sucedido en San Martín en los últimos meses ha sido una complicada historia de arquitectos y contratistas, algunos traídos por los líderes laicos de la iglesia, otros por la diócesis episcopal.
La sacristía, el órgano de gobierno de la parroquia, formado por líderes laicos - escribió la diócesis en julio con preocupaciones de que la diócesis "buscara pasar los costos" a la sacristía, a pesar de que la sacristía no había participado en la contratación de los arquitectos y contratistas que la diócesis envió.
Algunos feligreses se quejaron de la falta de transparencia por parte de la diócesis.
Un tiburón hiere a un niño de 13 años en una pesca de langosta en California
Un tiburón atacó e hirió a un niño de 13 años el sábado mientras buceaba para pescar langosta en California en el primer día de la temporada de langosta, dijeron las autoridades.
El ataque ocurrió justo antes de las 7 a.m. cerca de Beacon's Beach en Encinitas.
Chad Hammel le dijo a KSWB-TV en San Diego que había estado buceando con amigos durante aproximadamente media hora el sábado por la mañana cuando escuchó al niño gritar por ayuda y luego remó con un grupo para ayudar a sacarlo del agua.
Hammel dijo que al principio pensó que era solo la emoción de atrapar una langosta, pero luego "se dio cuenta de que estaba gritando: '¡Me mordieron!
¡Me han mordido!
Toda su clavícula estaba abierta", Hammel dijo que se dio cuenta una vez que llegó al niño.
"Grité a todos que salieran del agua: '¡Hay un tiburón en el agua!'" Hammel añadió.
El niño fue trasladado en helicóptero al Hospital de Niños Rady en San Diego donde está en estado crítico.
Se desconoce la especie de tiburón responsable del ataque.
El capitán Larry Giles dijo en una rueda de prensa que un tiburón había sido visto en la zona unas semanas antes, pero se determinó que no era una especie peligrosa de tiburón.
Giles agregó que la víctima sufrió lesiones traumáticas en la parte superior del torso.
Las autoridades cerraron el acceso a la playa desde Ponto Beach en Casablad hasta Swami's en Ecinitas durante 48 horas por razones de investigación y seguridad.
Giles señaló que hay más de 135 especies de tiburones en la zona, pero la mayoría no se consideran peligrosas.
Los planes de Sainsbury avanzan en el mercado de la belleza del Reino Unido
Sainsbury's se está enfrentando a Boots, Superdrug y Debenhams con pasillos de belleza al estilo de los grandes almacenes con personal de asistentes especializados.
Como parte de un impulso sustancial en el mercado de belleza de 2.800 millones de libras del Reino Unido, que continúa creciendo mientras que las ventas de moda y artículos para el hogar retroceden, los pasillos de belleza más grandes serán probados en 11 tiendas en todo el país y llevados a más tiendas el próximo año si es un éxito.
La inversión en belleza se produce cuando los supermercados buscan formas de utilizar el espacio de las estanterías una vez demandado por televisores, microondas y artículos para el hogar.
Sainsbury's dijo que iba a duplicar el tamaño de su oferta de belleza hasta 3.000 productos, incluyendo marcas como Revlon, Essie, Tweezerman y Dr. PawPaw por primera vez.
Las gamas existentes de L'Oreal, Maybelline y Burt's Bees también tendrán más espacio con áreas de marca similares a las que se encuentran en tiendas como Boots.
El supermercado también está relanzando su gama de maquillaje Boutique para que la mayoría de los productos sean veganos, algo cada vez más demandado por los compradores más jóvenes.
Además, el minorista de perfumes Fragrance Shop probará concesiones en dos tiendas de Sainsbury, la primera de las cuales se abrió en Croydon, al sur de Londres, la semana pasada, mientras que una segunda se abre en Selly Oak, Birmingham, a finales de este año.
Las compras en línea y un cambio hacia la compra diaria de pequeñas cantidades de alimentos en tiendas locales significa que los supermercados tienen que hacer más para persuadir a la gente a visitar.
Mike Coupe, el director ejecutivo de Sainsbury's, ha dicho que los puntos de venta se parecerán cada vez más a los grandes almacenes, ya que la cadena de supermercados trata de luchar contra las tiendas de descuentos Aldi y Lidl con más servicios y productos no alimentarios.
Sainsbury's ha estado poniendo puntos de venta de Argos en cientos de tiendas y también ha introducido una serie de hábitats desde que compró ambas cadenas hace dos años, lo que dice que ha reforzado las ventas de comestibles y ha hecho que las adquisiciones sean más rentables.
El intento anterior del supermercado de renovar sus departamentos de belleza y farmacia terminó en fracaso.
Sainsbury probó una empresa conjunta con Boots a principios de la década de 2000, pero el vínculo terminó después de una disputa sobre cómo dividir los ingresos de las tiendas de la farmacia en sus supermercados.
La nueva estrategia se produce después de que Sainsbury's vendió su negocio de farmacias de 281 tiendas a Celesio, el propietario de la cadena de farmacias Lloyds, por 125 millones de libras, hace tres años.
Dijo que Lloyds jugaría un papel en el plan, al agregar una amplia gama de marcas de cuidado de la piel de lujo, incluidas La Roche-Posay y Vichy, en cuatro tiendas.
Paul Mills-Hicks, director comercial de Sainsbury, dijo: "Hemos transformado el aspecto y la sensación de nuestros pasillos de belleza para mejorar el entorno para nuestros clientes.
También hemos invertido en colegas especialmente entrenados que estarán disponibles para ofrecer consejos.
Nuestra gama de marcas está diseñada para satisfacer todas las necesidades y el atractivo entorno y las convenientes ubicaciones hacen que ahora seamos un atractivo destino de belleza que desafía la antigua forma de comprar".
Peter Jones 'furioso' después de que Holly Willoughby se retire de un acuerdo de 11 millones de libras
La estrella de Dragons Den, Peter Jones, se enfureció después de que la presentadora de televisión Holly Willoughby se retirara de un acuerdo de 11 millones de libras con su negocio de marcas de estilo de vida para centrarse en sus nuevos contratos con Marks and Spencer e ITV.
Willoughby no tiene tiempo para su marca de ropa y accesorios Truly.
El negocio de la pareja había sido comparado con la marca Goop de Gwyneth Paltrow.
La presentadora de esta mañana, de 37 años, se dirigió a Instagram para anunciar que se va.
Holly Willoughby ha dejado a la estrella de Dragons, Peter Jones furioso por retirarse de su lucrativo negocio de marca de estilo de vida en el último minuto para centrarse en sus nuevos contratos con Marks & Spencer e ITV.
Las fuentes dicen que Jones estaba "furioso" cuando la chica de oro de la TV admitió durante una reunión tensa el martes en la sede de su imperio de negocios en Marlow, Buckinghamshire, que sus nuevos acuerdos, por valor de hasta 1,5 millones de libras, significaban que ya no tenía suficiente tiempo para dedicarse a su marca de ropa para el hogar y accesorios Truly.
El negocio había sido comparado con la marca Goop de Gwyneth Paltrow y se estimó que duplicaría la fortuna estimada de Willoughby de 11 millones de libras esterlinas.
Cuando Willoughby, de 37 años, tomó Instagram para anunciar que se iba de Truly, Jones salió de Gran Bretaña para dirigirse a una de sus casas de vacaciones.
Una fuente dijo: "Truly era, con mucho, la primera de las prioridades de Holly.
Sería su futuro a largo plazo que la vería a través de las próximas dos décadas.
Su decisión de retirarse dejó a todos los involucrados absolutamente atónitos.
Nadie podía creer lo que estaba sucediendo el martes, estaba tan cerca del lanzamiento.
Hay un almacén lleno de mercancías en la sede de Marlow que están listas para ser vendidas. "
Los expertos creen que la salida del presentador de esta mañana, que es una de las estrellas más rentables de Gran Bretaña, podría costarle a la empresa millones debido a la fuerte inversión en productos que van desde cojines y velas hasta ropa y ropa para el hogar, y la posibilidad de nuevos retrasos en su lanzamiento.
Y podría significar el final de una larga amistad.
Willoughby, madre de tres hijos, y su esposo Dan Baldwin han estado cerca de Jones y su esposa Tara Capp durante diez años.
Willoughby creó Truly con Capp en 2016 y Jones, de 52 años, se unió como presidente en marzo.
Las parejas de vacaciones juntos y Jones tiene una participación del 40 por ciento en la empresa de producción de televisión de Baldwin.
Willoughby se convertirá en embajador de la marca M&S y reemplazará a Ant McPartlin como presentador de I'm A Celebrity de ITV.
Una fuente cercana a Jones dijo anoche "No comentaríamos sus asuntos de negocios".
Hablo duro 'y luego nos enamoramos'
Bromeó sobre las críticas que recibiría de los medios de comunicación por hacer un comentario que algunos considerarían "no presidencial" y por ser tan positivo sobre el líder norcoreano.
¿Por qué el presidente Trump ha renunciado tanto?
Trump dijo con su falsa voz de "presentador de noticias".
"No he renunciado a nada".
Señaló que Kim está interesado en una segunda reunión después de que su reunión inicial en Singapur en junio fue aclamada por Trump como un gran paso hacia la desnuclearización de Corea del Norte.
Pero las negociaciones de desnuclearización se han estancado.
Más de tres meses después de la cumbre de junio en Singapur, el principal diplomático de Corea del Norte, Ri Yong Ho, dijo a los líderes mundiales en la Asamblea General de la ONU el sábado que el Norte no ve una "respuesta correspondiente" de los Estados Unidos a los primeros movimientos de desarme de Corea del Norte.
En cambio, señaló, EE.UU. continúa con las sanciones destinadas a mantener la presión.
Trump adoptó una visión mucho más optimista en su discurso en el mitin.
"Lo estamos haciendo muy bien con Corea del Norte", dijo.
"Ibamos a la guerra con Corea del Norte.
Millones de personas habrían muerto.
Ahora tenemos esta gran relación".
Dijo que sus esfuerzos por mejorar las relaciones con Kim han traído resultados positivos: poner fin a las pruebas de cohetes, ayudar a liberar rehenes y hacer que los restos de los soldados estadounidenses regresen a casa.
Y defendió su enfoque inusual al hablar de las relaciones con Kim.
"Es tan fácil ser presidencial, pero en lugar de tener 10,000 personas afuera tratando de entrar en esta arena repleta, tendríamos alrededor de 200 personas de pie justo ahí", dijo Trump, señalando a la multitud directamente frente a él.
Indonesia Tsunami y terremoto devastan una isla y matan a cientos
A raíz del terremoto de Lombok, por ejemplo, se les dijo a las organizaciones no gubernamentales extranjeras que no eran necesarias.
A pesar de que más del 10 por ciento de la población de Lombok había sido desplazada, no se declaró un desastre nacional, un requisito previo para catalizar la ayuda internacional.
"En muchos casos, desafortunadamente, han sido muy claros en que no están solicitando asistencia internacional, por lo que es un poco difícil", dijo la Sra. Sumbung.
Mientras Save the Children está reuniendo un equipo para viajar a Palu, aún no está seguro de si el personal extranjero puede trabajar en el terreno.
El Sr. Sutopo, portavoz de la agencia nacional de desastres, dijo que los funcionarios indonesios estaban evaluando la situación en Palu para ver si se permitiría a las agencias internacionales contribuir al esfuerzo de ayuda.
Dado el temblor de la tierra que Indonesia soporta constantemente, el país permanece lamentablemente mal preparado para la ira de la naturaleza.
Si bien se han construido refugios contra tsunamis en Aceh, no son una vista común en otras costas.
La aparente falta de una sirena de advertencia de tsunami en Palu, a pesar de que una advertencia había estado en efecto, es probable que haya contribuido a la pérdida de vidas.
En el mejor de los casos, viajar entre las muchas islas de Indonesia es un desafío.
Los desastres naturales hacen que la logística sea aún más complicada.
Un barco hospital que había estado estacionado en Lombok para atender a las víctimas del terremoto se dirige a Palu, pero tardará al menos tres días en llegar al lugar de la nueva calamidad.
El presidente Joko Widodo hizo de la mejora de la deteriorada infraestructura de Indonesia una pieza central de su campaña electoral, y ha derrochado dinero en carreteras y ferrocarriles.
Pero la escasez de fondos ha plagado a la administración del Sr. Joko mientras se enfrenta a la reelección el próximo año.
El Sr. Joko también se enfrenta a la presión de las persistentes tensiones sectarias en Indonesia, donde los miembros de la mayoría musulmana han abrazado una forma más conservadora de la fe.
Más de 1.000 personas murieron y decenas de miles fueron desplazadas de sus hogares cuando pandillas cristianas y musulmanas lucharon en las calles, usando machetes, arcos y flechas, y otras armas rudimentarias.
Mira: Daniel Sturridge de Liverpool se sumerge profundamente en el empate contra el Chelsea
Daniel Sturridge salvó al Liverpool de una derrota en la Premier League ante el Chelsea con un gol en el minuto 89 el sábado en el Stamford Bridge de Londres.
Sturridge recibió un pase de Xherdan Shaqiri a unas 30 yardas de la portería del Chelsea con su equipo perdiendo 1-0.
Golpeó la pelota a su izquierda antes de lanzar un tiro hacia el poste lejano.
El intento navegó muy por encima de la caja mientras se desplazaba hacia la esquina superior derecha de la red.
La pelota finalmente cayó sobre un Kepa Arrizabalaga saltando y cayó en la red.
"Sólo trataba de entrar en esa posición, de conseguir el balón y jugadores como Shaq siempre lo juegan hacia adelante tanto como sea posible, así que solo traté de crearme el mayor tiempo posible", dijo Sturridge a LiverpoolFC.com.
"Vi a Kante venir y tomé un toque y no lo pensé demasiado y simplemente le di el tiro".
Chelsea lideró 1-0 en el descanso después de conseguir un gol en el minuto 25 de la estrella belga Eden Hazard.
El delantero de los Blues devolvió un pase a Mateo Kovacic en esa jugada, antes de girar cerca del mediocampo y correr a la mitad de Liverpool.
Kovacic hizo un movimiento rápido en el mediocampo.
Luego disparó una hermosa pelota, llevando a Hazard a la caja.
Hazard superó a la defensa y terminó en la red del poste lejano con un tiro con el pie izquierdo más allá de Alisson Becker de Liverpool.
El Liverpool se enfrenta al Napoli en la fase de grupos de la Liga de Campeones a las 3 de la tarde del miércoles en el Stadio San Paolo en Nápoles, Italia.
Chelsea se enfrenta a Videoton en la UEFA Europa League el jueves a las 3 p.m. en Londres.
El número de muertos por el tsunami en Indonesia asciende a 832
El número de muertos en el terremoto y tsunami de Indonesia ha aumentado a 832, dijo la agencia de desastres del país el domingo por la mañana.
Se informó que muchas personas quedaron atrapadas en los escombros de los edificios derribados en el terremoto de magnitud 7.5 que azotó el viernes y provocó olas de hasta 20 pies de altura, dijo el portavoz de la agencia Sutopo Purwo Nugroho en una conferencia de prensa.
La ciudad de Palu, que tiene más de 380.000 habitantes, estaba cubierta de escombros de edificios derrumbados.
La policía detiene a un hombre, de 32 años, por sospecha de asesinato después de que una mujer fuera apuñalada hasta la muerte.
Se ha iniciado una investigación de asesinato después de que el cuerpo de una mujer fue encontrado en Birkenhead, Merseyside esta mañana.
El hombre de 44 años fue encontrado a las 7.55 am con heridas de arma blanca en Grayson Mews en John Street, con un hombre de 32 años arrestado por sospecha de asesinato.
La policía ha instado a las personas en el área que vieron o escucharon algo a darse a conocer.
El inspector detective Brian O'Hagan dijo: "La investigación se encuentra en las primeras etapas, pero hago un llamamiento a cualquier persona que estuviera en las cercanías de John Street en Birkenhead y que haya visto o oído algo sospechoso para que se ponga en contacto con nosotros.
También haría un llamamiento a cualquiera, especialmente a los taxistas, que puedan haber capturado algo en las imágenes de las cámaras de control para que nos contacten ya que pueden tener información que es vital para nuestra investigación".
Un portavoz de la policía ha confirmado que la mujer cuyo cuerpo fue encontrado es de Birkenhead y fue encontrada dentro de una propiedad.
Esta tarde amigos que creen conocer a la mujer han llegado a la escena para hacer preguntas sobre dónde fue encontrada esta mañana.
Las investigaciones están en curso ya que la policía ha dicho que están en el proceso de informar a los parientes más cercanos de la víctima.
Un taxista que vive en Grayson Mews ha intentado regresar a su apartamento pero la policía le ha dicho que nadie puede entrar o salir del edificio.
Se quedó sin palabras cuando descubrió lo que había sucedido.
A los residentes ahora se les dice que pasarán horas hasta que se les permita volver.
Se escuchó a un oficial de policía diciéndole a un hombre que toda la zona ahora está siendo tratada como una escena de crimen.
Una mujer apareció en la escena llorando.
Ella sigue repitiendo 'es tan horrible'.
A las 2 pm dos furgonetas de la policía estaban dentro del cordón con otra furgoneta justo afuera.
Varios oficiales estaban parados dentro del cordón vigilando el bloque de apartamentos.
A cualquier persona con información se le pide que llame a DM @MerPolCC, llame al 101 o contacte a Crimestoppers anónimamente en el 0800 555 111 citando el registro 247 del 30 de septiembre.
La estatua de Cromwell del Parlamento se convierte en el último monumento conmemorativo golpeado por la fila de "reescribir la historia"
Su destierro sería justicia poética por su destrucción talibanista de tantos artefactos culturales y religiosos de Inglaterra llevada a cabo por sus fanáticos seguidores puritanos.
Pero la Sociedad Cromwell describió la sugerencia del Sr. Crick como "tontería" y "intento de reescribir la historia".
John Goldsmith, presidente de la Sociedad Cromwell, dijo: "Fue inevitable en el presente debate sobre la eliminación de las estatuas que la figura de Oliver Cromwell fuera del Palacio de Westminster se convirtiera en un objetivo.
La iconoclasia de las guerras civiles inglesas no fue ordenada ni llevada a cabo por Cromwell.
Tal vez el Cromwell equivocado sería sacrificado por las acciones de su antepasado Thomas en el siglo anterior.
La magnífica representación de Cromwell de Sir William Hamo Thorneycroft es evidencia de la opinión del siglo XIX y parte de la historiografía de una figura que muchos creen que todavía vale la pena celebrar.
El Sr. Goldsmith dijo a The Sunday Telegraph: "Cromwell es considerado por muchos, tal vez más a finales del siglo XIX que hoy, como un defensor del parlamento contra la presión externa, en su caso, por supuesto, la monarquía.
Si esa es una representación totalmente exacta es el tema de continuo debate histórico.
Lo que es seguro es que el conflicto de mediados del siglo XVII ha dado forma al desarrollo posterior de nuestra nación, y Cromwell es una figura reconocible individual que representa un lado de esa división.
Sus logros como Lord Protector también merecen ser celebrados y conmemorados".
El cerdo asesino mata a un granjero chino
Un granjero fue atacado y asesinado por un cerdo en un mercado en el suroeste de China, según informes de los medios locales.
El hombre, identificado solo por su apellido "Yuan", fue encontrado muerto con una arteria cortada, cubierta de sangre cerca de un establo en el mercado de Liupanshui en la provincia de Guizhou, informó el domingo el South China Morning Post.
Un criador de cerdos se prepara para inyectar vacunas en cerdos en una granja de cerdos el 30 de mayo de 2005 en Xining de la provincia de Qinghai, China.
Según los informes, había viajado con su primo de la vecina provincia de Yunnan el miércoles para vender 15 cerdos en el mercado.
A la mañana siguiente, su primo lo encontró muerto, y descubrió una puerta abierta a un establo de cerdos vecino.
Dijo que en el corral había un gran cerdo macho con sangre en la boca.
Un examen forense confirmó que el cerdo de 550 libras había mutilado al granjero hasta la muerte, según el informe.
"Las piernas de mi primo estaban ensangrentadas y mutiladas", dijo el primo, conocido por su apellido "Wu", según lo citado por el Guiyang Evening News.
Las imágenes de las cámaras de seguridad mostraron a Yuan entrando al mercado a las 4.40 de la mañana del jueves para alimentar a sus cerdos.
Su cuerpo fue encontrado una hora después.
El animal que mató al hombre no pertenecía a Yuan ni a su primo.
Un gerente del mercado dijo al Evening News que el cerdo había sido encerrado para evitar que atacara a alguien más, mientras la policía reunía pruebas en el lugar.
Según los informes, la familia de Yuan y las autoridades del mercado están negociando una compensación por su muerte.
Aunque es raro, ya se han registrado casos de cerdos que atacan a humanos.
En 2016, un cerdo atacó a una mujer y a su esposo en su granja en Massachusetts, dejando al hombre con heridas graves.
Diez años antes, un cerdo de 650 libras sujetó a un granjero galés a su tractor hasta que su esposa ahuyentó al animal.
Después de que un granjero de Oregon fue comido por sus cerdos en 2012, un granjero de Manitoba le dijo a CBC News que los cerdos normalmente no son agresivos, pero el sabor de la sangre puede actuar como un "disparador".
"Sólo están jugando.
Son curiosos, muy curiosos... no quieren hacerte daño.
Sólo hay que darles el debido respeto", dijo.
Los restos del huracán Rosa traerán fuertes lluvias al suroeste de EE.UU.
Como se pronosticó, el huracán Rosa se está debilitando a medida que avanza sobre las aguas más frías de la costa norte de México.
Sin embargo, Rosa traerá lluvias en el norte de México y el suroeste de los Estados Unidos en los próximos días.
Rosa tenía vientos de 85 mph, un huracán de categoría 1, a las 5 a.m. hora del este el domingo, y se encuentra a 385 millas al suroeste de Punta Eugenia, México.
Se espera que Rosa se mueva hacia el norte el domingo.
Mientras tanto, un canal está comenzando a tomar forma sobre el Océano Pacífico y se mueve hacia el este hacia la costa oeste de los EE.UU. Como Rosa se acerca a la península de Baja California el lunes como una tormenta tropical que comenzará a empujar humedad tropical profunda hacia el norte en el suroeste de EE.UU.
Rosa traerá hasta 10 pulgadas de lluvia en algunas partes de México el lunes.
Luego, la humedad tropical interactuando con el valle que se acerca creará fuertes lluvias en el suroeste durante los próximos días.
A nivel local, de 1 a 4 pulgadas de lluvia causarán peligrosas inundaciones repentinas, flujos de escombros y posibles deslizamientos de tierra en el desierto.
La humedad tropical profunda hará que las tasas de lluvia se acerquen a 2 a 3 pulgadas por hora en algunos lugares, especialmente en partes del sur de Nevada y Arizona.
Se espera de 2 a 4 pulgadas de lluvia en algunas partes del suroeste, especialmente en gran parte de Arizona.
Las inundaciones repentinas son posibles con condiciones que se deterioran rápidamente debido a la naturaleza dispersa de las lluvias tropicales.
Sería extremadamente poco aconsejable aventurarse en el desierto a pie con la amenaza de lluvias tropicales.
Las fuertes lluvias podrían hacer que los cañones se conviertan en ríos furiosos y las tormentas eléctricas traerán vientos localizados y polvo que sopla.
El tramo que se acerca traerá algunas lluvias localmente fuertes a partes de la costa del sur de California.
Las precipitaciones totales de más de media pulgada son posibles, lo que podría causar pequeños flujos de escombros y carreteras resbaladizas.
Esta sería la primera lluvia de la región en su temporada de lluvias.
Algunas lluvias tropicales dispersas comenzarán a acercarse a Arizona el domingo por la noche y el lunes temprano, antes de que la lluvia se extienda más el lunes por la noche y el martes.
Las fuertes lluvias se extenderán a los cuatro rincones el martes y durarán hasta el miércoles.
Octubre puede ver algunos cambios intensos de temperatura en los EE.UU. a medida que el Ártico se enfría, pero los trópicos permanecen bastante cálidos.
A veces esto lleva a cambios dramáticos en la temperatura en distancias cortas.
Hay un gran ejemplo de dramáticas diferencias de temperatura a través del centro de los EE.UU. el domingo.
Hay casi 20 grados de diferencia de temperatura entre Kansas City, Missouri, y Omaha, Nebraska, y entre St. Louis y Des Moines, Iowa.
Durante los próximos días, el prolongado calor del verano tratará de crecer y expandirse de nuevo.
Se espera que gran parte del centro y el este de los Estados Unidos vea un comienzo cálido para octubre con 80s generalizados desde las llanuras del sur hasta partes del noreste.
La ciudad de Nueva York podría alcanzar los 80 grados el martes, lo que sería aproximadamente 10 grados por encima del promedio.
Nuestro pronóstico climático a largo plazo indica altas posibilidades de temperaturas por encima de la media para el este de los EE.UU. a través de la primera mitad de octubre.
Más de 20 millones de personas vieron la audiencia de Brett Kavanaugh
Más de 20 millones de personas vieron el emocionante testimonio del jueves del candidato a la Corte Suprema Brett Kavanaugh y la mujer que lo acusó de una agresión sexual que supuestamente ocurrió en la década de 1980, Christine Blasey Ford, en seis cadenas de televisión.
Mientras tanto, el enfrentamiento político continuó, con las emisoras interrumpiendo la programación regular para el giro de última hora del viernes: un acuerdo diseñado por el senador de Arizona Jeff Flake para que el FBI lleve a cabo una investigación de una semana de los cargos.
Ford le dijo al Comité Judicial del Senado que está 100% segura de que Kavanaugh la tocó borracho y trató de quitarle la ropa en una fiesta de la secundaria.
Kavanaugh, en un testimonio apasionado, dijo que está 100% seguro de que no sucedió.
Es probable que más de los 20,4 millones de personas reportadas por Nielsen el viernes lo vieron.
La compañía estaba contando la audiencia promedio en CBS, ABC, NBC, CNN, Fox News Channel y MSNBC.
Las cifras no estaban disponibles de inmediato para otras redes que lo mostraron, incluidas PBS, C-SPAN y Fox Business Network.
Y Nielsen por lo general tiene algunos problemas para medir a la gente que mira en las oficinas.
Para poner eso en perspectiva, ese es un tamaño de audiencia similar al de un partido de playoff de fútbol o los Premios de la Academia.
Fox News Channel, cuyos presentadores de opinión han respaldado fuertemente el nombramiento de Kavanaugh, lideró todas las redes con un promedio de 5.69 millones de espectadores durante la audiencia de todo el día, dijo Nielsen.
ABC fue segundo con 3,26 millones de espectadores.
CBS tenía 3.1 millones, NBC tenía 2.94 millones, MSNBC tenía 2.89 millones y CNN tenía 2.52 millones, dijo Nielsen.
El interés se mantuvo elevado tras la audiencia.
Flake fue la figura central en el drama del viernes.
Después de que la oficina del republicano moderado emitió una declaración de que votaría a favor de Kavanaugh, fue capturado por las cámaras de CNN y CBS el viernes por la mañana siendo gritado por los manifestantes mientras intentaba subir en un ascensor a una audiencia del Comité Judicial.
Estuvo de pie con los ojos hacia abajo durante varios minutos mientras era reprendido, televisado en vivo por la CNN.
"Estoy aquí delante de ustedes", dijo una mujer.
"¿Crees que le está diciendo la verdad al país?
Le dijeron: "Tienes poder cuando tantas mujeres son impotentes".
Flake dijo que su oficina había emitido una declaración y dijo, antes de que el ascensor se cerrara, que tendría más que decir en la audiencia del comité.
Las cadenas de cable y de radiodifusión estaban cubriendo en vivo horas más tarde, cuando el Comité Judicial iba a votar para adelantar la nominación de Kavanaugh al pleno del Senado para una votación.
Pero Flake dijo que solo lo haría con el entendimiento de que el FBI investigaría las acusaciones contra el candidato para la próxima semana, lo que los demócratas de la minoría han estado instando.
Flake fue convencido en parte por conversaciones con su amigo, el senador demócrata Chris Coons.
Después de una conversación con Coons y varios senadores después, Flake tomó su decisión.
La elección de Flake tenía poder, porque era evidente que los republicanos no tendrían los votos para aprobar a Kavanaugh sin la investigación.
El presidente Trump ha abierto una investigación del FBI sobre las acusaciones contra Kavanaugh.
El primer ministro británico May acusa a los críticos de "jugar a la política" sobre el Brexit
La primera ministra Theresa May acusó a los críticos de sus planes de abandonar la Unión Europea de "jugar a la política" con el futuro de Gran Bretaña y socavar el interés nacional en una entrevista con el periódico Sunday Times.
La primera ministra de Gran Bretaña, Theresa May, llega a la Conferencia del Partido Conservador en Birmingham, Gran Bretaña, el 29 de septiembre de 2018.
En otra entrevista junto a la con ella en la primera página del periódico, su ex ministro de Relaciones Exteriores, Boris Johnson, insistió en su ataque al llamado plan de Chequers para el Brexit, diciendo que una propuesta de que Gran Bretaña y la UE deberían cobrar los aranceles de cada uno era "totalmente absurda".
La policía detiene al sospechoso Dyteon Simpson en la muerte del jugador de LSU
La policía ha arrestado a un sospechoso en el tiroteo fatal de Wayde Sims, un jugador de baloncesto de 20 años en LSU.
Dyteon Simpson, de 20 años, ha sido arrestado y encarcelado por asesinato en segundo grado, dijo el Departamento de Policía de Baton Rouge.
Las autoridades publicaron un video de la confrontación entre Sims y Simpson, y la policía dijo que Sims perdió sus gafas durante la pelea.
La policía recuperó las gafas de la escena y dijo que encontraron el ADN de Simpson en ellos, CBS afiliado WAFB informes.
Después de interrogar a Simpson, la policía dijo que admitió haber disparado fatalmente a Wayde.
Su fianza ha sido fijada en 350.000 dólares, informa el Advocate.
La oficina del forense de East Baton Rouge dio a conocer un informe preliminar el viernes, diciendo que la causa de la muerte es una herida de bala en la cabeza en el cuello.
El departamento está acreditando al grupo de trabajo de fugitivos de la Policía Estatal de Luisiana, el laboratorio criminal de la policía estatal, la policía de la Universidad del Sur y los ciudadanos del área en la asistencia en la investigación que condujo al arresto.
El director atlético de LSU, Joe Alleva, agradeció a la policía local por su "diligencia y búsqueda de justicia".
Sims tenía 20 años.
El delantero de 6 pies y 6 pulgadas creció en Baton Rouge, donde su padre, Wayne, también jugó baloncesto para LSU.
Promedió 5.6 puntos y 2.6 rebotes por partido la temporada pasada.
El viernes por la mañana, el entrenador de baloncesto de LSU, Will Wade, dijo que el equipo está "devastado" y "en shock" por la muerte de Wayde.
"Esto es lo que te preocupa todo el tiempo", dijo Wade.
El volcán arroja cenizas sobre la Ciudad de México
Las cenizas arrojadas por el volcán Popocatépetl han alcanzado los barrios del sur de la capital de México.
El Centro Nacional para la Prevención de Desastres advirtió a los mexicanos el sábado que se mantuvieran alejados del volcán después de que la actividad aumentara en el cráter y registrara 183 emisiones de gas y ceniza en 24 horas.
El centro estaba monitoreando múltiples estruendos y temblores.
Las imágenes en las redes sociales mostraban finas capas de ceniza que cubrían los parabrisas de los coches en barrios de la Ciudad de México como Xochimilco.
Los geofísicos han notado un aumento de la actividad en el volcán que se encuentra a 45 millas (72 kilómetros) al sureste de la capital desde que un terremoto de magnitud 7.1 sacudió el centro de México en septiembre de 2017.
El volcán conocido como "Don Goyo" ha estado activo desde 1994.
La policía se enfrenta a los separatistas catalanes antes del aniversario de la votación de la independencia
Seis personas fueron arrestadas en Barcelona el sábado después de que manifestantes a favor de la independencia se enfrentaron con la policía antidisturbios, y mientras miles se unieron a manifestaciones rivales para conmemorar el primer aniversario de la votación polarizada de Cataluña sobre la secesión.
Un grupo de separatistas enmascarados retenidos por la policía antidisturbios les arrojaron huevos y pintura en polvo, creando nubes oscuras de polvo en las calles que normalmente estarían llenas de turistas.
Las peleas también estallaron más tarde en el día con la policía usando sus porras para contener los combates.
Durante varias horas, grupos independentistas que gritaban "No hay olvido, no hay perdón" se enfrentaron a manifestantes unionistas que gritaban "Viva España".
Catorce personas recibieron tratamiento por heridas leves recibidas en las protestas, informó la prensa local.
Las tensiones siguen siendo altas en la región independentista un año después del referéndum del 1 de octubre considerado ilegal por Madrid, pero celebrado por los separatistas catalanes.
Los votantes optaron abrumadoramente por ser independientes, aunque la participación fue baja y los que estaban en contra de la secesión boicotearon en gran medida el voto.
Según las autoridades catalanas, casi 1000 personas resultaron heridas el año pasado después de que la policía trató de detener la votación en los colegios electorales de toda la región en violentos enfrentamientos.
Los grupos independentistas habían acampado durante la noche del viernes para evitar una manifestación en apoyo de la policía nacional.
La manifestación continuó pero se vio obligada a tomar un camino diferente.
Narcis Termes, de 68 años, un electricista que asistió a la protesta separatista con su esposa, dijo que ya no tenía esperanzas sobre las perspectivas de la independencia de Cataluña.
"El año pasado vivimos uno de nuestros mejores momentos.
Vi a mis padres llorar de alegría por poder votar, pero ahora estamos atrapados", dijo.
A pesar de lograr una victoria vital aunque estrecha en las elecciones regionales del pasado diciembre, Los partidos pro-independencia catalanes han luchado por mantener el impulso este año con muchos de sus líderes más conocidos ya sea en el exilio autoimpuesto o en detención a la espera de juicio por su papel en la organización del referéndum y la posterior declaración de independencia.
Joan Puig, un mecánico de 42 años que grababa la protesta en apoyo de la policía en su teléfono, dijo que el conflicto había sido avivado por políticos de ambos lados.
"Se está poniendo cada vez más tenso", dijo.
El sábado, Oriol Junqueras, uno de los nueve líderes catalanes en prisión preventiva desde finales del año pasado, anunció que se presentaría a las elecciones al Parlamento Europeo el próximo año.
"Presentarme como candidato a las elecciones europeas es la mejor manera de denunciar la regresión en los valores democráticos y la represión que hemos visto por parte del gobierno español", dijo.
Londonderry: hombres arrestados después de que una casa fuera atropellada por un automóvil
Tres hombres, de 33, 34 y 39 años, han sido arrestados después de que un coche chocara repetidamente contra una casa en Londonderry.
El incidente ocurrió en Ballynagard Crescent el jueves alrededor de las 19:30 BST.
El inspector Bob Blemmings dijo que hubo daños en las puertas y en el edificio.
Una ballesta también puede haber sido disparada contra el coche en algún momento.
La huelga de Menga le da a Livingston una victoria por 1-0 sobre los Rangers .
El primer gol de Dolly Menga para Livingston aseguró la victoria
Promovido Livingston sorprendió a los Rangers para enviar a Steven Gerrard a su segunda derrota en 18 partidos como entrenador del club de Ibrox.
La huelga de Dolly Menga demostró ser la diferencia cuando el equipo de Gary Holt se unió al Hibernian en segundo lugar.
El equipo de Gerrard sigue sin una victoria fuera de casa en la Premier esta temporada y se enfrentará a los líderes Hearts, a los que siguen por ocho puntos, el próximo domingo.
Antes de eso, los Rangers reciben al Rapid Vienna en la Liga Europa el jueves.
Livingston, mientras tanto, extiende su racha invicta en la división a seis juegos, con el entrenador en jefe Holt todavía para saborear la derrota desde que reemplazó a Kenny Miler el mes pasado.
Livingston pierde las oportunidades contra los visitantes contundentes
El equipo de Holt debería haber estado adelante mucho antes de anotar, con su franqueza causando a los Rangers todo tipo de problemas.
Scott Robinson se abrió paso pero arrastró su esfuerzo a través de la cara de la portería, luego Alan Lithgow solo pudo dirigir su esfuerzo ampliamente después de deslizarse para encontrarse con el cabezazo de Craig Halkett a través de la portería.
Los anfitriones se contentaron con dejar a los Rangers jugar delante de ellos, sabiendo que podían molestar a los visitantes en las partidas establecidas.
Y esa fue la manera en que llegó el objetivo crucial.
Los Rangers concedieron un tiro libre y Livingston trabajó una apertura, Declan Gallagher y Robinson se combinaron para configurar a Menga, quien tomó un toque y anotó desde el centro de la caja.
En esa etapa, los Rangers habían dominado la posesión, pero habían encontrado la defensa de casa impenetrable y el portero Liam Kelly estaba en gran medida sin problemas,
Ese patrón continuó en la segunda mitad, aunque Alfredo Morelos forzó un salvamento de Kelly.
Scott Pittman fue rechazado por los pies del portero de los Rangers Allan McGregor y Lithgow lanzó de largo desde otro set de Livingston.
Las cruces continuamente entraron en la caja de Livingston y fueron continuamente eliminadas, mientras que dos reclamos de penalización, después del desafío de Halkett al sustituto Glenn Middleton, y uno para el balonmano, fueron retirados.
"Fenomenal" de Livingston - análisis
Alasdair Lamont de la BBC Escocia en el Tony Macaroni Arena
Una actuación y un resultado fenomenal para Livingston.
Para un hombre, fueron excelentes, continuando superando las expectativas en esta trayectoria ascendente.
Su estilo de juego y el personal apenas han cambiado desde su regreso a la máxima categoría, pero gran crédito tiene que ir a Holt por la forma en que ha galvanizado al equipo desde su llegada.
Tenía muchos héroes.
El capitán Halkett fue inmenso, organizando una defensa magníficamente organizada, mientras Menga mantuvo a Connor Goldson y Joe Worrall en sus pies.
Los guardabosques carecían de inspiración, sin embargo.
Por muy buenos que hayan sido a veces bajo Gerrard, quedaron muy por debajo de esos estándares.
Su bola final faltaba - sólo una vez cortaron el lado de casa abierto - y es algo así como una llamada de atención para los Rangers, que se encuentran en la mitad de la tabla.
Erdogan recibe una recepción mixta en Colonia
Hubo sonrisas y cielos azules el sábado (29 de septiembre) cuando los líderes de Turquía y Alemania se reunieron para desayunar en Berlín.
Es el último día de la polémica visita del presidente Erdogan a Alemania, cuyo objetivo es reparar las relaciones entre los aliados de la OTAN.
Se han peleado por cuestiones como los derechos humanos, la libertad de prensa y la adhesión de Turquía a la UE.
Erdogan luego se dirigió a Colonia para abrir una nueva mezquita gigante.
La ciudad es el hogar de la mayor población turca fuera de Turquía.
La policía citó razones de seguridad para evitar que una multitud de 25,000 personas se reuniera frente a la mezquita, pero muchos partidarios salieron cerca para ver a su presidente.
Cientos de manifestantes anti-Erdogan - muchos de ellos kurdos - también hicieron oír sus voces, condenando tanto las políticas de Erdogan como la decisión del gobierno alemán de darle la bienvenida al país.
Las protestas de duelo reflejan la división de un visitante aclamado como héroe por algunos turcos alemanes y insultado como un autócrata por otros.
Accidente de Deptford: un ciclista muere en una colisión con un automóvil
Un ciclista ha muerto en una colisión con un coche en Londres.
El accidente ocurrió cerca de la intersección de Bestwood Street y Evelyn Street, una calle muy transitada en Deptford, en el sureste de la ciudad, alrededor de las 10:15 BST.
El conductor del coche se detuvo y los paramédicos asistieron, pero el hombre murió en el lugar.
El accidente ocurre meses después de que otro ciclista muriera en un atropello en Childers Street, a una milla de distancia del accidente del sábado.
La Policía Metropolitana dijo que los oficiales estaban trabajando para identificar al hombre e informar a su pariente más cercano.
Se han establecido cierres de carreteras y desvíos de autobuses y se ha aconsejado a los automovilistas que eviten la zona.
Prisión de Long Lartin: Seis oficiales heridos en el desorden
Seis agentes penitenciarios resultaron heridos en un disturbio en una cárcel de hombres de alta seguridad, dijo la Oficina Penitenciaria.
El trastorno estalló en HMP Long Lartin en Worcestershire alrededor de las 09:30 BST el domingo y está en curso.
Oficiales especializados en "Tornado" han sido traídos para lidiar con el disturbio, que involucra a ocho reclusos y está contenido en un ala.
Los oficiales fueron tratados por lesiones faciales leves en la escena.
Un portavoz del Servicio Penitenciario dijo: "El personal penitenciario especialmente entrenado ha sido desplegado para hacer frente a un incidente en curso en HMP Long Lartin.
Seis miembros del personal han sido tratados por lesiones.
No toleramos la violencia en nuestras prisiones, y tenemos claro que los responsables serán remitidos a la policía y podrían pasar más tiempo tras las rejas".
HMP Long Lartin tiene más de 500 prisioneros, incluyendo algunos de los delincuentes más peligrosos del país.
En junio se informó que el gobernador de la prisión recibió tratamiento hospitalario después de haber sido atacado por un prisionero.
Y en octubre del año pasado los oficiales antidisturbios fueron llamados a la prisión para hacer frente a un grave disturbio en el que el personal fue atacado con pelotas de billar.
El huracán Rosa amenaza Phoenix, Las Vegas y Salt Lake City con inundaciones repentinas (las áreas secas pueden beneficiarse)
Es raro que una depresión tropical golpee Arizona, pero eso es exactamente lo que es probable que suceda a principios de la próxima semana, ya que las huellas de energía restantes del huracán Rosa a través del desierto suroeste, conllevan riesgos de inundaciones repentinas.
El Servicio Meteorológico Nacional ya ha emitido alertas de inundación repentina para el lunes y el martes para el oeste de Arizona en el sur y este de Nevada, sureste de California y Utah, incluyendo las ciudades de Phoenix, Flagstaff, Las Vegas y Salt Lake City.
Se espera que Rosa tome un camino directo sobre Phoenix el martes, acercándose tarde el lunes con lluvia.
El Servicio Meteorológico Nacional en Phoenix señaló en un tweet que solo "diez ciclones tropicales han mantenido el estatus de tormenta tropical o depresión dentro de 200 millas de Phoenix desde 1950!
Katrina (1967) fue un huracán dentro de las 40 millas de la frontera de Arizona".
Los últimos modelos del Centro Nacional de Huracanes predicen de 2 a 4 pulgadas de lluvia, con cantidades aisladas de hasta 6 pulgadas en el Mogollon Rim de Arizona.
Otras áreas del sudoeste del desierto, incluidas las Montañas Rocosas centrales y la Gran Cuenca, probablemente obtendrán de 1 a 2 pulgadas, con totales aislados de hasta 4 pulgadas posibles.
Para los que no corren el riesgo de inundaciones repentinas, la lluvia de Rosa puede ser una bendición, ya que la región está azotada por la sequía.
Aunque las inundaciones son una preocupación muy seria, algunas de estas lluvias probablemente serán beneficiosas ya que el suroeste actualmente está experimentando condiciones de sequía.
Según el Monitor de Sequía de los Estados Unidos, poco más del 40 por ciento de Arizona está experimentando al menos una sequía extrema, la segunda categoría más alta", informó weather.com.
Primero, la trayectoria del huracán Rosa lleva a tocar tierra a través de la península de Baja California en México.
Rosa, aún con fuerza de huracán el domingo por la mañana con vientos máximos de 85 millas por hora, está a 385 millas al sur de Punta Eugenia, México y se mueve hacia el norte a 12 millas por hora.
La tormenta está encontrando aguas más frías en el Pacífico y por lo tanto apagando.
Por lo tanto, se espera que toque tierra en México con fuerza de tormenta tropical en la tarde o la noche del lunes.
Las lluvias en partes de México podrían ser fuertes, lo que plantea un riesgo significativo de inundaciones.
"Se esperan precipitaciones totales de 3 a 6 pulgadas desde Baja California hasta el noroeste de Sonora, con hasta 10 pulgadas posibles", informó weather.com.
Rosa luego seguirá hacia el norte a través de México como una tormenta tropical antes de llegar a la frontera de Arizona en las primeras horas de la mañana del martes como una depresión tropical, que luego seguirá a través de Arizona y al sur de Utah a última hora del martes por la noche.
"El principal peligro que se espera de Rosa o de sus restos son las fuertes lluvias en Baja California, el noroeste de Sonora y el desierto suroeste de Estados Unidos", dijo el Centro Nacional de Huracanes.
Se espera que estas lluvias produzcan inundaciones repentinas y flujos de escombros que ponen en peligro la vida en los desiertos, y deslizamientos de tierra en terrenos montañosos.
El ataque de Midsomer Norton: cuatro detenciones por intento de asesinato
Tres adolescentes y un hombre de 20 años han sido arrestados bajo sospecha de intento de asesinato después de que un joven de 16 años fue encontrado con heridas de arma blanca en Somerset.
El adolescente fue encontrado herido en la zona de Excelsior Terrace de Midsomer Norton, alrededor de las 04:00 BST el sábado.
Fue llevado al hospital donde permanece en una condición "estable".
Un joven de 17 años, dos de 18 años y un hombre de 20 años fueron arrestados durante la noche en el área de Radstock, dijo la policía de Avon y Somerset.
Los oficiales han pedido a cualquiera que tenga alguna grabación de lo ocurrido que se presente.
Trump dice que Kavanaugh 'sufría, la mezquindad, la ira' del Partido Demócrata
"Un voto por el juez Kavanaugh es un voto para rechazar las tácticas despiadadas y escandalosas del Partido Demócrata", dijo Trump en un mitin en Wheeling, Virginia Occidental.
Trump dijo que Kavanaugh ha "sufrido la mezquindad, la ira" del Partido Demócrata a lo largo de su proceso de nominación.
Kavanaugh testificó ante el Congreso el jueves, negando con fuerza y emoción una acusación de Christine Blasey Ford de que la agredió sexualmente hace décadas cuando eran adolescentes.
Ford también testificó en la audiencia sobre su acusación.
El presidente dijo el sábado que el "pueblo estadounidense vio la brillantez y la calidad y el coraje" de Kavanaugh ese día.
"Un voto para confirmar al juez Kavanaugh es un voto para confirmar a una de las mentes legales más consumadas de nuestro tiempo, un jurista con un excelente historial de servicio público", dijo a la multitud de partidarios de Virginia Occidental.
El presidente se refirió indirectamente a la nominación de Kavanaugh mientras hablaba de la importancia de la participación republicana en las elecciones de mitad de período.
"A cinco semanas de una de las elecciones más importantes de nuestras vidas.
No estoy corriendo, pero realmente estoy corriendo", dijo.
"Es por eso que estoy en todo el lugar luchando por grandes candidatos".
Trump argumentó que los demócratas están en una misión de "resistir y obstruir".
Se espera que la primera votación procedimental clave en el Senado sobre la nominación de Kavanaugh tenga lugar a más tardar el viernes, dijo a CNN un alto asesor de liderazgo del Partido Republicano.
Cientos de muertos por el terremoto y el tsunami de Indonesia, y se espera que la cifra aumente
Al menos 384 personas murieron, muchas arrastradas por olas gigantes que chocaron contra las playas, cuando un gran terremoto y tsunami golpearon la isla indonesia de Sulawesi, dijeron las autoridades el sábado.
Cientos de personas se habían reunido para un festival en la playa de la ciudad de Palu el viernes cuando olas de hasta seis metros (18 pies) azotaron la costa al anochecer, matando a muchos y destruyendo todo a su paso.
El tsunami siguió a un terremoto de magnitud 7.5.
"Cuando la amenaza de tsunami surgió ayer, la gente todavía estaba haciendo sus actividades en la playa y no corrieron de inmediato y se convirtieron en víctimas", dijo Sutopo Purwo Nugroho, portavoz de la agencia de mitigación de desastres de Indonesia BNPB en una sesión informativa en Yakarta.
"El tsunami no vino solo, arrastró coches, troncos, casas, golpeó todo en tierra", dijo Nugroho, y agregó que el tsunami había viajado a través del mar abierto a velocidades de 800 kph (497 mph) antes de golpear la costa.
Algunas personas treparon a los árboles para escapar del tsunami y sobrevivieron, dijo.
Alrededor de 16.700 personas fueron evacuadas a 24 centros en Palu.
Las fotografías aéreas publicadas por la agencia de desastres mostraron muchos edificios y tiendas destruidos, puentes retorcidos y colapsados y una mezquita rodeada de agua.
Las réplicas continuaron sacudiendo la ciudad costera el sábado.
La serie de terremotos se sintieron en un área con 2,4 millones de personas.
La Agencia de Indonesia para la Evaluación y Aplicación de la Tecnología (BPPT) dijo en un comunicado que la energía liberada por el terremoto masivo del viernes era alrededor de 200 veces la potencia de la bomba atómica lanzada sobre Hiroshima en la Segunda Guerra Mundial.
La geografía de la ciudad, que se encuentra al final de una bahía larga y estrecha, podría haber magnificado el tamaño del tsunami, dijo.
Nugroho describió el daño como "extenso" y dijo que miles de casas, hospitales, centros comerciales y hoteles se habían derrumbado.
Los cuerpos de algunas víctimas fueron encontrados atrapados bajo los escombros de los edificios derrumbados, dijo, y agregó que 540 personas resultaron heridas y 29 estaban desaparecidas.
Nugroho dijo que las bajas y el daño podrían ser mayores a lo largo de la costa a 300 km al norte de Palu, un área llamada Donggala, que está más cerca del epicentro del terremoto.
Las comunicaciones "estaban totalmente paralizadas sin información" de Donggala, dijo Nugroho.
Hay más de 300.000 personas viviendo allí", dijo la Cruz Roja en un comunicado, y agregó que su personal y voluntarios se dirigían a las áreas afectadas.
"Esto ya es una tragedia, pero podría ser mucho peor", dijo.
El sábado, la agencia fue ampliamente criticada por no informar que un tsunami había golpeado Palu, aunque los funcionarios dijeron que las olas habían llegado en el momento en que se emitió la advertencia.
En imágenes de aficionados compartidas en las redes sociales se puede escuchar a un hombre en el piso superior de un edificio gritando frenéticamente advertencias del tsunami que se acerca a las personas en la calle de abajo.
En cuestión de minutos, una muralla de agua choca contra la orilla, arrastrando edificios y automóviles.
Reuters no pudo verificar de inmediato la autenticidad de las imágenes.
El terremoto y el tsunami causaron un gran corte de energía que cortó las comunicaciones alrededor de Palu, lo que dificultó a las autoridades coordinar los esfuerzos de rescate.
El ejército ha comenzado a enviar aviones de carga con ayuda desde Yakarta y otras ciudades, dijeron las autoridades, pero los evacuados todavía necesitan alimentos y otras necesidades básicas.
El aeropuerto de la ciudad se ha reabierto solo para los esfuerzos de socorro y permanecerá cerrado hasta Oct.
El presidente Joko Widodo estaba programado para visitar los centros de evacuación en Palu el domingo.
El número de víctimas del tsunami en Indonesia se eleva por encima de los 800.
Es muy malo.
Mientras que el personal de World Vision de Donggala ha llegado a salvo a la ciudad de Palu, donde los empleados se están refugiando en refugios de lona establecidos en el patio de su oficina, pasaron por escenas de devastación en el camino, dijo el Sr. Doseba.
"Me dijeron que vieron muchas casas que fueron destruidas", dijo.
Es muy malo.
Incluso cuando los grupos de ayuda comenzaron los movimientos sombríos de encender los engranajes de socorro de desastres, algunos se quejaron de que a los trabajadores de ayuda extranjeros con profunda experiencia se les impedía viajar a Palu.
Según las regulaciones indonesias, la financiación, los suministros y el personal del extranjero solo pueden comenzar a fluir si el sitio de una calamidad se declara una zona de desastre nacional.
Eso aún no ha sucedido.
"Todavía es un desastre a nivel provincial", dijo Aulia Arriani, portavoz de la Cruz Roja de Indonesia.
"Una vez que el gobierno diga, "OK, esto es un desastre nacional", podemos abrirnos para la asistencia internacional pero aún no hay estatus".
A medida que caía la segunda noche en Palu después del terremoto y el tsunami del viernes, los amigos y familiares de los que aún estaban desaparecidos mantenían la esperanza de que sus seres queridos fueran los milagros que levaduran las tristes líneas narrativas de los desastres naturales.
El sábado, un niño fue sacado de una alcantarilla.
El domingo, los rescatistas liberaron a una mujer que había estado atrapada bajo los escombros durante dos días con el cuerpo de su madre a su lado.
Gendon Subandono, el entrenador del equipo nacional de parapente de Indonesia, había entrenado a dos de los parapentes desaparecidos para los Juegos Asiáticos, que concluyeron a principios de este mes en Indonesia.
Otros de los atrapados en el Hotel Roa Roa, incluido el Sr. Mandagi, eran sus estudiantes.
"Como mayor en el campo del parapente, tengo mi propia carga emocional", dijo.
El Sr. Gendon contó cómo, en las horas después de que la noticia del colapso del Hotel Roa Roa circuló entre la comunidad de parapente, había enviado desesperadamente mensajes de WhatsApp a los competidores de Palu, que estaban participando en el festival de playa.
Sus mensajes, sin embargo, sólo resultaron en una marca de verificación gris, en lugar de un par de cheques azules.
"Creo que eso significa que los mensajes no fueron entregados", dijo.
Los ladrones toman $ 26,750 durante el reabastecimiento de cajeros automáticos en Newport en el Levee
Los ladrones el viernes por la mañana robaron $ 26,750 de un trabajador de Brink que llenaba un cajero automático en Newport en el Levee, según un comunicado de prensa del Departamento de Policía de Newport.
El conductor del coche había estado vaciando un cajero automático en el complejo de entretenimiento y preparándose para entregar más dinero, Det. Dennis McCarthy escribió en el comunicado.
Mientras él estaba ocupado, otro hombre "se acercó corriendo por detrás del empleado de Brink" y robó una bolsa de dinero que debía ser entregada.
Los testigos vieron a varios sospechosos huyendo de la escena, según el comunicado, pero la policía no especificó el número involucrado en el incidente.
Cualquiera que tenga información sobre sus identidades debe comunicarse con la policía de Newport al 859-292-3680.
Kanye West: El rapero cambia su nombre a Ye
El rapero Kanye West está cambiando su nombre a Ye.
Anunciando el cambio en Twitter el sábado, escribió: "El ser formalmente conocido como Kanye West".
West, de 41 años, ha sido apodado Ye por algún tiempo y usó el apodo como el título de su octavo álbum, que fue lanzado en junio.
El cambio se produce antes de su aparición en Saturday Night Live, donde se espera que lance su nuevo álbum Yandhi.
Él reemplaza a la cantante Ariana Grande en el programa que canceló por "razones emocionales", dijo el creador del programa.
Además de ser una abreviatura de su actual nombre profesional, West ha dicho anteriormente que la palabra tiene un significado religioso para él.
"Creo que 'ye' es la palabra más comúnmente usada en la Biblia, y en la Biblia significa 'tú'", dijo West a principios de este año, discutiendo el título de su álbum con el presentador de radio Big Boy.
"Así que soy tú, soy nosotros, somos nosotros.
Pasó de Kanye, que significa el único, a sólo Ye - sólo ser un reflejo de nuestro bien, nuestro mal, nuestra confusión, todo.
El álbum es más un reflejo de quiénes somos".
Es uno de varios raperos famosos que cambiaron su nombre.
Sean Combs ha sido conocido como Puff Daddy, P. Diddy o Diddy, pero este año anunció su preferencia por los nombres Love y Brother Love.
Un ex colaborador de West, JAY-Z, también se ha conformado con o sin un guión y mayúsculas.
El AMLO de México promete no usar el ejército contra civiles
El presidente electo de México, Andrés Manuel López Obrador, ha prometido nunca usar la fuerza militar contra civiles mientras el país se acerca al 50 aniversario de una sangrienta represalia contra los estudiantes.
López Obrador prometió el sábado en la Plaza Tlatelolco "nunca utilizará el ejército para reprimir al pueblo mexicano".
Las tropas dispararon contra una manifestación pacífica en la plaza el 2 de octubre de 1968, matando a hasta 300 personas en un momento en que los movimientos estudiantiles de izquierda estaban echando raíces en toda América Latina.
López Obrador se ha comprometido a apoyar a los jóvenes mexicanos dando subsidios mensuales a aquellos que estudian y abriendo más universidades públicas gratuitas.
Ha dicho que el desempleo y la falta de oportunidades educativas atraen a los jóvenes a las pandillas criminales.
EE.UU. debería duplicar el financiamiento de la I.A.
A medida que China se vuelve más activa en la inteligencia artificial, Estados Unidos debería duplicar la cantidad que gasta en investigación en el campo, dice el inversor y practicante de IA Kai-Fu Lee, que ha trabajado para Google, Microsoft y Apple.
Los comentarios se producen después de que varias partes del gobierno de los Estados Unidos hayan hecho anuncios de IA, incluso cuando los Estados Unidos en general carecen de una estrategia formal de IA.
Mientras tanto, China presentó su plan el año pasado: su objetivo es ser el número uno en innovación de IA para 2030.
"Duplicar el presupuesto de investigación de IA sería un buen comienzo, dado que todos los demás países están mucho más atrás que Estados Unidos, y estamos buscando el próximo avance en IA", dijo Lee.
La duplicación de la financiación podría duplicar las posibilidades de que el próximo gran logro de IA se realice en los Estados Unidos, dijo Lee a CNBC en una entrevista esta semana.
Lee, cuyo libro "Superpotencias de IA: China, Silicon Valley y el Nuevo Orden Mundial" fue publicado este mes por Houghton Mifflin Harcourt, es CEO de Sinovation Ventures, que ha invertido en una de las compañías de IA más prominentes de China, Face ++.
En la década de 1980 en la Universidad Carnegie Mellon trabajó en un sistema de inteligencia artificial que venció al jugador estadounidense de Othello mejor clasificado, y más tarde fue ejecutivo de Microsoft Research y presidente de la sucursal china de Google.
Lee reconoció las anteriores competiciones tecnológicas del gobierno de los Estados Unidos como el Desafío de Robótica de la Agencia de Proyectos de Investigación Avanzada de Defensa y preguntó cuándo sería el próximo, para ayudar a identificar a los próximos visionarios.
Los investigadores en los EE.UU. a menudo tienen que trabajar duro para ganar subvenciones del gobierno, dijo Lee.
"No es China la que se está llevando a los líderes académicos; son las corporaciones", dijo Lee.
Facebook, Google y otras compañías tecnológicas han contratado a luminarias de universidades para trabajar en IA en los últimos años.
Lee dijo que los cambios en la política de inmigración también podrían ayudar a los Estados Unidos a reforzar sus esfuerzos de IA.
"Creo que las tarjetas verdes deberían ofrecerse automáticamente a los doctorados en IA", dijo.
El Consejo de Estado de China emitió su Plan de Desarrollo de Inteligencia Artificial de Nueva Generación en julio de 2017.
La Fundación Nacional de Ciencias Naturales de China proporciona fondos a personas en instituciones académicas similares a la forma en que la Fundación Nacional de Ciencias y otras organizaciones gubernamentales reparten dinero a investigadores estadounidenses, Pero la calidad del trabajo académico es más baja en China, dijo Lee.
A principios de este año, el Departamento de Defensa de los Estados Unidos estableció un Centro Conjunto de Inteligencia Artificial, que está destinado a involucrar a socios de la industria y el mundo académico, y la Casa Blanca anunció la formación de un Comité Selecto de Inteligencia Artificial.
Y este mes DARPA anunció una inversión de 2 mil millones de dólares en una iniciativa llamada AI Next.
En cuanto a la NSF, actualmente invierte más de $ 100 millones por año en investigación de IA.
Mientras tanto, la legislación estadounidense que buscaba crear una Comisión de Seguridad Nacional sobre Inteligencia Artificial no ha visto acción en meses.
Los macedonios votan en el referéndum sobre si cambiar el nombre del país
El pueblo de Macedonia votó en un referéndum el domingo sobre si cambiar su nombre a "República de Macedonia del Norte", una medida que resolvería una disputa de décadas con Grecia que había bloqueado sus ofertas de membresía para la Unión Europea y la OTAN.
Grecia, que tiene una provincia llamada Macedonia, sostiene que el nombre de su vecino del norte representa un reclamo sobre su territorio y ha vetado su entrada en la OTAN y la UE.
Los dos gobiernos llegaron a un acuerdo en junio basado en el nuevo nombre propuesto, pero los opositores nacionalistas argumentan que el cambio socavaría la identidad étnica de la población de mayoría eslava de Macedonia.
El presidente Gjorge Ivanov ha dicho que no votará en el referéndum y una campaña de boicot ha arrojado dudas sobre si la participación alcanzará el mínimo del 50 por ciento requerido para que el referéndum sea válido.
La pregunta en la boleta del referéndum decía: "¿Está usted a favor de la adhesión a la OTAN y a la UE con la aceptación del acuerdo con Grecia?".
Los partidarios del cambio de nombre, incluido el primer ministro Zoran Zaev, argumentan que es un precio que vale la pena pagar para buscar la admisión en organismos como la UE y la OTAN para Macedonia, uno de los países que surgieron del colapso de Yugoslavia.
"He venido hoy a votar por el futuro del país, por los jóvenes de Macedonia para que puedan vivir libremente bajo el paraguas de la Unión Europea porque significa vidas más seguras para todos nosotros", dijo Olivera Georgijevska, de 79 años, en Skopje.
Aunque no es jurídicamente vinculante, bastantes miembros del parlamento han dicho que respetarán el resultado de la votación para que sea decisivo.
El cambio de nombre requeriría una mayoría de dos tercios en el parlamento.
La comisión electoral estatal dijo que no había habido informes de irregularidades hasta la 1 p.m.
Sin embargo, la participación fue de solo el 16 por ciento, en comparación con el 34 por ciento en la última elección parlamentaria en 2016, cuando el 66 por ciento de los votantes registrados emitieron su voto.
"Salí a votar por mis hijos, nuestro lugar es en Europa", dijo Gjose Tanevski, de 62 años, un votante de la capital, Skopje.
El primer ministro de Macedonia, Zoran Zaev, su esposa Zorica y su hijo Dushko votaron por el referéndum en Macedonia sobre el cambio de nombre del país que abriría el camino para que se una a la OTAN y la Unión Europea en Strumica, Macedonia, el 30 de septiembre de 2018.
Frente al parlamento en Skopje, Vladimir Kavardarkov, de 54 años, estaba preparando un pequeño escenario y levantando sillas frente a las tiendas montadas por aquellos que boicotearán el referéndum.
"Estamos a favor de la OTAN y la UE, pero queremos unirnos con la cabeza en alto, no a través de la puerta de servicio", dijo Kavadarkov.
"Somos un país pobre, pero tenemos dignidad.
Si no quieren tomarnos como Macedonia, podemos recurrir a otros como China y Rusia y convertirnos en parte de la integración euroasiática".
El primer ministro Zaev dice que la membresía de la OTAN traerá la inversión muy necesaria a Macedonia, que tiene una tasa de desempleo de más del 20 por ciento.
"Creo que la gran mayoría estará a favor porque más del 80 por ciento de nuestros ciudadanos están a favor de la UE y la OTAN", dijo Zaev después de emitir su voto.
Dijo que un resultado de "sí" sería "la confirmación de nuestro futuro".
Una encuesta publicada el lunes pasado por el Instituto de Investigación Política de Macedonia dijo que entre el 30 y el 43 por ciento de los votantes participarían en el referéndum, por debajo de la participación requerida.
Otra encuesta, realizada por la televisión Telma de Macedonia, encontró que el 57 por ciento de los encuestados planea votar el domingo.
De ellos, el 70 por ciento dijo que votaría sí.
Para que el referéndum sea exitoso, la participación debe ser del 50 por ciento más un voto.
Un fracaso en el referéndum representaría el primer golpe serio a la política del gobierno pro-occidental desde que asumió el poder en mayo del año pasado.
Vea: Sergio Aguero de Manchester City navega a través de toda la defensa de Brighton para el gol
Sergio Aguero y Raheem Sterling despidieron a la defensa de Brighton en la victoria de Manchester City por 2-0 el sábado en el Etihad Stadium en Manchester, Inglaterra.
Aguero lo hizo parecer ridículamente fácil en su puntuación en el minuto 65.
El delantero argentino recibió un pase en el mediocampo al comienzo de la secuencia.
Corrió entre tres defensores de Brighton, antes de cortar en el campo abierto.
Aguero entonces se encontró rodeado por cuatro camisas verdes.
Empujó alrededor de un defensor antes de superar a varios más en el borde de la caja de Brighton.
Luego empujó un pase a su izquierda, encontrando a Sterling.
El delantero inglés usó su primer toque en la caja para devolver el balón a Aguero, quien usó su bota derecha para vencer al portero de Brighton Mathew Ryan con un disparo en el lado derecho de la red.
"Aguero está luchando con algunos problemas en sus pies", dijo el gerente del City, Pep Guardiola, a los periodistas.
"Hablamos de él jugando 55, 60 minutos.
Eso es lo que pasó.
Tuvimos suerte de que marcara un gol en ese momento".
Pero fue Sterling quien dio a los Sky Blues la ventaja inicial en la pelea de la Premier League.
Ese gol llegó en el minuto 29.
Aguero recibió el balón en el territorio de Brighton en esa jugada.
Envió una hermosa pelota a lo largo del flanco izquierdo a Leroy Sane.
Sane tomó algunos toques antes de llevar a Sterling hacia el poste más alejado.
El delantero de los Sky Blues metió el balón en la red justo antes de deslizarse fuera de los límites.
El City se enfrenta al Hoffenheim en la fase de grupos de la Liga de Campeones el martes a las 12:55 p.m. en el Rhein-Neckar-Arena en Sinsheim, Alemania.
Scherzer quiere jugar al spoiler contra los Rockies.
Con los Nacionales eliminados de la disputa por los playoffs, no había mucha razón para forzar otro comienzo.
Pero el siempre competitivo Scherzer espera tomar el montículo el domingo contra los Rockies de Colorado, pero solo si todavía hay implicaciones en los playoffs para los Rockies, que tienen una ventaja de un juego sobre los Dodgers de Los Ángeles en la División Oeste de la Liga Nacional.
Los Rockies se aseguraron al menos un puesto de comodín con una victoria de 5-2 sobre los Nacionales el viernes por la noche, pero aún buscan asegurar su primer título de división.
"A pesar de que estamos jugando por nada, al menos podemos ser capaces de poner el dedo en la goma sabiendo que la atmósfera aquí en Denver con la multitud y el otro equipo estaría jugando a probablemente el más alto nivel de cualquier punto que enfrentaría este año.
¿Por qué no querría competir en eso?"
Los Nacionales aún no han anunciado un titular para el domingo, pero se dice que están dispuestos a dejar que Scherzer lance en tal situación.
Scherzer, que haría su 34o inicio, lanzó una sesión de bullpen el jueves y lanzaría en su descanso normal el domingo.
El derecho de Washington tiene 18-7 con una efectividad de 2.53 y 300 ponches en 220 2/3 entradas esta temporada.
Trump se reúne en Virginia Occidental
El presidente se refirió oblicuamente a la situación que rodea a su elección de la Corte Suprema Brett Kavanaugh mientras hablaba de la importancia de la participación republicana en las elecciones de mitad de período.
"Todo lo que hemos hecho está en juego en noviembre.
A cinco semanas de una de las elecciones más importantes de nuestras vidas.
Este es uno de los grandes, grandes - no estoy corriendo pero realmente estoy corriendo es por eso que estoy en todo el lugar luchando por grandes candidatos", dijo.
Trump continuó: "Ves este horrible, horrible grupo radical de demócratas, lo ves sucediendo ahora mismo.
Y están decididos a recuperar el poder usando cualquier medio necesario, ves la maldad, la maldad.
No les importa a quién lastiman, a quién tienen que atropellar para obtener poder y control, eso es lo que quieren es poder y control, no se lo vamos a dar".
Los demócratas, dijo, están en una misión de "resistir y obstruir".
"Y lo ves en los últimos cuatro días", dijo, llamando a los demócratas "enfurecidos, malvados, desagradables y falsos".
Se refirió al Comité Judicial del Senado clasificando a la senadora demócrata Dianne Feinstein por su nombre, que recibió fuertes abucheos de la audiencia.
"¿Recuerdas su respuesta?
¿Usted filtró el documento?
Uh, uh, qué.
No, uh no, espero uno - que era muy mal lenguaje corporal - el peor lenguaje corporal que he visto nunca. "
El Partido Laborista ya no es una iglesia amplia.
Es intolerante con los que dicen lo que piensan.
Cuando los activistas de Momentum en mi partido local votaron para censurarme, no fue una sorpresa.
Después de todo, soy el último en una línea de diputados laboristas a los que se les dice que no somos bienvenidos, todo por decir lo que pensamos.
Mi colega parlamentaria Joan Ryan recibió un trato similar porque se opuso resueltamente al antisemitismo.
En mi caso, la moción de censura me criticó por estar en desacuerdo con Jeremy Corbyn.
Sobre la importancia de una política económica responsable, sobre la seguridad nacional, sobre Europa, cuestiones irónicamente similares en las que Jeremy no estaba de acuerdo con los líderes anteriores.
El aviso para la reunión laborista de Nottingham East el viernes decía que "queremos que las reuniones sean inclusivas y productivas".
Durante la mayor parte de mis ocho años como diputado laborista local, las reuniones del Comité General del viernes por la noche han sido exactamente eso.
Lamentablemente hoy en día, no es el tono de muchas reuniones y la promesa de una política "más amable y gentil" ha sido olvidada hace mucho tiempo, si es que alguna vez comenzó.
Se ha hecho cada vez más evidente que las opiniones diferentes no son toleradas en el Partido Laborista y cada opinión es juzgada en función de si es aceptable para la dirección del partido.
Esto comenzó poco después de que Jeremy se convirtió en líder, Como colegas con los que antes pensaba que compartía una perspectiva política similar comenzaron a esperar que hiciera un giro de 180 grados y tomara posiciones con las que de otro modo nunca habría estado de acuerdo, ya sea sobre la seguridad nacional o el mercado único de la UE.
Cada vez que hablo en público - y en realidad no importa lo que diga - se sigue una diatriba de abusos en las redes sociales pidiendo la deselección, denunciando la política del centro, diciéndome que no debería estar en el Partido Laborista.
Y esa no es solo mi experiencia.
De hecho, sé que soy más afortunado que algunos de mis colegas, ya que los comentarios dirigidos a mí tienden a ser políticos.
Estoy asombrada por la profesionalidad y la determinación de esos colegas que se enfrentan a un torrente de abusos sexistas o racistas todos los días, pero que nunca huyen.
Uno de los aspectos más decepcionantes de esta era de la política es cómo los niveles de abuso se han normalizado.
Jeremy Corbyn afirmó la semana pasada que el Partido Laborista debería fomentar una cultura de tolerancia.
La realidad es que ya no somos esa amplia iglesia y con cada moción de "no confianza" o cambio de las reglas de selección el partido se vuelve más estrecho.
He recibido muchos consejos en los últimos dos años instándome a mantener la cabeza baja, a no ser tan vocal y entonces estaría "bien".
Pero no es para eso que vine a la política.
Desde que me uní al Partido Laborista hace 32 años como alumno de escuela, provocado por la negligencia del gobierno de Thatcher que había dejado mi aula de escuela básica literalmente cayendo, he buscado defender mejores servicios públicos para aquellos que más los necesitan - ya sea como concejal local o ministro del gobierno.
Nunca he ocultado mi política, incluso en las últimas elecciones.
Nadie en Nottingham East podría haber estado de alguna manera confundido sobre mis posiciones políticas y áreas de desacuerdo con el liderazgo actual.
A los que promovieron la moción el viernes, todo lo que diría es que cuando el país está arando hacia un Brexit que perjudicará a los hogares, las empresas y nuestros servicios públicos, no entiendo el deseo de perder tiempo y energía en mi lealtad al líder del Partido Laborista.
Pero realmente el único mensaje que tengo no es para Nottingham Momentum, es para mis electores, ya sean miembros del Partido Laborista o no: Me enorgullece servirles y prometo que ninguna cantidad de amenazas de deselección o conveniencia política me disuadirán de actuar en lo que creo que son los mejores intereses de todos ustedes.
Chris Leslie es diputado por Nottingham East
Ayr 38 - 17 Melrose: El invicto Ayr está en la cima
Dos intentos tardíos pueden haber sesgado el resultado final un poco, pero no hay duda de que Ayr merecía triunfar en este maravilloso y entretenido partido de la Premiership del día de Tennent.
Ahora están en la cima de la tabla, el único equipo invicto de los diez.
Al final, fue su defensa superior, tanto como su mejor toma de riesgos, lo que llevó al equipo local y el entrenador Peter Murchie tenía todo el derecho a estar satisfecho.
"Hemos sido probados en nuestros juegos hasta ahora, y todavía estamos invictos, así que tengo que estar feliz", dijo.
Robyn Christie de Melrose dijo: "Crédito a Ayr, tomaron sus oportunidades mejor que nosotros".
El intento de Grant Anderson en el minuto 14, convertido por Frazier Climo, puso a Ayr al frente, pero, una tarjeta amarilla para el capitán de Escocia Rory Hughes, liberado para el juego por los Warriors, permitió a Melrose hacer que los números dijeran y Jason Baggot agarró un intento no convertido.
Climo extendió la ventaja de Ayr con un penal, antes, justo en el descanso, anotó y luego convirtió un intento en solitario para que fuera 17-5 para Ayr en el descanso.
Pero Melrose comenzó bien la segunda mitad y el intento de Patrick Anderson, convertido por Baggot, redujo el margen a cinco puntos.
Luego hubo un largo retraso por una lesión grave de Ruaridh Knott, que estaba en camilla, y desde el reinicio, Ayr avanzó más a través de un intento de Stafford McDowall, convertido por Climo.
El capitán en funciones de Ayr, Blair Macpherson, recibió una tarjeta amarilla, y de nuevo, Melrose hizo que el hombre extra pagara con un intento no convertido de Bruce Colvine, al final de un período de feroz presión.
Sin embargo, el equipo local regresó, y cuando Struan Hutchinson recibió una tarjeta amarilla por abordar a Climo sin la pelota, desde la línea de penalti, MacPherson tocó en la parte posterior del maul de Ayr que avanzaba.
Climo se convirtió, como lo hizo de nuevo casi desde el reinicio, después de que Kyle Rowe recogiera la patada de David Armstrong y enviara al flanquero Gregor Henry para el quinto intento del equipo local.
Aún así, la estrella del juego parece preparada para una nueva carrera en la industria de restaurantes.
La estrella de Still Game Ford Kieran parece preparada para entrar en la industria de la hospitalidad después de que se descubrió que fue nombrado director de una compañía de restaurantes con licencia.
El actor de 56 años interpreta a Jack Jarvis en el popular programa de la BBC, que escribe y coprotagoniza con su compañero de comedia Greg Hemphill.
El dúo ha anunciado que la próxima novena temporada será la última de la serie, y parece que Kiernan está planeando para la vida después de Craiglang.
Según los registros oficiales, es el director de Adriftmorn Limited.
El actor se negó a comentar sobre la historia, aunque una fuente del Scottish Sun insinuó que Kiernan estaba buscando involucrarse en el "próspero comercio de restaurantes" de Glasgow.
'El mar es nuestro': Bolivia sin litoral espera que el tribunal reabra el camino hacia el Pacífico
Los marineros patrullan una sede naval en La Paz.
Los edificios públicos llevan una bandera azul océano.
Las bases navales desde el lago Titicaca hasta el Amazonas están pintadas con el lema: "El mar es nuestro por derecho.
Recuperarlo es un deber".
En toda Bolivia, que no tiene salida al mar, el recuerdo de una costa perdida por Chile en un sangriento conflicto de recursos del siglo XIX sigue vivo, al igual que el anhelo de navegar por el Océano Pacífico una vez más.
Esas esperanzas están tal vez en su punto más alto en décadas, ya que Bolivia espera un fallo de la corte internacional de justicia el 1 de octubre después de cinco años de deliberaciones.
"Bolivia tiene el impulso, un espíritu de unidad y serenidad, y por supuesto está esperando con una visión positiva el resultado", dijo Roberto Calzadilla, un diplomático boliviano.
Muchos bolivianos verán el fallo de la CIJ en grandes pantallas en todo el país, con la esperanza de que el tribunal de La Haya decida a favor de la afirmación de Bolivia de que - después de décadas de discusiones irregulares - Chile está obligado a negociar otorgando a Bolivia una salida soberana al mar.
Evo Morales, el carismático presidente indígena de Bolivia, que se enfrenta a una polémica batalla por la reelección el próximo año, también tiene mucho en juego en el fallo del lunes.
"Estamos muy cerca de regresar al Océano Pacífico", prometió a finales de agosto.
Pero algunos analistas creen que es poco probable que la corte decida a favor de Bolivia, y que poco cambiaría si lo hiciera.
El organismo de la ONU con sede en los Países Bajos no tiene poder para otorgar territorio chileno, y ha estipulado que no determinará el resultado de posibles conversaciones.
El hecho de que el fallo de la CIJ se produzca solo seis meses después de que se escucharan los argumentos finales indica que el caso "no era complicado", dijo Paz Zárate, un experto chileno en derecho internacional.
Y lejos de promover la causa de Bolivia, los últimos cuatro años pueden haberlo hecho retroceder.
"La cuestión del acceso al mar ha sido secuestrada por la actual administración boliviana", dijo Zárate.
La retórica beligerante de Morales ha socavado cualquier buena voluntad chilena residual, sugirió.
Bolivia y Chile seguirán hablando en algún momento, pero será extremadamente difícil mantener conversaciones después de esto.
Los dos países no han intercambiado embajadores desde 1962.
El ex presidente Eduardo Rodríguez Veltzé, representante de Bolivia en La Haya, rechazó la idea de que la toma de decisiones de la corte fue inusualmente rápida.
El lunes traerá a Bolivia "una oportunidad extraordinaria para abrir una nueva era de relaciones con Chile" y una oportunidad para "poner fin a 139 años de desacuerdos con beneficios mutuos", dijo.
Calzadilla también negó que Morales - todavía uno de los presidentes más populares de América Latina - estuviera usando la cuestión marítima como una muleta política.
"Bolivia nunca renunciará a su derecho a tener acceso al Océano Pacífico", añadió.
"El fallo es una oportunidad para ver que necesitamos superar el pasado".
Corea del Norte dice que el desarme nuclear no vendrá a menos que pueda confiar en EE.UU.
El ministro de Relaciones Exteriores de Corea del Norte, Ri Yong Ho, dice que su nación nunca desarmará primero sus armas nucleares si no puede confiar en Washington.
Ri estaba hablando el sábado en la Asamblea General de las Naciones Unidas.
El Presidente de la Comisión de Asuntos Económicos y Monetarios y de Política Industrial, el Sr. Giscard d'Estaing, ha expresado su satisfacción por el éxito de las negociaciones entre la Unión Europea y el Reino Unido.
Sus comentarios vienen como nosotros. El secretario de Estado Mike Pompeo parece estar a punto de reanudar la diplomacia nuclear estancada más de tres meses después de Singapur con Kim Jong Un de Corea del Norte.
Ri dice que es un "sueño imposible" que las continuas sanciones y la objeción de Estados Unidos a una declaración que ponga fin a la Guerra de Corea lleven alguna vez al Norte de rodillas.
Washington es cauteloso de aceptar la declaración sin que Pyongyang primero haga movimientos significativos de desarme.
Tanto Kim como el presidente de los Estados Unidos, Donald Trump, quieren una segunda cumbre.
Pero hay un escepticismo generalizado de que Pyongyang esté hablando en serio acerca de renunciar a un arsenal que el país probablemente ve como la única manera de garantizar su seguridad.
Pompeo planea visitar Pyongyang el próximo mes para prepararse para una segunda cumbre Kim-Trump.
Los desfiles de moda de París revelan la última línea de sombreros masivos en su camino a una calle principal cerca de usted.
Si quieres aumentar tu colección de sombreros o bloquear completamente el sol entonces no busques más.
Los diseñadores Valentino y Thom Browne dieron a conocer una serie de extravagantes accesorios de cabeza de gran tamaño para su colección SS19 en la pasarela que deslumbró el conjunto de estilo en la Semana de la Moda de París.
Los sombreros muy poco prácticos han barrido Instagram este verano y estos diseñadores han enviado sus creaciones llamativas por la pasarela.
La pieza destacada de Valentino era un sombrero beige exagerado adornado con un borde ancho parecido a una pluma que inundaba las cabezas de las modelos.
Otros accesorios de gran tamaño incluyen sandías con joyas, un sombrero de mago e incluso una piña, pero no están diseñados para mantener la cabeza caliente.
Thom Browne también reveló una selección de máscaras extrañas y justo a tiempo para Halloween.
Muchas de las coloridas máscaras tenían labios cosidos y se parecían más a Hannibal Lecter que a la alta costura.
Una de las creaciones se parecía a un equipo de buceo completo con tubo de buceo y gafas, mientras que otra parecía un cono de helado derretido.
Y si continúas con la gran declaración de moda... estás de suerte.
Los observadores de la moda predicen que los enormes gorros podrían estar llegando a las calles principales cercanas a usted.
Los sombreros fuera de tamaño vienen caliente en los talones de 'La Bomba', el sombrero de paja con un borde de dos pies de ancho que se ha visto en todo el mundo de Rihanna a Emily Ratajkowski.
La etiqueta de culto detrás del sombrero altamente poco práctico que fue salpicado en las redes sociales envió otra gran creación por la pasarela: una bolsa de playa de paja casi tan grande como la modelo vestida de traje de baño que la llevaba.
La bolsa de rafia naranja quemada, adornada con flecos de rafia y rematada con un mango de cuero blanco, fue la pieza destacada en la colección La Riviera SS19 de Jacquemus en la Semana de la Moda de París.
El estilista de celebridades Luke Armitage dijo a FEMAIL: 'Espero ver grandes sombreros y bolsas de playa llegando a la calle principal para el próximo verano, ya que el diseñador ha tenido un impacto tan grande que sería difícil ignorar la demanda de los accesorios de gran tamaño'.
John Edward: Las competencias lingüísticas son esenciales para los ciudadanos del mundo
Las escuelas independientes de Escocia mantienen un historial de excelencia académica, y esto ha continuado en 2018 con otro conjunto de resultados de exámenes sobresalientes, que solo se fortalece con el éxito individual y colectivo en deportes, arte, música y otros esfuerzos comunitarios.
Con más de 30.000 alumnos en toda Escocia, estas escuelas, representadas por el Consejo Escocés de Escuelas Independientes (SCIS), se esfuerzan por ofrecer el mejor nivel de servicio a sus alumnos y padres.
Las escuelas independientes tienen como objetivo preparar a sus alumnos para la educación superior y superior, su carrera elegida y su lugar como ciudadanos globales.
Como un sector educativo que puede diseñar e implementar un plan de estudios escolar a medida, estamos viendo que las lenguas modernas continúan siendo un tema popular y deseado dentro de las escuelas.
Nelson Mandela dijo: "Si le hablas a un hombre en un idioma que entiende, eso va a su cabeza.
Si le hablas en su propio idioma, eso llega a su corazón".
Este es un poderoso recordatorio de que no podemos confiar solo en el inglés cuando queremos construir relaciones y confianza con personas de otros países.
De los recientes resultados de los exámenes de este año, podemos ver que las lenguas están encabezando las tablas de clasificación con las tasas de aprobación más altas dentro de las escuelas independientes.
Un total del 68% de los alumnos que estudiaron lenguas extranjeras obtuvieron un grado A superior.
Los datos, recopilados de las 74 escuelas miembros de SCIS, mostraron que el 72 por ciento de los estudiantes obtuvieron un grado superior A en mandarín, mientras que el 72 por ciento de los que estudiaban alemán, el 69 por ciento de los que estudiaban francés y el 63 por ciento de los que estudiaban español también obtuvieron un A.
Esto demuestra que las escuelas independientes de Escocia están apoyando las lenguas extranjeras como habilidades vitales que los niños y los jóvenes sin duda necesitarán en el futuro.
Las lenguas ahora, como una opción de asignatura, se están tomando en la misma consideración que las materias STEM (ciencia, tecnología, ingeniería y matemáticas) en los planes de estudio de las escuelas independientes y en otros lugares.
Una encuesta realizada por la Comisión de Empleo y Habilidades del Reino Unido en 2014 encontró que de las razones que los empleadores dieron para luchar para llenar las vacantes, el 17 por ciento se atribuyó a una escasez de habilidades lingüísticas.
Por lo tanto, cada vez más, las habilidades lingüísticas se vuelven imprescindibles para preparar a los jóvenes para sus futuras carreras.
Dado que cada vez hay más oportunidades laborales que requieren idiomas, estas competencias son esenciales en un mundo globalizado.
Independientemente de la carrera que alguien elija, si han aprendido un segundo idioma, tendrán una ventaja real en el futuro al tener una habilidad de por vida como esta.
Ser capaz de comunicarse directamente con personas de países extranjeros pondrá automáticamente a una persona multilingüe por delante de la competencia.
Según una encuesta de YouGov de más de 4,000 adultos del Reino Unido en 2013, el 75 por ciento no podía hablar un idioma extranjero lo suficientemente bien como para mantener una conversación y con el francés siendo el único idioma hablado por un porcentaje de dos dígitos, el 15 por ciento.
Esta es la razón por la que invertir en la enseñanza de idiomas ahora es importante para los niños de hoy.
Tener varios idiomas, especialmente los de las economías en desarrollo, proporcionará a los niños una mejor oportunidad de encontrar un empleo significativo.
Dentro de Escocia, cada escuela será diferente en los idiomas que enseñan.
Algunas escuelas se centrarán en las lenguas modernas más clásicas, mientras que otras enseñarán lenguas que se consideran más importantes para el Reino Unido a la vista de 2020, como el mandarín o el japonés.
Cualquiera que sea el interés de su hijo, siempre habrá varios idiomas para elegir dentro de las escuelas independientes, con personal docente especializado en esta área.
Las escuelas independientes escocesas se dedican a proporcionar un entorno de aprendizaje que prepare a los niños y les brinde las habilidades necesarias para tener éxito, sea cual sea el futuro.
No se puede negar en este momento, en un entorno empresarial global, que los idiomas siguen siendo de vital importancia para el futuro del país, por lo que esto debe reflejarse en la educación.
De hecho, las lenguas modernas realmente deberían considerarse "habilidades de comunicación internacional".
Las escuelas independientes seguirán ofreciendo esta opción, diversidad y excelencia para los jóvenes de Escocia.
Hay que hacerlo bien.
John Edward es Director del Consejo Escocés de Escuelas Independientes
LeBron hará su debut con los Lakers el domingo en San Diego.
La espera casi ha terminado para los fanáticos que buscan ver a LeBron James hacer su primera aparición para los Lakers de Los Ángeles.
El entrenador de los Lakers, Luke Walton, ha anunciado que James jugará el domingo en el partido inaugural de pretemporada contra los Denver Nuggets en San Diego.
Pero aún no se ha determinado cuántos minutos jugará.
"Será más de uno y menos de 48", dijo Walton en el sitio web oficial de los Lakers.
El reportero de los Lakers Mike Trudell tuiteó que James probablemente jugará minutos limitados.
A raíz de la práctica a principios de esta semana, James fue preguntado sobre sus planes para los Lakers 'seis juegos de la pretemporada.
"No necesito juegos de pretemporada en esta etapa de mi carrera para prepararme", dijo.
Tiempo del mitin de Trump en el oeste de Virginia, Canal de YouTube
El presidente Donald Trump comienza una serie de mítines de campaña esta noche en Wheeling, Virginia Occidental.
Es el primero de los cinco mítines programados de Trump para la próxima semana, incluyendo paradas en lugares amistosos como Tennessee y Mississippi.
Con la votación de confirmación en espera para su elección para llenar la vacante de la Corte Suprema, Trump apunta a generar apoyo para las próximas elecciones de mitad de período, ya que los republicanos corren el riesgo de perder el control del Congreso cuando se emitan los votos en noviembre.
¿A qué hora es el mitin de Trump en Virginia Occidental esta noche y cómo lo ves en línea?
El mitin de Trump en Wheeling, Virginia Occidental está programado para las 7 p.m. Esta noche, sábado 29 de septiembre de 2018.
Puede ver el mitin de Trump en Virginia Occidental en línea a través de la transmisión en vivo en YouTube.
Es probable que Trump se dirija a las audiencias de esta semana para el candidato a la Corte Suprema Brett Kavanaugh, que se volvieron tensas por las acusaciones de conducta sexual inapropiada con una anticipada votación de confirmación en el Senado suspendida hasta una semana mientras el FBI investiga.
Pero el objetivo principal de esta oleada de manifestaciones es ayudar a los republicanos que se enfrentan a las elecciones de noviembre a ganar algo de impulso.
Por lo tanto, la campaña del presidente Trump dijo que estos cinco mítines en la próxima semana tienen como objetivo "energizar a los voluntarios y partidarios mientras los republicanos intentan proteger y expandir las mayorías que tienen en el Senado y la Cámara de Representantes", según Reuters.
"El control del Congreso es tan crítico para su agenda que el presidente viajará a tantos estados como sea posible a medida que nos adentramos en la ajetreada temporada de campaña", dijo a Reuters un portavoz de la campaña de Trump que pidió no ser identificado.
Programado para el Wesbanco Arena en Wheeling, el mitin de esta noche podría traer partidarios de "Ohio y Pensilvania y atraer la cobertura de los medios de Pittsburgh", según el West Virginia Metro News.
El sábado será la segunda vez en el último mes que Trump visita Virginia Occidental, el estado que ganó por más de 40 puntos porcentuales en 2016.
Trump está tratando de ayudar al candidato republicano al Senado de Virginia Occidental, Patrick Morrisey, quien está rezagado en las encuestas.
"No es una buena señal para Morrisey que el presidente tenga que venir para tratar de darle un impulso en las encuestas", dijo Simon Haeder, un politólogo de la Universidad de Virginia Occidental, según Reuters.
Ryder Cup 2018: Equipo de EE.UU. muestra el estómago para luchar para mantener vivas las esperanzas dirigiéndose a los singles del domingo
Después de tres sesiones unilaterales, el cuarteto del sábado por la tarde podría haber sido justo lo que esta Ryder Cup necesitaba.
El péndulo oscilante del impulso es un concepto deportivo completamente inventado pero en el que los jugadores realmente creen, y nunca más que en competiciones como estas.
Entonces, ¿dónde dirían que está el impulso ahora?
"Tenían una ventaja de seis puntos y ahora son cuatro, así que lo estamos llevando como un poco de impulso, supongo", dijo Jordan Spieth mientras caminaba por el día.
Europa tiene la ventaja, por supuesto, cuatro puntos por delante con doce más en juego.
Los estadounidenses, como dice Spieth, sienten que tienen un poco de viento en sus velas y tienen mucho por lo que alentarse, no menos la forma de Spieth y Justin Thomas que jugaron juntos todo el día y cada uno cuenta con tres puntos de cuatro.
Spieth ha sido letal desde el tee hasta el green y está dando el ejemplo.
Esos gritos guturales de celebración se hicieron más fuertes a medida que su ronda continuaba, hundiendo un putt crucial para tomar el cuarto partido cuando él y Thomas habían estado dos abajo después de dos.
Su putt que les ganó el partido en el 15 fue recibido con un grito similar, el tipo que le dice que cree que el equipo estadounidense no está fuera de esto.
"Usted realmente sólo tiene que cavar profundamente y preocuparse por su propio partido", dijo Spieth.
Es todo lo que le queda a cada uno de estos jugadores.
18 hoyos para hacer una marca.
Los únicos jugadores con más puntos que Spieth y Thomas en los últimos dos días son Francesco Molinari y Tommy Fleetwood, la historia indiscutible de la Ryder Cup.
La extraña pero adorable pareja de Europa son cuatro de cuatro y no pueden equivocarse.
"Moliwood" fue la única pareja que no disparó a un bogey el sábado por la tarde, pero también evitaron a los bogey el sábado por la mañana, el viernes por la tarde y los nueve últimos el viernes por la mañana.
Esa carrera, y la forma en que su energía parece fluir tanto hacia y desde esta multitud bulliciosa cementa que son los jugadores para vencer el domingo, y no habría un jugador más popular para sellar una posible victoria europea mientras el sol se pone sobre Le Golf National que Fleetwood o Molinari.
Preferiblemente ambos simultáneamente en agujeros diferentes.
Sin embargo, es prematuro hablar de la gloria europea.
Bubba Watson y Webb Simpson hicieron un trabajo corto de Sergio García, el héroe de las cuatro bolas de la mañana, cuando fue emparejado con Alex Noren.
Un bogey y dos dobles en el nueve delantero cavaron al español y al sueco en un agujero del que nunca estuvieron cerca de salir.
El domingo, sin embargo, no hay nadie que te ayude a salir de tu agujero.
Las cuatro bolas y los cuádruples son tan fascinantes de observar de cerca debido a las interacciones entre los emparejamientos, los consejos que dan, los consejos que no dan y la forma en que una estrategia puede cambiar en un instante.
Europa ha jugado mejor como equipo hasta ahora y tiene una ventaja significativa en el último día, pero esta sesión de cuartos también mostró que el Equipo EE.UU. tiene el estómago para la pelea que algunos, especialmente en Estados Unidos, habían estado dudando.
Europa tiene una ventaja de 10-6 en el último día de la Ryder Cup
Europa tendrá una ventaja saludable en el último día de la Ryder Cup después de emerger de los partidos de cuatro bolas y cuadrangulares del sábado con una ventaja de 10-6 sobre los Estados Unidos.
El dúo inspirado Tommy Fleetwood y Francesco Molinari lideraron la carga con dos victorias sobre un luchador Tiger Woods para llevar su cuenta hasta ahora en Le Golf National a cuatro puntos.
El equipo europeo de Thomas Bjorn, tratando de retener el trofeo que perdieron en Hazeltine hace dos años, dominó a un equipo estadounidense que falló en las cuatro bolas de la mañana, ganando la serie 3-1.
Los EE.UU. ofrecieron más resistencia en los cuadrangulares, ganando dos partidos, pero no pudieron comer en el déficit.
El equipo de Jim Furyk necesita ocho puntos de los 12 partidos individuales del domingo para retener el trofeo.
Fleetwood es el primer novato europeo en ganar cuatro puntos seguidos mientras que él y Molinari, apodado "Molliwood" después de un fin de semana sensacional son solo la segunda pareja en ganar cuatro puntos de sus primeros cuatro partidos en la historia de la Ryder Cup.
Después de aplastar a Woods y Patrick Reed en las cuatro bolas, luego se pusieron magníficamente para vencer a un desinflado Woods y al novato estadounidense Bryson Dechambeau por un 5 y 4 aún más enfático.
Woods, que se arrastró a sí mismo a través de dos partidos el sábado, mostró estallidos ocasionales de brillantez, pero ahora ha perdido 19 de sus 29 partidos en cuatro bolas y cuadrangulares y siete en una fila.
Justin Rose, descansado para las cuatro bolas de la mañana, regresó a su compañero Henrik Stenson en los cuadrangulares para una derrota de 2 y 1 de Dustin Johnson y Brooks Koepka, clasificados primero y tercero en el mundo.
Europa no lo tenía todo a su manera aunque en un día agradable y ventoso al suroeste de París.
El tres veces ganador de Grandes Ligas Jordan Spieth y Justin Thomas establecieron el punto de referencia para los estadounidenses con dos puntos el sábado.
Ganaron una dura victoria de 2 y 1 sobre los españoles Jon Rahm e Ian Poulter en las cuatro bolas y regresaron más tarde para vencer a Poulter y Rory McIlroy 4 y 3 en las cuadrangulares después de haber perdido los dos hoyos iniciales.
Solo dos veces en la historia de la Ryder Cup un equipo ha vuelto de un déficit de cuatro puntos entrando en los singles, aunque como titulares, el equipo de Furyk solo necesita empatar para retener el trofeo.
Después de ser el segundo mejor durante dos días, sin embargo, un contraataque del domingo parece que será más allá de ellos.
Corea del Norte dice que 'de ninguna manera' se desarmará unilateralmente sin confianza
El ministro de Relaciones Exteriores de Corea del Norte dijo a las Naciones Unidas el sábado que las sanciones continuas estaban profundizando su desconfianza en los Estados Unidos y que no había forma de que el país renunciara unilateralmente a sus armas nucleares en tales circunstancias.
Ri Yong Ho dijo a la Asamblea General anual del organismo mundial que Corea del Norte había tomado "significativas medidas de buena voluntad" en el último año, como detener las pruebas nucleares y de misiles, desmantelar el sitio de pruebas nucleares y comprometerse a no proliferar armas nucleares y tecnología nuclear.
"Sin embargo, no vemos ninguna respuesta correspondiente de los EE.UU"., dijo.
"Sin ninguna confianza en los EE.UU. no habrá confianza en nuestra seguridad nacional y en tales circunstancias no hay manera de que nos desarmaremos unilateralmente primero".
Si bien Ri repitió las conocidas quejas de Corea del Norte sobre la resistencia de Washington a un enfoque "faseado" de desnuclearización bajo el cual Corea del Norte sería recompensada a medida que tomara medidas graduales, Su declaración parecía significativa en el sentido de que no rechazaba la desnuclearización unilateral como lo ha hecho Pyongyang en el pasado.
Ri se refirió a una declaración conjunta emitida por Kim Jong Un y Donald Trump en la primera cumbre entre un presidente estadounidense en funciones y un líder norcoreano en Singapur el 12 de junio. cuando Kim se comprometió a trabajar hacia la "desnuclearización de la península coreana" mientras que Trump prometió garantías de seguridad de Corea del Norte.
Corea del Norte ha estado buscando un final formal a la Guerra de Corea de 1950-53, pero Estados Unidos ha dicho que Pyongyang debe renunciar primero a sus armas nucleares.
Washington también se ha resistido a los llamados a relajar las duras sanciones internacionales contra Corea del Norte.
"Estados Unidos insiste en la "desnuclearización primero" y aumenta el nivel de presión mediante sanciones para lograr su propósito de manera coercitiva, e incluso se opone a la "declaración del fin de la guerra", dijo Ri.
"La percepción de que las sanciones nos pueden poner de rodillas es una ilusión de la gente que ignora sobre nosotros.
Pero el problema es que las sanciones continuas están profundizando nuestra desconfianza".
Ri no mencionó los planes para una segunda cumbre entre Kim y Trump que el líder estadounidense destacó en las Naciones Unidas a principios de la semana.
En cambio, el ministro destacó tres reuniones entre Kim y el líder surcoreano Moon Jae-in en los últimos cinco meses y agregó: "Si la parte en esta cuestión de desnuclearización hubiera sido Corea del Sur y no Estados Unidos, la desnuclearización de la península coreana no habría llegado a tal punto muerto".
Aun así, el tono del discurso de Ri fue dramáticamente diferente al del año pasado, cuando le dijo a la Asamblea General de la ONU que atacar el continente estadounidense con los cohetes de Corea del Norte era inevitable después de que el "Señor Presidente Malvado" Trump llamara a Kim un "hombre cohete" en una misión suicida.
Este año en las Naciones Unidas, Trump, quien el año pasado amenazó con "destruir totalmente" a Corea del Norte, elogió a Kim por su coraje al tomar medidas para desarmarse, pero dijo que aún quedaba mucho trabajo por hacer y que las sanciones debían permanecer en vigor hasta que Corea del Norte se desnuclearice.
El miércoles, Trump dijo que no tenía un marco de tiempo para esto, diciendo: "Si toma dos años, tres años o cinco meses, no importa".
China y Rusia argumentan que el Consejo de Seguridad de la ONU debería recompensar a Pyongyang por los pasos tomados.
Sin embargo, el secretario de Estado de los Estados Unidos, Mike Pompeo, le dijo al Consejo de Seguridad de la ONU el jueves que: "La aplicación de las sanciones del Consejo de Seguridad debe continuar vigorosamente y sin falta hasta que logremos la desnuclearización completa, final y verificada".
El Consejo de Seguridad ha aumentado unánimemente las sanciones contra Corea del Norte desde 2006 en un intento por ahogar el financiamiento para los programas de misiles nucleares y balísticos de Pyongyang.
Pompeo se reunió con Ri al margen de la Asamblea General de la ONU y dijo después que volvería a visitar Pyongyang el próximo mes para prepararse para una segunda cumbre.
Pompeo ya ha visitado Corea del Norte tres veces este año, pero su último viaje no fue bien.
Dejó Pyongyang en julio diciendo que se habían logrado avances, solo para que Corea del Norte en cuestión de horas lo denunciara por hacer "demandas parecidas a las de un gángster".
Corea del Norte se comprometió en una reunión con Moon este mes a desmantelar un sitio de misiles y también un complejo nuclear si Estados Unidos tomaba "medidas correspondientes".
Dijo que Kim le había dicho que las "medidas correspondientes" que estaba buscando eran garantías de seguridad que Trump prometió en Singapur y movimientos hacia la normalización de las relaciones con Washington.
Estudiantes de Harvard hacen un curso sobre cómo descansar lo suficiente
Un nuevo curso en la Universidad de Harvard este año ha hecho que todos sus estudiantes de pregrado duerman más en un intento por combatir la creciente cultura machista de estudiar a través de 'todas las noches' alimentadas con cafeína.
Un académico descubrió que los estudiantes de la universidad número uno del mundo a menudo no tienen ni idea de lo básico en cuanto a cómo cuidar de sí mismos.
Charles Czeisler, profesor de medicina del sueño en la Facultad de Medicina de Harvard y especialista en el Hospital Brigham and Women, diseñó el curso, que cree que es el primero de su tipo en los Estados Unidos.
Se inspiró para comenzar el curso después de dar una charla sobre el impacto que la falta de sueño tenía en el aprendizaje.
'Al final, una muchacha se me acercó y me dijo: '¿Por qué sólo me dicen esto ahora, en mi último año?'
Dijo que nadie le había dicho nunca sobre la importancia del sueño, lo que me sorprendió", dijo a The Telegraph.
El curso, lanzado por primera vez este año, explica a los estudiantes los aspectos esenciales de cómo los buenos hábitos de sueño ayudan al rendimiento académico y deportivo, así como a mejorar su bienestar general.
Paul Barreira, profesor de psiquiatría en la Escuela de Medicina de Harvard y director ejecutivo de los servicios de salud de la universidad, dijo que la universidad decidió introducir el curso después de encontrar que los estudiantes estaban seriamente privados de sueño durante la semana.
El curso de una hora de duración incluye una serie de tareas interactivas.
En una sección hay una imagen de una habitación de un dormitorio, donde los estudiantes hacen clic en tazas de café, cortinas, zapatillas y libros para ser informados sobre los efectos de la cafeína y la luz y cómo el rendimiento deportivo se ve afectado por la deficiencia de sueño, y la importancia de una rutina de la hora de acostarse.
En otra sección, se les dice a los participantes cómo la privación de sueño a largo plazo puede aumentar los riesgos de ataques cardíacos, accidentes cerebrovasculares, depresión y cáncer.
Un mapa del campus, con iconos interactivos, luego anima a los participantes a pensar en su rutina diaria.
Sabemos que no cambiará el comportamiento de los estudiantes al instante.
Pero creemos que tienen derecho a saberlo, al igual que usted tiene derecho a conocer los efectos sobre la salud de optar por fumar cigarrillos", añadió el profesor Czeisler.
La cultura del orgullo de 'llevar toda la noche' todavía existe, dijo, y agregó que la tecnología moderna y la creciente presión sobre los estudiantes significaban que la privación del sueño era un problema creciente.
Asegurarse de dormir lo suficiente, de buena calidad, debería ser el "arma secreta" de un estudiante para combatir el estrés, el agotamiento y la ansiedad, dijo, incluso para evitar aumentar de peso, ya que la falta de sueño pone el cerebro en modo de hambre, haciéndolos constantemente hambrientos.
Raymond So, un californiano de 19 años que estudia química y biología física, ayudó al profesor Czeisler a diseñar el curso, habiendo tomado una de sus clases el año pasado durante su primer año en Harvard.
Dijo que el curso le había abierto los ojos e inspirado a impulsar un curso en todo el campus.
El próximo paso, espera, será pedir a todos los estudiantes de posgrado que completen un programa de estudios similar antes de unirse a la institución competitiva.
El profesor Czeisler recomendó que los estudiantes consideraran la posibilidad de establecer una alarma para irse a la cama, Además, debe tener en cuenta los efectos nocivos de la "luz azul" emitida por las pantallas electrónicas y la iluminación LED, que puede alterar su ritmo circadiano y provocar problemas para conciliar el sueño.
Livingston 1 - 0 Rangers: el gol de Menga derriba a los hombres de Gerrard
Los Rangers sufrieron otro ataque de tristeza cuando el ataque de Dolly Menga envió al desarticulado equipo de Steven Gerrard a una derrota por 1-0 en Livingston.
El equipo de Ibrox buscaba registrar su primera victoria en la carretera desde el triunfo 4-1 de febrero en St Johnstone, pero el equipo de Gary Holt infligió la segunda derrota de Gerrard en 18 juegos como entrenador para dejar a su equipo a ocho puntos de Ladbrokes, líderes de la Premier League, Hearts.
Menga golpeó siete minutos antes del descanso y una alineación de Rangers con poca inspiración nunca parecía igualar.
Mientras que los Rangers ahora caen al sexto lugar, Livingston sube al tercero y sólo detrás de Hibernian en la diferencia de goles.
Y podría haber más problemas para los Rangers después de que el liniero Calum Spence tuvo que ser tratado por una herida en la cabeza después de que un objeto aparentemente fue lanzado desde el extremo lejano.
Gerrard hizo ocho cambios en el equipo que superó a Ayr en las semifinales de la Betfred Cup.
Holt, por otro lado, fue con el mismo Livi 11 que le quitó un punto a Hearts la semana pasada y habría estado encantado con la forma en que su equipo bien perforado sofocó a sus oponentes a cada paso.
Los Rangers pueden haber dominado la posesión pero Livingston hizo más con el balón que tenían.
Deberían haber anotado solo dos minutos cuando el primer disparo de Menga envió a Scott Pittman al gol de Allan McGregor, pero el mediocampista tiró de su gran oportunidad.
Un profundo tiro libre de Keaghan Jacobs encontró al capitán Craig Halkett pero su compañero defensivo Alan Lithgow sólo pudo atravesar el poste trasero.
Los Rangers tomaron el control pero parecía haber más esperanza que fe en su juego en el último tercio.
Alfredo Morelos ciertamente sintió que debería haber tenido una penalización en el cuarto de hora cuando él y Steven Lawless chocaron, pero el árbitro Steven Thomson rechazó las apelaciones del colombiano.
Los Rangers lograron solo dos tiros en el objetivo en la primera mitad, pero el ex portero de Ibrox, Liam Kelly, apenas fue molestado por el cabezazo de Lassana Coulibaly y un golpe manso de Ovie Ejaria.
Si bien el primer disparo de Livi en el minuto 34 puede haber estado en contra de la ejecución del juego, nadie puede negar que se lo merecían solo por su injerto.
Una vez más los Rangers no pudieron lidiar con un profundo set-piece de Jacobs.
Scott Arfield no reaccionó cuando Declan Gallagher le lanzó el balón a Scott Robinson, quien mantuvo la calma para elegir a Menga para un simple final.
Gerrard actuó en el descanso cuando cambió Coulibaly por Ryan Kent y el cambio casi proporcionó un impacto inmediato cuando el extremo se metió en Morelos, pero el impresionante Kelly corrió desde su línea hasta el bloqueo.
Pero Livingston continuó sugando a los visitantes para que jugaran exactamente el tipo de juego que les gustaba, con Lithgow y Halkett barriendo bola larga tras bola larga.
El equipo de Holt podría haber extendido su ventaja en las etapas finales pero McGregor se puso de pie bien para negar a Jacobs antes de que Lithgow se dirigiera desde la esquina.
El sustituto de los Rangers, Glenn Middleton, tuvo otra reclamación tardía de una penalización cuando se enredó con Jacobs, pero nuevamente Thomson miró hacia otro lado.
El inventor del contador Geiger
Y ahora una página de nuestro Almanaque "Sunday Morning": 30 de septiembre de 1882, hace 136 años hoy, y contando... el día en que el futuro físico Johannes Wilhelm "Hans" Geiger nació en Alemania.
Geiger desarrolló un método para detectar y medir la radiactividad, un invento que finalmente condujo al dispositivo conocido como el Contador Geiger.
Un pilar de la ciencia desde entonces, el contador Geiger se convirtió en un pilar de la cultura pop, así, como en la película de 1950 "Campanas de Coronado", protagonizada por los científicos vaqueros aparentemente improbables Roy Rogers y Dale Evans:
Hombre: "¿Qué demonios es eso?"
Rogers: "Es un contador Geiger, usado para localizar minerales radiactivos, como el uranio.
Cuando te pones estos auriculares, en realidad puedes oír los efectos de los átomos emitidos por la radiactividad en los minerales".
Evans: "¡Dígame, seguro que está estallando ahora!"
"Hans" Geiger murió en 1945, pocos días antes de su cumpleaños número 63.
Pero el invento que lleva su nombre sigue vivo.
Una nueva vacuna contra el cáncer puede enseñar al sistema inmunológico a 'ver' las células deshonestas
Una nueva vacuna contra el cáncer puede enseñar al sistema inmunológico a 'ver' las células enemigas y matarlas
La vacuna enseña al sistema inmunológico a reconocer las células extrañas como parte del tratamiento
El método consiste en extraer células inmunes de un paciente, alterarlas en el laboratorio
Pueden entonces "ver" una proteína común a muchos cánceres y luego volver a inyectar
Una vacuna de prueba está mostrando resultados prometedores en pacientes con una variedad de cánceres.
Una mujer tratada con la vacuna, que enseña al sistema inmunológico a reconocer las células deshonestas, vio desaparecer su cáncer de ovario durante más de 18 meses.
El método consiste en extraer células inmunes de un paciente, alterarlas en el laboratorio para que puedan "ver" una proteína común a muchos cánceres llamada HER2, y luego volver a inyectar las células.
El profesor Jay Berzofsky, del Instituto Nacional del Cáncer de Estados Unidos, en Bethesda, Maryland, dijo: "Nuestros resultados sugieren que tenemos una vacuna muy prometedora".
El HER2 "impulsa el crecimiento de varios tipos de cáncer", incluidos los cánceres de mama, ovario, pulmón y colorrectal, explicó el profesor Berzofsky.
Un enfoque similar de extraer células inmunes de los pacientes y "enseñarles" cómo atacar las células cancerosas ha funcionado en el tratamiento de un tipo de leucemia.
Kanye West se embarcó en una diatriba pro-Trump, usando un sombrero MAGA, después de su aparición en SNL.
No fue bien
Kanye West fue abucheado en el estudio durante un Saturday Night Live después de una actuación vaga en la que elogió al presidente de los Estados Unidos, Donald Trump, y dijo que se postularía para el cargo en 2020.
Después de interpretar su tercera canción de la noche, llamada Ghost Town en la que llevaba una gorra Make America Great, lanzó una diatriba contra los demócratas y reiteró su apoyo a Trump.
"Muchas veces hablo con una persona blanca y me dicen: "¿Cómo te puede gustar Trump, es racista?"
Bueno, si estuviera preocupado por el racismo me habría mudado de Estados Unidos hace mucho tiempo", dijo.
SNL comenzó el programa con un sketch protagonizado por Matt Damon en el que la estrella de Hollywood se burló del testimonio de Brett Kavanaugh ante el Comité Judicial del Senado sobre las denuncias de agresión sexual hechas por Christine Blasey Ford.
Aunque no fue transmitido, las imágenes de la diatriba de West fueron subidas a las redes sociales por el comediante Chris Rock.
No está claro si Rock estaba tratando de burlarse de West con la publicación.
Además, West se había quejado a la audiencia de que le había costado mucho trabajo en el backstage por el uso de la cabeza.
"Me intimidaron en el backstage.
Me dijeron: "No salgas con ese sombrero".
¡Ellos me acosaron!
Y luego dicen que estoy en un lugar hundido", dijo, según el Washington Examiner.
West continuó: "¿Quieres ver el lugar hundido?" diciendo que "me pondría mi capa de superhombre, porque esto significa que no puedes decirme qué hacer. ¿Quieres que el mundo avance?
Prueba el amor".
Sus comentarios provocaron abucheos por lo menos dos veces de la audiencia y los miembros del elenco de SNL parecían estar avergonzados, informó Variety, con una persona allí diciendo a la publicación: "Todo el estudio se quedó en silencio".
West había sido traído como un reemplazo tardío para la cantante Ariana Grande, cuyo ex novio, el rapero Mac Miller había muerto hace unos días.
West desconcertó a muchos con una interpretación de la canción I Love it, vestida como una botella de Perrier.
West recibió el respaldo de la jefa del grupo conservador TPUSA, Candace Turner, quien tuiteó: "A uno de los espíritus más valientes: MUCHAS GRACIAS POR PONERSE FRENTE A LA MOBA".
Pero la presentadora Karen Hunter tuiteó que West estaba simplemente "siendo quien es y eso es absolutamente maravilloso".
"Pero elegí NO recompensar a alguien (comprando su música o ropa o apoyando su "arte") que creo que está abrazando y vomitando ideología que es dañina para mi comunidad.
Él es libre.
Nosotros también", añadió.
Antes del show, el rapero anunció en Twitter que había cambiado su nombre, diciendo que ahora era "el ser formalmente conocido como Kanye West".
No es el primer artista en cambiar su nombre y sigue los pasos de Diddy, también conocido como Puff Daddy, Puffy y P Diddy.
Su compañero rapero, Snoop Dogg ha tenido el nombre de Snoop Lion y por supuesto la difunta leyenda de la música Prince, cambió su nombre a un símbolo y luego el artista anteriormente conocido como Prince.
Acusación de intento de asesinato por el apuñalamiento en un restaurante de Belfast.
Un hombre de 45 años ha sido acusado de intento de asesinato después de que un hombre fue apuñalado en un restaurante en el este de Belfast el viernes.
El incidente ocurrió en Ballyhackamore, dijo la policía.
Se espera que el acusado comparezca ante el Tribunal de Magistrados de Belfast el lunes.
Los cargos serán revisados por el Ministerio Público.
La estrella de Juego de Tronos Kit Harington ataca a la masculinidad tóxica
Kit Harington es conocido por su papel como Jon Snow en la serie de fantasía medieval Game of Thrones de HBO.
Pero el actor, de 31 años, ha atacado el estereotipo del héroe macho, diciendo que tales papeles en la pantalla significan que los chicos jóvenes a menudo sienten que tienen que ser duros para ser respetados.
Hablando con The Sunday Times Culture, Kit dijo que cree que "algo ha salido mal" y se preguntó cómo abordar el problema de la masculinidad tóxica en la era #MeToo.
Kit, quien recientemente se casó con su coprotagonista de Juego de Tronos, Rose Leslie, también de 31 años, admitió que siente "muy fuertemente" abordar el tema.
"Siento personalmente, bastante fuertemente, en este momento - ¿dónde nos hemos equivocado con la masculinidad?", dijo.
"¿Qué hemos estado enseñando a los hombres cuando están creciendo, en términos del problema que vemos ahora?"
Kit cree que la televisión puede ser en parte responsable del aumento de la masculinidad tóxica gracias a sus personajes muy masculinos.
Continuó: '¿Qué es innato y qué se enseña?
¿Qué es lo que se enseña en la televisión, y en las calles, que hace que los chicos jóvenes sientan que tienen que ser este cierto lado de ser un hombre?
Creo que esa es realmente una de las grandes preguntas de nuestro tiempo: ¿cómo cambiamos eso?
Porque claramente algo ha ido mal con los jóvenes.'
En la entrevista también admitió que no haría ninguna precuela o secuela de Juego de Tronos cuando la serie llegue a su fin el próximo verano, diciendo que está "hecho con los campos de batalla y los caballos".
A partir de noviembre Kit protagonizará un revival de True West de Sam Shepard que es la historia de un productor de cine y su hermano, que es un ladrón.
El actor reveló recientemente que considera que conocer a su esposa Rose es lo mejor que ha salido de Juego de Tronos.
"Conocí a mi esposa en este programa, así que de esa manera me dio mi futura familia, y mi vida de ahora en adelante", dijo.
Rose interpretó a Ygritte, el interés amoroso del personaje de Kit, Jon Snow, en la serie de fantasía ganadora del premio Emmy.
La pareja se casó en junio de 2018 en los terrenos de la propiedad familiar de Leslie en Escocia.
VIH/SIDA: China reporta un aumento del 14% en los nuevos casos
China ha anunciado un aumento del 14% en el número de sus ciudadanos que viven con VIH y SIDA.
Según las autoridades sanitarias, más de 820.000 personas están afectadas en el país.
Solo en el segundo trimestre de 2018 se reportaron alrededor de 40.000 nuevos casos.
La gran mayoría de los nuevos casos se transmitieron a través del sexo, marcando un cambio con respecto al pasado.
Tradicionalmente, el VIH se propagaba rápidamente a través de algunas partes de China como resultado de transfusiones de sangre infectada.
Pero el número de personas que contraen el VIH de esta manera se ha reducido a casi cero, dijeron funcionarios de salud chinos en una conferencia en la provincia de Yunnan.
Sin embargo, año tras año, el número de personas que viven con el VIH y el SIDA en China ha aumentado en 100.000 personas.
La transmisión del VIH a través del sexo es un problema agudo en la comunidad LGBT de China.
La homosexualidad fue despenalizada en China en 1997, pero se dice que la discriminación contra las personas LGBT es generalizada.
Debido a los valores conservadores del país, los estudios han estimado que el 70-90% de los hombres que tienen relaciones sexuales con hombres eventualmente se casarán con mujeres.
Muchas de las transmisiones de las enfermedades provienen de protecciones sexuales inadecuadas en estas relaciones.
Desde 2003, el gobierno de China ha prometido el acceso universal a los medicamentos para el VIH como parte de un esfuerzo para abordar el problema.
Maxine Waters niega que el personal haya filtrado los datos de los senadores republicanos, critica las "mentiras peligrosas" y las "teorías de conspiración"
La representante estadounidense Maxine Waters denunció el sábado las acusaciones de que un miembro de su personal había publicado la información personal de tres senadores estadounidenses republicanos en las páginas de Wikipedia de los legisladores.
El demócrata de Los Ángeles afirmó que las afirmaciones estaban siendo comercializadas por expertos y sitios web de "extrema derecha".
"Mentiras, mentiras y mentiras más despreciables", dijo Waters en una declaración en Twitter.
Según los informes, la información divulgada incluía las direcciones domiciliarias y los números de teléfono de los Senadores de los Estados Unidos. Lindsey Graham de Carolina del Sur, y Mike Lee y Orrin Hatch, ambos de Utah.
La información apareció en línea el jueves, publicada por una persona desconocida en el Capitolio durante la audiencia de un panel del Senado sobre las acusaciones de conducta sexual inapropiada contra el candidato a la Corte Suprema Brett Kavanaugh.
La filtración se produjo en algún momento después de que los tres senadores habían interrogado a Kavanaugh.
Sitios conservadores como Gateway Pundit y RedState informaron que la dirección IP que identifica la fuente de los mensajes estaba asociada con la oficina de Waters y publicó la información de un miembro del personal de Waters, informó Hill.
"Esta acusación sin fundamento es completamente falsa y una mentira absoluta", continuó Waters.
"El miembro de mi personal - cuya identidad, información personal y seguridad han sido comprometidas como resultado de estas acusaciones fraudulentas y falsas - no fue de ninguna manera responsable de la filtración de esta información.
Esta acusación sin fundamento es completamente falsa y una mentira absoluta".
La declaración de Waters rápidamente atrajo críticas en línea, incluso del ex secretario de prensa de la Casa Blanca, Ari Fleischer.
"Esta negación está enojada", escribió Fleischer.
"Esto sugiere que no tiene el temperamento para ser miembro del Congreso.
Cuando alguien es acusado de algo que no hizo, no debe enojarse.
No deben ser desafiantes.
No deben cuestionar los motivos del acusador.
Deben estar tranquilos y serenos".
Fleischer apareció para comparar la reacción de Waters con las críticas de los demócratas al juez Kavanaugh, quien fue acusado por los críticos de parecer demasiado enojado durante la audiencia del jueves.
Omar Navarro, un candidato republicano que se postula para derrocar a Waters en las elecciones de mitad de período, también expresó sus pensamientos en Twitter.
"Gran si es cierto", tuiteó.
En su declaración, Waters dijo que su oficina había alertado "a las autoridades apropiadas y a las entidades encargadas de hacer cumplir la ley sobre estos reclamos fraudulentos.
"Nos aseguraremos de que los perpetradores sean revelados", continuó, "y que sean considerados legalmente responsables por todas sus acciones que son destructivas y peligrosas para todos y cada uno de los miembros de mi personal".
Johnny Inglés golpea de nuevo revisión - Rowan Atkinson parodia de espionaje de baja potencia
Ahora es tradicional buscar significancias del Brexit en cualquier película nueva con una inclinación británica y eso parece aplicable a este renacimiento de la franquicia de parodia de comedia de acción de Johnny English, que comenzó en 2003 con Johnny English y volvió a la vida en 2011 con Johnny English Reborn.
¿Será la auto-satira burlona sobre el tema de lo obviamente basura que somos la nueva oportunidad de exportación de la nación?
En cualquier caso, el incompetente Johnny Inglés de ojos grandes y cara de goma ha renovado por segunda vez su licencia para joder cosas - ese nombre de su señalización más que cualquier otra cosa que él es una amplia creación cómica diseñada para territorios de cine de habla no inglesa.
Él es, por supuesto, el tonto agente secreto que a pesar de sus extrañas pretensiones de glamour batido tiene un poco de Clouseau, una pizca de Mr. Bean y una cucharada de ese tipo contribuyendo con una sola nota a la melodía del tema de los Carros de Fuego en la ceremonia de apertura de los Juegos Olímpicos de Londres 2012.
También está basado originalmente en el viajero y hombre internacional de misterio Atkinson que una vez jugó en los ahora olvidados anuncios de televisión de Barclaycard, dejando el caos a su paso.
Hay uno o dos momentos agradables en esta última salida de JE.
Me encantó que Johnny English se acercara a un helicóptero mientras vestía una armadura medieval y las palas del rotor resonaban brevemente contra su casco.
El don de Atkinson para la comedia física está en exhibición, pero el humor se siente bastante débil y extrañamente superfluo, especialmente porque las marcas de películas "serias" como 007 y Misión Imposible ahora ofrecen con confianza la comedia como ingrediente.
El humor se siente como si fuera lanzado a los niños en lugar de a los adultos, y para mí las desventuras locas de Johnny English no son tan inventivas y enfocadas como las bromas de películas mudas de Atkinson en el personaje de Bean.
La premisa perenne de actualidad ahora es que Gran Bretaña está en serios problemas.
Un pirata informático se ha infiltrado en la red súper secreta de espías de Gran Bretaña, revelando las identidades de todos los agentes británicos en el campo, para consternación del agente de guardia, un papel desafortunadamente pequeño para Kevin Eldon.
Es la gota que colmó el vaso para un primer ministro que es una figura pomposa y asediada, que ya está sufriendo un colapso completo de impopularidad política: Emma Thompson hace todo lo posible con este personaje cuasi-Teresa-May, pero no hay mucho en el guión para trabajar.
Sus asesores de inteligencia le informan que como todos los espías activos han sido comprometidos, tendrá que traer a alguien de la jubilación.
Y eso significa torpe el propio Johnny English, ahora empleado como maestro de escuela en algún establecimiento lujoso, pero dando lecciones no oficiales sobre cómo ser un agente encubierto: algunas buenas bromas aquí, ya que English ofrece una academia de espionaje tipo Escuela de Rock.
English es llevado de regreso a Whitehall para una reunión de emergencia y se reúne con su antiguo compañero Bough, interpretado nuevamente por Ben Miller.
Bough ahora es un hombre casado, enganchado a un comandante de submarino, un papel alegre de palos de hockey en el que Vicki Pepperdine está un poco desperdiciada.
Así que el Batman y Robin de hacer las cosas terriblemente mal en el Servicio Secreto de Su Majestad están de vuelta en acción, encontrándose con la hermosa femme fatale de Olga Kurylenko, Ophelia Bulletova.
Mientras tanto, el primer ministro está cayendo peligrosamente bajo el hechizo del carismático multimillonario tecnológico que afirma que puede resolver los problemas informáticos de Gran Bretaña: el siniestro Jason Volta, interpretado por Jake Lacy.
Inglés y Bough comienzan su odisea de bromas farsas: disfrazados de camareros, prendieron fuego a un restaurante francés de lujo; crean el caos contrabandeándose a bordo del yate de lujo de Volta; y Inglés desencadena la anarquía pura cuando intenta usar un auricular de realidad virtual para familiarizarse con el interior de la casa de Volta.
Todas las paradas son ciertamente sacado para que la última secuencia, pero tan amable y bulliciosa como es, hay un poco de televisión para niños sobre todo el asunto.
Cosas muy moderadas.
Y como con las otras películas de Johnny English no pude evitar pensar: ¿no puede la industria cinematográfica británica darle a Rowan Atkinson un papel que realmente haga justicia a su talento?
El Partido Laborista niega que esté ideando un plan para que los británicos trabajen cuatro días a la semana pero se les pague cinco días.
El Partido Laborista de Jeremy Corbyn está considerando un plan radical que hará que los británicos trabajen cuatro días a la semana, pero se les pague por cinco.
Según los informes, el partido quiere que los jefes de las empresas pasen los ahorros logrados a través de la revolución de la inteligencia artificial (IA) a los trabajadores dándoles un día de descanso adicional.
Se vería a los empleados disfrutar de un fin de semana de tres días - pero todavía llevar a casa el mismo salario.
Fuentes dijeron que la idea "encajaría" con la agenda económica del partido y los planes de inclinar el país a favor de los trabajadores.
El cambio a una semana de cuatro días ha sido respaldado por el Congreso de Sindicatos como una forma para que los trabajadores aprovechen la economía cambiante.
Una fuente de alto rango del Partido Laborista dijo al Sunday Times: "Se espera que se anuncie una revisión de la política antes de fin de año.
"No sucederá de la noche a la mañana, pero una semana laboral de cuatro días es una aspiración que encaja con el enfoque del partido para reequilibrar la economía a favor del trabajador, así como con la estrategia industrial general del partido".
El Partido Laborista no sería el primero en respaldar tal idea, ya que el Partido Verde prometió una semana laboral de cuatro días durante su campaña para las elecciones generales de 2017.
Sin embargo, la aspiración no está siendo respaldada actualmente por el Partido Laborista en su conjunto.
Un portavoz del Partido Laborista dijo: "Una semana laboral de cuatro días no es política del partido y no está siendo considerada por el partido".
El canciller John McDonnell aprovechó la conferencia laborista de la semana pasada para dar cuerpo a su visión de una revolución socialista en la economía.
El Sr. McDonnell dijo que estaba decidido a recuperar el poder de los "directores sin rostro" y los "beneficiarios" de las empresas de servicios públicos.
Los planes del canciller en la sombra también significan que los actuales accionistas de las compañías de agua pueden no recuperar toda su participación, ya que un gobierno laborista podría hacer "deducciones" sobre la base de presuntas irregularidades.
También confirmó planes para poner a los trabajadores en los consejos de administración de las empresas y crear fondos de propiedad inclusiva para entregar el 10 por ciento de las acciones de las empresas del sector privado a los empleados, que pueden embolsar dividendos anuales de hasta 500 libras esterlinas.
Lindsey Graham, John Kennedy dicen "60 Minutos" si la investigación del FBI de Kavanaugh podría cambiar sus mentes
La investigación del FBI sobre las acusaciones contra el juez Brett Kavanaugh ha retrasado la votación final sobre su nominación a la Corte Suprema por al menos una semana, y plantea la pregunta de si los hallazgos de la oficina podrían influir en cualquier senador republicano para retirar su apoyo.
En una entrevista que se emitió el domingo, el corresponsal de "60 Minutos" Scott Pelley preguntó a los republicanos Sens. John Kennedy y Lindsey Graham si el FBI podría desenterrar algo que los llevaría a cambiar de opinión.
Kennedy parecía más abierto que su colega de Carolina del Sur.
"Quiero decir, por supuesto", dijo Kennedy.
"Dije al entrar en la audiencia, dije, he hablado con el juez Kavanaugh.
Lo llamé después de que esto sucediera, esa acusación salió, dijo, '¿Lo hiciste?'
Él era decidido, decidido, inequívoco".
El voto de Graham, sin embargo, parece fijado en piedra.
"Mi mente está hecha sobre Brett Kavanaugh y se necesitaría una acusación de dinamita", dijo.
"Dr. Ford, no sé lo que pasó, pero sé esto: Brett lo negó enérgicamente", agregó Graham, refiriéndose a Christine Blasey Ford.
"Y todos los que ella nombra no pudieron verificarlo.
Tiene 36 años.
No veo nada nuevo cambiando".
¿Qué es el Festival Ciudadano Global y ha hecho algo para disminuir la pobreza?
Este sábado Nueva York será el anfitrión del Global Citizen Festival, un evento musical anual que tiene una alineación impresionante de estrellas que actúan y una misión igualmente impresionante; acabar con la pobreza mundial.
Ahora en su séptimo año, el Global Citizen Festival verá a decenas de miles de personas acudir al Great Lawn del Central Park no solo para disfrutar de actos como Janet Jackson, Cardi B y Shawn Mendes, sino también para crear conciencia sobre el verdadero objetivo del evento de acabar con la pobreza extrema para el 2030.
El Global Citizen Festival, que se declaró en 2012, es una extensión del Proyecto de Pobreza Global, un grupo de defensa internacional que espera poner fin a la pobreza aumentando el número de personas que luchan activamente contra ella.
Para recibir un boleto gratis para el evento (a menos que estuvieras dispuesto a pagar por un boleto VIP), los asistentes al concierto tenían que completar una serie de tareas, o "acciones" como el voluntariado, enviar un correo electrónico a un líder mundial, hacer una llamada telefónica o cualquier otra forma significativa para ayudar a crear conciencia de su objetivo de erradicar la pobreza.
Pero ¿qué tan exitoso ha sido Global Citizen con 12 años restantes para lograr su objetivo?
¿Es la idea de recompensar a la gente con un concierto gratuito una forma genuina de persuadir a la gente a exigir un llamado a la acción, o solo otro caso del llamado "clicktivismo" - personas que sienten que están haciendo una verdadera diferencia firmando una petición en línea o enviando un tweet?
Desde 2011, Global Citizen dice que ha registrado más de 19 millones de "acciones" de sus partidarios, impulsando una serie de objetivos diferentes.
Dice que estas acciones han ayudado a impulsar a los líderes mundiales a anunciar compromisos y políticas equivalentes a más de 37 mil millones de dólares que afectarán a las vidas de más de 2.25 mil millones de personas para 2030.
A principios de 2018, el grupo citó 390 compromisos y anuncios derivados de sus acciones, de los cuales al menos $ 10 mil millones ya han sido desembolsados o recaudados.
El grupo estima que los fondos asegurados hasta ahora han tenido un impacto directo en casi 649 millones de personas en todo el mundo.
Algunos de los compromisos clave incluyen el poder de la nutrición, una asociación con sede en el Reino Unido de inversores y implementadores comprometidos a "ayudar a los niños a desarrollar todo su potencial", prometiendo proporcionar a Ruanda 35 millones de dólares para ayudar a acabar con la desnutrición en el país después de recibir más de 4,700 tuits de Global Citizens.
"Con el apoyo del gobierno del Reino Unido, donantes, gobiernos nacionales y ciudadanos globales como usted, podemos hacer que la injusticia social de la desnutrición sea una nota al pie de la historia", dijo la embajadora de The Power of Nutrition, Tracey Ullman, a la multitud durante un concierto en vivo en Londres en abril de 2018.
El grupo también dijo que después de más de 5,El gobierno anunció la financiación de un proyecto, el Poder de la Nutrición, que llegará a 5 millones de mujeres y niños con intervenciones de nutrición.
En respuesta a una de las preguntas frecuentes en su sitio web preguntando "¿qué te hace pensar que podemos acabar con la pobreza extrema?"
Global citizen respondió: "Será un camino largo y difícil - a veces caeremos y fallaremos.
Pero, al igual que los grandes movimientos de derechos civiles y anti-apartheid antes que nosotros, tendremos éxito, porque juntos somos más poderosos.
Janet Jackson, The Weeknd, Shawn Mendes, Cardi B, Janelle Monáe están entre algunos de los artistas que actuarán en el evento de este año en Nueva York, que será presentado por Deborra-Lee Furness y Hugh Jackman.
EE.UU. podría usar la Marina para el "bloqueo" para obstaculizar las exportaciones de energía rusas - Secretario del Interior
Washington puede "si es necesario" recurrir a su Armada para evitar que la energía rusa golpee los mercados, incluso en el Medio Oriente, reveló el secretario del Interior de los Estados Unidos, Ryan Zinke, citado por el Washington Examiner.
Zinke alegó que la participación de Rusia en Siria, en particular, donde está operando a invitación del gobierno legítimo, es un pretexto para explorar nuevos mercados de energía.
"Creo que la razón por la que están en el Medio Oriente es que quieren negociar energía al igual que lo hacen en Europa del Este, el vientre del sur de Europa", ha dicho.
Y, según el funcionario, hay formas y medios para abordarlo.
"Estados Unidos tiene esa capacidad, con nuestra Armada, para asegurarse de que las rutas marítimas estén abiertas, y, si es necesario, para bloquear, para asegurarse de que su energía no vaya al mercado", dijo.
Zinke se dirigía a los asistentes al evento organizado por la Alianza de Energía del Consumidor, un grupo sin fines de lucro que se autodenomina como la "voz del consumidor de energía" en los Estados Unidos.
Fue a comparar los enfoques de Washington para tratar con Rusia e Irán, señalando que son efectivamente los mismos.
"La opción económica para Irán y Rusia es, más o menos, aprovechar y reemplazar los combustibles", dijo, mientras se refería a Rusia como un "pony de un solo truco" con una economía dependiente de los combustibles fósiles.
Las declaraciones se producen cuando la administración Trump ha estado en una misión para impulsar la exportación de su gas natural licuado a Europa, reemplazando a Rusia, la opción mucho más barata para los consumidores europeos.
Para ese efecto, los funcionarios de la administración Trump, incluido el propio presidente de los Estados Unidos, Donald Trump, intentan persuadir a Alemania para que se retire del "inapropiado" proyecto de oleoducto Nord Stream 2, que según Trump, convirtió a Berlín en "cautivo" de Moscú.
Moscú ha subrayado repetidamente que el oleoducto Nord Stream 2 de 11 mil millones de dólares, que duplicará la capacidad existente del oleoducto a 110 mil millones de metros cúbicos, es un proyecto puramente económico.
El Kremlin argumenta que la ferviente oposición de Washington al proyecto es simplemente impulsada por razones económicas y es un ejemplo de competencia desleal.
"Creo que compartimos la opinión de que la energía no puede ser una herramienta para ejercer presión y que los consumidores deben poder elegir a los proveedores", dijo el ministro de Energía ruso, Aleksandr Novak, después de una reunión con el secretario de Energía de Estados Unidos, Rick Perry, en Moscú en septiembre.
La postura de EE.UU. ha provocado una reacción violenta de Alemania, que ha reafirmado su compromiso con el proyecto.
La principal organización industrial alemana, la Federación de Industrias Alemanas (BDI), ha pedido a Estados Unidos que se mantenga alejado de la política energética de la UE y de los acuerdos bilaterales entre Berlín y Moscú.
"Tengo un gran problema cuando un tercer estado interfiere en nuestro suministro de energía", dijo Dieter Kempf, jefe de la Federación de Industrias Alemanas (BDI) después de una reciente reunión entre la canciller alemana Angela Merkel y el presidente ruso Vladimir Putin.
Elizabeth Warren tomará una "mirada dura" para postularse a la presidencia en 2020, dice el senador de Massachusetts
La senadora de Massachusetts, Elizabeth Warren, dijo el sábado que analizaría seriamente la posibilidad de postularse a la presidencia después de las elecciones de mitad de período.
Durante un ayuntamiento en Holyoke, Massachusetts, Warren confirmó que consideraría postularse.
"Es hora de que las mujeres vayan a Washington y arreglen nuestro gobierno roto y eso incluye a una mujer en la cima", dijo, según The Hill.
"Después del 6 de noviembre, consideraré seriamente postularme para presidente".
Warren intervino en el presidente Donald Trump durante el ayuntamiento, diciendo que estaba "llevando a este condado en la dirección equivocada.
"Estoy preocupada hasta los huesos por lo que Donald Trump está haciendo a nuestra democracia", dijo.
Warren ha sido abierta en sus críticas a Trump y a su candidato a la Corte Suprema, Brett Kavanaugh.
En un tweet el viernes, Warren dijo "por supuesto que necesitamos una investigación del FBI antes de votar".
Una encuesta publicada el jueves, sin embargo, mostró que la mayoría de los propios electores de Warren no piensan que debería postularse en 2020.
Cincuenta y ocho por ciento de los votantes "probables" de Massachusetts dijeron que el senador no debería postularse, según la encuesta del Centro de Investigación Política de la Universidad de Suffolk / Boston Globe.
El treinta y dos por ciento apoyó tal carrera.
La encuesta mostró más apoyo para una carrera del ex gobernador Deval Patrick, con un 38 por ciento apoyando una carrera potencial y un 48 por ciento en contra.
Otros nombres demócratas de alto perfil discutidos con respecto a una posible carrera para 2020 incluyen al ex vicepresidente Joe Biden y al senador de Vermont Bernie Sanders.
Biden dijo que decidiría oficialmente para enero, informó la Associated Press.
Sarah Palin cita el trastorno de estrés postraumático de Palin en el mitin de Donald Trump
Track Palin, de 26 años, pasó un año en Irak después de alistarse en septiembre.
Fue arrestado y acusado de un incidente de violencia doméstica el lunes por la noche.
"Lo que mi propio hijo está pasando, lo que está pasando al regresar, puedo relacionarme con otras familias que sienten las ramificaciones del trastorno de estrés postraumático y algunas de las heridas con las que regresan nuestros soldados", dijo a la audiencia en un mitin para Donald Trump en Tulsa, Oklahoma.
Palin llamó a su arresto "el elefante en la habitación" y dijo de su hijo y otros veteranos de guerra, "vuelven un poco diferentes, vuelven endurecidos, vuelven preguntándose si hay ese respeto por lo que sus compañeros soldados y aviadores, y todos los demás miembros de las fuerzas armadas, han dado al país".
Fue arrestado el lunes en Wasilla, Alaska, y acusado de agresión de violencia doméstica a una mujer, interferir con un informe de violencia doméstica y posesión de un arma mientras estaba intoxicado, según Dan Bennett, portavoz del Departamento de Policía de Wasilla.
18 estados, D.C. apoyan el desafío a la nueva política de asilo
Dieciocho estados y el Distrito de Columbia están apoyando un desafío legal a una nueva política de Estados Unidos que niega el asilo a las víctimas que huyen de las pandillas o la violencia doméstica.
Los representantes de los 18 estados y el distrito presentaron un informe de amigo de la corte el viernes en Washington para apoyar a un solicitante de asilo que desafía la política, informó NBC News.
El nombre completo del demandante en el caso Grace v. La demanda de Sessions que la Unión Americana de Libertades Civiles presentó en agosto contra la política federal no ha sido revelada.
Ella dijo que su compañero "y sus hijos miembros de pandillas violentos", la abusaron, pero los funcionarios estadounidenses rechazaron su solicitud de asilo el 20 de julio.
Fue detenida en Texas.
Los abogados de los estados que apoyan a Grace describieron a El Salvador, Honduras y Guatemala, que producen un gran número de solicitantes de asilo en los Estados Unidos, como naciones que enfrentan problemas generalizados con pandillas y violencia doméstica.
La nueva política de asilo de Estados Unidos revirtió una decisión de 2014 de la Junta de Apelaciones de Inmigrantes que permitía a los inmigrantes indocumentados que huían de la violencia doméstica solicitar asilo.
El fiscal general del Distrito de Columbia, Karl Racine, dijo en una declaración el viernes que la nueva política "ignora décadas de leyes estatales, federales e internacionales".
"La ley federal requiere que todas las solicitudes de asilo sean juzgadas sobre los hechos y circunstancias particulares de la solicitud, y tal prohibición viola ese principio", dijo el informe del amigo de la corte.
Los abogados argumentaron además en el informe que la política de negar la entrada a los inmigrantes perjudica a la economía de los Estados Unidos, diciendo que es más probable que se conviertan en empresarios y "ofrezcan la mano de obra necesaria".
El Fiscal General Jeff Sessions ordenó a los jueces de inmigración que ya no concedieran asilo a las víctimas que huían del abuso doméstico y la violencia de las pandillas en junio.
"El asilo está disponible para aquellos que abandonan su país de origen debido a la persecución o el miedo a causa de la raza, la religión, la nacionalidad o la pertenencia a un grupo social o opinión política particular", dijo Sessions en su anuncio del 11 de junio de la política.
El asilo nunca tuvo la intención de aliviar todos los problemas, incluso los graves, que la gente enfrenta todos los días en todo el mundo.
Desesperados esfuerzos de rescate en Palu mientras el número de muertos se duplica en la carrera por encontrar sobrevivientes
Para los sobrevivientes, la situación era cada vez más terrible.
"Se siente muy tenso", dijo Risa Kusuma, una madre de 35 años, confortando a su bebé con fiebre en un centro de evacuación en la ciudad destrozada de Palu.
"Cada minuto una ambulancia trae cuerpos.
El agua limpia es escasa".
Se vio a los residentes regresar a sus casas destruidas, buscando entre las pertenencias inundadas, tratando de rescatar cualquier cosa que pudieran encontrar.
Cientos de personas resultaron heridas y los hospitales, dañados por el terremoto de magnitud 7.5, se vieron abrumados.
Algunos de los heridos, incluido Dwi Haris, que sufrió una fractura en la espalda y el hombro, descansaron fuera del Hospital del Ejército de Palu, donde los pacientes estaban siendo tratados al aire libre debido a las fuertes réplicas.
Con lágrimas en los ojos contó cómo sintió que el violento terremoto sacudió la habitación de hotel del quinto piso que compartía con su esposa e hija.
"No hubo tiempo para salvarnos.
Estaba apretado en las ruinas del muro, creo", dijo Haris a Associated Press, y agregó que su familia estaba en la ciudad para una boda.
"Oí a mi esposa gritar por ayuda, pero luego el silencio.
No sé qué le pasó a ella y a mi hijo.
Espero que estén a salvo".
El embajador de EE.UU. acusa a China de 'intimidación' con 'anuncios de propaganda'
Una semana después de que un periódico oficial chino publicara un anuncio de cuatro páginas en un diario estadounidense que promocionaba los beneficios mutuos del comercio entre Estados Unidos y China, el embajador de Estados Unidos en China acusó a Beijing de usar la prensa estadounidense para difundir propaganda.
El presidente de los Estados Unidos, Donald Trump, el miércoles pasado se refirió al suplemento pagado por el China Daily en el Registro de Des Moines, el periódico más vendido del estado de Iowa, después de acusar a China de tratar de inmiscuirse en las elecciones del Congreso de los Estados Unidos del 6 de noviembre, Una acusación que China niega.
La acusación de Trump de que Pekín estaba tratando de inmiscuirse en las elecciones estadounidenses marcó lo que funcionarios estadounidenses dijeron a Reuters que era una nueva fase en una creciente campaña de Washington para presionar a China.
Si bien es normal que los gobiernos extranjeros publiquen anuncios para promover el comercio, Beijing y Washington se encuentran actualmente atrapados en una creciente guerra comercial que los ha visto nivelar rondas de aranceles sobre las importaciones de cada uno.
Los aranceles de represalia de China al comienzo de la guerra comercial fueron diseñados para golpear a los exportadores en estados como Iowa que apoyaron al Partido Republicano de Trump, dijeron expertos chinos y estadounidenses.
Terry Branstad, el embajador de Estados Unidos en China y ex gobernador de Iowa, un importante exportador de productos agrícolas a China, dijo que Beijing había dañado a los trabajadores, agricultores y empresas estadounidenses.
China, escribió Branstad en un artículo de opinión en el Des Moines Register del domingo, "ahora está duplicando esa intimidación al publicar anuncios de propaganda en nuestra propia prensa libre".
"Al difundir su propaganda, el gobierno de China se está aprovechando de la preciada tradición estadounidense de libertad de expresión y prensa libre al colocar un anuncio pagado en el Registro de Des Moines", escribió Branstad.
"Por el contrario, en el quiosco de periódicos al final de la calle aquí en Beijing, encontrarás voces disidentes limitadas y no verás ningún reflejo verdadero de las opiniones dispares que el pueblo chino puede tener sobre la preocupante trayectoria económica de China, dado que los medios están bajo el firme control del Partido Comunista Chino", escribió.
Añadió que "uno de los periódicos más prominentes de China evitó la oferta de publicar" su artículo, aunque no dijo en qué periódico.
Los republicanos alienan a las mujeres votantes antes de las elecciones de mitad de período con el desastre de Kavanaugh, advierten los analistas
Mientras muchos republicanos de alto nivel defienden al candidato a la Corte Suprema Brett Kavanaugh frente a varias acusaciones de agresión sexual, los analistas han advertido que verán una reacción violenta, particularmente de las mujeres, durante las próximas elecciones de mitad de período.
Las emociones que rodean esto han sido extremadamente altas, y la mayoría de los republicanos ya están registrados mostrando que querían seguir adelante con la votación.
Esas cosas no se pueden revertir", dijo Grant Reeher, profesor de ciencias políticas en la Escuela Maxwell de la Universidad de Syracuse, a The Hill para un artículo publicado el sábado.
Reeher dijo que duda de que el impulso de última hora del senador Jeff Flake (R-Arizona) para una investigación del FBI sea suficiente para aplacar a los votantes enojados.
"Las mujeres no van a olvidar lo que pasó ayer - no van a olvidarlo mañana y no en noviembre," Karine Jean-Pierre, asesora principal y portavoz nacional del grupo progresista MoveOn dijo el viernes, según el periódico de Washington, DC.
El viernes por la mañana, Los manifestantes gritaron "¡Noviembre está llegando!" mientras se manifestaban en el pasillo del Senado mientras los republicanos que controlan el Comité Judicial decidieron seguir adelante con la nominación de Kavanaugh a pesar del testimonio de la Dra. Christine Blasey Ford, informó Mic.
"El entusiasmo y la motivación democrática van a estar fuera de lugar", dijo Stu Rothenberg, un analista político no partidista, al sitio de noticias.
"La gente dice que ya ha sido alto; eso es cierto.
Pero podría ser mayor, particularmente entre las votantes femeninas cambiantes en los suburbios y los votantes más jóvenes, de 18 a 29 años, que aunque no les gusta el presidente, a menudo no votan".
Incluso antes del testimonio público de Ford detallando sus acusaciones de agresión sexual contra el candidato a la Corte Suprema, los analistas sugirieron que podría seguir una reacción violenta si los republicanos avanzaban con la confirmación.
"Esto se ha convertido en un lío confuso para el Partido Republicano", dijo Michael Steele, ex presidente del Comité Nacional Republicano, a principios de la semana pasada, según NBC News.
"No se trata de la votación del comité o la votación final o si Kavanaugh es puesto en el banquillo, También es sobre la forma en que los republicanos han manejado esto y cómo la han tratado", Guy Cecil, director de Priorities USA, un grupo que ayuda a elegir a los demócratas, señaló al canal de noticias.
Sin embargo, los estadounidenses parecen estar algo divididos sobre a quién creer a raíz de los testimonios de Ford y Kavanaugh, con un poco más de apoyo a este último.
Una nueva encuesta de YouGov muestra que el 41 por ciento de los encuestados definitivamente o probablemente creía el testimonio de Ford, mientras que el 35 por ciento dijo que definitivamente o probablemente creía a Kavanaugh.
Además, el 38 por ciento dijo que pensaba que Kavanaugh probablemente o definitivamente mintió durante su testimonio, mientras que solo el 30 por ciento dijo lo mismo sobre Ford.
Después del empuje de Flake, el FBI está investigando las acusaciones presentadas por Ford, así como al menos otra acusadora, Deborah Ramírez, informó The Guardian.
Ford testificó ante el Comité Judicial del Senado bajo juramento la semana pasada que Kavanaugh la atacó borracho a los 17 años.
Ramírez alega que el candidato a la Corte Suprema le expuso sus genitales mientras asistían a una fiesta durante su tiempo estudiando en Yale en la década de 1980.
El inventor de la World Wide Web planea comenzar una nueva Internet para competir con Google y Facebook
Tim Berners-Lee, el inventor de la World Wide Web, está lanzando una startup que busca competir con Facebook, Amazon y Google.
El último proyecto de la leyenda de la tecnología, Inrupt, es una compañía que se basa en la plataforma de código abierto de Berners-Lee, Solid.
Solid permite a los usuarios elegir dónde se almacenan sus datos y a qué personas se les permite tener acceso a qué información.
En una entrevista exclusiva con Fast Company, Berners-Lee bromeó diciendo que la intención detrás de Inrupt es "dominar el mundo".
"Tenemos que hacerlo ahora", dijo de la puesta en marcha.
"Es un momento histórico".
La aplicación utiliza la tecnología de Solid para permitir a las personas crear su propia "almacén de datos en línea personal" o POD.
Puede contener listas de contactos, listas de tareas pendientes, calendario, biblioteca de música y otras herramientas personales y profesionales.
Es como si Google Drive, Microsoft Outlook, Slack y Spotify estuvieran disponibles en un mismo navegador y todo al mismo tiempo.
Lo único del almacén de datos personales en línea es que depende completamente del usuario quién puede acceder a qué tipo de información.
La compañía lo llama "empoderamiento personal a través de datos".
La idea de Inrupt, según el CEO de la compañía, John Bruce, es que la compañía aporte recursos, procesos y habilidades apropiadas para ayudar a que Solid esté disponible para todos.
La compañía actualmente consta de Berners-Lee, Bruce, una plataforma de seguridad comprada por IBM, algunos desarrolladores contratados para trabajar en el proyecto y una comunidad de programadores voluntarios.
A partir de esta semana, los desarrolladores de tecnología de todo el mundo podrían crear sus propias aplicaciones descentralizadas utilizando las herramientas disponibles en el sitio web de Inrupt.
Berners-Lee dijo que él y su equipo no están hablando con "Facebook y Google sobre si introducir o no un cambio completo en el que todos sus modelos de negocio estén completamente alterados de la noche a la mañana.
"No estamos pidiendo su permiso".
En una publicación en Medium publicada el sábado, Berners-Lee escribió que la "misión de Inrupt es proporcionar energía comercial y un ecosistema para ayudar a proteger la integridad y la calidad de la nueva web construida en Solid".
En 1994, Berners-Lee transformó Internet cuando estableció el World Wide Web Consortium en el Instituto de Tecnología de Massachusetts.
En los últimos meses, Berners-Lee ha sido una voz influyente en el debate sobre la neutralidad de la red.
Incluso durante el lanzamiento de Inrupt, Berners-Lee seguirá siendo el fundador y director del World Wide Web Consortium, la Web Foundation y el Open Data Institute.
"Soy increíblemente optimista para esta nueva era de la web", añadió Berners-Lee.
Bernard Vann: celebrado clérigo de la Cruz de Victoria de la Primera Guerra Mundial
El único clérigo de la Iglesia Anglicana que ganó una Cruz Victoria durante la Primera Guerra Mundial como combatiente ha sido celebrado en su ciudad natal 100 años después.
El reverendo Bernard Vann ganó el premio el 29 de septiembre de 1918 en el ataque a Bellenglise y Lehaucourt.
Sin embargo, fue asesinado por un francotirador cuatro días después y nunca supo que había ganado el más alto honor militar británico.
Una piedra conmemorativa fue descubierta por sus dos nietos en un desfile en Rushden, Northamptonshire, el sábado.
Uno de sus nietos, Michael Vann, dijo que era "brillantemente simbólico" que la piedra se revelaría exactamente 100 años después de la hazaña premiada de su abuelo.
Según el London Gazette, el 29 de septiembre de 1918, el teniente coronel Vann condujo a su batallón a través del Canal de Saint-Quentin "a través de una niebla muy espesa y bajo un fuerte fuego de cañones de campo y ametralladoras".
Más tarde se precipitó hacia la línea de fuego y con la "mayor valentía" lideró la línea hacia adelante antes de lanzar un cañón de campo con una sola mano y noquear a tres del destacamento.
El teniente coronel Vann fue asesinado por un francotirador alemán el 4 de octubre de 1918, poco más de un mes antes de que terminara la guerra.
Michael Vann, de 72 años, dijo que las acciones de su abuelo fueron "algo que sé que nunca podría estar a la altura, pero algo que es humillante".
Él y su hermano el Dr. James Vann también colocaron una corona de flores después del desfile, que fue dirigido por la Brentwood Imperial Youth Band.
Michael Vann dijo que se sentía "muy honrado de participar en el desfile" y agregó que "el valor de un verdadero héroe está siendo demostrado por el apoyo que va a dar mucha gente".
Los fanáticos de las MMA se quedaron despiertos toda la noche para ver Bellator 206, y en su lugar recibieron a Peppa Pig.
Imagínate esto, te has quedado despierto toda la noche para ver el repleto Bellator 206 sólo para que te nieguen ver el evento principal.
El proyecto de ley de San José contenía 13 peleas, incluidas seis en la tarjeta principal y se mostraba en vivo durante la noche en el Reino Unido en el Canal 5.
A las 6 de la mañana, justo cuando Gegard Mousasi y Rory MacDonald se preparaban para enfrentarse, los espectadores en el Reino Unido quedaron atónitos cuando la cobertura cambió a Peppa Pig.
Algunos no quedaron impresionados después de haber permanecido despiertos hasta las primeras horas especialmente para la pelea.
Un fanático en Twitter describió el cambio a la caricatura infantil como "una especie de broma enfermiza".
"Es la regulación del gobierno que a las 6 a.m. ese contenido no era adecuado por lo que tuvieron que cambiar a la programación para niños", dijo Dave Schwartz, vicepresidente senior de marketing y comunicación de Bellator, cuando se le preguntó sobre la transmisión.
"Peppa el cerdo", sí.
El presidente de la compañía Bellator, Scott Coker, dijo que van a trabajar en su programación para incluir a los espectadores del Reino Unido en el futuro.
"Creo que cuando pienso en la repetición, creo que probablemente podamos resolverlo", dijo Coker.
"Pero son las seis de la mañana de un domingo allí y no vamos a ser capaces de resolver esto hasta el domingo nuestro tiempo, el lunes su tiempo.
Pero estamos trabajando en ello.
Créeme, cuando cambió hubo muchos mensajes de texto yendo y viniendo y no todos eran amistosos.
Estábamos tratando de arreglarlo, pensamos que era un fallo técnico.
Pero no lo era, era un asunto gubernamental.
Puedo prometerte que la próxima vez no va a suceder.
Vamos a mantenerlo a cinco peleas en lugar de seis - como lo hacemos normalmente - y tratamos de entregar más para los aficionados y nos fuimos.
Es una situación desafortunada".
Desert Island Discs: Tom Daley se sintió 'inferior' por su sexualidad
El buzo olímpico Tom Daley dice que creció sintiéndose inferior a todos debido a su sexualidad, pero eso le dio la motivación para convertirse en un éxito.
El joven de 24 años dijo que no se dio cuenta hasta que fue a la escuela secundaria de que "no todos son como yo".
Hablando en el primer Radio 4 Desert Island Discs presentado por Lauren Laverne, dijo que habló sobre los derechos de los homosexuales para dar a otros "esperanza".
También dijo que ser padre hizo que le importara menos ganar los Juegos Olímpicos.
La presentadora habitual del programa de larga duración, Kirsty Young, se ha tomado varios meses de descanso debido a una enfermedad.
Apareciendo como un náufrago en el primer programa de Laverne, Daley dijo que se sentía "menos que" todos los demás cuando crecía porque "no era socialmente aceptable que le gustaran los niños y las niñas".
Él dijo: "Hasta el día de hoy, esos sentimientos de sentirme inferior, y de sentirme diferente, han sido las cosas reales que me han dado el poder y la fuerza para poder tener éxito".
Quería demostrar que era "algo", dijo, para no decepcionar a todos cuando finalmente se enteraran de su sexualidad.
El dos veces medallista de bronce olímpico se ha convertido en un destacado activista LGBT y utilizó su aparición en los Juegos de la Commonwealth de este año en Australia para apelar a que más países despenalicen la homosexualidad.
Dijo que habló porque se sentía afortunado de poder vivir abiertamente sin ramificaciones y quería dar a otros "esperanza".
El tres veces campeón del mundo dijo que enamorarse de un hombre, el cineasta estadounidense Dustin Lance Black, a quien conoció en 2013, "me sorprendió".
Daley se casó con el ganador del Oscar, que es 20 años mayor que él, el año pasado, pero dijo que la diferencia de edad nunca había sido un problema.
"Cuando pasas por tantas cosas a una edad tan joven" - fue a sus primeras Olimpiadas a los 14 años y su padre murió de cáncer tres años después - dijo que era difícil encontrar a alguien de la misma edad que hubiera experimentado altibajos similares.
La pareja se convirtió en padres en junio, de un hijo llamado Robert Ray Black-Daley, y Daley dijo que su "perspectiva completa" había cambiado.
"Si me hubieras preguntado el año pasado, todo se trataba de 'Necesito ganar una medalla de oro'", dijo.
"Sabes qué, hay cosas más grandes que las medallas de oro olímpicas.
Mi medalla de oro olímpica es Robbie".
Su hijo tiene el mismo nombre que su padre Robert, quien murió en 2011 a los 40 años después de ser diagnosticado con cáncer cerebral.
Daley dijo que su padre no aceptaba que iba a morir y una de las últimas cosas que le había preguntado era si ya tenían sus boletos para Londres 2012, ya que quería estar en la primera fila.
"No podía decirle 'no vas a estar cerca para estar en la primera fila, papá'", dijo.
"Estaba sosteniendo su mano cuando dejó de respirar y no fue hasta que realmente dejó de respirar y estaba muerto que finalmente reconocí que no era invencible", dijo.
Al año siguiente, Daley compitió en los Juegos Olímpicos de 2012 y ganó el bronce.
"Solo sabía que esto era lo que había soñado toda mi vida: bucear frente a una multitud local en los Juegos Olímpicos, no había mejor sensación", dijo.
También inspiró su primera elección de canción - Proud de Heather Small - que había resonado con él en la preparación para los Juegos Olímpicos y todavía le daba piel de gallina.
Desert Island Discs está en la BBC Radio 4 el domingo a las 11:15 BST.
Mickelson, fuera de forma, en el banquillo el sábado en la Ryder Cup.
El estadounidense Phil Mickelson establecerá un récord el domingo cuando juegue su 47o partido de la Ryder Cup, pero tendrá que cambiar su forma para evitar que sea un triste hito.
Mickelson, jugando en el evento bienal por un récord de 12 veces, fue puesto en el banquillo por el capitán Jim Furyk para las cuatro bolas y cuadrangulares del sábado.
En lugar de estar en el centro de la acción, como tantas veces ha sido para los Estados Unidos, el ganador de cinco majors dividió su día entre ser una animadora y trabajar en su juego en el campo con la esperanza de rectificar lo que le aflige.
Nunca el más recto de los pilotos, incluso en el pico de su carrera, el de 48 años no es un ajuste ideal para el apretado campo Le Golf National, donde el largo áspero rutinariamente castiga los tiros errantes.
Y si el campo por sí solo no es lo suficientemente desalentador, Mickelson, en el noveno partido del domingo, se enfrenta al campeón del Abierto de Gran Bretaña Francesco Molinari, quien se ha unido al novato Tommy Fleetwood para ganar sus cuatro partidos esta semana.
Si los americanos, cuatro puntos abajo comenzando los 12 partidos individuales, tienen un buen comienzo, el partido de Mickelson podría ser absolutamente crucial.
Furyk expresó confianza en su hombre, no que pudiera decir mucho más.
"Él entendió completamente el papel que tenía hoy, me dio una palmada en la espalda y puso su brazo alrededor de mí y dijo que estaría listo mañana", dijo Furyk.
"Tiene mucha confianza en sí mismo.
Es un miembro del Salón de la Fama y ha aportado mucho a estos equipos en el pasado, y esta semana.
Probablemente no lo imaginé jugando dos partidos.
Imaginé más, pero así es como funcionó y así es como pensamos que teníamos que ir.
Quiere estar ahí fuera, como todos los demás".
Mickelson superará el récord de Nick Faldo por la mayor cantidad de partidos de la Ryder Cup jugados el domingo.
Podría marcar el final de una carrera en la Ryder Cup que nunca ha igualado las alturas de su récord individual.
Mickelson tiene 18 victorias, 20 derrotas y siete mitades, aunque Furyk dijo que su presencia trajo algunos intangibles al equipo.
"Es gracioso, es sarcástico, ingenioso, le gusta burlarse de la gente, y es un gran tipo para tener en la sala del equipo", explicó.
"Creo que los jugadores más jóvenes se divirtieron teniendo un ir a él, así, esta semana, que fue divertido de ver.
Él provee mucho más que solo juego".
El capitán de Europa, Thomas Bjorn, sabe que una gran ventaja puede desaparecer pronto.
Thomas Bjorn, el capitán europeo, sabe por experiencia que una ventaja considerable que se dirige a los singles del último día en la Ryder Cup puede convertirse fácilmente en un viaje incómodo.
El danés hizo su debut en el partido de 1997 en Valderrama, donde un equipo capitaneado por Seve Ballesteros tenía una ventaja de cinco puntos sobre los estadounidenses, pero apenas superó la línea de meta con sus narices al frente por el más estrecho de los márgenes, ganando 141⁄2-131⁄2.
"Sigues recordándote a ti mismo que teníamos una gran ventaja en Valderrama; Teníamos una gran ventaja en Brookline, donde perdimos, y en Valderrama, donde ganamos, pero apenas", dijo Bjorn, en la foto, después de ver a la Clase de 2018 ganar 5-3 tanto el viernes como ayer para liderar 10-6 en Le Golf National.
Así que la historia me mostrará a mí y a todos en ese equipo que esto no ha terminado.
Mañana lo harás todo.
Salir y hacer todas las cosas correctas.
Esto no ha terminado hasta que tengas los puntos en el tablero.
Tenemos un objetivo, y es intentar ganar este trofeo, y ahí es donde se centra.
He dicho todo el tiempo, me concentro en los 12 jugadores que están en nuestro lado, pero somos muy conscientes de lo que está de pie en el otro lado - los mejores jugadores del mundo".
Encantado por la forma en que sus jugadores se han desempeñado en un campo de golf difícil, Bjorn añadió: "Nunca me adelantaría a mí mismo en esto.
Mañana es una bestia diferente.
Mañana son las actuaciones individuales que se presentan, y eso es algo diferente de hacer.
Es genial estar ahí fuera con un compañero cuando las cosas van bien, pero cuando estás ahí fuera individualmente, entonces se pone a prueba toda tu capacidad como golfista.
Ese es el mensaje que necesitas transmitir a los jugadores, es sacar lo mejor de ti mismo mañana.
Ahora, dejas a tu compañero atrás y él tiene que ir y sacar lo mejor de sí mismo, también".
En contraste con Bjorn, el oponente Jim Furyk buscará que sus jugadores se desempeñen mejor individualmente de lo que lo hicieron como socios, las excepciones son Jordan Spieth y Justin Thomas, que obtuvieron tres puntos de cuatro.
El propio Furyk ha estado en ambos extremos de esos grandes giros del último día, habiendo sido parte del equipo ganador en Brookline antes de terminar como perdedor cuando Europa logró el "Milagro en Medina".
"Recuerdo cada maldita palabra", dijo en respuesta a la pregunta de cómo Ben Crenshaw, el capitán en 1999, había reunido a sus jugadores en el último día.
"Tenemos 12 partidos importantes mañana, pero te gustaría comenzar rápido como lo viste en Brookline, como lo viste en Medinah.
Cuando ese impulso se va en una dirección, pone mucha presión en esos partidos del medio.
Arreglamos nuestra alineación en consecuencia y pusimos a los muchachos en la moda que sentimos, ya sabes, estamos tratando de hacer algo mágico mañana. "
Thomas ha recibido la tarea de tratar de liderar la lucha y se enfrenta a Rory McIlroy en el primer partido, con Paul Casey, Justin Rose, Jon Rahm, Tommy Fleetwood e Ian Poulter los otros europeos en la mitad superior de la orden.
"Fui con este grupo de chicos en este orden porque creo que cubre todo el camino", dijo Bjorn de sus selecciones de solteros.
El nuevo buque de guerra de Alemania se pospuso una vez más.
La fragata más nueva de la Armada alemana debería haber sido puesta en servicio en 2014 para reemplazar a los viejos buques de guerra de la Guerra Fría, pero no estará allí hasta al menos el próximo año debido a los sistemas defectuosos y el costo de la bola de nieve, informaron los medios locales.
La puesta en servicio del "Rheinland-Pfalz", el buque principal de las nuevas fragatas de la clase Baden-Wuerttemberg, ahora se ha pospuesto hasta la primera mitad de 2019, según el periódico Die Zeit citando a un portavoz militar.
El buque debería haberse unido a la Armada en 2014, pero los problemáticos problemas posteriores a la entrega afectaron el destino del ambicioso proyecto.
Los cuatro buques de la clase Baden-Wuerttemberg que la Armada ordenó en 2007 reemplazarán a las viejas fragatas de la clase Bremen.
Se entiende que contarán con un poderoso cañón, una serie de misiles antiaéreos y antibuque, así como algunas tecnologías de sigilo, como radar reducido, infrarrojos y firmas acústicas.
Otras características importantes incluyen períodos de mantenimiento más largos: debería ser posible desplegar las fragatas más nuevas hasta dos años lejos de los puertos de origen.
Sin embargo, las continuas demoras significan que los buques de guerra de vanguardia - que se dice permiten a Alemania proyectar poder en el extranjero - ya estarán obsoletos para cuando entren en servicio, señala Die Zeit.
La nefasta fragata F125 llegó a los titulares el año pasado, cuando la Armada alemana se negó oficialmente a encargar el buque y lo devolvió al astillero Blohm & Voss en Hamburgo.
Esta fue la primera vez que la Armada devolvió un barco a un constructor naval después de la entrega.
Poco se sabía sobre las razones detrás del regreso, pero los medios alemanes citaron una serie de "defectos de software y hardware" cruciales que hicieron que el buque de guerra fuera inútil si se desplegaba en una misión de combate.
Las deficiencias de software fueron particularmente importantes ya que los buques de la clase Baden-Wuerttemberg serán operados por una tripulación de unos 120 marineros, solo la mitad de la mano de obra de las fragatas más antiguas de la clase Bremen.
Además, surgió que el barco tiene un sobrepeso dramático que reduce su rendimiento y limita la capacidad de la Armada para agregar futuras actualizaciones.
Se cree que el "Rheinland-Pfalz" de 7.000 toneladas es dos veces más pesado que los barcos de clase similar utilizados por los alemanes en la Segunda Guerra Mundial.
Aparte del hardware defectuoso, el precio de todo el proyecto - incluyendo la capacitación de la tripulación - también se está convirtiendo en un problema.
Se dice que ha alcanzado los asombrosos 3,1 mil millones de euros (3,6 mil millones de dólares), frente a los 2,2 mil millones de euros iniciales.
Los problemas que afectan a las fragatas más nuevas se vuelven especialmente importantes a la luz de las recientes advertencias de que el poder naval de Alemania se está reduciendo.
A principios de este año, Hans-Peter Bartels, jefe del comité de defensa del parlamento alemán, reconoció que la Armada en realidad "se está quedando sin barcos capaces de ser desplegados".
El funcionario dijo que el problema se ha convertido en una bola de nieve con el tiempo, porque los barcos viejos fueron retirados del servicio pero no se proporcionaron buques de reemplazo.
Lamentó que ninguna de las fragatas de la clase Baden-Wuerttemberg pudiera unirse a la Armada.
El National Trust escucha la vida secreta de los murciélagos
Una nueva investigación que se está llevando a cabo en una finca en las tierras altas de Escocia tiene como objetivo revelar cómo los murciélagos utilizan el paisaje en su búsqueda de alimento.
Se espera que los hallazgos arrojen nueva luz sobre el comportamiento de los únicos mamíferos voladores y ayuden a guiar futuras actividades de conservación.
El estudio realizado por científicos del National Trust for Scotland seguirá a las pipistrellas comunes y sopranas, así como a los murciélagos marrones de orejas largas y de Daubenton en Inverewe Gardens en Wester Ross.
Se colocarán registradores especiales en lugares clave alrededor de la propiedad para rastrear las actividades de los murciélagos durante toda la temporada.
El personal y los voluntarios del NHS también llevarán a cabo encuestas móviles utilizando detectores portátiles.
El análisis de sonido de expertos de todas las grabaciones determinará la frecuencia de las llamadas de los murciélagos y qué especies están haciendo qué.
A continuación, se elaborará un mapa y un informe de hábitat para crear una imagen detallada a escala de paisaje de su comportamiento.
Rob Dewar, asesor de conservación de la naturaleza de NTS, espera que los resultados revelen qué áreas de hábitat son más importantes para los murciélagos y cómo las utilizan cada una de las especies.
Esta información ayudará a determinar los beneficios del trabajo de gestión del hábitat, como la creación de prados y la mejor manera de mantener los bosques para los murciélagos y otras especies asociadas.
Las poblaciones de murciélagos en Escocia y en todo el Reino Unido han disminuido considerablemente en el último siglo.
Están amenazados por la construcción y los trabajos de desarrollo que afectan a los descansos y la pérdida de hábitat.
Las turbinas eólicas y la iluminación también pueden representar un riesgo, al igual que el papel mosca y algunos tratamientos químicos de los materiales de construcción, así como los ataques de los gatos domésticos.
Los murciélagos no son en realidad ciegos.
Sin embargo, debido a sus hábitos de caza nocturna sus oídos son más útiles que sus ojos cuando se trata de atrapar presas.
Utilizan una sofisticada técnica de eco-localización para localizar insectos y obstáculos en su trayectoria de vuelo.
El NTS, que es responsable del cuidado de más de 270 edificios históricos, 38 jardines importantes y 76.000 hectáreas de tierra en todo el país, toma muy en serio a los murciélagos.
Cuenta con diez expertos capacitados, que llevan a cabo periódicamente encuestas, inspecciones de gallinas y, a veces, rescates.
La organización incluso ha creado la primera y única reserva de murciélagos de Escocia en la finca Threave en Dumfries y Galloway, que alberga ocho de las diez especies de murciélagos de Escocia.
El administrador de la finca David Thompson dice que la finca es el territorio ideal para ellos.
"Aquí en Threave tenemos una gran área para los murciélagos", dijo.
"Tenemos los edificios antiguos, muchos árboles veteranos y todo el buen hábitat.
Pero hay mucho sobre los murciélagos que aún se desconoce, por lo que el trabajo que hacemos aquí y en otras propiedades nos ayudará a entender más sobre lo que necesitan para prosperar".
Hace hincapié en la importancia de comprobar si hay murciélagos antes de llevar a cabo el mantenimiento dentro de las propiedades, ya que es posible que la destrucción involuntaria de un solo nido de maternidad pueda matar hasta 400 hembras y crías, posiblemente eliminando a toda una población local.
Los murciélagos están protegidos y es ilegal matarlos, acosarlos o molestarlos o destruir sus guaridas.
Elisabeth Ferrell, oficial escocesa de la Fundación para la Conservación del Murciélago, ha animado al público a ayudar.
Ella dijo: "Todavía tenemos mucho que aprender sobre nuestros murciélagos y para muchas de nuestras especies simplemente no sabemos cómo les va a sus poblaciones".
Ronaldo rechaza las acusaciones de violación mientras los abogados se preparan para demandar a la revista alemana
Cristiano Ronaldo ha calificado las acusaciones de violación en su contra como "noticias falsas", diciendo que la gente "quiere promocionarse" usando su nombre.
Sus abogados están listos para demandar a la revista alemana Der Spiegel, que publicó las acusaciones.
El delantero de Portugal y Juventus ha sido acusado de violar a una mujer estadounidense, llamada Kathryn Mayorga, en una habitación de hotel de Las Vegas en 2009.
Se alega que luego le pagó $ 375,000 para que guardara silencio sobre el incidente, informó Der Spiegel el viernes.
Hablando en un video de Instagram Live a sus 142 millones de seguidores horas después de que se informaran los reclamos, Ronaldo, de 33 años, criticó los informes como "noticias falsas".

Lo que dijeron hoy, noticias falsas", dice el cinco veces ganador del Balón de Oro a la cámara.
"Quieren promocionarse usando mi nombre.
Eso es normal.
Quieren ser famosos por decir mi nombre, pero es parte del trabajo.
Soy un hombre feliz y todo bien", añadió el jugador, sonriendo.
Los abogados de Ronaldo se están preparando para demandar a Der Spiegel por las acusaciones, que han llamado "un informe inadmisible de sospechas en el área de privacidad", según Reuters.
El abogado Christian Schertz dijo que el jugador buscaría una compensación por "daños morales en una cantidad correspondiente a la gravedad de la infracción, que es probablemente una de las violaciones más graves de los derechos personales en los últimos años".
Se dice que el presunto incidente tuvo lugar en junio de 2009 en una suite del Hotel y Casino Palms en Las Vegas.
Después de reunirse en un club nocturno, Ronaldo y Mayorga supuestamente regresaron a la habitación de la jugadora, donde supuestamente la violó analmente, según documentos presentados en el Tribunal de Distrito del Condado de Clark en Nevada.
Mayorga afirma que Ronaldo cayó de rodillas después del presunto incidente y le dijo que era "99 por ciento" un "buen tipo" decepcionado por el "un por ciento".
Los documentos afirman que Ronaldo confirmó que la pareja tuvo relaciones sexuales, pero que fue consensual.
Mayorga también afirma que fue a la policía y se tomaron fotografías de sus heridas en un hospital, pero más tarde aceptó un acuerdo extrajudicial porque se sentía "aterrorizada de represalias" y estaba preocupada por "ser humillada públicamente".
La mujer de 34 años dice que ahora está buscando anular el acuerdo ya que continúa traumatizada por el presunto incidente.
Ronaldo estaba a punto de unirse al Real Madrid desde el Manchester United en el momento del presunto asalto, y este verano se trasladó a los gigantes italianos Juve en un acuerdo de 100 millones de euros.
Brexit: el Reino Unido "se arrepentiría para siempre" de perder a los fabricantes de automóviles
El Reino Unido "lo lamentaría para siempre" si perdiera su estatus de líder mundial en la fabricación de automóviles después del Brexit, dijo el secretario de Comercio, Greg Clark.
Por último, el Parlamento Europeo ha adoptado una resolución en la que pide a la Comisión y a los Estados miembros que adopten medidas para combatir la corrupción y la delincuencia organizada, así como a la Comisión y a los Estados miembros que adopten medidas para combatir la delincuencia organizada y la delincuencia organizada.
"Necesitamos un acuerdo", dijo el Sr. Clark.
El fabricante de automóviles japonés dijo que el impacto de los retrasos fronterizos en el caso de un Brexit sin acuerdo podría costar empleos.
La planta de Burnaston, que fabrica los Auris y Avensis de Toyota, produjo el año pasado casi 150.000 automóviles, de los cuales el 90% se exportó al resto de la Unión Europea.
"Mi opinión es que si Gran Bretaña sale de la UE a finales de marzo, veremos que la producción se detiene en nuestra fábrica", dijo Marvin Cooke, director gerente de Toyota en Burnaston.
Otros fabricantes de automóviles del Reino Unido han expresado su temor a abandonar la UE sin un acuerdo sobre cómo funcionará el comercio transfronterizo, incluidos Honda, BMW y Jaguar Land Rover.
BMW, por ejemplo, dice que cerrará su planta Mini en Oxford durante un mes después del Brexit.
Las principales preocupaciones están relacionadas con lo que los fabricantes de automóviles dicen que son riesgos de la cadena de suministro en caso de un Brexit sin acuerdo.
La línea de producción de Toyota se ejecuta sobre una base de "justo a tiempo", con piezas que llegan cada 37 minutos de proveedores tanto en el Reino Unido como en la UE para automóviles hechos a pedido.
Si el Reino Unido abandona la UE sin un acuerdo el 29 de marzo, podría haber una interrupción en la frontera que, según la industria, podría provocar retrasos y escasez de piezas.
Sería imposible para Toyota mantener más de un día de inventario en su planta de Derbyshire, dijo la compañía, y por lo tanto la producción se detendría.
El Sr. Clark dijo que el plan Chequers de Theresa May para las futuras relaciones con la UE está "precisamente calibrado para evitar esos controles en la frontera".
"Necesitamos hacer un trato. Queremos tener el mejor acuerdo que permita, como digo, no solo disfrutar del éxito actual, sino aprovechar esta oportunidad", dijo en el programa Today de BBC Radio 4.
"La evidencia no sólo de Toyota sino de otros fabricantes es que necesitamos ser absolutamente capaces de continuar lo que ha sido un conjunto muy exitoso de cadenas de suministro".
Toyota no pudo decir cuánto tiempo se detendría la producción, pero a largo plazo, advirtió que los costos adicionales reducirían la competitividad de la planta y, finalmente, costarían empleos.
Peter Tsouvallaris, que ha trabajado en Burnaston durante 24 años y es el coordinador sindical de Unite en la planta, dijo que sus miembros están cada vez más preocupados: "Según mi experiencia, una vez que estos trabajos desaparecen, nunca vuelven.
Un portavoz del gobierno dijo: "Hemos presentado un plan preciso y creíble para nuestra futura relación con la UE".
La reunión de Trump con Rosenstein puede retrasarse de nuevo, dice la Casa Blanca
La reunión de alto riesgo de Donald Trump con el fiscal general adjunto Rod Rosenstein podría "retrasarse una semana más" mientras continúa la lucha por el candidato a la Corte Suprema Brett Kavanaugh, dijo el domingo la Casa Blanca.
Rosenstein supervisa el trabajo del fiscal especial Robert Mueller, quien está investigando la interferencia electoral rusa, los vínculos entre los asesores de Trump y Rusia y la posible obstrucción de la justicia por parte del presidente.
Si Trump despedirá o no al fiscal general adjunto, y por lo tanto pondrá en peligro la independencia de Mueller, ha alimentado chismes en Washington durante meses.
A principios de este mes, el New York Times informó que Rosenstein discutió el uso de un cable para grabar conversaciones con Trump y la posibilidad de destituir al presidente a través de la 25a enmienda.
Rosenstein negó el reporte.
Pero el lunes pasado fue a la Casa Blanca, en medio de informes de que estaba a punto de renunciar.
En cambio, se anunció para el jueves una reunión con Trump, que entonces se encontraba en las Naciones Unidas en Nueva York.
Trump dijo que "preferiría no" despedir a Rosenstein, pero luego la reunión se retrasó para evitar un choque con la audiencia del comité judicial del Senado en la que Kavanaugh y una de las mujeres que lo han acusado de conducta sexual inapropiada, la doctora Christine Blasey Ford, testificaron.
El viernes, Trump ordenó una investigación de una semana del FBI de las reclamaciones contra Kavanaugh, retrasando aún más la votación completa del Senado.
La secretaria de prensa de Trump, Sarah Sanders, apareció el domingo en Fox News.
Cuando se le preguntó sobre la reunión de Rosenstein, dijo: "No se ha establecido una fecha para eso, podría ser esta semana, podría ver que retrasar otra semana dado todas las otras cosas que están sucediendo con la corte suprema.
Pero ya veremos y siempre me gusta mantener a la prensa actualizada".
Algunos periodistas cuestionarían esa afirmación: Sanders no ha mantenido una rueda de prensa en la Casa Blanca desde el 10 de septiembre.
El anfitrión Chris Wallace preguntó por qué.
Sanders dijo que la escasez de sesiones informativas no se debió a una aversión por los reporteros de televisión "grandstanding", aunque dijo: "No estaré en desacuerdo con el hecho de que se presentan".
Luego sugirió que el contacto directo entre Trump y la prensa aumentará.
"El presidente hace más sesiones de preguntas y respuestas que cualquier presidente que lo haya precedido", dijo, y agregó sin citar pruebas: "Hemos mirado esas cifras".
Las reuniones informativas todavía sucederán, dijo Sanders, pero "si la prensa tiene la oportunidad de hacer preguntas al presidente de los Estados Unidos directamente, eso es infinitamente mejor que hablar conmigo.
Tratamos de hacer eso mucho y nos han visto hacer mucho en las últimas semanas y que va a tomar el lugar de una rueda de prensa cuando se puede hablar con el presidente de los Estados Unidos. "
Trump regularmente responde preguntas al salir de la Casa Blanca o al participar en sesiones abiertas o conferencias de prensa con dignatarios visitantes.
Las conferencias de prensa en solitario son raras.
En Nueva York esta semana el presidente tal vez demostró por qué, haciendo una aparición libre y a veces extraña ante los periodistas reunidos.
El secretario de Salud escribe a los trabajadores de la UE en el NHS de Escocia sobre los temores del Brexit
El Secretario de Salud ha escrito al personal de la UE que trabaja en el NHS de Escocia para expresar la gratitud del país y el deseo de que permanezcan en el post-Brexit.
Jeane Freeman MSP envió una carta con menos de seis meses para que el Reino Unido se retire de la UE.
El Gobierno escocés ya se ha comprometido a cubrir el coste de las solicitudes de estatus de residente para los ciudadanos de la UE que trabajan en sus servicios públicos descentralizados.
En su carta, la Sra. Freeman escribió: "Durante el verano han continuado las negociaciones entre el Reino Unido y la UE sobre la retirada, con vistas a las decisiones que se esperan este otoño.
Pero el Gobierno del Reino Unido también ha estado intensificando sus preparativos para un posible escenario de no acuerdo.
Sé que esto debe ser un momento muy inquietante para todos ustedes.
Por eso quise reiterar ahora cuánto valoro la contribución de cada miembro del personal, independientemente de su nacionalidad.
Los colegas de toda la UE y de otros países aportan una valiosa experiencia y habilidades que fortalecen y mejoran el trabajo del servicio de salud y benefician a los pacientes y a las comunidades a las que servimos.
Escocia es absolutamente tu hogar y queremos mucho que te quedes aquí".
Christion Abercrombie se somete a una cirugía de emergencia después de sufrir una lesión en la cabeza
El linebacker de los Tigres del Estado de Tennessee, Christion Abercrombie, se sometió a una cirugía de emergencia después de sufrir una lesión en la cabeza en la derrota del sábado por 31-27 ante los Vanderbilt Commodores, informó Mike Organ, del Tennessean.
El entrenador en jefe de Tennessee State, Rod Reed, dijo a los periodistas que la lesión ocurrió poco antes del descanso.
"Llegó a la línea lateral y se derrumbó allí", dijo Reed.
Los entrenadores y el personal médico le dieron oxígeno a Abercrombie en la línea lateral antes de colocarlo en una camilla y llevarlo de vuelta para una evaluación adicional.
Un funcionario del estado de Tennessee le dijo a Chris Harris de WSMV en Nashville, Tennessee, que Abercrombie estaba fuera de la cirugía en el Centro Médico Vanderbilt.
Harris agregó que "todavía no hay detalles sobre el tipo / extensión de la lesión" y Tennessee State está tratando de averiguar cuándo ocurrió la lesión.
Abercrombie, un camiseta roja estudiante de segundo año, está en su primera temporada con el estado de Tennessee después de la transferencia de Illinois.
Tuvo cinco tacleadas totales el sábado antes de salir del juego, lo que elevó su total de la temporada a 18 tacleadas.
A los compradores extranjeros se les cobrará un impuesto de timbre más alto cuando compren una propiedad en el Reino Unido
A los compradores extranjeros se les cobrará un impuesto de timbre más alto cuando compren una propiedad en el Reino Unido con el dinero extra utilizado para ayudar a las personas sin hogar bajo los nuevos planes conservadores.
La medida neutralizará el éxito de la campaña de Corbyn para atraer a los votantes jóvenes
El aumento del impuesto de timbre se aplicará a aquellos que no estén pagando impuestos en el Reino Unido
El Tesoro espera recaudar hasta 120 millones de libras al año para ayudar a las personas sin hogar.
A los compradores extranjeros se les cobrará un impuesto de timbre más alto cuando compren propiedades en el Reino Unido, con el dinero extra utilizado para ayudar a las personas sin hogar, anunciará hoy Theresa May.
La medida será vista como un intento de neutralizar el éxito de la campaña de Jeremy Corbyn para atraer a los votantes jóvenes con promesas de proporcionar viviendas más asequibles y dirigirse a las personas de altos ingresos.
El aumento del impuesto de timbre se cobrará a las personas y empresas que no pagan impuestos en el Reino Unido, con el dinero extra que impulsa el impulso del Gobierno para combatir el sueño áspero.
El recargo - que se añade al actual impuesto de timbre, incluidos los niveles más altos introducidos hace dos años en las segundas viviendas y las compras para alquilar - podría ser de hasta el tres por ciento.
El Tesoro espera que el movimiento recaude hasta 120 millones de libras al año.
Se estima que el 13 por ciento de las propiedades de nueva construcción en Londres son compradas por no residentes en el Reino Unido, lo que hace subir los precios y hace que sea más difícil para los compradores por primera vez poner un pie en la escalera de la vivienda.
Muchas zonas ricas del país - especialmente en la capital - se han convertido en "ciudades fantasmas" debido al alto número de compradores extranjeros que pasan la mayor parte de su tiempo fuera del país.
La nueva política llega pocas semanas después de que Boris Johnson pidiera un recorte de impuestos de sello para ayudar a más jóvenes a tener su primera casa.
El Parlamento Europeo ha adoptado una serie de resoluciones en las que se recomienda a los Estados miembros que respeten los principios de subsidiariedad y la libre circulación de las personas.
El Sr. Corbyn ha anunciado una serie llamativa de reformas de vivienda propuestas, incluidos los controles de alquiler y el fin de los desalojos "sin culpa".
También quiere dar a los ayuntamientos mayores poderes para construir nuevas viviendas.
La Sra. May dijo: "El año pasado dije que dedicaría mi cargo de primera ministra a restaurar el sueño británico: que la vida sea mejor para cada nueva generación.
Y eso significa arreglar nuestro mercado inmobiliario roto.
Gran Bretaña siempre estará abierta a las personas que quieran vivir, trabajar y construir una vida aquí.
Sin embargo, no puede ser correcto que sea tan fácil para las personas que no viven en el Reino Unido, así como para las empresas con sede en el extranjero, comprar casas como para los residentes británicos que trabajan duro.
Para demasiadas personas el sueño de poseer una casa se ha vuelto demasiado lejano, y la indignidad de dormir en la calle sigue siendo demasiado real".
Jack Ross: "Mi mayor ambición es dirigir Escocia"
El jefe de Sunderland, Jack Ross, dice que su "última ambición" es convertirse en el gerente de Escocia en algún momento.
El escocés, de 42 años, está disfrutando el desafío de revivir el club del noreste, que actualmente ocupa el tercer lugar en la Liga Uno, a tres puntos de la cima.
Se mudó al Estadio de la Luz este verano después de guiar a St Mirren de regreso a la Premiership escocesa la temporada pasada.
"Yo quería jugar para mi país como jugador.
Obtuve una gorra B y eso fue todo", dijo Ross a BBC Scotland's Sportsound.
"Pero crecí viendo a Escocia en Hampden mucho con mi padre cuando era niño, y siempre es algo que me ha traído de vuelta.
Esa oportunidad sólo vendría, sin embargo, si tengo éxito en la gestión del club".
Los predecesores de Ross como entrenador del Sunderland incluyen a Dick Advocaat, David Moyes, Sam Allardyce, Martin O'Neill, Roy Keane, Gus Poyet y Paulo Di Canio.
El ex jefe de Alloa Athletic dice que no sintió temor en seguir nombres tan establecidos en un club tan grande, habiendo rechazado previamente propuestas de Barnsley e Ipswich Town.
"El éxito para mí en este momento será medido por '¿Puedo devolver este club a la Premier League?'
Debido a la estructura y las instalaciones de este club, sin duda pertenece a la Premier League", dijo.
"No es una tarea fácil llevarlo allí, pero probablemente solo me considere exitoso aquí si puedo hacer que el club vuelva allí".
Ross solo tiene tres años en su carrera como gerente, después de un período como asistente de jefe en Dumbarton y un período de 15 meses en el cuerpo técnico de Hearts.
Luego ayudó a Alloa a recuperarse del descenso a la tercera división, y transformó a St Mirren del borde del descenso a ganadores del título del Campeonato la temporada siguiente.
Y Ross dice que se siente más cómodo ahora de lo que lo hizo durante su carrera como jugador en Clyde, Hartlepool, Falkirk, St Mirren y Hamilton Academical.
"Probablemente fue una verdadera encrucijada", recordó, de hacerse cargo de Alloa.
"Realmente creía que la dirección era lo más adecuado para mí, más que jugar.
Suena extraño porque lo hice bien, gané una vida razonable con eso, y disfruté de algunas altas razonables.
Pero jugar puede ser difícil.
Hay muchas cosas que tienes que hacer semanalmente.
Todavía paso por eso en términos de estrés y presión del trabajo pero la gerencia se siente bien.
Siempre quise manejarme y ahora que lo estoy haciendo, es lo más cómodo que he estado en mi propia piel a lo largo de toda mi vida adulta".
Puede escuchar la entrevista completa en Sportsound el domingo 30 de septiembre, en Radio Scotland entre las 12:00 y las 13:00 BST
La hora perfecta para una cerveza es las 5:30 p.m. de un sábado, según la encuesta
La ola de calor del verano ha aumentado las ganancias de los bares en dificultades de Gran Bretaña, pero ha aumentado la presión sobre las cadenas de restaurantes.
Los grupos de pubs y bares registraron un aumento de las ventas del 2,7 por ciento en julio, pero las compras en los restaurantes cayeron un 4,8 por ciento, revelaron las cifras.
Peter Martin, de la consultora de negocios CGA, que recopiló las cifras, dijo: "El continuo sol y la participación más larga de lo esperado de Inglaterra en la Copa del Mundo significaron que julio siguió un patrón similar al mes anterior de junio, cuando los pubs subieron un 2,8 por ciento, excepto que los restaurantes fueron golpeados aún más.
La caída del 1,8 por ciento en el comercio de restaurantes en junio empeoró en julio.
Los pubs y bares dirigidos por bebidas fueron los más fuertes, con similares por similares más que los restaurantes.
Los pubs alimentarios también sufrieron en el sol, aunque no tan dramáticamente como los operadores de restaurantes.
Parece que la gente sólo quería salir a tomar una copa.
En los pubs y bares administrados, las ventas de bebidas aumentaron un 6,6 por ciento durante el mes, mientras que las de alimentos bajaron un tres por ciento".
Paul Newman, de los analistas de ocio y hospitalidad RSM, dijo: "Estos resultados continúan la tendencia que hemos visto desde finales de abril.
El clima y el impacto de los principales eventos sociales o deportivos siguen siendo los factores más importantes en lo que respecta a las ventas en el mercado exterior.
No es de extrañar que los grupos de restaurantes sigan luchando, aunque una caída de las ventas del 4,8% interanual será particularmente dolorosa además de las continuas presiones de costos.
El largo y caluroso verano no podría haber llegado en un peor momento para los operadores alimentarios y el tiempo dirá si las temperaturas más moderadas que hemos experimentado en agosto proporcionarán un respiro muy necesario".
El crecimiento total de las ventas en pubs y restaurantes, incluidas las nuevas aperturas, fue del 2,7% en julio, lo que refleja la desaceleración en el despliegue de marcas.
El monitor de ventas de la industria Coffer Peach Tracker para el sector de pubs, bares y restaurantes del Reino Unido recopila y analiza datos de rendimiento de 47 grupos operativos, con una facturación combinada de más de 9 000 millones de libras esterlinas, y es el punto de referencia establecido de la industria.
Uno de cada cinco niños tiene cuentas secretas de redes sociales que ocultan a sus padres
Según una encuesta, uno de cada cinco niños, algunos de tan solo 11 años, tiene cuentas secretas en las redes sociales que ocultan a sus padres y maestros.
Una encuesta a 20.000 estudiantes de secundaria reveló un aumento en las páginas "falsas de Insta"
Las noticias han aumentado los temores de que se esté publicando contenido sexual
Veinte por ciento de los alumnos dijeron que tienen una cuenta "principal" para mostrar a los padres
Uno de cada cinco niños - algunos de tan sólo 11 años - están creando cuentas de redes sociales que mantienen en secreto de los adultos.
Una encuesta a 20.000 estudiantes de secundaria reveló un rápido crecimiento en las cuentas "falsas de Insta" - una referencia al sitio de intercambio de fotos Instagram.
Las noticias han aumentado los temores de que se esté publicando contenido sexual.
El veinte por ciento de los alumnos dijeron que operan una cuenta "principal" saneada para mostrar a los padres, mientras que también tienen cuentas privadas.
Una madre que se encontró con el sitio secreto de su hija de 13 años encontró a una adolescente instando a otros a "violarme".
La investigación, realizada por Digital Awareness UK y la Conferencia de Directores y Directoras (HMC) de escuelas independientes, encontró que el 40 por ciento de los jóvenes de 11 a 18 años tenían dos perfiles, y la mitad de ellos admitió tener cuentas privadas.
El director de HMC, Mike Buchanan, dijo: "Es preocupante que tantos adolescentes estén tentados a crear espacios en línea donde los padres y los maestros no puedan encontrarlos".
Eilidh Doyle será "la voz de los atletas" en la junta de Atletismo de Escocia
Eilidh Doyle ha sido elegida para el consejo de Scottish Athletics como directora no ejecutiva en la reunión general anual del órgano rector.
Doyle es la atleta de pista y campo más condecorada de Escocia y el presidente Ian Beattie describió el movimiento como una gran oportunidad para que los que guían el deporte se beneficien de su amplia experiencia a nivel internacional en la última década.
"Eilidh tiene un enorme respeto en toda la comunidad atlética escocesa, del Reino Unido y del mundo y estamos seguros de que el atletismo en Escocia se beneficiaría enormemente al traerla a la junta", dijo Beattie.
Doyle dijo: "Estoy ansioso por actuar como una voz para los atletas y espero poder realmente contribuir y ayudar a guiar el deporte en Escocia".
El estadounidense, que ganó los 200 metros y los 400 metros en los Juegos de 1996 en Atlanta entre sus cuatro medallas de oro olímpicas y ahora es un experto regular de la BBC, quedó incapacitado para caminar después de sufrir un ataque isquémico transitorio.
Escribió en Twitter: "Hace un mes hoy sufrí un derrame cerebral.
No podía caminar.
Los médicos dijeron que solo el tiempo dirá si me recuperaré o en qué grado.
Ha sido un trabajo agotador, pero me he recuperado completamente, he vuelto a aprender a caminar y hoy hago ejercicios de agilidad.
¡Gracias por los mensajes de aliento!"
El anuncio de la bomba de leche que compara a las madres con las vacas divide la opinión en línea
Una compañía de bombas de leche ha dividido la opinión en línea con un anuncio que compara a las madres lactantes con las vacas que se ordeñan.
Para conmemorar el lanzamiento de lo que se dice que es "la primera protuberancia mamaria portátil silenciosa del mundo", la compañía de tecnología de consumo Elvie lanzó un anuncio inspirado en un video musical irónico para mostrar la libertad que la nueva bomba da a las madres que se expresan.
Cuatro madres reales bailan en un granero lleno de heno de vacas a una canción que incluye letras como: "Sí, me ordeño a mí misma, pero no ves cola" y "En caso de que no lo hayas notado, estos no son ubres, son mis pechos".
El coro continúa: "Bombardeo, bombardeo, estoy alimentando a los bebés, bombardeo, bombardeo, estoy ordeñando a mis damas".
Sin embargo, el anuncio, que ha sido publicado en la página de Facebook de la firma, ha causado controversia en línea.
Con 77.000 visitas y cientos de comentarios, el video ha recibido reacciones mixtas de los espectadores, y muchos dicen que hace caso omiso de los "horrores" de la industria láctea.
"Muy mala decisión usar vacas para anunciar este producto.
Al igual que nosotros, necesitan quedar embarazadas y dar a luz para producir leche, excepto que sus bebés les son robados a los pocos días de dar a luz", escribió uno.
El bombeador de mama Elvie cabe discretamente dentro de un sostén de enfermería (Elvie/Madre)
Otra comentó: "Es comprensible que sea traumático tanto para la madre como para el bebé.
Pero sí, ¿por qué no usarlos para anunciar una bomba de leche para las madres que se quedan con sus bebés?"
Otra persona añadió: "Qué anuncio tan desactualizado".
Otros defendieron el anuncio, y una mujer admitió que encontró la canción "hilarante".
"Creo que esta es una idea de género.
Hubiera tenido uno si todavía estuviera amamantando.
El bombeo me hacía sentir exactamente como una vaca.
El anuncio es un poco loco pero lo tomé por lo que era.
Este es un producto genial", escribió uno.
Otro comentó: "Este es un anuncio divertido dirigido a las madres que bombean (a menudo en sus lugares de trabajo o en los baños) y se sienten como "vacas".
Este no es un anuncio que elogia o juzga a la industria láctea".
Al final del video el grupo de mujeres revelan que han estado bailando con las bombas discretas metidas en sus sujetadores.
El concepto detrás de la campaña se basa en la percepción de que muchas mujeres que bombean el pecho dicen que se sienten como vacas.
La bomba Elvie, sin embargo, es completamente silenciosa, no tiene cables ni tubos y se ajusta discretamente dentro de un sostén de enfermería, dando a las mujeres la libertad de moverse, sostener a sus bebés e incluso salir mientras bombea.
Ana Balarin, socia y ECD en Mother comentó: "La bomba Elvie es un producto tan revolucionario que merecía un lanzamiento audaz y provocativo.
Al trazar un paralelo entre expresar a las mujeres y las vacas lecheras, quisimos poner el bombeo mamario y todos sus desafíos en el centro de atención, al tiempo que demostramos de una manera entretenida y relatable la increíble sensación de libertad que traerá la nueva bomba.
Esta no es la primera vez que la bomba de Elvie ha sido noticia.
Durante la Semana de la Moda de Londres, una madre de dos hijos apareció en la pasarela para la diseñadora Marta Jakubowski mientras usaba el producto.
Cientos de niños migrantes fueron trasladados en silencio a un campamento de tiendas en la frontera de Texas
El número de niños migrantes detenidos ha aumentado a pesar de que los cruces fronterizos mensuales se han mantenido relativamente sin cambios, en parte porque la dura retórica y las políticas introducidas por la administración Trump han dificultado la colocación de niños con patrocinadores.
Tradicionalmente, la mayoría de los patrocinadores han sido inmigrantes indocumentados y han temido poner en peligro su propia capacidad de permanecer en el país al presentarse para reclamar a un niño.
El riesgo aumentó en junio, cuando las autoridades federales anunciaron que los posibles patrocinadores y otros miembros adultos de sus hogares tendrían que presentar huellas dactilares, y que los datos serían compartidos con las autoridades de inmigración.
La semana pasada, Matthew Albence, un alto funcionario de Inmigración y Control de Aduanas, testificó ante el Congreso que la agencia había arrestado a docenas de personas que solicitaron patrocinar a menores no acompañados.
La agencia confirmó más tarde que el 70 por ciento de los arrestados no tenían antecedentes penales.
"Casi el 80 por ciento de las personas que son patrocinadores o miembros de la familia de patrocinadores están aquí en el país ilegalmente, y una gran parte de ellos son extranjeros criminales.
Por lo tanto, continuamos persiguiendo a esos individuos", dijo el Sr. Albence.
Buscando procesar a los niños más rápidamente, los funcionarios introdujeron nuevas reglas que requerirán que algunos de ellos comparezcan ante el tribunal dentro de un mes de ser detenidos, en lugar de después de 60 días, que era el estándar anterior, según los trabajadores del refugio.
Muchos comparecerán por videoconferencia, en lugar de en persona, para defender su caso de estatus legal ante un juez de inmigración.
Aquellos que se considere no elegibles para el alivio serán deportados rápidamente.
Cuanto más tiempo permanezcan los niños bajo custodia, más probable es que se vuelvan ansiosos o deprimidos, lo que puede conducir a estallidos violentos o intentos de escape, según los trabajadores del refugio y los informes que han surgido del sistema en los últimos meses.
Los defensores dijeron que esas preocupaciones se intensifican en una instalación más grande como Tornillo, donde las señales de que un niño está luchando son más propensas a ser pasadas por alto, debido a su tamaño.
Añadieron que trasladar a los niños a la ciudad de las tiendas de campaña sin darles suficiente tiempo para prepararlos emocionalmente o para despedirse de los amigos podría agravar el trauma con el que muchos ya están luchando.
Siria pide a las 'fuerzas de ocupación' estadounidenses, francesas y turcas que se retiren de inmediato
Dirigiéndose a la Asamblea General de la ONU, el Ministro de Relaciones Exteriores Walid al-Moualem también pidió a los refugiados sirios que regresen a casa, a pesar de que la guerra del país está ahora en su octavo año.
Moualem, quien también se desempeña como viceprimer ministro, dijo que las fuerzas extranjeras estaban en suelo sirio ilegalmente, bajo el pretexto de luchar contra el terrorismo, y "serán tratadas en consecuencia".
"Deben retirarse de inmediato y sin condiciones", dijo a la asamblea.
Moualem insistió en que la "guerra contra el terrorismo casi ha terminado" en Siria, donde más de 360,000 personas han muerto desde 2011, con millones más desarraigadas de sus hogares.
Dijo que Damasco continuaría "luchando esta batalla sagrada hasta que purguemos todos los territorios sirios" de ambos grupos terroristas y "cualquier presencia extranjera ilegal".
Estados Unidos tiene unos 2.000 soldados en Siria, principalmente entrenando y asesorando tanto a las fuerzas kurdas como a los árabes sirios que se oponen al presidente Bashar al-Assad.
Francia tiene más de 1.000 soldados en el terreno en el país devastado por la guerra.
Sobre el tema de los refugiados, Moualem dijo que las condiciones eran buenas para que regresaran, y culpó a "algunos países occidentales" por "difundir miedos irracionales" que impulsaron a los refugiados a mantenerse alejados.
"Hemos pedido a la comunidad internacional y a las organizaciones humanitarias que faciliten estos retornos", dijo.
"Están politizando lo que debería ser un asunto puramente humanitario".
Los Estados Unidos y la Unión Europea han advertido que no habrá ayuda para la reconstrucción de Siria hasta que haya un acuerdo político entre Assad y la oposición para poner fin a la guerra.
Diplomáticos de la ONU dicen que un reciente acuerdo entre Rusia y Turquía para establecer una zona de amortiguación en el último gran bastión rebelde de Idlib ha creado una oportunidad para seguir adelante con las conversaciones políticas.
El acuerdo ruso-turco evitó un ataque a gran escala de las fuerzas sirias respaldadas por Rusia en la provincia, donde viven tres millones de personas.
Moualem, sin embargo, enfatizó que el acuerdo tenía "plazos claros" y expresó la esperanza de que la acción militar se dirija a los yihadistas, incluidos los combatientes del Frente Nusra vinculado a Al-Qaeda, que "serán erradicados".
El enviado de la ONU, Staffan de Mistura, espera convocar pronto las primeras reuniones de un nuevo comité compuesto por miembros del gobierno y la oposición para redactar una constitución de posguerra para Siria y allanar el camino para las elecciones.
Moualem expuso las condiciones para la participación del gobierno sirio en el comité, diciendo que el trabajo del panel debería limitarse "a revisar los artículos de la constitución actual", y advirtió contra la interferencia.
Por qué Trump ganará un segundo mandato
Según esa lógica, el Sr. Trump ganaría la reelección en 2020 a menos que, como muchos espectadores liberales probablemente esperan, el juicio político y el escándalo terminen su presidencia prematuramente.
En lo que sin duda sería "El final más dramático de una presidencia nunca!"
A partir de ahora, no hay signos de fatiga de los espectadores.
Desde 2014, las audiencias en horario estelar se han más que duplicado a 1,05 millones en CNN y casi se han triplicado a 1,6 millones en MSNBC.
Fox News tiene un promedio de 2.4 millones de espectadores en horario estelar, frente a 1.7 millones hace cuatro años, según Nielsen, y "The Rachel Maddow Show" de MSNBC ha encabezado las calificaciones de cable con hasta 3.5 millones de espectadores en las principales noches de noticias.
"Este es un incendio al que la gente se siente atraída porque no es algo que entendamos", dijo Neal Baer, presentador del drama de ABC "Designated Survivor", sobre un secretario de gabinete que se convierte en presidente después de que un ataque destruye el Capitolio.
Nell Scovell, una veterana escritora de comedias y autora de "Sólo las partes divertidas: y algunas verdades duras sobre colarse en el club de los chicos de Hollywood", tiene otra teoría.
Recuerda un viaje en taxi en Boston antes de las elecciones de 2016.
El conductor le dijo que votaría por el Sr. Trump.
- ¿Por qué no? Ella preguntó.
Él dijo: "Porque me hace reír", me dijo la Srta. Scovell.
Hay valor de entretenimiento en el caos.
Por supuesto, a diferencia de cualquier otra cosa en la TV, las líneas de la historia que salen de Washington podrían determinar el futuro de Roe v. Wade, si las familias inmigrantes pueden reunirse y la salud de la economía global.
La desconexión es un lujo que sólo los espectadores más privilegiados pueden permitirse.
Y sin embargo, va más allá de ser un ciudadano informado cuando te encuentras en la sexta hora de ver a un panel de expertos debatir el uso de Bob Woodward de fuentes "de fondo profundo" para su libro "Miedo,"La chaqueta bomba de piel de avestruz de $ 15,000 de Paul Manafort ("una prenda gruesa con arrogancia", dijo The Washington Post) y las implicaciones de las descripciones espeluznantes de Stormy Daniels de la anatomía del Sr. Trump.
Yo, por ejemplo, nunca volveré a ver a Super Mario de la misma manera.
"Parte de lo que hace que parezca un reality show es que te da algo de comer todas las noches," dijo Brent Montgomery, director ejecutivo de Wheelhouse Entertainment y creador de "Pawn Stars", sobre el reparto rotativo del programa de Trump y los giros diarios de la trama (elegir una pelea con la NFL, elogiando a Kim Jong-un).
No puedes permitirte perderte un episodio o te quedas atrás.
Cuando llegué al Sr. Fleiss esta semana, había unos 80 grados soleados fuera de su casa en la costa norte de Kauai, pero él estaba encerrado dentro viendo MSNBC mientras grababa CNN.
No podía separarse, no con Brett Kavanaugh listo para enfrentarse al Comité Judicial del Senado y el futuro de la Corte Suprema colgando de un hilo.
"Recuerdo cuando hacíamos todos esos espectáculos locos en el pasado y la gente decía: 'Este es el comienzo del fin de la civilización occidental'", me dijo el Sr. Fleiss.
"Pensé que era una especie de broma, pero resulta que tenían razón".
Amy Chozick, una escritora en libertad para The Times que cubre negocios, política y medios, es la autora de las memorias "Persiguiendo a Hillary".
El dinero de afuera inunda las elecciones de mitad de período más apretadas de las carreras de la Cámara
No es sorprendente que el 17 de Pensilvania esté viendo una avalancha de dinero, gracias a una realineación de los distritos del Congreso que aterrizaron dos titulares en una carrera por el mismo asiento.
Este recientemente rediseñado distrito suburbano de Pittsburg enfrenta al representante demócrata Conor Lamb, quien ganó su escaño en otro distrito en una elección especial la primavera pasada.
Lamb está compitiendo contra otro titular, el republicano Keith Rothfus, quien actualmente representa el antiguo distrito 12 de Pensilvania, que se solapa fuertemente con el nuevo 17.
Los mapas fueron rediseñados después de que la Corte Suprema de Pensilvania dictaminara en enero que los antiguos distritos fueron manipulados inconstitucionalmente a favor de los republicanos.
La carrera en el nuevo 17o ha desatado una pelea de finanzas de campaña entre los principales brazos financieros del partido, el Comité de Campaña Demócrata del Congreso (DCCC) y el Comité Nacional de Campaña Republicana (NRCC).
Lamb se convirtió en un nombre familiar en Pensilvania después de una estrecha victoria en una elección especial ampliamente observada en marzo para el 18o Distrito del Congreso de Pensilvania.
Ese asiento había sido ocupado por un republicano durante más de una década, y el presidente Donald Trump ganó el distrito por 20 puntos.
Los expertos políticos han dado a los demócratas una ligera ventaja.
EE.UU. consideró penalizar a El Salvador por el apoyo a China, luego se retiró
Los diplomáticos señalaron que la República Dominicana y Panamá ya habían reconocido a Pekín, con poco rechazo de Washington.
El Sr. Trump tuvo una cálida reunión con el presidente Juan Carlos Varela de Panamá en junio de 2017 y tenía un hotel en Panamá hasta que los socios desalojaron al equipo directivo de la Organización Trump.
Los funcionarios del Departamento de Estado decidieron llamar a los jefes estadounidenses de las misiones diplomáticas de El Salvador, la República Dominicana y Panamá por las "recientes decisiones de no reconocer más a Taiwán", dijo Heather Nauert, portavoz del departamento, en un comunicado a principios de este mes.
Pero las sanciones solo se consideraron contra El Salvador, que recibió una ayuda estadounidense estimada en 140 millones de dólares en 2017, incluido el control de narcóticos, el desarrollo y el apoyo económico.
Las sanciones propuestas, que incluían recortes en la ayuda financiera y restricciones específicas de visados, habrían sido dolorosas para el país centroamericano y sus altas tasas de desempleo y asesinato.
A medida que avanzaban las reuniones internas, Los funcionarios norteamericanos y centroamericanos pospusieron una conferencia de alto nivel centrada en la seguridad y la prosperidad económica para dar seguimiento a una reunión similar el año pasado que fue vista como un paso adelante en los esfuerzos para evitar que los migrantes se dirigieran a los Estados Unidos.
Pero a mediados de septiembre, altos funcionarios de la administración dejaron en claro que querían que la conferencia siguiera adelante, terminando efectivamente cualquier consideración de sanciones para El Salvador.
El vicepresidente Mike Pence está programado para dirigirse a la conferencia, ahora programada para mediados de octubre, en una señal de la importancia que la administración pone en la reunión, dijeron los diplomáticos.
Y los tres enviados estadounidenses regresaron silenciosamente a El Salvador, Panamá y la República Dominicana sin nuevos mensajes duros o castigos de Washington.
Un portavoz de la Casa Blanca para el Sr. Bolton se negó a comentar sobre los detalles del debate que fueron descritos por los tres funcionarios estadounidenses, incluidos dos diplomáticos, que acordaron discutir las deliberaciones internas bajo la condición de anonimato.
Sus cuentas fueron corroboradas por un analista externo que está cerca de la administración y también habló bajo condición de anonimato.
Historia del estudio
El próximo zapato en caer podría ser el informe del fiscal especial Robert Mueller sobre la posible obstrucción de la justicia por parte del Sr. Trump, de la cual ahora hay evidencia muy sustancial en el registro público.
Según los informes, el Sr. Mueller también está dirigiendo su investigación a si la campaña del Sr. Trump conspiró con Rusia en su ataque a nuestras elecciones.
Si el Congreso cambia de manos, el Sr. Trump se encontrará frente a la rendición de cuentas en ese cuerpo, al igual que se prepara para ir de nuevo ante los votantes, y tal vez eventualmente un jurado de sus pares.
Son muchos si, y no quiero sugerir que la caída del Sr. Trump sea inevitable, ni la de sus equivalentes en Europa.
Hay opciones que todos debemos tomar a ambos lados del Atlántico que afectarán la duración de la lucha.
En 1938, los oficiales alemanes estaban listos para organizar un golpe de estado contra Hitler, si Occidente le hubiera resistido y apoyado a los checoslovacos en Munich.
Fracasamos, y perdimos una oportunidad de evitar los años de carnicería que siguieron.
El curso de la historia gira en torno a tales puntos de inflexión, y la marcha inexorable de la democracia se acelera o se retrasa.
Los estadounidenses enfrentan varios de estos puntos de inflexión ahora.
¿Qué haremos si el Sr. Trump despide al Fiscal General Adjunto Rod Rosenstein, el hombre que controla el destino de la investigación del Sr. Mueller?
Rosenstein ha estado en problemas desde que este periódico informó que, el año pasado, sugirió grabar en secreto al presidente y especuló sobre su no ser apto para el cargo.
El Sr. Rosenstein dice que el relato del Times es inexacto.
"¿Cómo responderemos si la recientemente solicitada investigación del FBI de Brett Kavanaugh no es completa o justa, o si es confirmado para la Corte Suprema a pesar de las acusaciones creíbles de agresión sexual y testimonio deshonesto?
Y sobre todo, ¿votaremos en las elecciones de mitad de período por un Congreso que responsabilice al Sr. Trump?
Si no aprobamos esas pruebas, la democracia tendrá un largo invierno.
Pero creo que no fallaremos, por la lección que aprendí en Praga.
Mi madre era una judía checoslovaca que fue deportada a Auschwitz por el mismo régimen nazi que una vez ocupó mi casa embajadora.
Ella sobrevivió, emigró a Estados Unidos y, 60 años más tarde, me envió a encender las velas del sábado en esa mesa con la esvástica.
Con eso como mi herencia, ¿cómo no ser optimista acerca de nuestro futuro?"
Norman Eisen, miembro de la Brookings Institution, es el presidente de Ciudadanos por la Responsabilidad y la Ética en Washington y el autor de "El último palacio: Siglo turbulento de Europa en cinco vidas y una casa legendaria".
El jugador de los Rangers, Graham Dorrans, se muestra optimista ante el encuentro con el Rapid Vienna.
Los Rangers reciben al Rapid Viena el jueves, sabiendo que la victoria sobre los austriacos, después del impresionante empate en España contra el Villarreal a principios de este mes, los pondrá en una posición sólida para clasificarse del Grupo G de la Liga Europa.
Una lesión en la rodilla impidió que el mediocampista Graham Dorrans hiciera su primera aparición de la temporada hasta el empate 2-2 con el Villarreal, pero cree que los Rangers pueden usar ese resultado como un trampolín para cosas más grandes.
"Fue un buen punto para nosotros porque el Villarreal es un buen equipo", dijo el jugador de 31 años.
"Entramos en el juego creyendo que podíamos conseguir algo y salimos con un punto.
Tal vez podríamos haberlo robado al final pero, en general, un empate fue probablemente un resultado justo.
Ellos probablemente fueron mejores en la primera mitad y nosotros salimos en la segunda mitad y fuimos el lado mejor.
Entrando en el jueves, es otra gran noche europea.
Con suerte, podemos obtener tres puntos pero será un juego difícil porque tuvieron un buen resultado en su último juego pero, con la multitud detrás de nosotros, estoy seguro de que podemos seguir adelante y obtener un resultado positivo.
El año pasado fue definitivamente duro, entre todo lo que sucedió con mis lesiones y los cambios en el propio club pero hay un factor de bienestar sobre el lugar ahora.
El equipo es bueno y los chicos lo están disfrutando, el entrenamiento es bueno.
Con suerte, podemos seguir adelante ahora, dejar atrás la temporada pasada y tener éxito".
Las mujeres están perdiendo el sueño por este temor a los ahorros para la jubilación
A pesar de que los participantes en la encuesta tenían una idea clara de cómo querían ser atendidos, pocas personas hablaban con sus familiares al respecto.
Alrededor de la mitad de las personas en el estudio de Nationwide dijeron que estaban hablando con sus cónyuges sobre el costo de la atención a largo plazo.
Solo el 10 por ciento dijo que habló con sus hijos al respecto.
"La gente quiere que un familiar se ocupe de ella, pero no toma las medidas necesarias para hablar de ello", dijo Holly Snyder, vicepresidenta del negocio de seguros de vida de Nationwide.
Aquí es donde comenzar.
Hable con su cónyuge y con los hijos: No puede preparar a su familia para prestar atención si no le hace saber sus deseos con suficiente antelación.
Trabaje con su asesor y su familia para discutir dónde y cómo recibir atención, ya que esas opciones pueden ser un factor importante en la determinación del costo.
Traiga a su asesor financiero: Su asesor también puede ayudarle a encontrar una manera de pagar esos gastos.
Sus opciones de financiamiento para la atención a largo plazo pueden incluir una póliza de seguro tradicional de atención a largo plazo, una póliza de seguro de vida híbrida de valor en efectivo para ayudar a cubrir estos gastos o autoasegurarse con su propia riqueza, siempre y cuando tenga el dinero.
Prepara tus documentos legales y evita las batallas legales en el paso.
Establezca un poder de atención médica para que designe a una persona de confianza para que supervise su atención médica y se asegure de que los profesionales cumplan con sus deseos en caso de que no pueda comunicarse.
También considere un poder legal para sus finanzas.
Seleccionarías a una persona de confianza para que tome decisiones financieras por ti y se asegure de que tus cuentas sean pagadas si estás incapacitado.
No te olvides de los pequeños detalles: Imagina que tu padre o tu madre de edad avanzada tiene una emergencia médica y está en camino al hospital.
¿Podría responder preguntas sobre medicamentos y alergias?
Especifica esos detalles en un plan escrito para que estés listo.
"No son solo las finanzas las que están en juego, sino también quiénes son los médicos", preguntó Martin.
"¿Cuáles son los medicamentos?
¿Quién cuidará del perro?
Tenga ese plan en su lugar".
Hombre disparado varias veces con rifle de aire en Ilfracombe
A un hombre le han disparado varias veces con un rifle de aire cuando caminaba a casa de una salida nocturna.
La víctima, de unos 40 años, estaba en el área de Oxford Grove de Ilfracombe, Devon, cuando le dispararon en el pecho, el abdomen y la mano.
Los oficiales describieron el tiroteo, que tuvo lugar alrededor de las 02:30 BST, como un "acto aleatorio".
La víctima no vio a su atacante.
Sus heridas no ponen en peligro la vida y la policía ha pedido testigos.
Terremotos y tsunamis en Indonesia
Al menos 384 personas han muerto por un poderoso terremoto y tsunami que azotó la ciudad indonesia de Palu el viernes, dijeron las autoridades, y se espera que la cifra de muertos aumente.
Con las comunicaciones cortadas, los funcionarios de socorro no han podido obtener ninguna información de la regencia de Donggala, un área al norte de Palu que está más cerca del epicentro del terremoto de magnitud 7.5.
En Palu, más de 16.000 personas fueron evacuadas tras el desastre.
Estos son algunos datos clave sobre Palu y Donggala, en la isla de Sulawesi:
Palu es la capital de la provincia de Sulawesi Central, ubicada al final de una estrecha bahía en la costa oeste de la isla de Sulawesi, con una población estimada de 379,800 en 2017.
La ciudad estaba celebrando su 40 aniversario cuando se produjo el terremoto y el tsunami.
Donggala es una regencia que se extiende a lo largo de más de 300 km (180 millas) de costa en el noroeste de la isla de Sulawesi.
La regencia, una región administrativa por debajo de una provincia, tenía una población estimada de 299,200 en 2017.
La pesca y la agricultura son los pilares de la economía de la provincia de Sulawesi Central, especialmente la región costera de Donggala.
La minería de níquel también es importante en la provincia, pero se concentra principalmente en Morowali, en la costa opuesta de Sulawesi.
Palu y Donggala han sido azotadas por tsunamis varias veces en los últimos 100 años, según la Agencia de Mitigación de Desastres de Indonesia.
En 1938, un tsunami mató a más de 200 personas y destruyó cientos de casas en Donggala.
Un tsunami también azotó el oeste de Donggala en 1996, matando a nueve.
Indonesia se encuentra en el círculo sísmico de fuego del Pacífico y es regularmente golpeado por terremotos.
Estos son algunos de los mayores terremotos y tsunamis de los últimos años:
2004: Un gran terremoto en la costa occidental de la provincia indonesia de Aceh en el norte de Sumatra el 26 de diciembre provocó un tsunami que azotó a 14 países, matando a 226.000 personas a lo largo de la costa del Océano Índico, más de la mitad de ellas en Aceh.
2005: Una serie de fuertes terremotos azotaron la costa occidental de Sumatra a finales de marzo y principios de abril.
Cientos murieron en la isla de Nias, frente a la costa de Sumatra.
2006: Un terremoto de magnitud 6,8 golpeó el sur de Java, la isla más poblada de Indonesia, provocando un tsunami que se estrelló en la costa sur, matando a casi 700 personas.
2009: Un terremoto de magnitud 7.6 golpeó cerca de la ciudad de Padang, capital de la provincia de Sumatra Occidental.
Más de 1.100 personas murieron.
2010: Un terremoto de magnitud 7.5 azotó una de las islas Mentawai, frente a Sumatra, provocando un tsunami de hasta 10 metros que destruyó docenas de aldeas y mató a unas 300 personas.
2016: Un terremoto de poca profundidad azotó la regencia de Pidie Jaya en Aceh, causando destrucción y pánico mientras la gente recordaba la devastación del mortal terremoto y tsunami de 2004.
Esta vez no se produjo un tsunami, pero más de 100 personas murieron por la caída de edificios.
2018: Grandes terremotos azotan la isla turística indonesia de Lombok, matando a más de 500 personas, en su mayoría en el lado norte de la isla.
El terremoto destruyó miles de edificios y dejó a miles de turistas temporalmente varados.
El hijo mayor de Sarah Palin arrestado por cargos de violencia doméstica
Track Palin, el hijo mayor de la ex gobernadora de Alaska y candidata a la vicepresidencia Sarah Palin, ha sido arrestado por cargos de asalto.
Palin, de 29 años, de Wasilla, Alaska, fue arrestada bajo sospecha de violencia doméstica, interferir con un informe de violencia doméstica y resistirse al arresto, según un informe publicado el sábado por las tropas estatales de Alaska.
Según el informe policial, cuando una conocida intentó llamar a la policía para denunciar los presuntos crímenes, él le quitó el teléfono.
Palin está siendo detenida en Mat-Su Pre-Trial Facility y está siendo retenida con una fianza sin garantía de $500, informó KTUU.
Apareció en el tribunal el sábado, donde se declaró "no culpable, sin duda" cuando se le preguntó su declaración de culpabilidad, informó la cadena.
Palin enfrenta tres delitos menores de Clase A, lo que significa que podría ser encarcelado por hasta un año y multado con $250,000.
También ha sido acusado de un delito menor Clase B, castigado con un día en la cárcel y una multa de $2.000.
No es la primera vez que se presentan cargos criminales contra Palin.
En diciembre de 2017, fue acusado de agredir a su padre, Todd Palin.
Su madre, Sarah Palin, llamó a la policía para denunciar el presunto ataque.
El caso está actualmente ante el Tribunal de Veteranos de Alaska.
En enero de 2016 fue acusado de agresión doméstica, interferencia con el informe de un delito de violencia doméstica y posesión de un arma mientras estaba intoxicado en relación con el incidente.
Su novia había alegado que él le había dado un puñetazo en la cara.
Sarah Palin fue criticada por grupos de veteranos en 2016 después de vincular el comportamiento violento de su hijo con el trastorno de estrés postraumático derivado de su servicio en Irak.
Terremoto y tsunami en Indonesia: cientos de muertos
Al menos 384 personas han muerto después de que un terremoto azotara la isla indonesia de Sulawesi el viernes.
El terremoto de magnitud 7,5 provocó un tsunami y ha destruido miles de hogares.
Las redes eléctricas y de comunicaciones están caídas y se espera que el número de muertes aumente en los próximos días.
El terremoto golpeó justo en el centro de Sulawesi, que está al noreste de la capital indonesia, Yakarta.
Los videos están circulando en las redes sociales mostrando el momento del impacto.
Cientos de personas se habían reunido para un festival de playa en la ciudad de Palu cuando el tsunami azotó la costa.
Los fiscales federales buscan la pena de muerte para el sospechoso del ataque terrorista de Nueva York.
Los fiscales federales de Nueva York están buscando la pena de muerte para Sayfullo Saipov, el sospechoso del ataque terrorista de la ciudad de Nueva York que mató a ocho personas, un raro castigo que no se ha llevado a cabo en el estado por un delito federal desde 1953.
Saipov, de 30 años, supuestamente usó un camión de alquiler de Home Depot para llevar a cabo un ataque en un sendero para bicicletas a lo largo de la autopista West Side en el Bajo Manhattan, derribando a peatones y ciclistas en su camino el Oct.
Con el fin de justificar una sentencia de muerte, Los fiscales tendrán que probar que Saipov "intencionalmente" mató a las ocho víctimas y "intencionalmente" infligió lesiones corporales graves, según el aviso de intención de buscar la pena de muerte, presentado en el Distrito Sur de Nueva York.
Ambos cargos conllevan una posible sentencia de muerte, según el documento de la corte.
Semanas después del ataque, un gran jurado federal golpeó a Saipov con una acusación de 22 cargos que incluía ocho cargos de asesinato en ayuda del crimen organizado, típicamente utilizado por los fiscales federales en casos de crimen organizado, y un cargo de violencia y destrucción de vehículos de motor.
El ataque requirió "planificación y premeditación sustanciales", dijeron los fiscales, describiendo la forma en que Saipov lo llevó a cabo como "heino, cruel y depravado".
"Sayfullo Habibullaevic Saipov causó lesiones, daño y pérdida a las familias y amigos de Diego Enrique Angelini, Nicholas Cleves, Ann-Laure Decadt, Darren Drake, Ariel Erlij, Hernan Ferruchi, Hernan Diego Mendoza y Alejandro Damian Pagnucco", dice el aviso de intención.
Cinco de las víctimas eran turistas de Argentina.
Ha pasado una década desde que el Distrito Sur de Nueva York procesó por última vez un caso de pena de muerte.
El acusado, Khalid Barnes, fue declarado culpable de asesinar a dos proveedores de drogas pero finalmente fue sentenciado a cadena perpetua en septiembre de 2009.
La última vez que se ejecutó la pena de muerte en un caso federal de Nueva York fue en 1953 para Julius y Ethel Rosenberg, una pareja casada ejecutada después de haber sido condenados por conspiración para cometer espionaje para la Unión Soviética durante la Guerra Fría dos años antes.
Ambos Rosenbergs fueron ejecutados en la silla eléctrica el 19 de junio de 1953.
Saipov, originario de Uzbekistán, demostró una falta de remordimiento en los días y meses posteriores al ataque, según documentos judiciales.
Declaró a los investigadores que se sentía bien por lo que había hecho, dijo la policía.
Saipov dijo a las autoridades que se inspiró para llevar a cabo el ataque después de ver videos de ISIS en su teléfono, según la acusación.
También solicitó exhibir la bandera de ISIS en su habitación del hospital, dijo la policía.
Se ha declarado inocente de los 22 cargos.
David Patton, uno de los defensores públicos federales que representan a Saipov, dijo que están "obviamente decepcionados" con la decisión de la fiscalía.
"Creemos que la decisión de buscar la pena de muerte en lugar de aceptar una declaración de culpabilidad a cadena perpetua sin posibilidad de liberación solo prolongará el trauma de estos eventos para todos los involucrados", dijo Patton.
El equipo de defensa de Saipov había pedido previamente a los fiscales que no pidieran la pena de muerte.
El diputado conservador dice que NIGEL FARAGE debería estar a cargo de las negociaciones del Brexit
Nigel Farage prometió "movilizar al ejército del pueblo" hoy durante una protesta en la conferencia de los conservadores.
El ex líder del UKIP dijo que los políticos tenían que "sentir el calor" de los euroescépticos, ya que uno de los propios parlamentarios de Theresa May sugirió que debería estar a cargo de las negociaciones con la UE.
El diputado conservador Peter Bone dijo a la marcha en Birmingham que el Reino Unido "habría salido" ya si el Sr. Farage fuera el Secretario del Brexit.
Pero el desafío al que se enfrenta la Sra. May para reconciliar sus filas profundamente divididas ha sido subrayado por los conservadores pro-Remain que se unieron a una protesta separada contra el Brexit en la ciudad.
La primera ministra está luchando para mantener su plan de compromiso de Chequers en el buen camino en medio de los ataques de Brexiteers, Remainers y la UE.
Los aliados insistieron en que ella seguirá adelante con el intento de llegar a un acuerdo con Bruselas a pesar de la reacción negativa - y obligará a los euroescépticos y laboristas a elegir entre su paquete y el "caos".
El Sr. Bone dijo en el mitin de Leave Means Leave en Solihull que quería "derribar a Chequers".
El Sr. Farage debería haber sido nombrado "peer" y se le debería haber dado la responsabilidad de las negociaciones con Bruselas.
"Si él hubiera estado a cargo, ya habríamos salido", dijo.
El diputado de Wellingborough añadió: "Voy a apoyar el Brexit, pero tenemos que deshacernos de Chequers".
Explicando su oposición a la UE, dijo: "No peleamos las guerras mundiales para ser serviles.
Queremos hacer nuestras propias leyes en nuestro propio país'.
El Sr. Bone rechazó las sugerencias de que la opinión pública había cambiado desde la votación de 2016: "La idea de que el pueblo británico ha cambiado de opinión y quiere permanecer es completamente falsa".
Andrea Jenkyns, conservadora del Brexit, también estuvo en la marcha y dijo a los periodistas: "Simplemente estoy diciendo: Primer Ministro, escuche a la gente.
'Chequers es impopular entre el público en general, la Oposición no va a votar por él, es impopular entre nuestro partido y nuestros activistas que en realidad golpean las calles y nos hacen elegir en primer lugar.
Por favor, deje Chequers y comience a escuchar.
En un mensaje directo a la Sra. May, añadió: "Los primeros ministros conservan sus puestos de trabajo cuando cumplen sus promesas".
El Sr. Farage dijo al mitin que los políticos deben "sentir el calor" si están a punto de traicionar la decisión tomada en el referéndum de 2016.
"Ahora se trata de una cuestión de confianza entre nosotros, el pueblo, y nuestra clase política", dijo.
"Están tratando de traicionar el Brexit y estamos aquí hoy para decirles 'no vamos a dejar que se salgan con la suya haciendo eso'".
En un mensaje dirigido a la multitud entusiasta, añadió: "Quiero que hagáis que nuestra clase política, que está a punto de traicionar el Brexit, sienta el calor.
"Estamos movilizando al ejército popular de este país que nos dio la victoria en el Brexit y nunca descansará hasta que nos hayamos convertido en un Reino Unido independiente, autónomo y orgulloso".
Mientras tanto, los Remainers marcharon a través de Birmingham antes de celebrar una manifestación de dos horas en el centro de la ciudad.
Un puñado de activistas agitaron pancartas de Tories Against Brexit después del lanzamiento del grupo este fin de semana.
El par laborista Lord Adonis se burló de los conservadores por los problemas de seguridad que sufrieron con una aplicación del partido cuando se abrió la conferencia.
"Estas son las personas que nos dicen que pueden tener los sistemas informáticos y toda la tecnología para Canadá más más, para la frontera sin fricciones, para el libre comercio sin fronteras en Irlanda", añadió.
Es una completa farsa.
No hay tal cosa como un buen Brexit", añadió.
Warren planea echar un vistazo a las elecciones presidenciales
La senadora Elizabeth Warren dice que considerará seriamente postularse a la presidencia después de las elecciones de noviembre.
El Boston Globe informa que la demócrata de Massachusetts habló sobre su futuro durante un ayuntamiento en el oeste de Massachusetts el sábado.
Warren, un crítico frecuente del presidente Donald Trump, se postula para la reelección en noviembre contra el representante estatal republicano Geoff Diehl, quien fue copresidente de la campaña de Trump en Massachusetts en 2016.
Ha estado en el centro de la especulación de que podría enfrentarse a Trump en 2020.
El evento del sábado por la tarde en Holyoke fue su 36a reunión con los electores usando el formato del ayuntamiento desde que Trump asumió el cargo.
Un asistente le preguntó si planeaba postularse para presidente.
Warren respondió que es hora "de que las mujeres vayan a Washington para arreglar nuestro gobierno roto, y eso incluye a una mujer en la cima".
Detenido por el asesinato a tiros de los Sims de LSU
La policía en Baton Rouge, Louisiana, anunció el sábado que un sospechoso ha sido arrestado en el tiroteo de la muerte del jugador de baloncesto LSU Wayde Sims el viernes.
El Departamento de Policía de Baton Rouge anunció el arresto de Dyteon Simpson, de 20 años, a las 11 a.m. Conferencia de prensa de ET.
Habían publicado un video del tiroteo el viernes, pidiendo ayuda para identificar a un hombre visto en las imágenes.
Sims, de 20 años, fue asesinado a tiros cerca del campus de la Universidad del Sur el viernes por la mañana.
"Wayde Sims sufrió una herida de bala en la cabeza y finalmente murió como resultado", dijo el jefe de policía Murphy J. Paul a los medios el sábado, por 247sports.
Wayde intervino para defender a su amigo y Simpson le disparó.
Simpson fue interrogado y admitió estar en la escena, en posesión de un arma, y admitió haber disparado a Wayde Sims.
Simpson fue arrestado sin incidentes y puesto bajo custodia en el Departamento de Policía de East Baton Rouge Parish.
Sims jugó en 32 partidos con 10 aperturas la temporada pasada y promedió 17.4 minutos, 5.6 puntos y 2.9 rebotes por juego.
Gran Premio de Rusia: Lewis Hamilton se acerca al título mundial después de que las órdenes del equipo le dieran la victoria sobre Sebastian Vettel
Quedó claro desde el momento en que Valtteri Bottas se clasificó por delante de Lewis Hamilton el sábado que las órdenes del equipo de Mercedes jugarían un papel importante en la carrera.
Desde la pole, Bottas tuvo un buen comienzo y casi colgó a Hamilton mientras defendía su posición en las dos primeras curvas e invitó a Vettel a atacar a su compañero de equipo.
Vettel entró en boxes primero y dejó a Hamilton para correr en el tráfico en la cola del paquete, algo que debería haber sido decisivo.
El Mercedes hizo una vuelta más tarde y salió detrás de Vettel, pero Hamilton salió adelante después de una acción de rueda a rueda que vio al piloto de Ferrari dejar a regañadientes el interior libre con el riesgo de aguantar después de un doble movimiento para defenderse en la tercera curva.
Max Verstappen comenzó desde la última fila de la parrilla y estaba en séptimo al final de la primera vuelta en su cumpleaños número 21.
Luego lideró durante una gran parte de la carrera mientras mantenía sus neumáticos para apuntar a un final rápido y adelantar a Kimi Raikkonen en cuarto lugar.
Finalmente llegó a los boxes en la vuelta 44, pero no pudo aumentar su ritmo en las ocho vueltas restantes, ya que Raikkonen quedó cuarto.
Es un día difícil porque Valtteri hizo un trabajo fantástico todo el fin de semana y fue un verdadero caballero.
El equipo ha hecho un trabajo excepcional para tener un uno dos", dijo Hamilton.
Ese fue un mal lenguaje corporal .
El presidente Donald Trump se burló de la senadora Dianne Feinstein en un mitin el sábado por su insistencia en no filtrar la carta de Christine Blasey Ford acusando al candidato a la Corte Suprema Brett Kavanaugh de agresión sexual.
Hablando en un mitin en Virginia Occidental, el presidente no se dirigió directamente al testimonio dado por Ford ante el Comité Judicial del Senado, en lugar de comentar que lo que estaba sucediendo en el Senado mostraba que la gente era "mala y desagradable y falsa".
"La única cosa que podría suceder y la cosa hermosa que está sucediendo en los últimos días en el Senado, cuando ves la ira, cuando ves a personas que están enojadas y malas y desagradables y mentirosas", dijo.
"Cuando miras los comunicados y las filtraciones y luego dicen "oh, yo no lo hice.
Yo no lo hice".
¿Te acuerdas?
Dianne Feinstein, ¿has hecho una filtración?
¿Recuerdas su respuesta? ¿Has filtrado el documento? "Oh, oh, ¿qué?
Oh, no, no es eso.
No se me escapó".
Bueno, espera un minuto.
¿Hemos hecho una filtración...No, no hemos filtrado", agregó, en una impresión del senador.
A Feinstein se le envió la carta detallando las acusaciones contra Kavanaugh por Ford en julio, y se filtró a principios de septiembre, pero Feinstein negó que la filtración proviniera de su oficina.
"No oculté las acusaciones del Dr. Ford, no filtré su historia", dijo Feinstein al comité, informó The Hill.
"Ella me pidió que lo mantuviera confidencial y lo mantuve confidencial como me lo pidió".
Pero su negación no pareció gustarle al presidente, quien comentó durante la manifestación del sábado por la noche: "Te diré algo, ese fue un lenguaje corporal realmente malo.
Tal vez no, pero ese es el peor lenguaje corporal que he visto".
Continuando su defensa del candidato a la Corte Suprema, quien ha sido acusado de conducta sexual inapropiada por tres mujeres, el presidente sugirió que los demócratas estaban usando las acusaciones para sus propios fines.
"Están decididos a recuperar el poder por cualquier medio necesario.
Ves la mezquindad, la maldad, no les importa a quién lastiman, a quién tienen que atropellar para obtener poder y control", informó Mediaite que el presidente dijo.
Liga de élite: Estrellas de Dundee 5-3 Gigantes de Belfast
Patrick Dwyer marcó dos goles para los Gigantes contra Dundee .
Las Estrellas de Dundee expiaron la derrota de la Liga de Élite del viernes contra los Gigantes de Belfast al ganar el partido de vuelta 5-3 en Dundee el sábado.
Los Gigantes obtuvieron una ventaja temprana de dos goles a través de ataques de Patrick Dwyer y Francis Beauvillier.
Mike Sullivan y Jordan Cownie trajeron el nivel del lado de casa antes de que Dwyer restaurara la ventaja de los Giants.
Francois Bouchard empató para Dundee antes de que dos goles de Lukas Lundvald Nielsen aseguraran su victoria.
Fue la tercera derrota de la Liga de Élite de la temporada para los hombres de Adam Keefe, que habían vencido a Dundee por 2-1 en Belfast el viernes por la noche.
Fue el cuarto encuentro de la temporada entre los dos equipos, con los Giants ganando los tres partidos anteriores.
El primer gol de Dwyer llegó en el cuarto minuto a las 3:35 de una asistencia de Kendall McFaull, con David Rutherford proporcionando la asistencia mientras Beauvillier duplicaba la ventaja cuatro minutos después.
En lo que fue un período de apertura ocupado, Sullivan trajo al equipo local de vuelta al juego a las 13:10 antes de que Matt Marquardt se convirtiera en el proveedor del empate de Cownie a las 15:16.
Dwyer se aseguró de que los Gigantes tomaran la delantera en el primer descanso cuando marcó su segundo gol de la noche al final del primer período.
El equipo local se reagrupó y Bouchard una vez más los puso en igualdad de condiciones con un gol de juego de poder a las 27:37.
Cownie y Charles Corcoran se combinaron para ayudar a Nielsen a dar a Dundee la ventaja por primera vez en el partido a finales del segundo período y se aseguró la victoria con el quinto gol de su equipo a mitad del último período.
Los Gigantes, que ahora han perdido cuatro de sus últimos cinco partidos, están en casa ante Milton Keynes en su próximo partido el viernes.
Un controlador de tráfico aéreo muere para asegurar que cientos de pasajeros puedan escapar del terremoto.
Un controlador de tráfico aéreo en Indonesia está siendo aclamado como un héroe después de que murió asegurando que un avión que transportaba a cientos de personas despegara de forma segura.
Más de 800 personas han muerto y muchas están desaparecidas después de que un gran terremoto azotara la isla de Sulawesi el viernes, provocando un tsunami.
Fuertes réplicas continúan azotando la zona y muchos están atrapados en los escombros en la ciudad de Palu.
Pero a pesar de que sus colegas huían por sus vidas, Anthonius Gunawan Agung, de 21 años, se negó a dejar su puesto en la salvajemente oscilante torre de control del aeropuerto Mutiara Sis Al Jufri Palu.
Se quedó para asegurarse de que el vuelo 6321 de Batik Air, que estaba en la pista en ese momento, pudiera despegar con seguridad.
Luego saltó de la torre de control de tráfico cuando pensó que se estaba derrumbando.
Murió más tarde en el hospital.
El portavoz de la Agencia de Navegación Aérea de Indonesia, Yohannes Sirait, dijo que la decisión puede haber salvado cientos de vidas, informó ABC News de Australia.
Preparamos un helicóptero desde Balikpapan en Kalimantan para llevarlo a un hospital más grande en otra ciudad.
Desafortunadamente lo perdimos esta mañana antes de que el helicóptero llegara a Palu.
"Nuestro corazón se rompe al escuchar esto", añadió.
Mientras tanto, las autoridades temen que el número de muertos pueda llegar a los miles con la agencia de mitigación de desastres del país diciendo que el acceso a las ciudades de Donggala, Sigi y Boutong es limitado.
"Se cree que el número de víctimas sigue aumentando ya que muchos cuerpos todavía estaban bajo los escombros mientras que muchos no han podido ser alcanzados", dijo el portavoz de la agencia Sutopo Purwo Nugroho.
Olas de hasta seis metros de altura han devastado Palu, donde el domingo se llevará a cabo un entierro en masa.
Aviones militares y comerciales están trayendo ayuda y suministros.
Risa Kusuma, una madre de 35 años, le dijo a Sky News: "Cada minuto una ambulancia trae cuerpos.
El agua limpia es escasa.
Los mini-mercados están saqueados en todas partes".
Jan Gelfand, jefe de la Cruz Roja Internacional en Indonesia, dijo a CNN: "La Cruz Roja de Indonesia está corriendo para ayudar a los sobrevivientes, pero no sabemos qué encontrarán allí.
Esto ya es una tragedia, pero podría ser mucho peor".
El presidente de Indonesia, Joko Widodo, llegó a Palu el domingo y dijo a los militares del país: "Les pido a todos ustedes que trabajen día y noche para completar todas las tareas relacionadas con la evacuación.
¿Estás listo?" Así lo informó la CNN.
Indonesia fue golpeada a principios de este año por terremotos en Lombok en los que murieron más de 550 personas.
Accidente de avión de Micronesia: Air Niugini ahora dice que un hombre desapareció después del accidente de avión de la laguna
La aerolínea que operaba un vuelo que se estrelló en una laguna del Pacífico en Micronesia ahora dice que un hombre está desaparecido, después de haber dicho anteriormente que los 47 pasajeros y tripulantes habían evacuado con seguridad el avión que se hundía.
Air Niugini dijo en un comunicado que a partir del sábado por la tarde, no pudo dar cuenta de un pasajero masculino.
La aerolínea dijo que estaba trabajando con las autoridades locales, hospitales e investigadores para tratar de encontrar al hombre.
La aerolínea no respondió de inmediato a las solicitudes de más detalles sobre el pasajero, como su edad o nacionalidad.
Barcos locales ayudaron a rescatar a los otros pasajeros y tripulantes después de que el avión golpeara el agua mientras intentaba aterrizar en el aeropuerto de la isla Chuuk.
Las autoridades dijeron el viernes que siete personas habían sido llevadas a un hospital.
La aerolínea dijo que seis pasajeros permanecieron en el hospital el sábado, y todos estaban en condición estable.
Lo que causó el accidente y la secuencia exacta de los eventos sigue sin estar claro.
La aerolínea y la Marina de EE.UU. ambos dijeron que el avión aterrizó en la laguna antes de la pista.
Algunos testigos pensaron que el avión sobrepasó la pista.
El pasajero estadounidense Bill Jaynes dijo que el avión llegó muy bajo.
"Eso es algo muy bueno", dijo Jaynes.
Jaynes dijo que él y otros lograron vadear el agua hasta la cintura hasta las salidas de emergencia del avión que se hundía.
Dijo que las azafatas estaban en pánico y gritando, y que sufrió una lesión menor en la cabeza.
La Marina de los Estados Unidos dijo que los marineros que trabajaban cerca en la mejora de un muelle también ayudaron en el rescate al usar un bote inflable para trasladar a las personas a tierra antes de que el avión se hundiera en unos 30 metros (100 pies) de agua.
Los datos de la Red de Seguridad Aérea indican que 111 personas han muerto en accidentes de aerolíneas registradas en PNG en las últimas dos décadas, pero ninguno involucró a Air Niugini.
El analista establece la línea de tiempo de la noche en que la mujer fue quemada viva.
La fiscalía descansó su caso el sábado en el nuevo juicio de un hombre acusado de quemar viva a una mujer de Mississippi en 2014.
El analista del Departamento de Justicia Paul Rowlett testificó durante horas como testigo experto en el campo del análisis de inteligencia.
Explicó al jurado cómo usó registros de teléfonos celulares para reconstruir los movimientos del acusado de 29 años Quinton Tellis y la víctima de 19 años, Jessica Chambers, la noche en que murió.
Rowlett dijo que recibió datos de ubicación de varios teléfonos celulares que mostraban que Tellis estaba con Chambers la noche de su muerte, contradiciendo sus afirmaciones anteriores, informó The Clarion Ledger .
Cuando los datos mostraron que su celular estaba con Chambers durante el tiempo que dijo que estaba con su amigo Michael Sanford, la policía fue a hablar con Sanford.
Sanford tomó el estrado el sábado y testificó que no estaba en la ciudad ese día.
Cuando los fiscales le preguntaron si Tellis estaba diciendo la verdad cuando dijo que estaba en la camioneta de Sanford esa noche, Sanford dijo que estaba "mintiendo, porque mi camioneta estaba en Nashville".
Otra inconsistencia fue que Tellis dijo que había conocido a Chambers por unas dos semanas cuando ella murió.
Los registros de celulares indican que sólo se conocen desde hace una semana.
Rowlett dijo que en algún momento después de la muerte de Chambers, Tellis borró los mensajes de Chambers, llamadas e información de contacto de su teléfono.
"Él la borró de su vida", dijo Hale.
La defensa está programada para comenzar sus argumentos finales el domingo.
El juez dijo que esperaba que el juicio fuera al jurado ese mismo día.
The High Breed: ¿Qué es el hip hop consciente?
Un trío de hip hop quiere desafiar la visión negativa del género llenando su música de mensajes positivos.
The High Breed, de Bristol, afirma que el hip hop se alejó de sus orígenes de mensajes políticos y de abordar problemas sociales.
Quieren volver a sus raíces y hacer que el hip hop consciente vuelva a ser popular.
Artistas como The Fugees y Common han visto un resurgimiento reciente en el Reino Unido a través de artistas como Akala y Lowkey.
¿Otra persona negra?
Una niñera de Nueva York demanda a una pareja por despedir después de un mensaje "racista"
Una niñera de Nueva York está demandando a una pareja por despido discriminatorio después de recibir un mensaje de texto mal dirigido de la madre quejándose de que era "otra persona negra".
La pareja niega ser racista, comparando la demanda con la "extorsión".
Lynsey Plasco-Flaxman, madre de dos hijos, expresó su consternación al descubrir que la nueva proveedora de cuidado infantil, Giselle Maurice, era negra al llegar a su primer día de trabajo en 2016.
"NOOOOOOOOOO Otra persona negra", escribió la señora Plasco-Flaxman a su marido en un mensaje de texto.
Sin embargo, en vez de enviarlo a su marido, se lo envió a la Srta. Maurice, dos veces.
Después de darse cuenta de su equivocación, un Plasco-Flaxman "incómodo" despidió a la Sra. Maurice, afirmando que su niñera saliente, que era afroamericana, había hecho un mal trabajo y que en su lugar estaba esperando a un filipino, según el New York Post.
A la Srta. Maurice le pagaron por un día de trabajo y luego la enviaron a casa en un Uber.
Ahora, Maurice está demandando a la pareja por la indemnización por el despido, y está buscando una indemnización por la suma de $350 al día por los seis meses, en vivo en el concierto que inicialmente había sido contratada para hacer, aunque sin contrato.
"Quiero mostrarles, mira, no haces cosas así", le dijo al Post el viernes, y agregó: "Sé que es discriminación".
La pareja ha respondido a las afirmaciones de que son racistas, diciendo que terminar el empleo de Maurice era lo más razonable, temiendo que no pudieran confiar en ella después de ofenderla.
"Mi esposa le había enviado algo que no quería decir.
Ella no es racista.
No somos personas racistas", dijo el esposo Joel Plasco al Post.
"Pero, ¿daría usted a sus hijos en manos de alguien con quien ha sido grosero, aunque fuera por error?
¿Su bebé recién nacido?
Vamos a hacerlo".
Comparando la demanda con la "extorsión", Plasco dijo que a su esposa le faltaban solo dos meses para tener un bebé y que se encontraba en una "situación muy difícil".
"¿Vas a ir tras alguien así?
Eso no es una cosa muy agradable de hacer", agregó el banquero de inversiones.
Mientras el caso legal aún está en curso, el tribunal de opinión pública se ha apresurado a denunciar a la pareja en las redes sociales, criticándolos por su comportamiento y lógica.
Los editores de Paddington temían que los lectores no se relacionaran con un oso parlante, revela una nueva carta.
La hija de Bond, Karen Jankel, que nació poco después de que el libro fuera aceptado, dijo de la carta: "Es difícil ponerse en el lugar de alguien que la lee por primera vez antes de que fuera publicada.
Es muy divertido saber ahora lo que sabemos sobre el gran éxito de Paddington".
Decirle a su padre, que había trabajado como camarógrafo de la BBC antes de ser inspirado para escribir el libro infantil por un pequeño oso de juguete, habría sido optimista sobre su trabajo siendo rechazado, agregó que el 60 aniversario de la publicación de los libros fue "dulce amargo" después de su muerte el año pasado.
De Paddington, a quien describe como un "miembro muy importante de nuestra familia", agregó que su padre estaba orgulloso de su eventual éxito.
"Era un hombre bastante tranquilo, y no era una persona jactanciosa", dijo ella.
"Pero debido a que Paddington era tan real para él, era casi como si tuvieras un hijo que logre algo: estás orgulloso de ellos a pesar de que en realidad no es tu culpa.
Creo que veía el éxito de Paddington de esa manera.
Aunque fue su creación y su imaginación, siempre solía dar el crédito al propio Paddington".
Mi hija se estaba muriendo y tuve que despedirme por teléfono.
Al aterrizar, su hija había sido llevada de urgencia al Hospital Louis Pasteur 2 de Niza, donde los médicos trabajaron en vano para salvar su vida.
"Nad llamaba regularmente para decir que estaba muy mal, que no se esperaba que llegara", dijo la Sra. Ednan-Laperouse.
"Entonces me llamó Nad para decirme que iba a morir en los próximos dos minutos y tuve que despedirme de ella.
Y lo hice.
Le dije: "Tashi, te quiero mucho, querida.
Estaré con ustedes pronto.
Yo estaré contigo.
Los medicamentos que los médicos le habían dado para que su corazón siguiera bombeando se estaban agotando lentamente y abandonando su sistema.
Ella había muerto algún tiempo antes de la mano y esto era todo el cierre.
Tuve que sentarme allí y esperar, sabiendo que todo esto se estaba desarrollando.
No podía aullar, gritar o llorar porque estaba en una situación rodeada de familias y personas.
Tenía que mantenerme unido".
Con el tiempo, la señora Ednan-Laperouse, ahora afligida por la pérdida de su hija, abordó el avión junto con los otros pasajeros, inconsciente de la terrible experiencia por la que estaba pasando.
"Nadie lo sabía", dijo.
"Tenía la cabeza agachada, y las lágrimas caían todo el tiempo.
Es difícil de explicar, pero fue en el vuelo que sentí esta abrumadora sensación de simpatía por Nad.
Que necesitaba mi amor y mi comprensión.
Sabía cuánto la amaba".
Mujeres afligidas envían tarjetas para evitar suicidios en el puente
Dos mujeres que perdieron seres queridos por suicidio están trabajando para evitar que otros se quiten la vida.
Sharon Davis y Kelly Humphreys han estado publicando tarjetas en un puente de Gales con mensajes inspiradores y números de teléfono a los que la gente puede llamar para obtener apoyo.
El hijo de la Sra. Davis, Tyler, tenía 13 años cuando comenzó a sufrir de depresión y se suicidó a los 18 años.
"No quiero que ningún padre sienta lo que yo tengo que sentir todos los días", dijo.
Davis, de 45 años, que vive en Lydney, dijo que su hijo era un chef prometedor con una sonrisa contagiosa.
"Todo el mundo lo conocía por su sonrisa.
Siempre decían que su sonrisa iluminaba cualquier habitación".
Sin embargo, dejó de trabajar antes de morir, pues estaba "en un lugar realmente oscuro".
En 2014, el hermano de Tyler, que tenía 11 años en ese momento, fue el que encontró a su hermano después de que se hubiera quitado la vida.
La Sra. Davis dijo: "Me preocupa continuamente que vaya a haber un golpe en el efecto".
La Srta. Davis creó las tarjetas, "para que la gente sepa que hay gente por ahí a la que puedes ir y con la que puedes hablar, incluso si es un amigo.
No te quedes en silencio, necesitas hablar".
La Sra. Humphreys, que ha sido amiga de la Sra. Davies durante años, perdió a Mark, su compañero de 15 años, poco después de la muerte de su madre.
"No dijo que se sintiera deprimido o deprimido o algo así", dijo ella.
"Un par de días antes de Navidad notamos un cambio en su actitud.
Estaba en su punto más bajo el día de Navidad - cuando los niños abrían sus regalos él no hacía contacto visual con ellos ni nada".
Ella dijo que su muerte fue un gran trauma para ellos, pero tienen que superarlo: "Esto hace un agujero en la familia.
Nos hace pedazos.
Pero todos tenemos que seguir adelante y luchar".
Si estás luchando para sobrellevarlo, puedes llamar a Samaritans gratis al 116 123 (Reino Unido e Irlanda), enviar un correo electrónico a jo@samaritans.org, o visitar el sitio web de Samaritans aquí.
El futuro de Brett Kavanaugh está en juego mientras el FBI comienza la investigación

¿Por qué el Sr. Kavanaugh y sus partidarios republicanos no querían que el FBI investigara?
Su renuencia se debe a la sincronización.
Faltan solo cinco semanas para las elecciones de mitad de período, el 6 de noviembre - si, como se espera, los republicanos lo hacen mal, entonces se verán gravemente debilitados en sus intentos de conseguir que el hombre que quieren sea elegido para el tribunal más alto del país.
George W. Bush ha estado tomando el teléfono para llamar a los senadores, presionándolos para que apoyen al Sr. Kavanaugh, quien trabajó en la Casa Blanca para el Sr. Bush y a través de él conoció a su esposa Ashley, quien era la secretaria personal del Sr. Bush.
¿Qué pasa después de que el FBI produzca su informe?
Habrá una votación en el Senado, donde 51 republicanos y 49 demócratas se sientan actualmente.
Todavía no está claro si el Sr. Kavanaugh puede obtener al menos 50 votos en el Senado, lo que permitiría a Mike Pence, el vicepresidente, romper un empate y confirmarlo en la Corte Suprema.
El número de desertores de Corea del Norte 'cae' bajo Kim
El número de desertores norcoreanos a Corea del Sur ha disminuido desde que Kim Jong-un llegó al poder hace siete años, dijo un legislador surcoreano.
Park Byeong-seug, citando datos del Ministerio de Unificación del Sur, dijo que hubo 1.127 deserciones el año pasado, en comparación con 2.706 en 2011.
El Sr. Park dijo que los controles fronterizos más estrictos entre Corea del Norte y China y las tarifas más altas cobradas por los traficantes de personas fueron factores clave.
Pyongyang no ha hecho comentarios públicos.
A la gran mayoría de los desertores del Norte eventualmente se les ofrece la ciudadanía surcoreana.
Seúl dice que más de 30.000 norcoreanos han cruzado ilegalmente la frontera desde el final de la Guerra de Corea en 1953.
La mayoría huye a través de China, que tiene la frontera más larga con Corea del Norte y es más fácil de cruzar que la Zona Desmilitarizada (DMZ) fuertemente protegida entre las dos Coreas.
China considera a los desertores como inmigrantes ilegales en lugar de refugiados y a menudo los repatria por la fuerza.
Las relaciones entre el Norte y el Sur - que todavía están técnicamente en guerra - han mejorado notablemente en los últimos meses.
A principios de este mes, los líderes de los dos países se reunieron en Pyongyang para conversaciones que se centraron en las estancadas negociaciones de desnuclearización.
Esto se produjo después de la histórica reunión de junio entre el presidente de los Estados Unidos, Donald Trump, y Kim Jong-un en Singapur, cuando acordaron en términos generales trabajar para lograr una península coreana libre de armas nucleares.
Pero el sábado, el ministro de Relaciones Exteriores de Corea del Norte, Ri Yong-ho, culpó a las sanciones estadounidenses por la falta de progreso desde entonces.
"Sin ninguna confianza en los Estados Unidos, no habrá confianza en nuestra seguridad nacional y en tales circunstancias, no hay manera de que nos desarmemos unilateralmente primero", dijo Ri en un discurso ante la Asamblea General de la ONU en Nueva York.
Nancy Pelosi llama a Brett Kavanaugh "histerico", dice que no es apto para servir en el Tribunal Supremo
La líder de la minoría de la Cámara de Representantes, Nancy Pelosi, calificó al candidato a la Corte Suprema, Brett Kavanaugh, de "histérico" y dijo que era temperamentalmente inadecuado para servir en la Corte Suprema.
Pelosi hizo los comentarios en una entrevista el sábado en el Festival Texas Tribune en Austin, Texas.
"No pude evitar pensar que si una mujer alguna vez se hubiera comportado de esa manera, dirían 'histérica'", dijo Pelosi sobre su reacción al testimonio de Kavanaugh ante el Comité Judicial del Senado el jueves.
Kavanaugh negó emocionalmente las acusaciones de que había agredido sexualmente a la Dra. Christine Blasey Ford cuando ambos eran adolescentes.
Durante su declaración inicial, Kavanaugh fue muy emotivo, a veces casi gritando y asfixiándose mientras hablaba de su familia y sus años de escuela secundaria.
También condenó explícitamente a los demócratas en el comité, calificando las acusaciones en su contra de un "grotesco y coordinado asesinato de carácter" organizado por liberales enojados de que Hillary Clinton perdiera las elecciones presidenciales de 2016.
Pelosi dijo que creía que el testimonio de Kavanaugh demostró que no podía servir en la Corte Suprema, porque mostraba que estaba sesgado contra los demócratas.
"Creo que se descalifica a sí mismo con esas declaraciones y la forma en que fue tras los Clinton y los demócratas", dijo.
Pelosi se negó cuando se le preguntó si trataría de acusar a Kavanaugh si es confirmado, y si los demócratas obtienen la mayoría en la Cámara de Representantes.
"Diré esto: si no le está diciendo la verdad al Congreso o al FBI, entonces no es apto no solo para estar en la Corte Suprema, sino para estar en la corte en la que está ahora mismo", dijo Pelosi.
Kavanaugh es actualmente juez en el Tribunal de Apelaciones del Circuito de D.C.
Pelosi agregó que como demócrata estaba preocupada por los posibles fallos de Kavanaugh contra la Ley de Cuidado de Salud Asequible o Roe v. Wade, ya que es considerado un juez conservador.
En sus audiencias de confirmación, Kavanaugh eludió las preguntas sobre si anularía ciertas decisiones de la Corte Suprema.
"No es hora de que una persona histérica y sesgada vaya a la corte y espere que digamos, '¿no es maravilloso?'", dijo Pelosi.
Y las mujeres necesitan manejarlo.
Es una diatriba justa, meses y años de furia derramándose, y ella no puede sacarlo sin llorar.
"Lloramos cuando nos enfadamos", me dijo la Srta. Steinem 45 años después.
"No creo que eso sea raro, ¿y usted?"
Ella continuó, "Me ayudó mucho una mujer que era ejecutiva en algún lugar, que dijo que también lloraba cuando se enojaba, pero desarrolló una técnica que significaba que cuando se enojaba y comenzaba a llorar, le decía a la persona con la que estaba hablando: "Puede que pienses que estoy triste porque estoy llorando.
Estoy enojado".
Y luego ella siguió adelante.
Y pensé que eso era brillante".
Las lágrimas se permiten como una salida de ira en parte porque son fundamentalmente incomprendidas.
Uno de mis mejores recuerdos de un trabajo temprano, en una oficina dominada por hombres, donde una vez me encontré llorando con una rabia inexpresable, fue mi ser agarrado por el cuello por una mujer mayor - una gerente fría de la que siempre había estado un poco aterrorizado - que me arrastró a una escalera.
"Nunca dejes que te vean llorando", me dijo.
"No saben que estás furioso.
Piensan que estás triste y estarán contentos porque llegaron a ti".
Patricia Schroeder, entonces una congresista demócrata de Colorado, había trabajado con Gary Hart en sus carreras presidenciales.
En 1987, cuando el Sr. Hart fue atrapado en una aventura extramatrimonial a bordo de un barco llamado Monkey Business y se retiró de la carrera, la Srta. Schroeder, profundamente frustrada, pensó que no había razón para que no explorara la idea de postularse a la presidencia ella misma.
"No fue una decisión bien pensada", me dijo con una sonrisa 30 años después.
"Ya había otros siete candidatos en la carrera, y lo último que necesitaban era otro.
Alguien lo llamó "Blancanieves y los siete enanos".
Debido a que era tarde en la campaña, estaba atrasada en la recaudación de fondos, y así que juró que no entraría en la carrera a menos que recaudara $ 2 millones.
Fue una batalla perdida.
Descubrió que algunos de sus seguidores que daban 1.000 dólares a los hombres solo le daban a ella 250.
"¿Piensan que obtengo un descuento?" se preguntó.
Cuando ella hizo su discurso anunciando que no lanzaría una campaña formal, Estaba tan abrumada por las emociones, la gratitud por las personas que la habían apoyado, la frustración con el sistema que hacía tan difícil recaudar dinero y apuntar a los votantes en lugar de a los delegados, y la ira por el sexismo, que se asfixió.
"Usted habría pensado que había tenido un colapso nervioso", recordó la Sra. Schroeder acerca de cómo la prensa reaccionó a ella.
"Habrías pensado que Kleenex era mi patrocinador corporativo.
Recuerdo haber pensado, ¿qué van a poner en mi lápida?
"Ella lloró"?""
Cómo la guerra comercial entre Estados Unidos y China puede ser buena para Beijing
Los salvos iniciales de la guerra comercial entre Estados Unidos y China fueron ensordecedores, y aunque la batalla está lejos de terminar, una ruptura entre los países puede ser beneficiosa para Beijing a largo plazo, dicen los expertos.
Donald Trump, el presidente de los Estados Unidos, lanzó la primera advertencia a principios de este año al gravar las principales exportaciones chinas, incluidos los paneles solares, el acero y el aluminio.
La escalada más significativa se produjo esta semana con nuevos aranceles que afectan a artículos por valor de $ 200 mil millones (150 mil millones de libras esterlinas), gravando efectivamente la mitad de todos los bienes que entran a los Estados Unidos desde China.
Beijing ha tomado represalias cada vez en especie, recientemente aplicando aranceles de cinco a diez por ciento a $60 mil millones de bienes estadounidenses.
China se ha comprometido a igualar a los EE.UU. tiro por tiro, y es poco probable que la segunda economía más grande del mundo parpadee en el corto plazo.
Hacer que Washington retroceda significa ceder a las demandas, pero rendirse públicamente a los EE.UU. sería demasiado vergonzoso para Xi Jinping, el presidente de China.
Sin embargo, los expertos dicen que si Pekín puede jugar sus cartas correctamente, las presiones de la guerra comercial de Estados Unidos podrían apoyar positivamente a China a largo plazo al reducir la interdependencia de las dos economías.
"El hecho de que una rápida decisión política en Washington o Pekín pueda crear las condiciones que inicien una caída económica en cualquiera de los dos países es en realidad mucho más peligroso de lo que los espectadores han reconocido antes," dijo Abigail Grace, una investigadora asociada que se centra en Asia en el Centro para la Nueva Seguridad Americana, un grupo de expertos.
Siria 'preparada' para el regreso de los refugiados, dice el Ministro de Asuntos Exteriores
Siria dice que está lista para el regreso voluntario de los refugiados y está pidiendo ayuda para reconstruir el país devastado por una guerra de más de siete años.
Hablando ante la Asamblea General de las Naciones Unidas, el ministro de Relaciones Exteriores, Walid al-Moualem, dijo que las condiciones en el país están mejorando.
"Hoy en día, la situación en el terreno es más estable y segura gracias a los progresos realizados en la lucha contra el terrorismo", dijo.
El gobierno continúa rehabilitando las áreas destruidas por los terroristas para restaurar la normalidad.
Ahora existen todas las condiciones para el regreso voluntario de los refugiados al país que tuvieron que abandonar a causa del terrorismo y de las medidas económicas unilaterales que atacaban su vida cotidiana y sus medios de vida.
La ONU estima que más de 5,5 millones de sirios han huido del país desde que comenzó la guerra en 2011.
Otros seis millones de personas que aún viven en el país necesitan ayuda humanitaria.
Al-Moualem dijo que el régimen sirio daría la bienvenida a la ayuda en la reconstrucción del país devastado.
Pero subrayó que no aceptaría asistencia condicional o ayuda de los países que patrocinaron la insurgencia.
Europa se hace con la victoria en la Ryder Cup en París
El equipo de Europa ha ganado la Ryder Cup 2018 derrotando al equipo de Estados Unidos por un puntaje final de 16.5 a 10.5 en Le Golf National, a las afueras de París, Francia.
Los EE.UU. han perdido seis veces consecutivas en suelo europeo y no han ganado una Copa Ryder en Europa desde 1993.
Europa recuperó la corona cuando el equipo del capitán danés Thomas Bjorn alcanzó los 14,5 puntos que necesitaban para vencer a los Estados Unidos.
La estrella estadounidense Phil Mickelson, que luchó la mayor parte del torneo, lanzó su tee-shot al agua en el hoyo 16 de par-3, concediendo su partido a Francesco Molinari.
El golfista italiano Molinari brilló en todas sus rondas, convirtiéndose en el 1 de los 4 jugadores en ir 5-0-0 desde que comenzó el formato actual del torneo en 1979.
El estadounidense Jordan Spieth fue eliminado 5 y 4 por el jugador de menor rango en el equipo europeo, Thorbjorn Olesen de Dinamarca.
El mejor jugador del mundo, Dustin Johnson, cayó 2 y 1 ante Ian Poulter de Inglaterra que pudo haber jugado en su última Ryder Cup.
Un veterano de ocho Ryder Cups, el español Sergio García se convirtió en el europeo más ganador de todos los torneos con 25.5 puntos en su carrera.
"Normalmente no lloro, pero hoy no puedo evitarlo.
Ha sido un año duro.
Estoy muy agradecida de que Thomas me eligiera y creyera en mí.
Estoy tan feliz, tan feliz de tener la copa de vuelta.
Se trata del equipo, y estoy feliz de haber podido ayudar", dijo un emotivo García después de la victoria europea.
Él pasa la antorcha a su compatriota John Ram que derribó a la leyenda del golf estadounidense Tiger Woods 2 y 1 en el juego individual el domingo.
"El increíble orgullo que siento, por vencer a Tiger Woods, crecí viendo a ese tipo", dijo Rahm, de 23 años.
Woods perdió sus cuatro partidos en Francia y ahora tiene un récord de 13-21-3 en la Ryder Cup.
Una extraña estadística de uno de los mejores jugadores de todos los tiempos, habiendo ganado 14 títulos importantes sólo superado por Jack Nicklaus.
Equipo EE.UU. luchó todo el fin de semana para encontrar las calles con la excepción de Patrick Reed, Justin Thomas y Tony Finau, que jugó golf de alto calibre durante todo el torneo.
El capitán estadounidense Jim Furyk habló después de una decepcionante actuación de su escuadrón: "Estoy orgulloso de estos chicos, lucharon.
Había tiempo esta mañana cuando pusimos un poco de calor en Europa.
Lo dejamos.
Me quito el sombrero por Thomas.
Es un gran capitán.
Sus 12 jugadores jugaron muy bien.
Nos reagruparemos, trabajaré con la PGA de América y nuestro Comité de la Ryder Cup y seguiremos adelante.
Amo a estos 12 muchachos y estoy orgulloso de servir como capitán.
Tienes que levantar el sombrero.
Fuimos superados".
Actualización de la marea roja: las concentraciones disminuyen en Pinellas, Manatee y Sarasota
El último informe de la Comisión de Pesca y Vida Silvestre de Florida muestra una disminución general en las concentraciones de marea roja para partes del área de la bahía de Tampa.
Según el FWC, se están reportando condiciones de floración de manchas en áreas de los condados de Pinellas, Manatee, Sarasota, Charlotte y Collier, lo que sugiere una disminución de las concentraciones.
La marea roja se extiende aproximadamente 130 millas de costa desde el norte de Pinellas hasta el sur de los condados de Lee.
Los parches se pueden encontrar a unas 10 millas de la costa del condado de Hillsborough, pero en menos sitios en relación con la semana pasada.
La marea roja también se ha observado en el condado de Pasco.
Se han reportado concentraciones medianas en el condado de Pinellas en la última semana. concentraciones de baja a alta en la costa del condado de Hillsborough, antecedentes de las altas concentraciones en el condado de Manatee, Antecedentes de altas concentraciones en el condado de Sarasota o en la costa, antecedentes de concentraciones medias en el condado de Charlotte, antecedentes de altas concentraciones en el condado de Lee o en la costa y bajas concentraciones en el condado de Collier.
La irritación respiratoria continúa siendo reportada en los condados de Pinellas, Manatee, Sarasota, Lee y Collier.
No se han reportado irritaciones respiratorias en el noroeste de Florida durante la semana pasada.
