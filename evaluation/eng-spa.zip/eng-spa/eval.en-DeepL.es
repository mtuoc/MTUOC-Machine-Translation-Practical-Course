Los diputados galeses temen «parecer unos payasos»
Hay consternación entre algunos diputados ante la propuesta de que su título pase a ser «MWP» (Miembro del Parlamento de Gales).
Esto se debe a los planes de cambiar el nombre de la asamblea por el de Parlamento de Gales.
A los diputados de todo el espectro político les preocupa que esto pueda dar lugar a burlas.
Un diputado del Partido Laborista afirmó que a su grupo le preocupaba «que rime con Twp y Pwp».
Para los lectores que no sean de Gales: en galés, «twp» significa «tonto» y «pwp» significa «caca».
Un miembro del Plaid AM afirmó que el grupo en su conjunto «no estaba contento» y ha propuesto alternativas.
Un conservador galés afirmó que su grupo tenía «una actitud abierta» respecto al cambio de nombre, pero señaló que de MWP a Muppet solo hay un pequeño salto fonético.
En este contexto, la letra «w» galesa se pronuncia de forma similar a la pronunciación de la letra «u» en el inglés de Yorkshire.
La Comisión de la Asamblea, que actualmente está elaborando la legislación para introducir los cambios de denominación, declaró: «La decisión final sobre cómo se denominará a los miembros de la Asamblea corresponderá, por supuesto, a los propios miembros».
La Ley del Gobierno de Gales de 2017 otorgó a la Asamblea de Gales la facultad de cambiar su nombre.
En junio, la Comisión publicó los resultados de una consulta pública sobre las propuestas, en la que se observó un amplio apoyo a la idea de denominar a la asamblea «Parlamento de Gales».
En cuanto a la denominación de los miembros de la Asamblea, la Comisión se decantó por «miembros del Parlamento de Gales» (WMP), pero la opción «MWP» fue la que recibió más apoyo en una consulta pública.
Al parecer, los diputados están proponiendo opciones alternativas, pero la dificultad para alcanzar un consenso podría suponer un quebradero de cabeza para la presidenta, Elin Jones, de quien se espera que presente un proyecto de ley sobre los cambios en las próximas semanas.
La legislación sobre las reformas incluirá otros cambios en el funcionamiento de la Asamblea, entre ellos normas relativas a la inhabilitación de los diputados y la configuración del sistema de comisiones.
Los diputados tendrán la última palabra sobre cómo se les debe llamar cuando debatan la ley.
Los macedonios acuden a las urnas en un referéndum sobre el cambio de nombre del país
Los votantes decidirán este domingo si cambian el nombre de su país por el de «República de Macedonia del Norte».
La votación popular se organizó con el fin de resolver una disputa que se prolongaba desde hacía décadas con la vecina Grecia, que cuenta con una provincia propia llamada Macedonia.
Atenas lleva mucho tiempo insistiendo en que el nombre de su vecino del norte supone una reivindicación sobre su territorio y se ha opuesto en repetidas ocasiones a sus solicitudes de adhesión a la UE y a la OTAN.
El presidente de Macedonia, Gjorge Ivanov, opositor al referéndum sobre el cambio de nombre, ha declarado que no tendrá en cuenta el resultado de la votación.
Sin embargo, los partidarios del referéndum, entre ellos el primer ministro Zoran Zaev, sostienen que el cambio de nombre es simplemente el precio que hay que pagar para entrar en la UE y la OTAN.
Las campanas de St. Martin's callan mientras las iglesias de Harlem atraviesan dificultades
«Según me han contado las personas mayores con las que he hablado, antiguamente había un bar y una iglesia en cada esquina», dijo el Sr. Adams.
«Hoy en día, no hay nada de eso».
Dijo que la desaparición de los bares era comprensible.
«Hoy en día, la gente se relaciona de otra manera», afirmó.
«Los bares ya no son los salones de barrio a los que la gente acude habitualmente».
En cuanto a las iglesias, le preocupa que el dinero obtenido con la venta de activos no dure tanto como esperan los responsables, «y que, tarde o temprano, vuelvan a encontrarse en la misma situación de partida».
Las iglesias, añadió, podrían ser sustituidas por edificios de apartamentos con viviendas en propiedad horizontal ocupadas por el tipo de gente que no ayudará a los santuarios que aún quedan en el barrio.
«La inmensa mayoría de las personas que compren apartamentos en estos edificios serán blancas,«—dijo—, y, por lo tanto, acelerará el día en que estas iglesias cierren definitivamente, ya que es poco probable que la mayoría de las personas que se muden a estos bloques de pisos se hagan miembros de estas iglesias».
Ambas iglesias fueron construidas por congregaciones blancas antes de que Harlem se convirtiera en una metrópolis negra: la Metropolitan Community en 1870 y St. Martin's una década más tarde.
La congregación metodista blanca original se marchó en la década de 1930.
Una congregación negra que había estado celebrando sus cultos en las inmediaciones se hizo con la propiedad del edificio.
La iglesia de St. Martin's pasó a manos de una congregación negra dirigida por el reverendo John Howard Johnson, quien encabezó un boicot contra los comercios de la calle 125, una de las principales calles comerciales de Harlem, que se negaban a contratar o ascender a personas de raza negra.
Un incendio ocurrido en 1939 dejó el edificio gravemente dañado, pero cuando los feligreses del padre Johnson hicieron planes para reconstruirlo, encargaron el carillón.
El reverendo David Johnson, hijo del padre Johnson y su sucesor en St. Martin's, se refería con orgullo al carillón como «las campanas de los pobres».
El experto que tocó el carillón en julio lo describió de otra manera: «Un tesoro cultural» y «un instrumento histórico irreemplazable».
La experta, Tiffany Ng, de la Universidad de Míchigan, también señaló que fue el primer carillón del mundo en ser tocado por un músico negro, Dionisio A. Lind, quien se trasladó al carillón más grande de la iglesia Riverside hace 18 años.
El Sr. Merriweather dijo que St. Martin's no lo sustituyó.
Lo que ha ocurrido en St. Martin's durante los últimos meses ha sido una complicada historia de arquitectos y contratistas, algunos contratados por los líderes laicos de la iglesia y otros por la diócesis episcopal.
La junta parroquial, el órgano rector de la parroquia, formado por líderes laicos —escribió la diócesis en julio—, expresando su preocupación por que la diócesis «intentara repercutir los costes» a la junta parroquial, a pesar de que esta no había participado en la contratación de los arquitectos y contratistas que la diócesis había designado.
Algunos feligreses se quejaron de la falta de transparencia por parte de la diócesis.
Un tiburón hiere a un niño de 13 años durante una inmersión para pescar langostas en California
Según las autoridades, un tiburón atacó e hirió a un niño de 13 años el sábado mientras buceaba en busca de langosta en California, en el día de apertura de la temporada de pesca de la langosta.
El ataque tuvo lugar poco antes de las 7 de la mañana cerca de Beacon's Beach, en Encinitas.
Chad Hammel contó a KSWB-TV, de San Diego, que llevaba aproximadamente media hora buceando con unos amigos el sábado por la mañana cuando oyó al niño gritar pidiendo ayuda y que, a continuación, se acercó nadando con un grupo para ayudar a sacarlo del agua.
Hammel dijo que al principio pensó que solo era la emoción de haber pescado una langosta, pero luego «se dio cuenta de que estaba gritando: "¡Me ha mordido!"».
¡Me ha picado!
«Tenía toda la clavícula desgarrada», dijo Hammel al llegar junto al niño.
«Les grité a todos que salieran del agua: “¡Hay un tiburón en el agua!”» añadió Hammel.
El niño fue trasladado en helicóptero al Rady Children's Hospital de San Diego, donde se encuentra en estado crítico.
Se desconocía la especie de tiburón responsable del ataque.
El capitán de los socorristas, Larry Giles, declaró en una rueda de prensa que unas semanas antes se había avistado un tiburón en la zona, pero que se había determinado que no se trataba de una especie peligrosa.
Giles añadió que la víctima sufrió lesiones traumáticas en la parte superior del torso.
Las autoridades han cerrado el acceso a la playa desde Ponto Beach, en Casablanco, hasta Swami's, en Ecinitas, durante 48 horas por motivos de investigación y seguridad.
Giles señaló que hay más de 135 especies de tiburones en la zona, pero que la mayoría no se consideran peligrosas.
Sainsbury's planea expandirse en el mercado británico de la belleza
Sainsbury's compite con Boots, Superdrug y Debenhams con secciones de belleza al estilo de los grandes almacenes, atendidas por dependientes especializados.
Como parte de una importante ofensiva en el mercado británico de la belleza, valorado en 2.800 millones de libras, que sigue creciendo mientras que las ventas de moda y artículos para el hogar se reducen, se pondrán a prueba los pasillos de productos de belleza ampliados en 11 tiendas de todo el país y, si tienen éxito, se extenderán a más tiendas el año que viene.
La inversión en productos de belleza surge en un momento en que los supermercados buscan formas de aprovechar el espacio en las estanterías que antes se dedicaba a televisores, microondas y artículos para el hogar.
Sainsbury's ha anunciado que duplicará su oferta de productos de belleza hasta alcanzar los 3.000 artículos, incluyendo por primera vez marcas como Revlon, Essie, Tweezerman y Dr. PawPaw.
Las gamas actuales de L'Oréal, Maybelline y Burt's Bees también contarán con más espacio, con zonas dedicadas a cada marca similares a las que se encuentran en tiendas como Boots.
El supermercado también está relanzando su gama de maquillaje «Boutique» para que la mayoría de los productos sean aptos para veganos, algo que demandan cada vez más los compradores más jóvenes.
Además, la cadena de perfumerías The Fragrance Shop pondrá a prueba varios puestos de venta en dos tiendas de Sainsbury's; el primero de ellos abrió sus puertas la semana pasada en Croydon, al sur de Londres, mientras que el segundo abrirá en Selly Oak, Birmingham, a finales de este año.
Las compras por Internet y la tendencia a comprar pequeñas cantidades de comida a diario en las tiendas locales hacen que los supermercados tengan que esforzarse más para convencer a la gente de que los visite.
Mike Coupe, director ejecutivo de Sainsbury's, ha afirmado que las tiendas se parecerán cada vez más a unos grandes almacenes, ya que la cadena de supermercados intenta hacer frente a las cadenas de descuento Aldi y Lidl ofreciendo más servicios y productos no alimentarios.
Sainsbury's ha instalado puntos de venta de Argos en cientos de tiendas y también ha incorporado varios establecimientos de Habitat desde que compró ambas cadenas hace dos años, lo que, según afirma, ha impulsado las ventas de alimentación y ha aumentado la rentabilidad de las adquisiciones.
El anterior intento del supermercado de renovar sus secciones de belleza y farmacia terminó en fracaso.
Sainsbury's probó una empresa conjunta con Boots a principios de la década de 2000, pero la alianza terminó tras una disputa sobre cómo repartir los ingresos de las farmacias ubicadas en sus supermercados.
La nueva estrategia se produce después de que, hace tres años, Sainsbury's vendiera su negocio de farmacias, compuesto por 281 establecimientos, a Celesio, propietaria de la cadena Lloyds Pharmacy, por 125 millones de libras.
Según la información, Lloyds participaría en el plan incorporando una amplia gama de marcas de productos de lujo para el cuidado de la piel, entre ellas La Roche-Posay y Vichy, en cuatro tiendas.
Paul Mills-Hicks, director comercial de Sainsbury's, afirmó: «Hemos renovado el aspecto y el ambiente de nuestras secciones de belleza para mejorar la experiencia de nuestros clientes».
También hemos invertido en personal especialmente formado que estará a su disposición para ofrecerle asesoramiento.
«Nuestra gama de marcas está diseñada para satisfacer todas las necesidades, y gracias a su atractivo ambiente y a su excelente ubicación, nos hemos convertido en un destino de belleza irresistible que rompe con las viejas costumbres de compra».
Peter Jones, «furioso» tras la retirada de Holly Willoughby de un acuerdo de 11 millones de libras
Peter Jones, estrella del programa «Dragons’ Den», se ha quedado «furioso» después de que la presentadora de televisión Holly Willoughby se retirara de un acuerdo de 11 millones de libras con su marca de estilo de vida para centrarse en sus nuevos contratos con Marks and Spencer e ITV
Willoughby no tiene tiempo para su marca de ropa para estar por casa y accesorios, Truly.
El negocio de la pareja se había comparado con la marca Goop de Gwyneth Paltrow.
La presentadora de «This Morning», de 37 años, anunció en Instagram que deja el programa.
Holly Willoughby ha enfurecido a Peter Jones, estrella de «Dragons' Den», al retirarse en el último momento de su lucrativo negocio de marcas de estilo de vida para centrarse en sus propios y jugosos contratos con Marks & Spencer e ITV.
Según algunas fuentes, Jones se puso «furioso» cuando la estrella de la televisión admitió, durante una tensa reunión celebrada el martes en la sede de su imperio empresarial en Marlow, Buckinghamshire, que sus nuevos contratos —por un valor de hasta 1,5 millones de libras— le impedían dedicar el tiempo suficiente a su marca de ropa para el hogar y accesorios, Truly.
El negocio se había comparado con la marca Goop de Gwyneth Paltrow y se preveía que duplicara la fortuna estimada de Willoughby, que ascendía a 11 millones de libras.
Mientras Willoughby, de 37 años, anunciaba en Instagram que dejaba Truly, Jones salió de Gran Bretaña para dirigirse a una de sus casas de vacaciones.
Una fuente afirmó: «Truly era, con diferencia, la principal prioridad de Holly».
Sería su futuro a largo plazo lo que le permitiría salir adelante durante las próximas dos décadas.
Su decisión de retirarse dejó a todos los implicados completamente atónitos.
Nadie podía creer lo que estaba pasando el martes, tan cerca del lanzamiento.
«En la sede central de Marlow hay un almacén repleto de productos listos para su venta».
Los expertos creen que la salida del presentador de «This Morning», quien figura entre las estrellas más rentables de Gran Bretaña, podría costarle a la empresa millones debido a la cuantiosa inversión realizada en productos que van desde cojines y velas hasta ropa y artículos para el hogar, así como a la posibilidad de que se produzcan nuevos retrasos en su lanzamiento.
Y podría significar el fin de una larga amistad.
Willoughby, madre de tres hijos, y su marido, Dan Baldwin, llevan diez años siendo muy amigos de Jones y su esposa, Tara Capp.
Willoughby fundó Truly junto con Capp en 2016, y Jones, de 52 años, se incorporó como presidente en marzo.
Las parejas pasan las vacaciones juntas y Jones tiene una participación del 40 % en la productora de televisión de Baldwin.
Willoughby se convertirá en embajador de la marca M&S y sustituirá a Ant McPartlin como presentador del programa de ITV «I'm A Celebrity».
Una fuente cercana a Jones declaró anoche: «No vamos a hacer comentarios sobre sus asuntos comerciales».
«Palabras duras... y luego nos enamoramos»
Bromeó sobre las críticas que recibiría de los medios de comunicación por hacer un comentario que algunos considerarían «poco presidencial» y por mostrarse tan positivo con respecto al líder norcoreano.
¿Por qué ha cedido tanto el presidente Trump?
dijo Trump imitando la voz de un «presentador de noticias».
«No renuncié a nada».
Señaló que Kim está interesado en celebrar una segunda reunión, después de que su encuentro inicial en Singapur, celebrado en junio, fuera calificado por Trump como un gran paso hacia la desnuclearización de Corea del Norte.
Pero las negociaciones sobre la desnuclearización se han estancado.
Más de tres meses después de la cumbre celebrada en junio en Singapur, el jefe de la diplomacia norcoreana, Ri Yong Ho, declaró el sábado ante los líderes mundiales reunidos en la Asamblea General de la ONU que Corea del Norte no ha observado una «respuesta adecuada» por parte de Estados Unidos a las primeras medidas de desarme adoptadas por su país.
En cambio, señaló, Estados Unidos mantiene las sanciones con el fin de seguir ejerciendo presión.
Trump se mostró mucho más optimista en su discurso durante el mitin.
«Nos va muy bien con Corea del Norte», dijo.
«Íbamos a entrar en guerra con Corea del Norte».
Habrían muerto millones de personas.
«Ahora tenemos una relación estupenda».
Afirmó que sus esfuerzos por mejorar las relaciones con Kim han dado resultados positivos: el cese de los ensayos con cohetes, la liberación de rehenes y la repatriación de los restos mortales de militares estadounidenses.
Y defendió su peculiar forma de abordar las relaciones con Kim.
«Es muy fácil parecer presidencial, pero en lugar de tener a 10 000 personas fuera intentando entrar en este estadio abarrotado, tendríamos a unas 200 personas justo ahí», dijo Trump, señalando al público que tenía justo delante.
Un tsunami y un terremoto devastan una isla en Indonesia y causan la muerte de cientos de personas
Por ejemplo, tras el terremoto de Lombok, se comunicó a las organizaciones no gubernamentales extranjeras que no se les necesitaba.
Aunque más del 10 % de la población de Lombok se había visto desplazada, no se declaró el estado de catástrofe nacional, requisito indispensable para movilizar la ayuda internacional.
«En muchos casos, por desgracia, han dejado muy claro que no solicitan ayuda internacional, por lo que resulta un poco complicado», afirmó la Sra. Sumbung.
Aunque Save the Children está formando un equipo para viajar a Palu, aún no se sabe con certeza si el personal extranjero podrá trabajar sobre el terreno.
El Sr. Sutopo, portavoz de la agencia nacional de gestión de desastres, afirmó que las autoridades indonesias estaban evaluando la situación en Palu para determinar si se permitiría a las agencias internacionales colaborar en las labores de ayuda.
A pesar de los constantes terremotos que sufre Indonesia, el país sigue estando lamentablemente mal preparado para hacer frente a la furia de la naturaleza.
Aunque en Aceh se han construido refugios contra el tsunami, no son habituales en otras costas.
Es probable que la aparente ausencia de una sirena de alerta de tsunami en Palu, a pesar de que se había emitido una alerta, haya contribuido a la pérdida de vidas humanas.
Incluso en las mejores circunstancias, viajar entre las numerosas islas de Indonesia supone todo un reto.
Los desastres naturales complican aún más la logística.
Un buque hospital que se encontraba en Lombok para atender a las víctimas del terremoto se dirige ahora a Palu, pero tardará al menos tres días en llegar al lugar de la nueva catástrofe.
El presidente Joko Widodo hizo de la mejora de la deteriorada infraestructura de Indonesia uno de los ejes centrales de su campaña electoral, y ha destinado ingentes recursos a carreteras y ferrocarriles.
Sin embargo, la falta de financiación ha lastrado el gobierno del Sr. Joko, que se enfrenta a la reelección el año que viene.
El Sr. Joko también se enfrenta a la presión derivada de las persistentes tensiones sectarias en Indonesia, donde miembros de la mayoría musulmana han adoptado una forma más conservadora de la fe.
Más de 1.000 personas perdieron la vida y decenas de miles se vieron obligadas a abandonar sus hogares mientras bandas cristianas y musulmanas se enfrentaban en las calles, utilizando machetes, arcos y flechas, y otras armas rudimentarias.
Vídeo: Daniel Sturridge, del Liverpool, marca el gol del empate con un disparo raso ante el Chelsea
Daniel Sturridge salvó al Liverpool de una derrota en la Premier League ante el Chelsea con un gol en el minuto 89 el sábado en Stamford Bridge, en Londres.
Sturridge recibió un pase de Xherdan Shaqiri cuando se encontraba a unos 30 metros de la portería del Chelsea, con su equipo perdiendo por 1-0.
Desvió el balón hacia su izquierda antes de lanzar un tiro raso hacia el segundo palo.
El disparo salió muy por encima del área y se dirigió hacia la esquina superior derecha de la portería.
El balón acabó pasando por encima de Kepa Arrizabalaga, que se había lanzado al suelo, y entró en la portería.
«Solo intentaba colocarme en esa posición, recibir el balón, y jugadores como Shaq siempre lo lanzan hacia delante tanto como pueden, así que yo solo intenté ganarme todo el tiempo posible», explicó Sturridge a LiverpoolFC.com.
«Vi que venía Kanté, controlé el balón con un toque, no lo pensé demasiado y simplemente disparé».
El Chelsea ganaba 1-0 al descanso tras marcar en el minuto 25 gracias a la estrella belga Eden Hazard.
En esa jugada, el delantero del Chelsea le pasó el balón de tacón a Mateo Kovacic, antes de girarse cerca del centro del campo y lanzarse a toda velocidad hacia el campo del Liverpool.
Kovacic realizó una rápida jugada de pared en el centro del campo.
A continuación, lanzó un magnífico pase en profundidad que llevó a Hazard al área.
Hazard superó a la defensa y remató al segundo palo con un disparo con la izquierda que superó a Alisson Becker, el portero del Liverpool.
El Liverpool se enfrentará al Nápoles en la fase de grupos de la Liga de Campeones el miércoles a las 15:00 horas en el Estadio San Paolo de Nápoles, Italia.
El Chelsea se enfrentará al Videoton en la UEFA Europa League el jueves a las 15:00 horas en Londres.
El número de víctimas mortales del tsunami de Indonesia asciende a 832
El número de víctimas mortales del terremoto y el tsunami de Indonesia ha ascendido a 832, según informó la agencia nacional de gestión de desastres a primera hora del domingo.
Según informó el portavoz de la agencia, Sutopo Purwo Nugroho, en una rueda de prensa, se ha informado de que muchas personas han quedado atrapadas entre los escombros de los edificios derrumbados por el terremoto de magnitud 7,5 que sacudió la zona el viernes y provocó olas de hasta seis metros de altura.
La ciudad de Palu, con más de 380 000 habitantes, estaba llena de escombros procedentes de edificios derrumbados.
La policía detiene a un hombre de 32 años como sospechoso de asesinato tras la muerte a puñaladas de una mujer
Se ha iniciado una investigación por asesinato tras el hallazgo esta mañana del cadáver de una mujer en Birkenhead, Merseyside.
El hombre, de 44 años, fue hallado a las 7:55 de la mañana con heridas de arma blanca en Grayson Mews, en John Street, y un hombre de 32 años fue detenido como sospechoso de asesinato.
La policía ha pedido a los vecinos de la zona que hayan visto o escuchado algo que se pongan en contacto con ellos.
El inspector Brian O'Hagan declaró: «La investigación se encuentra en una fase inicial, pero ruego a cualquier persona que se encontrara en las inmediaciones de John Street, en Birkenhead, y que haya visto u oído algo sospechoso que se ponga en contacto con nosotros».
«También quiero pedir a cualquiera, especialmente a los taxistas, que haya grabado algo con la cámara del salpicadero que se ponga en contacto con nosotros, ya que podría tener información fundamental para nuestra investigación».
Un portavoz de la policía ha confirmado que la mujer cuyo cadáver fue hallado es vecina de Birkenhead y que fue encontrada dentro de una vivienda.
Esta tarde han llegado al lugar algunos amigos que creen conocer a la mujer para preguntar dónde la encontraron esta mañana.
Las investigaciones siguen en curso, ya que la policía ha informado de que se encuentra en proceso de notificar a los familiares de la víctima.
Un taxista que vive en Grayson Mews acaba de intentar volver a su piso, pero la policía le ha dicho que no se permite la entrada ni la salida del edificio.
Se quedó sin palabras cuando se enteró de lo que había pasado.
Ahora se les está diciendo a los residentes que tendrán que esperar varias horas antes de que se les permita volver a entrar.
Se oyó a un agente de policía decirle a un hombre que toda la zona se considera ahora escena del crimen.
Una mujer apareció en el lugar llorando.
No deja de repetir «es horrible».
A las 14:00 horas había dos furgones policiales dentro del cordón de seguridad y otro justo fuera.
Varios agentes se encontraban dentro del cordón de seguridad vigilando el bloque de pisos.
Se ruega a cualquier persona que tenga información que envíe un mensaje directo a @MerPolCC, llame al 101 o se ponga en contacto de forma anónima con Crimestoppers en el 0800 555 111, indicando el número de registro 247 del 30 de septiembre.
La estatua de Cromwell del Parlamento se convierte en el último monumento afectado por la polémica sobre la «reescritura de la historia»
Su destierro sería una justicia poética por la destrucción, al estilo talibán, de tantos bienes culturales y religiosos de Inglaterra llevada a cabo por sus fanáticos seguidores puritanos.
Sin embargo, la Sociedad Cromwell calificó la sugerencia del Sr. Crick de «locura» y de «intento de reescribir la historia».
John Goldsmith, presidente de la Cromwell Society, afirmó: «Era inevitable que, en el debate actual sobre la retirada de estatuas, la figura de Oliver Cromwell situada frente al Palacio de Westminster se convirtiera en blanco de las críticas».
El iconoclasmo de las guerras civiles inglesas no fue ni ordenado ni llevado a cabo por Cromwell.
Quizás el Cromwell equivocado acabara pagando por las acciones de su antepasado Thomas en el siglo anterior.
La magnífica representación de Cromwell realizada por Sir William Hamo Thorneycroft es un reflejo de la opinión del siglo XIX y forma parte de la historiografía de una figura que, según muchos, sigue mereciendo ser homenajeada.
El Sr. Goldsmith declaró a The Sunday Telegraph: «Muchos consideran a Cromwell, quizá más a finales del siglo XIX que en la actualidad, un defensor del Parlamento frente a las presiones externas; en su caso, por supuesto, la monarquía».
Si se trata de una descripción totalmente fiel es objeto de un debate histórico que aún no ha concluido.
Lo que es seguro es que el conflicto de mediados del siglo XVII ha marcado el desarrollo posterior de nuestra nación, y Cromwell es una figura emblemática que representa uno de los bandos de esa división.
«Sus logros como Lord Protector también merecen ser celebrados y conmemorados».
Un cerdo asesino mata a mordiscos a un granjero chino
Según informan los medios locales, un granjero fue atacado y asesinado por un cerdo en un mercado del suroeste de China.
El hombre, identificado únicamente por su apellido, «Yuan», fue hallado muerto con una arteria seccionada y cubierto de sangre cerca de una pocilga en el mercado de Liupanshui, en la provincia de Guizhou, según informó el domingo el South China Morning Post.
Un criador de cerdos se dispone a vacunar a los animales en una granja porcina el 30 de mayo de 2005 en Xining, provincia de Qinghai (China).
Según se ha informado, el miércoles había viajado con su primo desde la vecina provincia de Yunnan para vender 15 cerdos en el mercado.
A la mañana siguiente, su primo lo encontró muerto y vio que la puerta de la pocilga de al lado estaba abierta.
Dijo que en la pocilga había un cerdo macho grande con sangre en la boca.
Según el informe, un examen forense confirmó que el cerdo, de unos 250 kilos, había matado a zarpazos al granjero.
«Las piernas de mi primo estaban ensangrentadas y destrozadas», declaró el primo, al que se hace referencia por su apellido, «Wu», según recoge el Guiyang Evening News.
Las imágenes de las cámaras de seguridad mostraban a Yuan entrando en el mercado a las 4:40 de la madrugada del jueves para dar de comer a sus cerdos.
Su cuerpo fue hallado aproximadamente una hora después.
El animal que mató al hombre no era de Yuan ni de su primo.
Un responsable del mercado declaró al Evening News que habían encerrado al cerdo para evitar que atacara a más personas, mientras la policía recogía pruebas en el lugar de los hechos.
Según se informa, la familia de Yuan y las autoridades del mercado están negociando una indemnización por su fallecimiento.
Aunque son poco frecuentes, ya se han registrado casos de cerdos que han atacado a personas.
En 2016, un cerdo atacó a una mujer y a su marido en su granja de Massachusetts, causando heridas graves al hombre.
Diez años antes, un cerdo de 295 kilos inmovilizó a un granjero galés contra su tractor hasta que su mujer ahuyentó al animal.
Después de que unos cerdos devoraran a un granjero de Oregón en 2012, un granjero de Manitoba declaró a CBC News que los cerdos no suelen ser agresivos, pero que el sabor de la sangre puede actuar como un «desencadenante».
«Solo están jugando».
Son crías, muy curiosas... no quieren hacerte daño.
«Solo hay que mostrarles el respeto que se merecen», dijo.
Los restos del huracán Rosa traerán lluvias intensas generalizadas al suroeste de Estados Unidos
Tal y como se había pronosticado, el huracán Rosa se está debilitando a medida que avanza sobre las aguas más frías de la costa norte de México.
Sin embargo, Rosa provocará lluvias torrenciales en el norte de México y el suroeste de Estados Unidos durante los próximos días.
A las 5 de la mañana, Rosa registraba vientos de 85 millas por hora, lo que la convertía en un huracán de categoría 1. El domingo, hora del Este, se encontraba a 385 millas al suroeste de Punta Eugenia, México.
Se prevé que Rosa se desplace hacia el norte el domingo.
Mientras tanto, Se está formando una depresión sobre el océano Pacífico que se desplaza hacia el este, en dirección a la costa oeste de Estados Unidos. A medida que Rosa se acerque a la península de Baja California el lunes en forma de tormenta tropical, comenzará a empujar la humedad tropical hacia el norte, hacia el suroeste de Estados Unidos.
Rosa dejará hasta 25 centímetros de lluvia en algunas zonas de México el lunes.
A continuación, la humedad tropical, al interactuar con la vaguada que se aproxima, provocará lluvias intensas y generalizadas en el suroeste durante los próximos días.
A nivel local, unas precipitaciones de entre 2,5 y 10 cm provocarán peligrosas inundaciones repentinas, corrimientos de escombros y posibles deslizamientos de tierra en el desierto.
La intensa humedad tropical provocará que, en algunos puntos, las precipitaciones alcancen intensidades de entre 50 y 75 mm por hora, especialmente en algunas zonas del sur de Nevada y Arizona.
Se prevén precipitaciones de entre 5 y 10 centímetros en algunas zonas del suroeste, especialmente en gran parte de Arizona.
Es posible que se produzcan inundaciones repentinas debido al rápido empeoramiento de las condiciones, como consecuencia del carácter disperso de las lluvias tropicales.
Sería muy poco aconsejable adentrarse en el desierto a pie ante la amenaza de lluvias tropicales.
Las fuertes lluvias podrían convertir los barrancos en ríos embravecidos, y las tormentas eléctricas traerán consigo rachas de viento y polvo en suspensión a nivel local.
La vaguada que se aproxima traerá lluvias, en algunos casos intensas, a zonas de la costa del sur de California.
Es posible que se registren precipitaciones de más de 1,27 cm, lo que podría provocar pequeños deslizamientos de tierra y carreteras resbaladizas.
Esta sería la primera lluvia de la temporada de lluvias en la región.
A última hora del domingo y a primera hora del lunes empezarán a llegar a Arizona algunas lluvias tropicales dispersas, antes de que las precipitaciones se generalicen a última hora del lunes y el martes.
Las fuertes lluvias se extenderán a la región de Four Corners el martes y se prolongarán hasta el miércoles.
En octubre pueden producirse fuertes variaciones de temperatura en todo Estados Unidos, ya que el Ártico se enfría, mientras que los trópicos siguen siendo bastante cálidos.
A veces, esto provoca cambios drásticos de temperatura en distancias cortas.
El domingo se observará un claro ejemplo de las marcadas diferencias de temperatura que se dan en el centro de Estados Unidos.
Hay una diferencia de temperatura de casi 20 grados entre Kansas City (Misuri) y Omaha (Nebraska), y entre San Luis y Des Moines (Iowa).
En los próximos días, el calor residual del verano intentará volver a intensificarse y extenderse.
Se prevé que gran parte del centro y el este de Estados Unidos tenga un comienzo cálido en octubre, con temperaturas generalizadas en torno a los 27 °C desde las Llanuras del Sur hasta algunas zonas del noreste.
El martes podrían alcanzarse los 27 °C en la ciudad de Nueva York, lo que supondría unos 5 °C por encima de la media.
Nuestra previsión climática a largo plazo apunta a que hay muchas posibilidades de que las temperaturas en el este de Estados Unidos se sitúen por encima de la media durante la primera quincena de octubre.
Más de 20 millones de personas vieron la audiencia de Brett Kavanaugh
Más de 20 millones de personas siguieron el jueves, a través de seis cadenas de televisión, el apasionante testimonio del candidato al Tribunal Supremo Brett Kavanaugh y de la mujer que lo acusó de una agresión sexual que supuestamente tuvo lugar en la década de 1980, Christine Blasey Ford.
Mientras tanto, el enfrentamiento político continuaba, y las cadenas de televisión interrumpieron su programación habitual para informar del giro de última hora del viernes: un acuerdo impulsado por el senador de Arizona Jeff Flake para que el FBI llevara a cabo una investigación de una semana sobre los cargos.
Ford declaró ante la Comisión Judicial del Senado que está totalmente segura de que Kavanaugh la manoseó en estado de embriaguez e intentó quitarle la ropa en una fiesta del instituto.
Kavanaugh, en una apasionada declaración, afirmó estar seguro al 100 % de que eso no ocurrió.
Es probable que lo hayan visto más personas de las 20,4 millones que Nielsen dio a conocer el viernes.
La empresa contabilizaba la audiencia media de CBS, ABC, NBC, CNN, Fox News Channel y MSNBC.
No se disponía de datos inmediatos sobre otras cadenas que lo emitieron, como PBS, C-SPAN y Fox Business Network.
Además, a Nielsen suele costarle medir la audiencia de quienes ven la televisión en la oficina.
Para que te hagas una idea, se trata de una audiencia similar a la de un partido de fútbol de los playoffs o a la de la entrega de los Premios de la Academia.
Según Nielsen, Fox News Channel, cuyos presentadores de programas de opinión han respaldado firmemente el nombramiento de Kavanaugh, fue la cadena más vista, con una media de 5,69 millones de espectadores durante la audiencia, que se prolongó durante todo el día.
ABC quedó en segundo lugar con 3,26 millones de espectadores.
Según Nielsen, la CBS tuvo 3,1 millones, la NBC 2,94 millones, la MSNBC 2,89 millones y la CNN 2,52 millones.
El interés siguió siendo elevado tras la vista.
Flake fue el protagonista del drama del viernes.
Después de que la oficina del republicano moderado emitiera un comunicado en el que anunciaba que votaría a favor de Kavanaugh, las cámaras de la CNN y la CBS lo captaron el viernes por la mañana mientras unos manifestantes le gritaban cuando intentaba subir en un ascensor para acudir a una audiencia del Comité Judicial.
Permaneció de pie, con la mirada baja, durante varios minutos mientras le reprendían, en directo por la CNN.
«Estoy aquí mismo, delante de ti», dijo una mujer.
«¿Crees que le está diciendo la verdad al país?
Le dijeron: «Tienes poder cuando tantas mujeres carecen de él».
Flake afirmó que su oficina había emitido un comunicado y señaló, antes de que se cerraran las puertas del ascensor, que daría más detalles en la audiencia de la comisión.
Las cadenas de televisión por cable y en abierto retransmitían en directo horas más tarde, cuando la Comisión Judicial iba a votar para remitir la candidatura de Kavanaugh al pleno del Senado para su votación.
Sin embargo, Flake afirmó que solo lo haría con la condición de que el FBI investigara las acusaciones contra el candidato durante la próxima semana, tal y como han estado pidiendo los demócratas de la minoría.
Flake se convenció, en parte, gracias a las conversaciones que mantuvo con su amigo, el senador demócrata Chris Coons.
Tras una conversación con Coons y varios senadores, Flake tomó su decisión.
La decisión de Flake tuvo gran peso, ya que era evidente que los republicanos no contarían con los votos necesarios para aprobar a Kavanaugh sin la investigación.
El presidente Trump ha ordenado al FBI que investigue las acusaciones contra Kavanaugh.
La primera ministra británica, May, acusa a sus detractores de «hacer política» con el Brexit
La primera ministra Theresa May acusó a quienes critican sus planes de salir de la Unión Europea de «hacer política» con el futuro de Gran Bretaña y de socavar el interés nacional en una entrevista concedida al periódico Sunday Times.
La primera ministra británica, Theresa May, llega al Congreso del Partido Conservador en Birmingham, Reino Unido, el 29 de septiembre de 2018.
En otra entrevista que aparece junto a la suya en la portada del periódico, Su antiguo ministro de Asuntos Exteriores, Boris Johnson, redobló sus críticas al llamado «plan de Chequers» para el Brexit, calificando de «totalmente absurdo» el hecho de que el Reino Unido y la UE se cobraran mutuamente aranceles.
Tiroteo de Wayde Sims: la policía detiene al sospechoso Dyteon Simpson por la muerte del jugador de la LSU
La policía ha detenido a un sospechoso por el homicidio de Wayde Sims, un jugador de baloncesto de 20 años de la LSU.
Dyteon Simpson, de 20 años, ha sido detenido e ingresado en prisión acusado de asesinato en segundo grado, según ha informado el Departamento de Policía de Baton Rouge.
Las autoridades han difundido un vídeo del enfrentamiento entre Sims y Simpson, y la policía ha informado de que Sims perdió sus gafas durante la pelea.
La policía recuperó las gafas del lugar de los hechos y afirmó haber encontrado ADN de Simpson en ellas, según informa la cadena WAFB, afiliada a la CBS.
Tras interrogar a Simpson, la policía afirmó que este había admitido haber disparado mortalmente a Wayde.
Según informa el Advocate, su fianza se ha fijado en 350 000 dólares.
La Oficina del Forense de la parroquia de East Baton Rouge publicó el viernes un informe preliminar en el que se indica que la causa de la muerte fue una herida de bala en la cabeza que penetró en el cuello.
El departamento agradece a la unidad especial de búsqueda de fugitivos de la Policía Estatal de Luisiana, al laboratorio criminalístico de la policía estatal, a la policía de la Universidad del Sur y a los ciudadanos de la zona por su colaboración en la investigación que condujo a la detención.
El director deportivo de la LSU, Joe Alleva, agradeció a las fuerzas del orden de la zona su «diligencia y su compromiso con la justicia».
Sims tenía 20 años.
El alero, de 1,98 metros de altura, creció en Baton Rouge, donde su padre, Wayne, también jugó al baloncesto en la LSU.
La temporada pasada promedió 5,6 puntos y 2,6 rebotes por partido.
El viernes por la mañana, el entrenador de baloncesto de la LSU, Will Wade, declaró que el equipo está «devastado» y «conmocionado» por la muerte de Wayde.
«Esto es lo que te preocupa constantemente», dijo Wade.
Un volcán arroja cenizas sobre la Ciudad de México
La ceniza expulsada por el volcán Popocatépetl ha llegado a los barrios del sur de la capital de México.
El Centro Nacional de Prevención de Desastres advirtió el sábado a los mexicanos que se mantuvieran alejados del volcán, tras el aumento de la actividad en el cráter y el registro de 183 emisiones de gas y ceniza en 24 horas.
El centro estaba registrando múltiples retumbos y temblores.
Las imágenes difundidas en las redes sociales mostraban finas capas de ceniza cubriendo los parabrisas de los coches en barrios de la Ciudad de México como Xochimilco.
Los geofísicos han observado un aumento de la actividad en el volcán situado a 72 kilómetros al sureste de la capital desde que un terremoto de magnitud 7,1 sacudió el centro de México en septiembre de 2017.
El volcán conocido como «Don Goyo» lleva activo desde 1994.
La policía se enfrenta a los separatistas catalanes en vísperas del aniversario del referéndum sobre la independencia
El sábado fueron detenidas seis personas en Barcelona tras los enfrentamientos entre manifestantes independentistas y la policía antidisturbios, mientras miles de personas se sumaban a manifestaciones contrarias para conmemorar el primer aniversario del polémico referéndum sobre la secesión de Cataluña.
Un grupo de separatistas enmascarados, contenidos por la policía antidisturbios, les lanzó huevos y pintura en polvo, creando densas nubes de polvo en unas calles que normalmente estarían repletas de turistas.
Más tarde se produjeron también enfrentamientos, y la policía tuvo que recurrir a las porras para controlar la situación.
Durante varias horas, grupos independentistas que coreaban «Ni olvidar, ni perdonar» se enfrentaron a manifestantes unionistas que gritaban «Viva España».
Según informó la prensa local, catorce personas recibieron atención médica por lesiones leves sufridas durante las protestas.
Las tensiones siguen siendo elevadas en esta región independentista un año después del referéndum del 1 de octubre, considerado ilegal por Madrid pero celebrado por los catalanes separatistas.
Los votantes se pronunciaron de forma abrumadora a favor de la independencia, aunque la participación fue baja, ya que quienes se oponían a la secesión boicotearon en gran medida la votación.
Según las autoridades catalanas, el año pasado resultaron heridas casi 1 000 personas tras los violentos enfrentamientos que se produjeron cuando la policía intentó impedir la celebración de las votaciones en los colegios electorales de toda la región.
Los grupos independentistas habían acampado durante la noche del viernes para impedir una manifestación en apoyo de la policía nacional.
La manifestación se llevó a cabo, pero se vio obligada a tomar un recorrido diferente.
Narcis Termes, de 68 años, un electricista que asistía a la manifestación independentista junto a su esposa, afirmó que ya no tenía esperanzas en que Cataluña lograra la independencia.
«El año pasado vivimos uno de nuestros mejores momentos.
«Vi a mis padres llorar de alegría por poder votar, pero ahora estamos atascados», dijo.
A pesar de haber logrado una victoria decisiva, aunque por un estrecho margen, en las elecciones regionales del pasado diciembre, Los partidos independentistas catalanes han tenido dificultades para mantener el impulso este año, ya que muchos de sus líderes más conocidos se encuentran en el exilio voluntario o detenidos a la espera de juicio por su participación en la organización del referéndum y la posterior declaración de independencia.
Joan Puig, un mecánico de 42 años que grababa con su teléfono móvil la manifestación en apoyo de la policía, afirmó que el conflicto había sido avivado por políticos de ambos bandos.
«La situación se está volviendo cada vez más tensa», dijo.
El sábado, Oriol Junqueras, uno de los nueve líderes catalanes que se encuentran en prisión preventiva desde finales del año pasado, anunció que se presentaría a las elecciones al Parlamento Europeo del año que viene.
«Presentarse como candidato a las elecciones europeas es la mejor manera de denunciar el retroceso en los valores democráticos y la represión que hemos observado por parte del Gobierno español», afirmó.
Londonderry: Detienen a varios hombres tras el choque de un coche contra una vivienda
Tres hombres, de 33, 34 y 39 años, han sido detenidos tras embestir repetidamente con un coche contra una vivienda en Londonderry.
El suceso tuvo lugar en Ballynagard Crescent el jueves, alrededor de las 19:30 hora británica.
El inspector Bob Blemmings afirmó que se produjeron daños en las puertas y en el propio edificio.
Es posible que, en algún momento, también se haya disparado una ballesta contra el coche.
Un gol de Menga da la victoria por 1-0 al Livingston sobre el Rangers
El primer gol de Dolly Menga con el Livingston aseguró la victoria
El recién ascendido Livingston dio la sorpresa al derrotar al Rangers, lo que supuso la segunda derrota de Steven Gerrard en 18 partidos al frente del club de Ibrox.
El gol de Dolly Menga marcó la diferencia y el equipo de Gary Holt empató a puntos con el Hibernian en el segundo puesto.
El equipo de Gerrard sigue sin conocer la victoria fuera de casa en la Premiership esta temporada y el próximo domingo se enfrentará al líder, el Hearts, del que se encuentra a ocho puntos.
Antes de eso, el Rangers recibirá al Rapid de Viena en la Europa League el jueves.
Por su parte, el Livingston prolonga su racha invicta en la liga a seis partidos, y el entrenador Holt sigue sin conocer la derrota desde que sustituyó a Kenny Miler el mes pasado.
El Livingston desperdicia ocasiones ante unos visitantes poco incisivos
El equipo de Holt debería haber marcado mucho antes de abrir el marcador, ya que su juego directo causó todo tipo de problemas a los Rangers.
Scott Robinson se abrió paso, pero su disparo se fue raso junto al poste; a continuación, Alan Lithgow, tras lanzarse en plancha para rematar de cabeza un centro de Craig Halkett, solo pudo enviar el balón fuera.
Los locales se limitaron a dejar que el Rangers jugara en su campo, sabiendo que podían poner en aprietos a los visitantes en las jugadas a balón parado.
Y así fue como llegó el gol decisivo.
El Rangers concedió un tiro libre y el Livingston creó una ocasión: Declan Gallagher y Robinson combinaron para habilitar a Menga, quien controló el balón y marcó desde el centro del área.
Para entonces, el Rangers había dominado la posesión, pero se había topado con una defensa local impenetrable y el portero Liam Kelly apenas había tenido trabajo,
Esa tónica se mantuvo en la segunda parte, aunque Alfredo Morelos obligó a Kelly a realizar una parada.
Scott Pittman vio cómo Allan McGregor, el portero del Rangers, le negaba el gol con los pies, y Lithgow envió fuera un remate tras otra jugada a balón parado del Livingston.
Los centros llegaban continuamente al área del Livingston y eran despejados una y otra vez, mientras que se desestimaron dos peticiones de penalti: una tras una entrada de Halkett sobre el suplente Glenn Middleton y otra por mano.
«Fenomenal» de Livingston: análisis
Alasdair Lamont, de BBC Escocia, en el Tony Macaroni Arena
Una actuación y un resultado fenomenales para el Livingston.
Sin excepción, todos ellos estuvieron excelentes y siguieron superando las expectativas en esta trayectoria ascendente.
Su estilo de juego y su plantilla apenas han cambiado desde su regreso a la máxima categoría, pero hay que reconocer el gran mérito de Holt por la forma en que ha motivado al equipo desde su llegada.
Tenía tantos héroes.
El capitán Halkett estuvo magnífico, dirigiendo una defensa magníficamente organizada, mientras que Menga mantuvo en vilo a Connor Goldson y Joe Worrall durante todo el partido.
Sin embargo, a los Rangers les faltó la inspiración.
Por muy bien que hayan jugado en ocasiones bajo la dirección de Gerrard, esta vez se quedaron muy por debajo de ese nivel.
Les faltó precisión en el último pase —solo en una ocasión lograron abrir la defensa local— y esto supone una especie de llamada de atención para los Rangers, que se encuentran en la zona media de la tabla.
Erdogan recibe una acogida dispar en Colonia
El sábado (29 de septiembre) reinaba un ambiente festivo bajo un cielo azul cuando los líderes de Turquía y Alemania se reunieron para desayunar en Berlín.
Es el último día de la polémica visita del presidente Erdogan a Alemania, cuyo objetivo es restablecer las relaciones entre los aliados de la OTAN.
Se han distanciado por cuestiones como los derechos humanos, la libertad de prensa y la adhesión de Turquía a la UE.
A continuación, Erdogan se dirigió a Colonia para inaugurar una nueva mezquita de grandes dimensiones.
La ciudad alberga la mayor comunidad turca fuera de Turquía.
La policía alegó motivos de seguridad para impedir que una multitud de 25 000 personas se congregara frente a la mezquita, pero muchos simpatizantes se reunieron en las inmediaciones para ver a su presidente.
Cientos de manifestantes contrarios a Erdogan —muchos de ellos kurdos— también hicieron oír su voz, condenando tanto las políticas de Erdogan como la decisión del Gobierno alemán de recibirlo en el país.
Las protestas enfrentadas reflejan la polarización que suscita un visitante aclamado como héroe por algunos turcos residentes en Alemania y vilipendiado como autócrata por otros.
Accidente en Deptford Road: un ciclista fallece tras chocar contra un coche
Un ciclista ha fallecido en un accidente con un coche en Londres.
El accidente se produjo cerca del cruce entre Bestwood Street y Evelyn Street, una calle muy transitada de Deptford, en el sureste de la ciudad, alrededor de las 10:15 hora británica.
El conductor del coche se detuvo y acudieron los servicios de emergencia, pero el hombre falleció en el lugar del accidente.
El accidente se produce meses después de que otro ciclista falleciera en un atropello con fuga en la calle Childers, a unos dos kilómetros del lugar del accidente del sábado.
La Policía Metropolitana informó de que los agentes estaban trabajando para identificar al hombre e informar a sus familiares.
Se han cerrado algunas carreteras y se han establecido desvíos para los autobuses; se recomienda a los conductores que eviten la zona.
Prisión de Long Lartin: seis agentes heridos en unos disturbios
Según ha informado la Oficina de Prisiones, seis funcionarios de prisiones han resultado heridos en un altercado ocurrido en una cárcel de alta seguridad para hombres.
El domingo, alrededor de las 09:30 (hora británica), se produjeron disturbios en la prisión de Long Lartin, en Worcestershire, que aún continúan.
Se ha recurrido a agentes especializados de la unidad «Tornado» para hacer frente al altercado, en el que están implicados ocho reclusos y que se limita a un ala del centro.
Los agentes recibieron atención médica en el lugar por heridas leves en la cara.
Un portavoz del Servicio Penitenciario declaró: «Se ha desplegado personal penitenciario especialmente formado para hacer frente a un incidente que se está produciendo en la prisión de Long Lartin».
Seis miembros del personal han recibido atención médica por sus lesiones.
«No toleramos la violencia en nuestras cárceles, y dejamos claro que los responsables serán denunciados a la policía y podrían pasar más tiempo entre rejas».
La prisión de Long Lartin alberga a más de 500 reclusos, entre los que se encuentran algunos de los delincuentes más peligrosos del país.
En junio se informó de que el director de la prisión había recibido atención médica en el hospital tras ser agredido por un recluso.
Y en octubre del año pasado se llamó a la policía antidisturbios a la prisión para hacer frente a un grave altercado en el que se atacó al personal con bolas de billar.
El huracán Rosa amenaza a Phoenix, Las Vegas y Salt Lake City con inundaciones repentinas (las zonas afectadas por la sequía podrían beneficiarse)
No es habitual que una depresión tropical azote Arizona, pero eso es precisamente lo que parece que va a ocurrir a principios de la próxima semana, cuando los restos del huracán Rosa atraviesen el desierto del suroeste, lo que conlleva riesgo de inundaciones repentinas.
El Servicio Meteorológico Nacional ya ha emitido alertas de inundaciones repentinas para el lunes y el martes en el oeste de Arizona, el sur y el este de Nevada, el sureste de California y Utah, incluidas las ciudades de Phoenix, Flagstaff, Las Vegas y Salt Lake City.
Se prevé que Rosa siga una trayectoria directa hacia Phoenix el martes y que se acerque a última hora del lunes trayendo lluvias.
El Servicio Meteorológico Nacional de Phoenix señaló en un tuit que «¡solo diez ciclones tropicales han mantenido la categoría de tormenta tropical o depresión a menos de 320 kilómetros de Phoenix desde 1950!».
«El huracán Katrina (1967) se encontraba a menos de 65 kilómetros de la frontera con Arizona».
Los últimos modelos del Centro Nacional de Huracanes prevén entre 50 y 100 mm de lluvia, con precipitaciones aisladas de hasta 150 mm en la cordillera Mogollon Rim de Arizona.
Es probable que en otras zonas del suroeste desértico, incluidas las Montañas Rocosas centrales y la Gran Cuenca, caigan entre 2,5 y 5 cm de lluvia, con posibilidad de que en algunos puntos aislados se alcancen hasta 10 cm.
Para quienes no corren riesgo de sufrir crecidas repentinas, la lluvia de Rosa puede ser una bendición, ya que la región se encuentra azotada por la sequía.
Aunque las inundaciones son motivo de gran preocupación, es probable que parte de estas lluvias resulten beneficiosas, ya que el suroeste se encuentra actualmente en situación de sequía.
«Según el Observatorio de Sequías de EE. UU., algo más del 40 % de Arizona sufre al menos una sequía extrema, la segunda categoría más grave», informó weather.com.
En primer lugar, la trayectoria del huracán Rosa lo llevará a tocar tierra en la península de Baja California, en México.
Rosa, que este domingo por la mañana seguía teniendo la intensidad de un huracán, con vientos máximos de 85 millas por hora, se encuentra a 385 millas al sur de Punta Eugenia (México) y se desplaza hacia el norte a una velocidad de 12 millas por hora.
La tormenta está entrando en aguas más frías del Pacífico y, por lo tanto, está perdiendo fuerza.
Por lo tanto, se prevé que toque tierra en México con la intensidad de una tormenta tropical durante la tarde o la noche del lunes.
Las lluvias en algunas zonas de México podrían ser intensas, lo que supone un riesgo importante de inundaciones.
«Se esperan precipitaciones totales de entre 7,6 y 15,2 cm desde Baja California hasta el noroeste de Sonora, con la posibilidad de que alcancen los 25,4 cm», informó weather.com.
A continuación, Rosa se desplazará hacia el norte a través de México en forma de tormenta tropical antes de llegar a la frontera con Arizona en la madrugada del martes como depresión tropical, tras lo cual seguirá su trayectoria hacia el norte a través de Arizona hasta el sur de Utah a última hora del martes por la noche.
«El principal riesgo que se prevé que plantee Rosa o sus restos son lluvias muy intensas en Baja California, el noroeste de Sonora y el desierto del suroeste de Estados Unidos», ha informado el Centro Nacional de Huracanes.
Se prevé que estas lluvias provoquen inundaciones repentinas y corrimientos de escombros que pueden poner en peligro la vida en los desiertos, así como deslizamientos de tierra en las zonas montañosas.
Ataque en Midsomer Norton: cuatro detenciones por intento de asesinato
Tres adolescentes y un joven de 20 años han sido detenidos como sospechosos de intento de asesinato tras hallarse a un joven de 16 años con heridas de arma blanca en Somerset.
El adolescente fue hallado herido en la zona de Excelsior Terrace, en Midsomer Norton, alrededor de las 04:00 BST del sábado.
Lo llevaron al hospital, donde permanece en estado «estable».
Según la Policía de Avon y Somerset, un joven de 17 años, dos de 18 y un hombre de 20 fueron detenidos durante la noche en la zona de Radstock.
La policía ha pedido a cualquier persona que tenga grabaciones de lo ocurrido en su teléfono móvil que se ponga en contacto con ellos.
Trump afirma que Kavanaugh «sufrió la maldad y la ira» del Partido Demócrata
«Un voto a favor del juez Kavanaugh es un voto para rechazar las tácticas despiadadas e indignantes del Partido Demócrata», afirmó Trump en un mitin celebrado en Wheeling, Virginia Occidental.
Trump afirmó que Kavanaugh ha «sufrido la maldad y la ira» del Partido Demócrata a lo largo de todo el proceso de su nominación.
Kavanaugh declaró ante el Congreso el jueves, negando con firmeza y emoción la acusación de Christine Blasey Ford de que él la había agredido sexualmente hace décadas, cuando ambos eran adolescentes.
Ford también declaró en la vista sobre su denuncia.
El presidente afirmó el sábado que «el pueblo estadounidense pudo apreciar la brillantez, la calidad y el valor» de Kavanaugh ese día.
«Un voto a favor de la confirmación del juez Kavanaugh es un voto a favor de la confirmación de una de las mentes jurídicas más destacadas de nuestro tiempo, un jurista con una trayectoria intachable al servicio público», declaró ante la multitud de simpatizantes de Virginia Occidental.
El presidente aludió indirectamente al nombramiento de Kavanaugh mientras hablaba de la importancia de la participación de los republicanos en las elecciones de mitad de legislatura.
«Faltan cinco semanas para una de las elecciones más importantes de nuestras vidas.
«No estoy corriendo, pero en realidad sí que estoy corriendo», dijo.
«Por eso voy de un lado para otro luchando por conseguir buenos candidatos».
Trump afirmó que los demócratas tienen como objetivo «resistirse y obstaculizar».
Según ha informado a la CNN un alto cargo del Partido Republicano, se espera que la primera votación de procedimiento clave sobre la nominación de Kavanaugh en el pleno del Senado tenga lugar a más tardar el viernes.
Cientos de muertos por el terremoto y el tsunami en Indonesia; se prevé que el número de víctimas aumente
Al menos 384 personas perdieron la vida, muchas de ellas arrastradas por las olas gigantes que se estrellaron contra las playas, cuando un fuerte terremoto y un tsunami azotaron la isla indonesia de Sulawesi, según informaron las autoridades el sábado.
El viernes, cientos de personas se habían reunido para celebrar un festival en la playa de la ciudad de Palu cuando, al anochecer, olas de hasta seis metros de altura rompieron en la costa, arrastrando a muchas personas hacia una muerte segura y arrasando con todo a su paso.
El tsunami se produjo tras un terremoto de magnitud 7,5.
«Cuando ayer surgió la amenaza de un tsunami, la gente seguía realizando sus actividades en la playa y no huyó de inmediato, por lo que acabaron siendo víctimas», declaró Sutopo Purwo Nugroho, portavoz de la Agencia Nacional de Gestión de Desastres de Indonesia (BNPB), en una rueda de prensa celebrada en Yakarta.
«El tsunami no llegó solo, arrastró coches, troncos y casas, y arrasó con todo lo que encontró en tierra», afirmó Nugroho, quien añadió que el tsunami había recorrido el mar abierto a una velocidad de 800 km/h (497 mph) antes de alcanzar la costa.
«Algunas personas se subieron a los árboles para escapar del tsunami y sobrevivieron», dijo.
Unas 16 700 personas fueron evacuadas a 24 centros de Palu.
Las fotografías aéreas difundidas por la agencia de gestión de catástrofes mostraban numerosos edificios y comercios destruidos, puentes retorcidos y derrumbados, y una mezquita rodeada de agua.
Las réplicas siguieron sacudiendo la ciudad costera el sábado.
La serie de terremotos se sintió en una zona donde viven 2,4 millones de personas.
La Agencia de Evaluación y Aplicación de Tecnología de Indonesia (BPPT) afirmó en un comunicado que la energía liberada por el potente terremoto del viernes fue aproximadamente 200 veces superior a la potencia de la bomba atómica lanzada sobre Hiroshima durante la Segunda Guerra Mundial.
Según el informe, la configuración geográfica de la ciudad, situada al final de una bahía larga y estrecha, podría haber amplificado la magnitud del tsunami.
Nugroho calificó los daños de «extensos» y señaló que se habían derrumbado miles de viviendas, hospitales, centros comerciales y hoteles.
Según él, se encontraron los cuerpos de algunas víctimas atrapados bajo los escombros de los edificios derrumbados, y añadió que había 540 heridos y 29 desaparecidos.
Nugroho señaló que el número de víctimas y los daños podrían ser mayores a lo largo de la costa situada a 300 km (190 millas) al norte de Palu, en una zona llamada Donggala, más cercana al epicentro del terremoto.
«Las comunicaciones estaban totalmente colapsadas y no había información» procedente de Donggala, afirmó Nugroho.
«Hay más de 300 000 personas viviendo allí», afirmó la Cruz Roja en un comunicado, y añadió que su personal y sus voluntarios se dirigían a las zonas afectadas.
«Esto ya es una tragedia, pero podría empeorar mucho más», señaló.
El sábado, la agencia fue objeto de numerosas críticas por no informar de que un tsunami había azotado Palu, aunque las autoridades afirmaron que las olas habían llegado en el plazo en que se emitió la alerta.
En un vídeo amateur compartido en las redes sociales se oye a un hombre que se encuentra en la planta superior de un edificio gritando frenéticamente a la gente que está en la calle para advertirles de la llegada del tsunami.
En cuestión de minutos, un muro de agua se abalanza sobre la costa, arrastrando edificios y coches.
Reuters no pudo verificar de inmediato la autenticidad de las imágenes.
El terremoto y el tsunami provocaron un gran corte de electricidad que interrumpió las comunicaciones en los alrededores de Palu, lo que dificultó a las autoridades la coordinación de las labores de rescate.
Según las autoridades, el ejército ha comenzado a enviar aviones de carga con ayuda desde Yakarta y otras ciudades, pero los evacuados siguen necesitando urgentemente alimentos y otros productos de primera necesidad.
El aeropuerto de la ciudad se ha reabierto únicamente para las labores de socorro y permanecerá cerrado hasta octubre.
El presidente Joko Widodo tenía previsto visitar los centros de evacuación de Palu el domingo.
El número de víctimas del tsunami en Indonesia supera ya las 800.
Es muy malo.
Según explicó el Sr. Doseba, aunque el personal de World Vision de Donggala ha llegado sano y salvo a la ciudad de Palu, donde los empleados se han refugiado en tiendas de lona instaladas en el patio de su oficina, durante el trayecto se encontraron con escenas de devastación.
«Me dijeron que habían visto muchas casas destruidas», dijo.
Es muy malo.
A pesar de que las organizaciones humanitarias ya habían iniciado los sombríos preparativos para poner en marcha las operaciones de socorro, algunos se quejaban de que se estaba impidiendo a los cooperantes extranjeros con amplia experiencia viajar a Palu.
Según la normativa indonesia, la financiación, los suministros y el personal procedentes del extranjero solo pueden empezar a llegar si el lugar donde se ha producido la catástrofe se declara zona de desastre nacional.
Eso aún no ha sucedido.
«Sigue siendo una catástrofe a escala provincial», afirmó Aulia Arriani, portavoz de la Cruz Roja Indonesia.
«En cuanto el Gobierno declare: "De acuerdo, se trata de una catástrofe nacional", podremos solicitar ayuda internacional, pero por ahora aún no hay nada oficial».
Al caer la segunda noche en Palu tras el terremoto y el tsunami del viernes, los amigos y familiares de los que seguían desaparecidos mantenían la esperanza de que sus seres queridos fueran esos milagros que salpican de esperanza las sombrías historias de las catástrofes naturales.
El sábado rescataron a un niño pequeño de una alcantarilla.
El domingo, los equipos de rescate rescataron a una mujer que llevaba dos días atrapada bajo los escombros, con el cadáver de su madre a su lado.
Gendon Subandono, el entrenador del equipo nacional indonesio de parapente, había entrenado a dos de los parapentistas desaparecidos para los Juegos Asiáticos, que concluyeron a principios de este mes en Indonesia.
Entre las demás personas que quedaron atrapadas en el Hotel Roa Roa, incluido el Sr. Mandagi, se encontraban sus alumnos.
«Como veterano en el mundo del parapente, tengo mi propia carga emocional», afirmó.
El Sr. Gendon relató cómo, en las horas posteriores a que se difundiera entre la comunidad de parapentistas la noticia del derrumbe del Hotel Roa Roa, había enviado mensajes desesperados por WhatsApp a los participantes de Palu, que estaban tomando parte en el festival de la playa.
Sin embargo, sus mensajes solo recibieron una marca de verificación gris, en lugar de dos marcas azules.
«Creo que eso significa que los mensajes no se enviaron», dijo.
Unos ladrones se llevan 26 750 dólares mientras se recarga un cajero automático en Newport on the Levee
Según un comunicado de prensa del Departamento de Policía de Newport, el viernes por la mañana unos ladrones robaron 26 750 dólares a un empleado de Brink's que estaba recargando un cajero automático en Newport on the Levee.
El conductor del coche había estado vaciando un cajero automático en el complejo de ocio y se disponía a llevar más dinero, según el detective. Dennis McCarthy escribió en el comunicado.
Mientras él estaba ocupado, otro hombre «se abalanzó por detrás del empleado de Brink's» y robó una bolsa con dinero que estaba destinada a ser entregada.
Según el comunicado, varios testigos vieron a varios sospechosos huyendo del lugar, pero la policía no ha precisado cuántas personas estuvieron implicadas en el incidente.
Cualquier persona que tenga información sobre su identidad debe ponerse en contacto con la policía de Newport llamando al 859-292-3680.
Kanye West: el rapero cambia su nombre por el de Ye
El rapero Kanye West va a cambiarse el nombre: ahora se llamará Ye.
Al anunciar el cambio en Twitter el sábado, escribió: «El ser anteriormente conocido como Kanye West».
West, de 41 años, lleva tiempo siendo conocido como Ye y utilizó ese apodo como título de su octavo álbum, que salió a la venta en junio.
El cambio se produce antes de su aparición en Saturday Night Live, donde se espera que presente su nuevo álbum, *Yandhi*.
Sustituye a la cantante Ariana Grande en el programa, quien canceló su participación por «motivos emocionales», según ha declarado el creador del programa.
Además de ser la abreviatura de su nombre artístico actual, West ha declarado en otras ocasiones que esa palabra tiene un significado religioso para él.
«Creo que "ye" es la palabra más utilizada en la Biblia, y en la Biblia significa "tú"», afirmó West a principios de este año, al hablar del título de su álbum con el locutor de radio Big Boy.
«Así que soy tú, soy nosotros, somos nosotros.
Pasó de ser Kanye, que significa «el único», a simplemente Ye: un reflejo de lo bueno, lo malo, lo confuso... de todo.
«El álbum es más bien un reflejo de quiénes somos».
Es uno de los muchos raperos famosos que se han cambiado el nombre.
A Sean Combs se le ha conocido por diversos nombres, como Puff Daddy, P. Diddy o Diddy, pero este año ha anunciado que prefiere los nombres Love y Brother Love.
JAY-Z, un antiguo colaborador de West, también se ha lascado con o sin guion y mayúsculas.
AMLO, de México, se compromete a no utilizar al ejército contra la población civil
El presidente electo de México, Andrés Manuel López Obrador, se ha comprometido a no recurrir nunca a la fuerza militar contra la población civil, ahora que el país se acerca al 50.º aniversario de una sangrienta represalia contra los estudiantes.
López Obrador prometió el sábado en la plaza de Tlatelolco que «nunca jamás utilizaría al ejército para reprimir al pueblo mexicano».
El 2 de octubre de 1968, las tropas abrieron fuego contra una manifestación pacífica en la plaza, causando la muerte de hasta 300 personas, en un momento en que los movimientos estudiantiles de izquierda estaban cobrando fuerza en toda América Latina.
López Obrador se ha comprometido a apoyar a los jóvenes mexicanos concediendo ayudas mensuales a quienes estudian y creando más universidades públicas gratuitas.
Ha afirmado que el desempleo y la falta de oportunidades educativas empujan a los jóvenes hacia las bandas criminales.
Estados Unidos debería duplicar la financiación destinada a la inteligencia artificial
A medida que China se vuelve más activa en el ámbito de la inteligencia artificial, Estados Unidos debería duplicar la inversión que destina a la investigación en este campo, afirma el inversor y experto en IA Kai-Fu Lee, quien ha trabajado para Google, Microsoft y Apple.
Estas declaraciones se producen después de que diversos organismos del Gobierno de Estados Unidos hayan hecho anuncios relacionados con la inteligencia artificial, a pesar de que el país carece en general de una estrategia oficial en materia de inteligencia artificial.
Por su parte, China presentó su plan el año pasado: su objetivo es convertirse en el número uno en innovación en inteligencia artificial para 2030.
«Duplicar el presupuesto destinado a la investigación en IA sería un buen comienzo, teniendo en cuenta que todos los demás países están muy por detrás de Estados Unidos y que estamos buscando el próximo avance decisivo en IA», afirmó Lee.
«Duplicar la financiación podría duplicar las posibilidades de que el próximo gran avance en IA se produzca en Estados Unidos», declaró Lee a la CNBC en una entrevista esta semana.
Lee, cuyo libro «AI Superpowers: China, Silicon Valley and the New World Order» ha sido publicado este mes por Houghton Mifflin Harcourt, es director ejecutivo de Sinovation Ventures, empresa que ha invertido en una de las compañías de inteligencia artificial más destacadas de China, Face++.
En la década de 1980, en la Universidad Carnegie Mellon, trabajó en un sistema de inteligencia artificial que venció al mejor jugador estadounidense de Othello; posteriormente, fue directivo en Microsoft Research y presidente de la filial de Google en China.
Lee se refirió a anteriores concursos tecnológicos del Gobierno de EE. UU., como el Robotics Challenge de la Agencia de Proyectos de Investigación Avanzada de Defensa (DARPA), y preguntó cuándo se celebraría el próximo, con el fin de ayudar a identificar a los próximos visionarios.
«Los investigadores de Estados Unidos suelen tener que esforzarse mucho para conseguir subvenciones del Gobierno», afirmó Lee.
«No es China quien se lleva a los líderes académicos, sino las empresas», afirmó Lee.
En los últimos años, Facebook, Google y otras empresas tecnológicas han contratado a destacados académicos de diversas universidades para trabajar en el campo de la inteligencia artificial.
Lee afirmó que los cambios en la política de inmigración también podrían ayudar a Estados Unidos a reforzar sus iniciativas en materia de inteligencia artificial.
«Creo que se debería conceder automáticamente la tarjeta de residencia a los doctores en inteligencia artificial», afirmó.
El Consejo de Estado de China publicó su «Plan de desarrollo de la inteligencia artificial de próxima generación» en julio de 2017.
La Fundación Nacional de Ciencias Naturales de China concede ayudas económicas a personas de instituciones académicas de forma similar a como la Fundación Nacional de Ciencias y otras organizaciones gubernamentales conceden ayudas a los investigadores estadounidenses, «Pero la calidad del trabajo académico es menor en China», afirmó Lee.
A principios de este año, el Departamento de Defensa de Estados Unidos creó un Centro Conjunto de Inteligencia Artificial, cuyo objetivo es contar con la participación de socios del sector empresarial y el mundo académico, y la Casa Blanca anunció la creación de una Comisión Especial sobre Inteligencia Artificial.
Y este mes, la DARPA ha anunciado una inversión de 2000 millones de dólares en una iniciativa denominada «AI Next».
En cuanto a la NSF, actualmente invierte más de 100 millones de dólares al año en investigación sobre inteligencia artificial.
Mientras tanto, la legislación estadounidense destinada a crear una Comisión de Seguridad Nacional sobre Inteligencia Artificial lleva meses sin avanzar.
Los macedonios votan en un referéndum sobre si cambiar el nombre del país
Los ciudadanos de Macedonia votaron el domingo en un referéndum sobre si cambiar su nombre por el de «República de Macedonia del Norte», una medida que resolvería una disputa de décadas con Grecia, la cual había bloqueado sus solicitudes de adhesión a la Unión Europea y a la OTAN.
Grecia, que cuenta con una provincia llamada Macedonia, sostiene que el nombre de su vecino del norte supone una reivindicación sobre su territorio y ha vetado su adhesión a la OTAN y a la UE.
Los dos gobiernos llegaron a un acuerdo en junio basado en el nuevo nombre propuesto, pero los opositores nacionalistas sostienen que el cambio socavaría la identidad étnica de la población mayoritaria eslava de Macedonia.
El presidente Gjorge Ivanov ha declarado que no votará en el referéndum, y una campaña de boicot ha sembrado dudas sobre si la participación alcanzará el mínimo del 50 % necesario para que el referéndum sea válido.
La pregunta que figuraba en la papeleta del referéndum era la siguiente: «¿Está usted a favor de la adhesión a la OTAN y a la UE, aceptando el acuerdo con Grecia?».
Los partidarios del cambio de nombre, entre ellos el primer ministro Zoran Zaev, sostienen que es un precio que vale la pena pagar para que Macedonia —uno de los países surgidos tras el desintegración de Yugoslavia— pueda aspirar a su adhesión a organismos como la UE y la OTAN.
«Hoy he venido a votar por el futuro del país, por los jóvenes de Macedonia, para que puedan vivir libremente bajo el amparo de la Unión Europea, porque eso significa una vida más segura para todos nosotros», declaró Olivera Georgijevska, de 79 años, en Skopje.
Aunque no es jurídicamente vinculante, un número suficiente de diputados ha manifestado que acatará el resultado de la votación, lo que la convierte en decisiva.
El cambio de nombre requeriría una mayoría de dos tercios en el Parlamento.
La comisión electoral estatal informó de que, a la 1 de la tarde, no se había recibido ninguna denuncia de irregularidades.
Sin embargo, la participación se situó en solo el 16 %, frente al 34 % de las últimas elecciones parlamentarias de 2016, en las que votó el 66 % de los electores inscritos.
«He salido a votar por mis hijos; nuestro lugar está en Europa», afirmó Gjose Tanevski, de 62 años, un votante de la capital, Skopje.
El primer ministro de Macedonia, Zoran Zaev, su esposa Zorica y su hijo Dushko votaron en el referéndum celebrado en Macedonia sobre el cambio de nombre del país, que allanaría el camino para su adhesión a la OTAN y a la Unión Europea, en Strumica (Macedonia), el 30 de septiembre de 2018.
Frente al Parlamento de Skopje, Vladimir Kavardarkov, de 54 años, estaba montando un pequeño escenario y colocando sillas delante de las tiendas de campaña instaladas por quienes boicotearán el referéndum.
«Estamos a favor de la OTAN y de la UE, pero queremos incorporarnos con la cabeza alta, no por la puerta de servicio», afirmó Kavadarkov.
«Somos un país pobre, pero tenemos dignidad.
«Si no quieren aceptarnos como Macedonia, podemos recurrir a otros países, como China y Rusia, y formar parte de la integración euroasiática».
El primer ministro Zaev afirma que la adhesión a la OTAN aportará a Macedonia unas inversiones muy necesarias, ya que el país tiene una tasa de desempleo superior al 20 %.
«Creo que la gran mayoría votará a favor, ya que más del 80 % de nuestros ciudadanos están a favor de la UE y la OTAN», declaró Zaev tras emitir su voto.
Dijo que un resultado favorable sería «la confirmación de nuestro futuro».
Una encuesta publicada el lunes pasado por el Instituto de Investigación Política de Macedonia reveló que entre el 30 % y el 43 % de los votantes participaría en el referéndum, por debajo del umbral de participación requerido.
Otra encuesta, realizada por la cadena macedonia Telma TV, reveló que el 57 % de los encuestados tenía previsto votar el domingo.
De ellos, el 70 % afirmó que votaría a favor.
Para que el referéndum sea válido, la participación debe ser del 50 % más un voto.
Un fracaso en el referéndum supondría el primer golpe grave a la política del Gobierno prooccidental desde que asumió el poder en mayo del año pasado.
Vídeo: Sergio Agüero, del Manchester City, se abre paso entre toda la defensa del Brighton para marcar un gol
Sergio Agüero y Raheem Sterling desarmaron a la defensa del Brighton en la victoria por 2-0 del Manchester City el sábado en el Etihad Stadium de Mánchester, Inglaterra.
Agüero hizo que su gol en el minuto 65 pareciera ridículamente fácil.
El delantero argentino recibió un pase en el centro del campo al inicio de la jugada.
Se abrió paso entre tres defensas del Brighton antes de lanzarse hacia el campo abierto.
Entonces, Agüero se vio rodeado por cuatro camisetas verdes.
Se deshizo de un defensa antes de dejar atrás a varios más en el borde del área del Brighton.
A continuación, lanzó un pase hacia su izquierda y se lo pasó a Sterling.
El delantero inglés aprovechó su primer toque dentro del área para pasarle el balón a Agüero, quien, con la pierna derecha, batió al portero del Brighton, Mathew Ryan, con un disparo que se coló por el lado derecho de la portería.
«Agüero está teniendo algunos problemas en los pies», declaró a los periodistas el entrenador del City, Pep Guardiola.
«Hablamos de que jugara entre 55 y 60 minutos.
Eso es lo que pasó.
«Tuvimos suerte de que marcara un gol en ese momento».
Pero fue Sterling quien dio a los Sky Blues la ventaja inicial en el enfrentamiento de la Premier League.
Ese gol se marcó en el minuto 29.
En esa jugada, Agüero recibió el balón en el campo del Brighton.
Le envió un precioso pase en profundidad por la banda izquierda a Leroy Sané.
Sane controló el balón un par de veces antes de habilitar a Sterling hacia el segundo palo.
El delantero de los Sky Blues empujó el balón al fondo de la red justo antes de salir deslizándose fuera del terreno de juego.
El City se enfrentará al Hoffenheim en la fase de grupos de la Liga de Campeones el martes a las 12:55 p. m. en el Rhein-Neckar-Arena de Sinsheim, Alemania.
Scherzer quiere dar la sorpresa ante los Rockies
Dado que los Nationals ya no tenían opciones de clasificarse para los playoffs, no había muchos motivos para forzar otra salida como titular.
Sin embargo, Scherzer, siempre competitivo, espera subir al montículo el domingo contra los Colorado Rockies, pero solo si el partido sigue siendo decisivo para los Rockies, que aventajan en un partido a los Los Angeles Dodgers en la División Oeste de la Liga Nacional.
Los Rockies se aseguraron al menos una plaza de comodín tras imponerse por 5-2 a los Nationals el viernes por la noche, pero aún aspiran a hacerse con su primer título de división.
«Aunque no nos juegue nada, al menos podremos saltar al campo sabiendo que el ambiente aquí en Denver, con el público y el otro equipo, será probablemente el más intenso de todos los partidos a los que me enfrente este año».
«¿Por qué no iba a querer participar en eso?»
Los Nationals aún no han anunciado quién será el lanzador titular para el domingo, pero, según se informa, se inclinan por dejar que Scherzer lance en esa situación.
Scherzer, que disputaría su 34.ª apertura, realizó una sesión de lanzamiento en el bullpen el jueves y lanzaría el domingo tras su descanso habitual.
El lanzador diestro de Washington tiene un balance de 18 victorias y 7 derrotas, con una efectividad de 2,53 y 300 ponches en 220 2/3 entradas esta temporada.
Trump celebra mítines en Virginia Occidental
El presidente aludió indirectamente a la situación en torno a su candidato al Tribunal Supremo, Brett Kavanaugh, mientras hablaba de la importancia de la participación republicana en las elecciones de mitad de legislatura.
«Todo lo que hemos hecho está en juego en noviembre».
Faltan cinco semanas para una de las elecciones más importantes de nuestra vida.
«Esta es una de las grandes, grandes... No me presento, pero en realidad sí que me presento; por eso estoy por todas partes luchando por unos candidatos estupendos», dijo.
Trump continuó diciendo: «Ya ves a ese horrible, horrible grupo radical de demócratas; lo estás viendo suceder en este mismo momento».
Y están decididos a recuperar el poder por cualquier medio necesario; ya ves la maldad, la crueldad.
«No les importa a quién hagan daño, a quién tengan que pisotear para conseguir poder y control; eso es lo que quieren, poder y control, y no se lo vamos a dar».
Según él, los demócratas tienen como misión «resistir y obstaculizar».
«Y eso se ha visto en los últimos cuatro días», dijo, calificando a los demócratas de «enfadados, mezquinos, desagradables y mentirosos».
Mencionó expresamente a la senadora demócrata Dianne Feinstein, vicepresidenta del Comité Judicial del Senado, lo que provocó fuertes abucheos por parte del público.
«¿Te acuerdas de su respuesta?
¿Fuiste tú quien filtró el documento?
Eh, eh, ¿qué?
«No, eh, no, un momento... Ese lenguaje corporal ha sido realmente malo... El peor lenguaje corporal que he visto nunca».
El Partido Laborista ya no es una formación tan heterogénea.
Es intolerante con quienes dicen lo que piensan
Cuando los activistas de Momentum de mi sección local votaron a favor de censurarme, no me sorprendió en absoluto.
Al fin y al cabo, soy el último de una serie de diputados laboristas a los que se nos ha dicho que no somos bienvenidos, y todo por decir lo que pensamos.
Mi compañera parlamentaria Joan Ryan recibió un trato similar por haberse enfrentado con firmeza al antisemitismo.
En mi caso, la moción de censura me reprochaba que no estuviera de acuerdo con Jeremy Corbyn.
Sobre la importancia de una política económica responsable, sobre la seguridad nacional, sobre Europa; irónicamente, temas similares en los que Jeremy discrepaba de los líderes anteriores.
En la convocatoria de la reunión del Partido Laborista de Nottingham Este del viernes se indicaba que «queremos que las reuniones sean inclusivas y productivas».
Durante la mayor parte de mis ocho años como diputado laborista por esta circunscripción, las reuniones del comité general de los viernes por la noche han sido exactamente eso.
Lamentablemente, hoy en día ese no es el tono que impera en muchas reuniones, y la promesa de una política «más amable y cordial» hace tiempo que ha caído en el olvido, si es que alguna vez llegó a existir.
Cada vez es más evidente que en el Partido Laborista no se toleran las opiniones divergentes y que todas las opiniones se juzgan en función de si son aceptables para la dirección del partido.
Esto empezó poco después de que Jeremy se convirtiera en líder, a medida que compañeros con los que antes creía compartir una visión política similar empezaron a esperar que diera un giro de 180 grados y adoptara posturas con las que, de otro modo, nunca habría estado de acuerdo, ya fuera en materia de seguridad nacional o del mercado único de la UE.
Cada vez que hablo en público —y da igual lo que diga—, se desata una avalancha de insultos en las redes sociales en la que se pide mi destitución, se critica la política de centro y se me dice que no debería estar en el Partido Laborista.
Y eso no es solo mi experiencia.
De hecho, sé que soy más afortunado que algunos de mis colegas, ya que los comentarios que me dirigen suelen ser de carácter político.
Me impresiona la profesionalidad y la determinación de aquellos compañeros que se enfrentan cada día a una avalancha de insultos sexistas o racistas, pero que nunca se echan atrás.
Uno de los aspectos más decepcionantes de la política actual es cómo se ha normalizado el abuso.
Jeremy Corbyn afirmó la semana pasada que el Partido Laborista debería fomentar una cultura de tolerancia.
La realidad es que ya no somos ese partido tan inclusivo y, con cada moción de censura o cada cambio en las normas de selección, el partido se va reduciendo.
En los últimos dos años he recibido muchos consejos que me instaban a mantener un perfil bajo, a no dar tanto que hablar, y que así «todo iría bien».
Pero eso no es para lo que me metí en política.
Desde que me afilié al Partido Laborista hace 32 años, cuando aún era estudiante, Motivado por la negligencia del Gobierno de Thatcher, que había dejado mi aula del instituto público literalmente en ruinas, he tratado de defender unos mejores servicios públicos para quienes más los necesitan, ya sea como concejal o como ministro del Gobierno.
Nunca he ocultado mis ideas políticas, ni siquiera en las últimas elecciones.
Nadie en Nottingham Este podía tener la menor duda sobre mis posturas políticas y los puntos en los que discrepo de la dirección actual.
A quienes presentaron la moción el viernes, Lo único que diría es que, cuando el país se encamina hacia un Brexit que perjudicará a los hogares, a las empresas y a nuestros servicios públicos, no entiendo por qué se quiere perder tiempo y energía en cuestionar mi lealtad hacia el líder del Partido Laborista.
Pero, en realidad, el mensaje que quiero transmitir no va dirigido a Nottingham Momentum, sino a mis electores, sean o no miembros del Partido Laborista: Me enorgullece estar a su servicio y les prometo que ni las amenazas de destitución ni el oportunismo político me disuadirán de actuar en lo que considero el mejor interés de todos ustedes.
Chris Leslie es diputado por Nottingham Este
Ayr 38 - 17 Melrose: El Ayr, invicto, se coloca líder
Puede que dos ensayos en los últimos minutos hayan sesgado un poco el resultado final, pero no hay duda de que el Ayr mereció la victoria en este partido de la Tennent's Premiership, que ha sido de lo más entretenido.
Ahora lideran la clasificación y son el único equipo invicto de los diez.
Al final, fue su defensa superior, tanto como su mayor acierto a la hora de materializar las ocasiones, lo que dio la victoria al equipo local, y el entrenador Peter Murchie tenía todo el derecho a estar satisfecho.
«Nos han puesto a prueba en los partidos que hemos disputado hasta ahora y seguimos invictos, así que no puedo sino estar contento», afirmó.
Robyn Christie, de Melrose, dijo: «Hay que reconocer el mérito del Ayr, aprovecharon sus oportunidades mejor que nosotros».
El ensayo de Grant Anderson en el minuto 14, transformado por Frazier Climo, puso al Ayr por delante, pero una tarjeta amarilla para el internacional escocés Rory Hughes, cedido para este partido por los Warriors, permitió al Melrose aprovechar su superioridad numérica y Jason Baggot anotó un ensayo sin transformar.
Climo amplió la ventaja del Ayr con un tiro de castigo y, justo antes del descanso, anotó y transformó un ensayo en solitario, dejando el marcador en 17-5 a favor del Ayr al llegar al descanso.
Pero Melrose comenzó bien la segunda parte y el ensayo de Patrick Anderson, transformado por Baggot, redujo la diferencia a cinco puntos.
A continuación, se produjo una larga interrupción debido a una lesión grave de Ruaridh Knott, que tuvo que ser retirado en camilla, y, tras la reanudación, el Ayr amplió su ventaja con un ensayo de Stafford McDowall, transformado por Climo.
A continuación, el capitán interino del Ayr, Blair Macpherson, recibió una tarjeta amarilla y, una vez más, el Melrose aprovechó la superioridad numérica para anotar un ensayo de Bruce Colvine, que no se transformó, al término de una fase de intensa presión.
Sin embargo, el equipo local remontó y, cuando Struan Hutchinson recibió una tarjeta amarilla por placar a Climo sin que hubiera el balón, a raíz del saque de banda desde la línea de penalti, MacPherson anotó un ensayo al final del maul de Ayr que avanzaba.
Climo anotó, como volvió a hacer casi nada más reanudarse el juego, después de que Kyle Rowe recogiera un puntapié de David Armstrong y habilitara al flanker Gregor Henry para que marcara el quinto ensayo del equipo local.
La estrella de «Still Game» parece dispuesta a emprender una nueva carrera en el sector de la restauración
Ford Kieran, protagonista de «Still Game», parece dispuesto a dar el salto al sector de la hostelería tras conocerse que ha sido nombrado director de una empresa de restaurantes con licencia para servir alcohol.
Este actor de 56 años interpreta a Jack Jarvis en la popular serie de la BBC, de la que es guionista y en la que comparte protagonismo con su compañero de comedia de toda la vida, Greg Hemphill.
El dúo ha anunciado que la próxima novena temporada será la última de la serie, y parece que Kiernan está haciendo planes para su vida después de Craiglang.
Según los registros oficiales, es el director de Adriftmorn Limited.
El actor se negó a hacer comentarios sobre la noticia, aunque una fuente del Scottish Sun insinuó que Kiernan tenía intención de entrar en el «floreciente sector de la restauración» de Glasgow.
«El mar es nuestro»: Bolivia, país sin litoral, espera que el tribunal reabra el camino hacia el Pacífico
Unos marineros patrullan un cuartel general naval rodeado de mástiles en La Paz.
Los edificios públicos enarbolan una bandera azul océano.
Las bases navales, desde el lago Titicaca hasta el Amazonas, lucen el lema: «El mar nos pertenece por derecho».
«Recuperarlo es un deber».
En toda Bolivia, país sin litoral, el recuerdo de una costa perdida a manos de Chile en un sangriento conflicto por los recursos del siglo XIX sigue vivo, al igual que el anhelo de navegar de nuevo por el océano Pacífico.
Es posible que esas esperanzas estén en su punto más alto en décadas, ya que Bolivia espera el fallo de la Corte Internacional de Justicia el 1 de octubre, tras cinco años de deliberaciones.
«Bolivia tiene el impulso necesario, un espíritu de unidad y serenidad, y, por supuesto, espera con optimismo el resultado», afirmó Roberto Calzadilla, diplomático boliviano.
Muchos bolivianos seguirán el fallo de la Corte Internacional de Justicia en pantallas gigantes repartidas por todo el país, con la esperanza de que el tribunal de La Haya falle a favor de la reclamación de Bolivia de que —tras décadas de negociaciones intermitentes— Chile está obligado a negociar la concesión a Bolivia de una salida soberana al mar.
Evo Morales, el carismático presidente indígena de Bolivia —que se enfrenta a una controvertida campaña para su reelección el año que viene— también se juega mucho con la sentencia del lunes.
«Estamos muy cerca de volver al océano Pacífico», prometió a finales de agosto.
Sin embargo, algunos analistas consideran poco probable que el tribunal falle a favor de Bolivia, y que, aunque lo hiciera, poco cambiaría.
El organismo de las Naciones Unidas con sede en los Países Bajos no tiene competencia para adjudicar territorio chileno y ha dejado claro que no determinará el resultado de unas posibles negociaciones.
El hecho de que el fallo de la CIJ se haya dictado tan solo seis meses después de que se escucharan los alegatos finales indica que el caso «no era complicado», afirmó Paz Zárate, experta chilena en Derecho internacional.
Y, lejos de impulsar la causa de Bolivia, es posible que los últimos cuatro años la hayan hecho retroceder.
«La cuestión del acceso al mar ha sido secuestrada por el actual Gobierno boliviano», afirmó Zárate.
Según ella, la retórica beligerante de Morales ha minado cualquier atisbo de buena voluntad que aún quedara por parte de Chile.
Bolivia y Chile volverán a dialogar en algún momento, pero será muy difícil mantener conversaciones a partir de ahora.
Los dos países no han intercambiado embajadores desde 1962.
El expresidente Eduardo Rodríguez Veltzé, representante de Bolivia en La Haya, rechazó la idea de que la toma de decisiones del tribunal hubiera sido inusualmente rápida.
«El lunes brindará a Bolivia “una oportunidad extraordinaria para iniciar una nueva era en las relaciones con Chile” y la posibilidad de “poner fin a 139 años de desacuerdos, en beneficio de ambas partes”», afirmó.
Calzadilla también negó que Morales —que sigue siendo uno de los presidentes más populares de América Latina— estuviera utilizando la cuestión marítima como pretexto político.
«Bolivia nunca renunciará a su derecho a tener salida al océano Pacífico», añadió.
«Esta sentencia es una oportunidad para darnos cuenta de que debemos superar el pasado».
Corea del Norte afirma que el desarme nuclear no será posible a menos que pueda confiar en Estados Unidos
El ministro de Asuntos Exteriores de Corea del Norte, Ri Yong Ho, afirma que su país nunca desarmará primero su arsenal nuclear si no puede confiar en Washington.
Ri intervino el sábado ante la Asamblea General de las Naciones Unidas.
Instó a Estados Unidos a que cumpliera las promesas realizadas durante la cumbre celebrada en Singapur entre los líderes de ambos países.
Sus comentarios se producen en un momento en que EE. UU. El secretario de Estado Mike Pompeo parece estar a punto de reactivar las negociaciones nucleares, que se encontraban en un punto muerto, más de tres meses después de la cumbre de Singapur con Kim Jong Un, de Corea del Norte.
Ri afirma que es una «quimera» pensar que la prolongación de las sanciones y la oposición de Estados Unidos a una declaración que ponga fin a la Guerra de Corea vayan a doblegar alguna vez a Corea del Norte.
Washington se muestra reacio a aceptar la declaración sin que Pyongyang haya dado primero pasos significativos hacia el desarme.
Tanto Kim como el presidente de Estados Unidos, Donald Trump, quieren celebrar una segunda cumbre.
Sin embargo, existe un escepticismo generalizado respecto a que Pyongyang se tome en serio la renuncia a un arsenal que el país probablemente considera la única forma de garantizar su seguridad.
Pompeo tiene previsto visitar Pyongyang el mes que viene para preparar una segunda cumbre entre Kim y Trump.
Los desfiles de moda de París presentan la última colección de sombreros de gran tamaño, que pronto llegará a las tiendas de tu ciudad
Si quieres ampliar tu colección de sombreros o protegerte completamente del sol, no busques más.
Los diseñadores Valentino y Thom Browne presentaron en la pasarela una serie de extravagantes tocados de gran tamaño para su colección Primavera-Verano 2019, que cautivaron al público de la Semana de la Moda de París.
Este verano, los sombreros de lo más extravagantes han arrasado en Instagram, y estos diseñadores han lucido sus llamativas creaciones en la pasarela.
La pieza más destacada de Valentino fue un extravagante sombrero beige adornado con un ala ancha que parecía una pluma y que cubría por completo la cabeza de las modelos.
Entre otros accesorios de gran tamaño había sandías con pedrería, un sombrero de mago e incluso una piña, pero no están pensados para abrigarte la cabeza.
Thom Browne también presentó una selección de máscaras extravagantes, justo a tiempo para Halloween.
Muchas de las coloridas máscaras tenían los labios cosidos y se parecían más a Hannibal Lecter que a la alta costura.
Una de las creaciones se parecía a un equipo de buceo, con tubo y gafas incluidas, mientras que otra parecía un cono de helado derretido.
Y si quieres seguir marcando tendencia, estás de suerte.
Los expertos en moda pronostican que esos enormes sombreros podrían llegar pronto a las tiendas de tu ciudad.
Estos sombreros de gran tamaño llegan justo después de «La Bomba», el sombrero de paja con una ala de medio metro de ancho que han lucido desde Rihanna hasta Emily Ratajkowski.
La marca de culto responsable del sombrero tan poco práctico que se hizo viral en las redes sociales presentó otra gran creación en la pasarela: un bolso de playa de paja casi tan grande como la modelo en bañador que lo llevaba.
El bolso de rafia en tono naranja quemado, adornado con flecos de rafia y rematado con un asa de cuero blanco, fue la pieza estrella de la colección «La Riviera» Primavera-Verano 2019 de Jacquemus en la Semana de la Moda de París.
El estilista de famosos Luke Armitage declaró a FEMAIL: «Espero que los sombreros grandes y los bolsos de playa lleguen a las tiendas el próximo verano; dado el enorme impacto que ha tenido el diseñador, sería difícil ignorar la demanda de estos accesorios de gran tamaño».
John Edward: Las competencias lingüísticas son esenciales para los ciudadanos del mundo
Los colegios privados de Escocia cuentan con un historial de excelencia académica, y esta tendencia ha continuado en 2018 con otra serie de excelentes resultados académicos, a lo que se suman los éxitos individuales y colectivos en el deporte, el arte, la música y otras iniciativas comunitarias.
Con más de 30 000 alumnos en toda Escocia, estos colegios, representados por el Consejo Escocés de Colegios Independientes (SCIS), se esfuerzan por ofrecer el mejor nivel de servicio a sus alumnos y a sus padres.
Los colegios privados tienen como objetivo preparar a sus alumnos para la educación superior, la carrera profesional que elijan y su papel como ciudadanos del mundo.
Como sector educativo capaz de diseñar y aplicar un plan de estudios escolar a medida, observamos que las lenguas modernas siguen siendo una asignatura muy popular y solicitada en los centros educativos.
Nelson Mandela dijo: «Si le hablas a un hombre en un idioma que entiende, eso le llega a la cabeza».
«Si le hablas en su propio idioma, le llegarás al corazón».
Esto nos recuerda claramente que no podemos limitarse a recurrir al inglés cuando queremos establecer relaciones y generar confianza con personas de otros países.
A juzgar por los resultados de los exámenes de este año, podemos observar que las lenguas ocupan los primeros puestos en las clasificaciones, con las tasas de aprobados más altas en los colegios privados.
El 68 % de los alumnos que cursaron lenguas extranjeras obtuvieron una calificación de «A» en el examen de nivel superior.
Los datos, recopilados entre las 74 escuelas miembros de la SCIS, revelaron que el 72 % de los alumnos obtuvieron una nota de «A» en el examen de nivel superior de chino, mientras que el 72 % de los que estudiaban alemán, el 69 % de los que estudiaban francés y el 63 % de los que estudiaban español también obtuvieron una «A».
Esto demuestra que los colegios privados de Escocia consideran que los idiomas extranjeros son competencias fundamentales que los niños y los jóvenes sin duda necesitarán en el futuro.
En la actualidad, las lenguas, como asignatura optativa, gozan de la misma consideración que las materias STEM (ciencias, tecnología, ingeniería y matemáticas) en los planes de estudios de los colegios privados y en otros centros educativos.
Una encuesta realizada en 2014 por la Comisión Británica para el Empleo y las Competencias reveló que, de entre las razones que alegaban los empleadores para explicar sus dificultades a la hora de cubrir las vacantes, el 17 % se atribuía a la falta de conocimientos lingüísticos.
Por lo tanto, cada vez es más imprescindible contar con competencias lingüísticas para preparar a los jóvenes para sus futuras carreras profesionales.
Dado que cada vez son más las oportunidades laborales que requieren conocimientos de idiomas, estas habilidades resultan esenciales en un mundo globalizado.
Independientemente de la carrera que elija cada uno, si ha aprendido un segundo idioma, contará con una ventaja real en el futuro al disponer de una competencia que le acompañará toda la vida.
El hecho de poder comunicarse directamente con personas de otros países situará automáticamente a una persona multilingüe por delante de la competencia.
Según una encuesta realizada por YouGov en 2013 a más de 4 000 adultos del Reino Unido, el 75 % no dominaba ningún idioma extranjero lo suficiente como para mantener una conversación, y el francés era el único idioma que hablaba un porcentaje de dos dígitos, concretamente el 15 %.
Por eso es importante invertir ahora en la enseñanza de idiomas para los niños de hoy.
El dominio de varios idiomas, especialmente los de las economías en desarrollo, ofrecerá a los niños mayores posibilidades de encontrar un empleo satisfactorio.
En Escocia, cada colegio imparte clases de idiomas diferentes.
Algunos centros se centrarán en las lenguas modernas más clásicas, mientras que otros impartirán las lenguas que se consideran más importantes para el Reino Unido de cara al año 2020, como el mandarín o el japonés.
Sean cuales sean los intereses de su hijo, en los colegios privados siempre habrá varios idiomas entre los que elegir, impartidos por profesores especializados en la materia.
Los colegios privados escoceses se dedican a ofrecer un entorno de aprendizaje que prepare a los niños y les dote de las habilidades necesarias para triunfar, sea cual sea el futuro que les depare.
En el contexto empresarial global actual, es innegable que los idiomas siguen siendo de vital importancia para el futuro del país, por lo que esto debe reflejarse en la educación.
De hecho, las lenguas modernas deberían considerarse realmente «competencias de comunicación internacional».
Los colegios privados seguirán ofreciendo esta variedad de opciones, diversidad y excelencia a los jóvenes de Escocia.
Hay que hacerlo bien.
John Edward es director del Consejo Escocés de Colegios Independientes
LeBron debutará con los Lakers el domingo en San Diego
La espera está a punto de terminar para los aficionados que esperan ver a LeBron James debutar como titular con los Lakers de Los Ángeles.
El entrenador de los Lakers, Luke Walton, ha anunciado que James jugará el primer partido de pretemporada del domingo contra los Denver Nuggets en San Diego.
Pero aún está por ver cuántos minutos jugará.
«Serán más de uno y menos de 48», declaró Walton en la página web oficial de los Lakers.
El periodista de los Lakers Mike Trudell ha publicado en Twitter que es probable que James juegue pocos minutos.
Tras el entrenamiento de principios de esta semana, se le preguntó a James por sus planes para los seis partidos de pretemporada de los Lakers.
«A estas alturas de mi carrera, no necesito partidos de pretemporada para ponerme a punto», afirmó.
Hora del mitin de Trump en Virginia Occidental, canal de YouTube
El presidente Donald Trump inicia esta noche una intensa serie de mítines de campaña en Wheeling, Virginia Occidental.
Es el primero de los cinco mítines que Trump tiene programados para la próxima semana, entre los que se incluyen paradas en lugares que le son favorables, como Tennessee y Misisipi.
Con la votación de confirmación de su candidato para cubrir la vacante en el Tribunal Supremo en suspenso, Trump pretende ganarse apoyos de cara a las próximas elecciones de mitad de legislatura, ya que los republicanos corren el riesgo de perder el control del Congreso cuando se celebren las votaciones el 8 de noviembre.
¿A qué hora es el mitin de Trump en Virginia Occidental esta noche y cómo se puede ver por Internet?
El mitin de Trump en Wheeling, Virginia Occidental, está programado para las 19:00 horas. Esta noche, sábado 29 de septiembre de 2018.
Puedes ver el mitin de Trump en Virginia Occidental a continuación a través de la retransmisión en directo en YouTube.
Es probable que Trump se pronuncie sobre las audiencias de esta semana relativas al candidato al Tribunal Supremo Brett Kavanaugh, que se han vuelto tensas debido a las acusaciones de conducta sexual inapropiada, y cuya votación de confirmación en el Senado, prevista inicialmente, ha quedado en suspenso hasta una semana mientras el FBI lleva a cabo su investigación.
Pero el objetivo principal de esta avalancha de mítines es ayudar a los republicanos, que se enfrentan a unas reñidas elecciones en noviembre, a ganar algo de impulso.
Así, según Reuters, la campaña del presidente Trump afirmó que estos cinco mítines de la próxima semana tienen como objetivo «motivar a los voluntarios y simpatizantes, en un momento en que los republicanos intentan proteger y ampliar las mayorías de las que disponen en el Senado y la Cámara de Representantes».
«El control del Congreso es tan crucial para su programa que el presidente viajará a tantos estados como sea posible a medida que nos adentramos en la ajetreada temporada de campaña», declaró a Reuters un portavoz de la campaña de Trump que prefirió mantener el anonimato.
La concentración de esta noche, que tendrá lugar en el Wesbanco Arena de Wheeling, podría atraer a simpatizantes de «Ohio y Pensilvania y contar con la cobertura de los medios de comunicación de Pittsburgh», según el West Virginia Metro News.
El sábado será la segunda vez en el último mes que Trump visite Virginia Occidental, el estado en el que ganó por más de 40 puntos porcentuales en 2016.
Trump está tratando de ayudar al candidato republicano al Senado por Virginia Occidental, Patrick Morrisey, que va por detrás en las encuestas.
«No es una buena señal para Morrisey que el presidente tenga que acudir para intentar darle un empujón en las encuestas», afirmó Simon Haeder, politólogo de la Universidad de Virginia Occidental, según Reuters.
Ryder Cup 2018: El equipo estadounidense demuestra su garra para mantener vivas las esperanzas de cara a los individuales del domingo
Tras tres sesiones muy desiguales, los foursomes del sábado por la tarde podrían haber sido justo lo que necesitaba esta Ryder Cup.
El péndulo del impulso es un concepto deportivo totalmente inventado, pero en el que los jugadores creen firmemente, y nunca tanto como en competiciones como estas.
Entonces, ¿dónde dirían que está el impulso ahora?
«Tenían una ventaja de seis puntos y ahora es de cuatro, así que supongo que eso nos da un poco de impulso», dijo Jordan Spieth mientras se retiraba al final de la jornada.
Europa tiene la ventaja, por supuesto, con cuatro puntos de ventaja y doce aún por disputar.
Sin embargo, como dice Spieth, los estadounidenses sienten que tienen el viento a favor y tienen muchos motivos para sentirse animados, sobre todo por el buen estado de forma de Spieth y Justin Thomas, que jugaron juntos todo el día y suman tres puntos cada uno en cuatro partidos.
Spieth ha estado imparable desde el tee hasta el green y está predicando con el ejemplo.
Esos gritos guturales de júbilo se hicieron más fuertes a medida que avanzaba su ronda, al embocar un putt decisivo que igualó el marcador a cuatro, cuando él y Thomas iban dos abajo tras los dos primeros hoyos.
Su golpe de putt que les dio la victoria en el hoyo 15 fue recibido con un grito similar, de esos que dejan claro que él cree que el equipo estadounidense aún tiene posibilidades.
«Lo único que hay que hacer es darlo todo y centrarse en el propio partido», dijo Spieth.
Es lo único que les queda ahora a todos estos jugadores.
18 hoyos para dejar huella.
Los únicos jugadores que han sumado más puntos que Spieth y Thomas en los últimos dos días son Francesco Molinari y Tommy Fleetwood, los protagonistas indiscutibles de la Ryder Cup.
La peculiar pero adorable pareja europea lleva cuatro victorias de cuatro y parece que todo les sale bien.
«Moliwood» fue la única pareja que no hizo ningún bogey el sábado por la tarde, pero tampoco hizo ninguno el sábado por la mañana, el viernes por la tarde ni en los últimos nueve hoyos del viernes por la mañana.
Esa carrera, y la forma en que su energía parece fluir tanto hacia como desde este bullicioso público confirma que son los rivales a batir el domingo, y no habría ningún jugador más popular que Fleetwood o Molinari para sellar una posible victoria europea mientras el sol se pone sobre Le Golf National.
A ser posible, ambos a la vez en hoyos diferentes.
Sin embargo, aún es pronto para hablar de gloria europea.
Bubba Watson y Webb Simpson no dieron ninguna oportunidad a Sergio García, el héroe de los fourballs de la mañana, cuando le tocó jugar con Alex Noren.
Un bogey y dos dobles en los primeros nueve hoyos dejaron al español y al sueco en una situación de la que nunca lograron salir.
El domingo, sin embargo, no hay nadie que te ayude a salir del atolladero.
Es fascinante ver de cerca los torneos de cuatro bolas y los de parejas, por la interacción entre los jugadores, los consejos que se dan, los que no se dan y la forma en que una estrategia puede cambiar en un instante.
Europa ha jugado mejor como equipo hasta ahora y llega a la última jornada con una ventaja considerable, pero esta sesión de foursomes también ha demostrado que el equipo de EE. UU. tiene la garra necesaria para luchar, algo de lo que algunos, sobre todo en Estados Unidos, habían dudado.
Europa llega al último día de la Ryder Cup con una ventaja de 10-6
Europa llega con una cómoda ventaja a la última jornada de la Ryder Cup tras salir airosa de los partidos de fourballs y foursomes del sábado con una ventaja de 10-6 sobre Estados Unidos.
El inspirador dúo formado por Tommy Fleetwood y Francesco Molinari lideró la remontada con dos victorias sobre un Tiger Woods en horas bajas, lo que les ha permitido sumar hasta ahora cuatro puntos en Le Golf National.
El equipo europeo de Thomas Bjorn, que aspiraba a revalidar el trofeo que perdió en Hazeltine hace dos años, dominó a un equipo estadounidense que no estuvo a la altura en los fourballs de la mañana, imponiéndose por 3-1.
Estados Unidos opuso más resistencia en los foursomes, ganando dos partidos, pero no logró reducir la diferencia.
El equipo de Jim Furyk necesita sumar ocho puntos en los doce partidos individuales del domingo para conservar el trofeo.
Fleetwood es el primer debutante europeo en sumar cuatro puntos consecutivos, mientras que él y Molinari, apodados «Molliwood» tras un fin de semana sensacional, son solo la segunda pareja en la historia de la Ryder Cup en sumar cuatro puntos en sus cuatro primeros partidos.
Tras arrollar a Woods y a Patrick Reed en los fourballs, se compenetraron a la perfección para imponerse por un margen aún más contundente, de 5 y 4, a un Woods desanimado y al novato estadounidense Bryson Dechambeau.
Woods, que el sábado tuvo que esforzarse al máximo para superar dos partidos, mostró algunos destellos de brillantez, pero ya ha perdido 19 de sus 29 partidos en fourballs y foursomes, y siete seguidos.
Justin Rose, que se había reservado para los fourballs de la mañana, volvió a formar pareja con Henrik Stenson en los foursomes y derrotaron por 2&1 a Dustin Johnson y Brooks Koepka, números uno y tres del mundo.
Sin embargo, Europa no lo tuvo todo a su favor en un día agradable y ventoso al suroeste de París.
Jordan Spieth, tres veces ganador de un torneo de Grand Slam, y Justin Thomas marcaron la pauta para los estadounidenses al sumar dos puntos el sábado.
Consiguieron una reñida victoria por 2 y 1 sobre los españoles Jon Rahm e Ian Poulter en el formato «fourballs» y, tras perder los dos primeros hoyos, remontaron más tarde para vencer a Poulter y Rory McIlroy por 4 y 3 en el formato «foursomes».
Solo en dos ocasiones en la historia de la Ryder Cup un equipo ha remontado una desventaja de cuatro puntos al llegar a los individuales, aunque, como actuales campeones, al equipo de Furyk le basta con empatar para conservar el trofeo.
Sin embargo, tras haber quedado en segundo lugar durante dos días, parece que un contraataque el domingo estará fuera de su alcance.
Corea del Norte afirma que «de ninguna manera» se desarmará unilateralmente sin que haya confianza
El ministro de Asuntos Exteriores de Corea del Norte declaró el sábado ante las Naciones Unidas que la persistencia de las sanciones estaba agravando su desconfianza hacia Estados Unidos y que, en tales circunstancias, era imposible que el país renunciara unilateralmente a sus armas nucleares.
Ri Yong Ho declaró ante la Asamblea General anual de la organización internacional que Corea del Norte había adoptado «importantes medidas de buena voluntad» durante el último año, como la suspensión de los ensayos nucleares y de misiles, el desmantelamiento del centro de ensayos nucleares y el compromiso de no proliferar armas nucleares ni tecnología nuclear.
«Sin embargo, no vemos ninguna respuesta por parte de Estados Unidos», afirmó.
«Sin confianza en Estados Unidos, no habrá confianza en nuestra seguridad nacional y, en tales circunstancias, de ninguna manera nos desarmaremos unilateralmente primero».
Aunque Ri volvió a repetir las habituales quejas de Corea del Norte sobre la resistencia de Washington a un enfoque «por fases» de la desnuclearización, en virtud del cual se recompensaría a Corea del Norte a medida que diera pasos graduales, Esta declaración resultó significativa, ya que no rechazaba de plano la desnuclearización unilateral, como había hecho Pyongyang en el pasado.
Ri se refirió a una declaración conjunta emitida por Kim Jong Un y Donald Trump con motivo de la primera cumbre celebrada entre un presidente estadounidense en ejercicio y un líder norcoreano, que tuvo lugar en Singapur el 12 de junio, mientras Kim se comprometía a trabajar por la «desnuclearización de la península de Corea» y Trump prometía garantías de seguridad para Corea del Norte.
Corea del Norte ha estado tratando de lograr el fin oficial de la Guerra de Corea (1950-1953), pero Estados Unidos ha afirmado que Pyongyang debe renunciar primero a sus armas nucleares.
Washington también se ha resistido a las peticiones de suavizar las duras sanciones internacionales impuestas a Corea del Norte.
«Estados Unidos insiste en la "desnuclearización primero" y aumenta la presión mediante sanciones para lograr su objetivo de forma coercitiva, llegando incluso a oponerse a la "declaración del fin de la guerra"», afirmó Ri.
«La idea de que las sanciones pueden doblegarnos es una quimera de quienes nos desconocen».
«Pero el problema es que el mantenimiento de las sanciones está agravando nuestra desconfianza».
Ri no hizo ninguna mención a los planes para una segunda cumbre entre Kim y Trump que el líder estadounidense había destacado ante las Naciones Unidas a principios de semana.
En cambio, el ministro destacó las tres reuniones mantenidas entre Kim y el líder surcoreano Moon Jae-in en los últimos cinco meses y añadió: «Si la parte implicada en esta cuestión de la desnuclearización fuera Corea del Sur y no Estados Unidos, la desnuclearización de la península coreana no habría llegado a un punto muerto como este».
Aun así, el tono del discurso de Ri fue radicalmente diferente al del año pasado, cuando declaró ante la Asamblea General de la ONU que era inevitable que los misiles de Corea del Norte apuntaran al territorio continental de Estados Unidos después de que el «malvado presidente» Trump llamara a Kim «hombre cohete» en una misión suicida.
Este año, en las Naciones Unidas, Trump —quien el año pasado amenazó con «destruir totalmente» Corea del Norte— elogió a Kim por su valentía a la hora de dar pasos hacia el desarme, pero señaló que aún queda mucho por hacer y que las sanciones deben mantenerse hasta que Corea del Norte se desnuclearice.
El miércoles, Trump afirmó que no tenía un plazo concreto para ello y añadió: «Si lleva dos años, tres años o cinco meses, da igual».
China y Rusia sostienen que el Consejo de Seguridad de la ONU debería recompensar a Pyongyang por las medidas adoptadas.
Sin embargo, el secretario de Estado de EE. UU., Mike Pompeo, declaró el jueves ante el Consejo de Seguridad de la ONU que: «La aplicación de las sanciones del Consejo de Seguridad debe continuar con firmeza y sin fisuras hasta que logremos una desnuclearización plena, definitiva y verificada».
El Consejo de Seguridad ha reforzado por unanimidad las sanciones contra Corea del Norte desde 2006, con el fin de cortar la financiación de los programas nucleares y de misiles balísticos de Pyongyang.
Pompeo se reunió con Ri al margen de la Asamblea General de la ONU y declaró posteriormente que volvería a visitar Pyongyang el mes que viene para preparar una segunda cumbre.
Pompeo ya ha visitado Corea del Norte tres veces este año, pero su último viaje no salió bien.
Se marchó de Pyongyang en julio afirmando que se habían logrado avances, pero, a las pocas horas, Corea del Norte lo denunció por plantear «exigencias propias de un gánster».
Corea del Norte se comprometió, en una reunión celebrada este mes con Moon, a desmantelar una base de misiles y también un complejo nuclear si Estados Unidos adoptaba «las medidas correspondientes».
Dijo que Kim le había explicado que las «medidas correspondientes» que buscaba eran las garantías de seguridad que Trump había prometido en Singapur y los pasos hacia la normalización de las relaciones con Washington.
Los estudiantes de Harvard cursan una asignatura sobre cómo descansar lo suficiente
Un nuevo curso impartido este año en la Universidad de Harvard ha conseguido que todos sus estudiantes universitarios duerman más, en un intento por combatir la creciente cultura machista de estudiar trasnochando y alimentándose de cafeína.
Un profesor descubrió que los estudiantes de la universidad número uno del mundo suelen carecer de conocimientos básicos sobre cómo cuidarse.
Charles Czeisler, profesor de medicina del sueño en la Facultad de Medicina de Harvard y especialista del Brigham and Women's Hospital, diseñó el curso, que, según él, es el primero de este tipo en Estados Unidos.
Se le ocurrió crear el curso después de dar una charla sobre el impacto que tiene la falta de sueño en el aprendizaje.
«Al final, una chica se me acercó y me dijo: "¿Por qué me lo dicen esto ahora, en mi último año?"»
«Me dijo que nadie le había hablado nunca de la importancia del sueño, lo cual me sorprendió», declaró a The Telegraph.
El curso, que se ha puesto en marcha por primera vez este año, explica a los alumnos los aspectos fundamentales de cómo unos buenos hábitos de sueño contribuyen al rendimiento académico y deportivo, además de mejorar su bienestar general.
Paul Barreira, profesor de psiquiatría en la Facultad de Medicina de Harvard y director ejecutivo de los servicios de salud de la universidad, afirmó que la universidad decidió introducir el curso tras constatar que los estudiantes sufrían una grave falta de sueño durante la semana.
El curso, de una hora de duración, incluye una serie de actividades interactivas.
En una sección aparece la imagen de una habitación de residencia universitaria, donde los estudiantes hacen clic en tazas de café, cortinas, zapatillas deportivas y libros para obtener información sobre los efectos de la cafeína y la luz, cómo la falta de sueño afecta al rendimiento deportivo y la importancia de seguir una rutina antes de acostarse.
En otra sección, se explica a los participantes cómo la privación del sueño a largo plazo puede aumentar el riesgo de sufrir infartos, accidentes cerebrovasculares, depresión y cáncer.
A continuación, un mapa del campus, con iconos interactivos, anima a los participantes a reflexionar sobre su rutina diaria.
«Sabemos que esto no va a cambiar el comportamiento de los alumnos de la noche a la mañana».
«Pero creemos que tienen derecho a saberlo, al igual que usted tiene derecho a conocer los efectos sobre la salud que conlleva fumar cigarrillos», añadió el profesor Czeisler.
Según él, la cultura de estar orgulloso de «pasarse la noche en vela» sigue existiendo, y añadió que la tecnología moderna y la presión cada vez mayor sobre los estudiantes hacen que la falta de sueño sea un problema cada vez más grave.
«Asegurarse de dormir lo suficiente y de buena calidad debería ser el "arma secreta" de cualquier estudiante para combatir el estrés, el agotamiento y la ansiedad», afirmó; incluso para evitar ganar peso, ya que la falta de sueño pone al cerebro en «modo de inanición», lo que hace que se sienta constantemente hambriento.
Raymond So, un californiano de 19 años que estudia biología química y física, ayudó al profesor Czeisler a diseñar el curso, tras haber asistido a una de sus clases el año pasado, durante su primer año en Harvard.
Dijo que el curso le había abierto los ojos y le había animado a impulsar un curso para todo el campus.
El siguiente paso, según espera, es pedir a todos los estudiantes de posgrado que completen un programa de estudios similar antes de incorporarse a esta prestigiosa institución.
El profesor Czeisler recomendó a los estudiantes que consideraran la posibilidad de poner una alarma para saber a qué hora deben acostarse, así como a la hora de despertarse, y ten en cuenta los efectos nocivos de la «luz azul» que emiten las pantallas electrónicas y la iluminación LED, ya que pueden alterar tu ritmo circadiano y provocar dificultades para conciliar el sueño.
Livingston 1 - 0 Rangers: Un gol de Menga derrota a los hombres de Gerrard
El Rangers volvió a sufrir otro tropiezo fuera de casa, ya que el gol de Dolly Menga condenó al descoordinado equipo de Steven Gerrard a una derrota por 1-0 en Livingston.
El equipo de Ibrox buscaba sumar su primera victoria fuera de casa desde el triunfo por 4-1 del pasado febrero ante el St Johnstone, pero el equipo de Gary Holt infligió a Gerrard su segunda derrota en 18 partidos como entrenador, lo que deja a su equipo a ocho puntos del Hearts, líder indiscutible de la Ladbrokes Premiership.
Menga marcó siete minutos antes del descanso y un equipo de los Rangers falto de inspiración nunca dio la impresión de poder empatar.
Mientras que el Rangers cae ahora al sexto puesto, el Livingston asciende al tercero, solo por detrás del Hibernian por diferencia de goles.
Y es posible que al Rangers le esperen más problemas, ya que el juez de línea Calum Spence tuvo que recibir atención médica por una herida en la cabeza después de que, al parecer, se lanzara un objeto desde la grada de los visitantes.
Gerrard realizó ocho cambios en el equipo que arrolló al Ayr y se clasificó para las semifinales de la Betfred Cup.
Holt, por su parte, apostó por el mismo once titular del Livi que le valió un punto ante el Hearts la semana pasada, y seguramente se habrá quedado encantado con la forma en que su bien entrenado equipo asfixió a sus rivales en todo momento.
Puede que el Rangers dominara la posesión, pero el Livingston aprovechó mejor el balón que tuvo.
Deberían haber marcado a los dos minutos, cuando un pase de primera de Menga dejó a Scott Pittman solo ante la portería de Allan McGregor, pero el centrocampista envió fuera esa gran ocasión.
A continuación, un lanzamiento de falta profundo de Keaghan Jacobs llegó al capitán Craig Halkett, pero su compañero en la defensa, Alan Lithgow, solo pudo rematar fuera desde el segundo palo.
El Rangers se hizo con el control del partido, pero su juego en el último tercio del campo parecía más fruto de la esperanza que de la convicción.
Alfredo Morelos estaba convencido de que le deberían haber pitado un penalti al cuarto de hora del partido, tras chocar con Steven Lawless, pero el árbitro Steven Thomson hizo caso omiso de las protestas del colombiano.
El Rangers solo logró dos tiros a puerta en la primera parte, pero el exguardameta del Ibrox, Liam Kelly, apenas tuvo que intervenir ante el cabezazo de Lassana Coulibaly y el flojo disparo de Ovie Ejaria.
Aunque el primer gol de Livi en el minuto 34 pudo haber sido contra la lógica del partido, nadie puede negar que se lo merecieron solo por su esfuerzo.
Una vez más, el Rangers no supo despejar una jugada a balón parado lanzada desde lejos por Jacobs.
Scott Arfield no reaccionó cuando Declan Gallagher pasó el balón a Scott Robinson, quien mantuvo la calma y asistió a Menga para que este rematara a puerta vacía.
Gerrard actuó en el descanso al sustituir a Coulibaly por Ryan Kent, y el cambio estuvo a punto de surtir efecto de inmediato, ya que el extremo asistió a Morelos, pero el impresionante Kelly salió rápidamente de su portería para bloquear el disparo.
Pero el Livingston siguió arrastrando a los visitantes a jugar exactamente el tipo de partido que les gusta, con Lithgow y Halkett despejando un pase en largo tras otro.
El equipo de Holt podría haber ampliado su ventaja en los últimos compases, pero McGregor se empleó a fondo para detener un disparo de Jacobs, antes de que Lithgow rematara de cabeza fuera tras un saque de esquina.
El suplente del Rangers, Glenn Middleton, volvió a reclamar un penalti en los últimos minutos tras un choque con Jacobs, pero, una vez más, Thomson hizo como si no viera nada.
Almanaque: El inventor del contador Geiger
Y ahora, una página de nuestro almanaque «Sunday Morning»: 30 de septiembre de 1882, hace hoy 136 años, y SUMANDO... el día en que nació en Alemania el futuro físico Johannes Wilhelm «Hans» Geiger.
Geiger desarrolló un método para detectar y medir la radiactividad, un invento que acabó dando lugar al dispositivo conocido como contador Geiger.
El contador Geiger, un elemento fundamental de la ciencia desde entonces, se convirtió también en un elemento fundamental de la cultura popular, como se ve en la película de 1950 «Las campanas de Coronado», protagonizada por esos científicos vaqueros, a primera vista tan poco probables, Roy Rogers y Dale Evans:
Hombre: «¿Qué demonios es eso?»
Rogers: «Es un contador Geiger, que se utiliza para localizar minerales radiactivos, como el uranio».
«Cuando te pones estos auriculares, puedes oír realmente los efectos de los átomos que emiten los minerales debido a su radiactividad».
Evans: «¡Vaya, ahora sí que está que arde!»
«Hans» Geiger falleció en 1945, a solo unos días de cumplir 63 años.
Pero el invento que lleva su nombre sigue vivo.
Una nueva vacuna contra el cáncer puede enseñar al sistema inmunitario a «detectar» las células anómalas
Una nueva vacuna contra el cáncer puede enseñar al sistema inmunitario a «detectar» las células anómalas y destruirlas
La vacuna enseña al sistema inmunitario a reconocer las células anómalas como parte del tratamiento
El método consiste en extraer células inmunitarias del paciente y modificarlas en el laboratorio
De este modo, pueden «detectar» una proteína común a muchos tipos de cáncer y volver a inyectarla
Una vacuna en fase de ensayo está dando resultados prometedores en pacientes con diversos tipos de cáncer.
Una mujer tratada con la vacuna, que enseña al sistema inmunitario a reconocer las células malignas, vio cómo su cáncer de ovario desaparecía durante más de 18 meses.
El método consiste en extraer células inmunitarias del paciente, modificarlas en el laboratorio para que puedan «detectar» una proteína común a muchos tipos de cáncer llamada HER2 y, a continuación, reinyectar las células.
El profesor Jay Berzofsky, del Instituto Nacional del Cáncer de Estados Unidos, con sede en Bethesda (Maryland), afirmó: «Nuestros resultados indican que contamos con una vacuna muy prometedora».
«El HER2 "impulsa el crecimiento de varios tipos de cáncer"», entre ellos el de mama, el de ovario, el de pulmón y el colorrectal, explicó el profesor Berzofsky.
Un enfoque similar, que consiste en extraer células inmunitarias de los pacientes y «enseñarles» a atacar las células cancerosas, ha dado buenos resultados en el tratamiento de un tipo de leucemia.
Kanye West se lanzó a una diatriba a favor de Trump, con una gorra de «Make America Great Again», tras su aparición en SNL.
No salió bien
Kanye West fue abucheado en el plató de Saturday Night Live tras una actuación inconexa en la que elogió al presidente de Estados Unidos, Donald Trump, y anunció que se presentaría a las elecciones en 2020.
Tras interpretar su tercera canción de la noche, titulada «Ghost Town», durante la cual llevaba una gorra con el lema «Make America Great», lanzó una diatriba contra los demócratas y reiteró su apoyo a Trump.
«Muchas veces hablo con personas blancas y me dicen: "¿Cómo te puede gustar Trump? Es racista"».
«Bueno, si me preocupara el racismo, me habría ido de Estados Unidos hace mucho tiempo», dijo.
SNL comenzó el programa con un sketch protagonizado por Matt Damon en el que la estrella de Hollywood se burló del testimonio de Brett Kavanaugh ante la Comisión Judicial del Senado sobre las acusaciones de agresión sexual formuladas por Christine Blasey Ford.
Aunque no se emitió, el cómico Chris Rock subió a las redes sociales el vídeo de la diatriba de West.
No está claro si Rock intentaba burlarse de West con esa publicación.
Además, West se había quejado ante el público de que le habían dado un buen repaso entre bastidores por el sombrero que llevaba.
«Me acosaron entre bastidores».
Me dijeron: «No salgas con ese sombrero puesto».
¡Me han acosado!
«Y luego dicen que estoy en un bache», afirmó, según el Washington Examiner.
West continuó: «¿Quieres ver el lugar más oscuro?», y añadió que se «pondría su capa de Superman, porque eso significa que no puedes decirme lo que tengo que hacer». ¿Quieres que el mundo avance?
«Prueba con el amor».
Sus comentarios provocaron abucheos al menos en dos ocasiones por parte del público, y los miembros del reparto de SNL parecían avergonzados, según informó Variety; una de las personas presentes declaró a la publicación: «Todo el estudio quedó en silencio».
West había sido contratado como sustituto de última hora de la cantante Ariana Grande, cuyo exnovio, el rapero Mac Miller, había fallecido hacía unos días.
West dejó perplejos a muchos con su interpretación de la canción «I Love It», vestido como una botella de Perrier.
West recibió el apoyo de la directora del grupo conservador TPUSA, Candace Turner, quien tuiteó: «A uno de los espíritus más valientes: GRACIAS POR HABERLE HECHO FRENTE A LA TURBA».
Sin embargo, la presentadora de programas de entrevistas Karen Hunter tuiteó que West simplemente «estaba siendo él mismo, y eso es absolutamente maravilloso».
«Pero decidí NO recompensar a alguien (comprando su música o su ropa, o apoyando su «arte») que, en mi opinión, abraza y difunde una ideología que es perjudicial para mi comunidad».
Está libre.
«Nosotros también», añadió ella.
Antes del concierto, el rapero anunció en Twitter que se había cambiado el nombre, afirmando que ahora era «el ser anteriormente conocido como Kanye West».
No es el primer artista en cambiarse el nombre y sigue los pasos de Diddy, también conocido como Puff Daddy, Puffy y P Diddy.
Su compañero rapero, Snoop Dogg, ha adoptado el nombre de Snoop Lion y, por supuesto, la difunta leyenda de la música Prince cambió su nombre por un símbolo y luego volvió a llamarse simplemente «Prince».
Acusación de intento de asesinato por un apuñalamiento en un restaurante de Belfast
Un hombre de 45 años ha sido acusado de intento de asesinato tras el apuñalamiento de otro hombre en un restaurante del este de Belfast el viernes.
Según la policía, el incidente tuvo lugar en Ballyhackamore.
Se espera que el acusado comparezca ante el Juzgado de Primera Instancia de Belfast el lunes.
La Fiscalía revisará los cargos.
Kit Harington, protagonista de «Juego de Tronos», arremete contra la masculinidad tóxica
Kit Harington es conocido por su papel de Jon Snow, un guerrero con la espada en la mano, en la violenta serie de fantasía medieval de HBO «Juego de Tronos».
Sin embargo, el actor, de 31 años, ha criticado el estereotipo del héroe machista, afirmando que esos papeles en la pantalla hacen que los chicos jóvenes a menudo sientan que tienen que mostrarse duros para ganarse el respeto.
En declaraciones a la sección de cultura de The Sunday Times, Kit afirmó que cree que «algo ha salido mal» y se preguntó cómo abordar el problema de la masculinidad tóxica en la era del #MeToo.
Kit, que se casó recientemente con su compañera de reparto en «Juego de Tronos», Rose Leslie, también de 31 años, admitió que le preocupa «mucho» abordar este tema.
«Personalmente, en este momento tengo la firme sensación de que algo ha fallado en lo que respecta a la masculinidad», afirmó.
«¿Qué les hemos estado enseñando a los hombres mientras crecían, en relación con el problema que vemos ahora?»
Kit cree que la televisión puede ser en parte responsable del aumento de la masculinidad tóxica debido a sus personajes tan masculinos.
Y continuó: «¿Qué es innato y qué se aprende?».
¿Qué es lo que se transmite en la televisión y en la calle que hace que los chicos jóvenes sientan que tienen que ajustarse a un determinado modelo de masculinidad?
Creo que esa es, sin duda, una de las grandes preguntas de nuestro tiempo: ¿cómo podemos cambiar eso?
«Porque está claro que algo ha salido mal para los jóvenes».
En la entrevista también admitió que no participaría en ninguna precuela ni secuela de «Juego de Tronos» cuando la serie llegue a su fin el próximo verano, afirmando que «ya ha tenido suficiente de campos de batalla y caballos».
A partir de noviembre, Kit protagonizará una reposición de «True West», de Sam Shepard, que cuenta la historia de un productor de cine y su hermano, que es un ladrón.
El actor reveló recientemente que considera que conocer a su esposa Rose ha sido lo mejor que le ha pasado gracias a «Juego de Tronos».
«Conocí a mi mujer en este programa, así que, en ese sentido, me proporcionó mi futura familia y mi vida a partir de ahora», dijo.
Rose interpretó a Ygritte, el interés amoroso del personaje de Kit, Jon Snow, en la serie fantástica ganadora de un premio Emmy.
La pareja se casó en junio de 2018 en los terrenos de la finca familiar de Leslie en Escocia.
VIH/sida: China registra un aumento del 14 % en los nuevos casos
China ha anunciado un aumento del 14 % en el número de ciudadanos que viven con el VIH y el sida.
Según las autoridades sanitarias, hay más de 820 000 personas afectadas en el país.
Solo en el segundo trimestre de 2018 se registraron unos 40 000 nuevos casos.
La gran mayoría de los nuevos casos se transmitieron por vía sexual, lo que supone un cambio con respecto al pasado.
Tradicionalmente, el VIH se propagó rápidamente por algunas zonas de China como consecuencia de transfusiones de sangre infectada.
Sin embargo, el número de personas que contraen el VIH de esta forma se ha reducido prácticamente a cero, según afirmaron las autoridades sanitarias chinas en una conferencia celebrada en la provincia de Yunnan.
Sin embargo, en comparación con el año anterior, el número de personas que viven con el VIH y el sida en China ha aumentado en 100 000.
La transmisión del VIH por vía sexual es un problema grave en la comunidad LGBT de China.
La homosexualidad dejó de ser delito en China en 1997, pero se dice que la discriminación contra las personas LGBT sigue siendo muy frecuente.
Debido a los valores conservadores del país, algunos estudios han estimado que entre el 70 % y el 90 % de los hombres que mantienen relaciones sexuales con otros hombres acabarán casándose con mujeres.
Muchas de las transmisiones de estas enfermedades se deben a la falta de protección sexual en estas relaciones.
Desde 2003, el Gobierno chino ha prometido el acceso universal a los medicamentos contra el VIH como parte de sus esfuerzos por abordar este problema.
Maxine Waters niega que un miembro de su equipo haya filtrado datos de senadores republicanos y critica las «mentiras peligrosas» y las «teorías de la conspiración»
La diputada estadounidense Maxine Waters denunció el sábado las acusaciones de que un miembro de su equipo había publicado la información personal de tres senadores republicanos en las páginas de Wikipedia de dichos legisladores.
El demócrata de Los Ángeles afirmó que esas afirmaciones las difundían comentaristas y sitios web de «extrema derecha».
«Mentiras, mentiras y más mentiras despreciables», afirmó Waters en un comunicado publicado en Twitter.
Según se ha informado, la información divulgada incluía las direcciones particulares y los números de teléfono de los senadores estadounidenses. Lindsey Graham, de Carolina del Sur, y Mike Lee y Orrin Hatch, ambos de Utah.
La información apareció en Internet el jueves, publicada por una persona desconocida en el Capitolio durante una audiencia de una comisión del Senado sobre las acusaciones de conducta sexual inapropiada contra el candidato al Tribunal Supremo Brett Kavanaugh.
La filtración se produjo poco después de que los tres senadores hubieran interrogado a Kavanaugh.
Sitios web conservadores como Gateway Pundit y RedState informaron de que la dirección IP que identifica el origen de las publicaciones estaba vinculada a la oficina de Waters y revelaron los datos de un miembro del personal de Waters, según informó The Hill.
«Esta acusación infundada es totalmente falsa y una mentira absoluta», prosiguió Waters.
«El miembro de mi equipo —cuya identidad, datos personales y seguridad se han visto comprometidos como consecuencia de estas acusaciones fraudulentas y falsas— no tuvo nada que ver con la filtración de esta información.
«Esta acusación infundada es totalmente falsa y una mentira absoluta».
Las declaraciones de Waters no tardaron en suscitar críticas en Internet, entre ellas las del exsecretario de prensa de la Casa Blanca, Ari Fleischer.
«Esta negación denota enfado», escribió Fleischer.
«Esto sugiere que no tiene el temperamento necesario para ser diputada».
Cuando alguien es acusado de algo que no ha hecho, no debe enfadarse.
No deben mostrarse desafiantes.
No deben cuestionar los motivos del acusador.
«Deben estar tranquilos y serenos».
Fleischer parecía estar comparando la reacción de Waters con las críticas de los demócratas al juez Kavanaugh, a quien sus detractores acusaban de mostrarse demasiado enfadado durante la audiencia del jueves.
Omar Navarro, candidato republicano que se presenta para desbancar a Waters en las elecciones de mitad de legislatura, también expresó su opinión en Twitter.
«Si fuera cierto, sería algo gordo», tuiteó.
En su comunicado, Waters afirmó que su oficina había alertado «a las autoridades competentes y a los organismos encargados de hacer cumplir la ley sobre estas reclamaciones fraudulentas».
«Nos aseguraremos de que se identifique a los responsables», prosiguió, «y de que se les exijan responsabilidades legales por todas sus acciones, que son destructivas y peligrosas para todos y cada uno de los miembros de mi personal».
Reseña de «Johnny English Strikes Again»: una parodia de espías protagonizada por un Rowan Atkinson sin chispa
Hoy en día es habitual buscar referencias al Brexit en cualquier película nueva con un toque británico, y eso parece aplicarse a esta nueva entrega de la saga de parodias de acción y comedia de Johnny English, que comenzó en 2003 con *Johnny English* y resurgió en 2011 con *Johnny English Reborn*.
¿Será la autoironía con un toque de humor sobre lo mal que lo hacemos, como es obvio, la nueva oportunidad de exportación del país?
En cualquier caso, Al incompetente Johnny English, con sus ojos saltones y su cara de goma, le han renovado por segunda vez su licencia para meter la pata; su nombre, más que nada, deja claro que se trata de un personaje cómico exagerado, creado para los mercados cinematográficos de habla no inglesa.
Es, por supuesto, ese agente secreto un poco chiflado que, a pesar de sus extravagantes pretensiones de glamour sofisticado, tiene algo de Clouseau, un toque de Mr. Bean y una pizca de ese tipo que tocó una sola nota del tema musical de «Carros de fuego» en la ceremonia de inauguración de los Juegos Olímpicos de Londres 2012.
Además, su personaje se inspira en el viajero y hombre internacional de misterio que Atkinson interpretó en su día en los ya olvidados anuncios de televisión de Barclaycard, dejando a su paso una estela de caos.
Esta última entrega de JE tiene uno o dos momentos interesantes.
Me encantó la escena en la que Johnny English se acerca a un helicóptero vestido con una armadura medieval y las palas del rotor le golpean brevemente el casco.
El talento de Atkinson para la comedia física queda patente, pero el humor resulta bastante flojo y, curiosamente, superfluo, sobre todo teniendo en cuenta que las propias sagas «serias» como 007 y Misión Imposible incorporan ahora con total naturalidad la comedia como uno de sus ingredientes.
El humor parece estar dirigido más a los niños que a los adultos y, en mi opinión, las extravagantes desventuras de Johnny English no son tan ingeniosas ni tan acertadas como los gags al estilo del cine mudo que Atkinson interpretaba en el personaje de Bean.
La premisa que siempre está de actualidad es que Gran Bretaña se encuentra en serios apuros.
Un pirata informático se ha infiltrado en la red web ultrasecreta de espías del Reino Unido y ha revelado las identidades de todos los agentes británicos sobre el terreno, para consternación del agente de guardia —un papel lamentablemente secundario para Kevin Eldon—.
Es la gota que colma el vaso para una primera ministra que es una figura pomposa y asediada, y que ya sufre un colapso total de su popularidad política: Emma Thompson lo da todo con este personaje que recuerda a Teresa May, pero el guion no le ofrece mucho con lo que trabajar.
Sus asesores de inteligencia le informan de que, dado que todos los espías en activo han sido descubiertos, tendrá que sacar a alguien de su retiro.
Y eso significa nada menos que el torpe Johnny English, que ahora trabaja como profesor en un centro de élite, pero imparte clases extraoficiales sobre cómo ser un agente encubierto: hay algunos gags muy chulos aquí, ya que English ofrece una academia de espionaje al estilo de «School of Rock».
English es llevado rápidamente a Whitehall para una reunión informativa de urgencia y se reencuentra con su antiguo y sufrido compañero Bough, interpretado de nuevo por Ben Miller.
Bough está casado ahora con una comandante de submarinos, un papel de lo más alegre en el que Vicki Pepperdine está un poco desaprovechada.
Así que el dúo de Batman y Robin, especialistas en meter la pata en «Al servicio secreto de Su Majestad», vuelve a la acción y se encuentra con la bella femme fatale interpretada por Olga Kurylenko, Ophelia Bulletova.
Mientras tanto, el primer ministro está cayendo peligrosamente bajo el hechizo del carismático multimillonario tecnológico que afirma poder resolver los problemas informáticos de Gran Bretaña: el siniestro Jason Volta, interpretado por Jake Lacy.
English y Bough comienzan su odisea de travesuras absurdas: disfrazados de camareros, prenden fuego a un elegante restaurante francés; provocan el caos al colarse a bordo del lujoso yate de Volta; y English desata la anarquía al intentar utilizar unas gafas de realidad virtual para familiarizarse con el interior de la casa de Volta.
Sin duda, se han puesto las pilas para esa última secuencia, pero, por muy simpática y animada que sea, todo el asunto tiene bastante de programa infantil.
Algo bastante moderado.
Y, al igual que con las otras películas de Johnny English, no pude evitar pensar: ¿es que la industria cinematográfica británica no puede ofrecerle a Rowan Atkinson un papel que realmente haga justicia a su talento?
El Partido Laborista niega que esté elaborando un plan para que los británicos trabajen cuatro días a la semana pero cobren cinco
El Partido Laborista de Jeremy Corbyn va a estudiar un plan radical según el cual los británicos trabajarían cuatro días a la semana, pero cobrarían el salario de cinco.
Según se informa, el partido quiere que los directivos de las empresas repercutan en los trabajadores el ahorro conseguido gracias a la revolución de la inteligencia artificial (IA), concediéndoles un día libre adicional.
De este modo, los empleados disfrutarían de un fin de semana de tres días, pero seguirían cobrando lo mismo.
Según algunas fuentes, la idea «encajaría» con la agenda económica del partido y con sus planes de inclinar la balanza a favor de los trabajadores.
El Congreso de Sindicatos ha respaldado el paso a la semana laboral de cuatro días como una forma de que los trabajadores saquen partido de los cambios en la economía.
Una fuente de alto rango del Partido Laborista declaró a The Sunday Times: «Se espera que se anuncie una revisión de las políticas antes de que termine el año».
«No va a suceder de la noche a la mañana, pero la semana laboral de cuatro días es un objetivo que encaja con el enfoque del partido para reequilibrar la economía a favor de los trabajadores, así como con su estrategia industrial general».
El Partido Laborista no sería el primero en respaldar esta idea, ya que el Partido Verde prometió una semana laboral de cuatro días durante su campaña para las elecciones generales de 2017.
Sin embargo, en estos momentos el Partido Laborista en su conjunto no respalda esa aspiración.
Un portavoz del Partido Laborista declaró: «La semana laboral de cuatro días no forma parte de la política del partido y este no la está barajando».
El portavoz de Economía del Partido Laborista, John McDonnell, aprovechó el congreso del partido celebrado la semana pasada para desarrollar su visión de una revolución socialista en la economía.
El Sr. McDonnell afirmó que estaba decidido a recuperar el poder de manos de los «directivos anónimos» y los «especuladores» de las empresas de servicios públicos.
Los planes del portavoz de Economía de la oposición también implican que es posible que los actuales accionistas de las empresas de suministro de agua no recuperen la totalidad de su participación, ya que un gobierno laborista podría aplicar «deducciones» alegando presuntas irregularidades.
También confirmó los planes de incorporar a trabajadores a los consejos de administración de las empresas y crear «fondos de propiedad inclusiva» para ceder el 10 % del capital social de las empresas del sector privado a los empleados, quienes podrían percibir dividendos anuales de hasta 500 libras.
Lindsey Graham y John Kennedy explican en «60 Minutes» si la investigación del FBI sobre Kavanaugh podría hacerles cambiar de opinión
La investigación del FBI sobre las acusaciones contra el juez Brett Kavanaugh ha retrasado al menos una semana la votación final sobre su nominación al Tribunal Supremo, y plantea la cuestión de si las conclusiones de la oficina podrían llevar a algún senador republicano a retirar su apoyo.
En una entrevista que se emitirá el domingo, el corresponsal de «60 Minutes», Scott Pelley, preguntó a los senadores republicanos... John Kennedy y Lindsey Graham se preguntaban si el FBI podría descubrir algo que les hiciera cambiar de opinión.
Kennedy se mostró más abierto que su colega de Carolina del Sur.
«Quiero decir, claro», dijo Kennedy.
«Antes de la audiencia, dije: "He hablado con el juez Kavanaugh".
Le llamé después de que pasara eso, de que saliera a la luz esa acusación, y le pregunté: «¿Lo hiciste tú?».
«Era firme, decidido e inequívoco».
El voto de Graham, sin embargo, parece inamovible.
«Ya tengo una opinión formada sobre Brett Kavanaugh y haría falta una acusación explosiva para que cambiara de opinión», afirmó.
«Dra. Ford, no sé qué pasó, pero sí sé esto: Brett lo negó rotundamente», añadió Graham, refiriéndose a Christine Blasey Ford.
«Y ninguna de las personas a las que ella menciona pudo confirmarlo».
Tiene 36 años.
«No veo que haya ningún cambio nuevo».
¿Qué es el Global Citizen Festival y ha servido para reducir la pobreza?
Este sábado, Nueva York acogerá el Global Citizen Festival, un evento musical anual que cuenta con un cartel de estrellas realmente impresionante y una misión igualmente impresionante: acabar con la pobreza en el mundo.
Ahora, en su séptimo año, El Global Citizen Festival reunirá a decenas de miles de personas en el Great Lawn de Central Park, no solo para disfrutar de actuaciones de artistas como Janet Jackson, Cardi B y Shawn Mendes, sino también para dar a conocer el verdadero objetivo del evento: acabar con la pobreza extrema para 2030.
El Global Citizen Festival, que se celebró por primera vez en 2012, es una iniciativa del Global Poverty Project, un grupo internacional de defensa que aspira a acabar con la pobreza aumentando el número de personas que luchan activamente contra ella.
Para recibir una entrada gratuita para el evento (a menos que estuvieras dispuesto a pagar por una entrada VIP), Los asistentes al concierto tuvieron que realizar una serie de tareas, o «acciones», como hacer voluntariado, enviar un correo electrónico a un líder mundial, hacer una llamada telefónica o cualquier otra iniciativa significativa para ayudar a dar a conocer su objetivo de acabar con la pobreza.
Pero, ¿qué éxito ha tenido Global Citizen cuando aún le quedan 12 años para alcanzar su objetivo?
¿Es la idea de recompensar a la gente con un concierto gratuito una forma auténtica de convencer a la gente para que exija que se tomen medidas, o se trata simplemente de otro caso del llamado «clicktivismo» —esa sensación que tiene la gente de que está marcando una verdadera diferencia al firmar una petición en línea o enviar un tuit?
Según Global Citizen, desde 2011 ha registrado más de 19 millones de «acciones» de sus seguidores, que han impulsado una gran variedad de objetivos.
Según el informe, estas medidas han contribuido a que los líderes mundiales anuncien compromisos y políticas por un valor superior a 37 000 millones de dólares, que se prevé que mejoren la vida de más de 2 250 millones de personas de aquí a 2030.
A principios de 2018, el grupo señaló que sus iniciativas habían dado lugar a 390 compromisos y anuncios, de los cuales al menos 10 000 millones de dólares ya se habían desembolsado o recaudado.
El grupo calcula que los fondos recaudados han tenido hasta ahora un impacto directo en casi 649 millones de personas en todo el mundo.
Entre los compromisos clave se encuentran «El poder de la nutrición», una asociación con sede en el Reino Unido formada por inversores y ejecutores comprometidos con «ayudar a los niños a desarrollar todo su potencial», que se ha comprometido a aportar 35 millones de dólares a Ruanda para ayudar a acabar con la malnutrición en el país tras recibir más de 4.700 tuits de Global Citizens.
«Con el apoyo del Gobierno del Reino Unido, «Con la ayuda de donantes, gobiernos nacionales y ciudadanos del mundo como tú, podemos hacer que la injusticia social que supone la desnutrición pase a ser una simple nota al pie de página en la historia», declaró Tracey Ullman, embajadora de «The Power of Nutrition», ante el público durante un concierto en directo celebrado en Londres en abril de 2018.
El grupo también señaló que, tras más de 5,Tras las 000 acciones emprendidas para instar al Reino Unido a mejorar la nutrición de madres y niños, el Gobierno anunció la financiación de un proyecto, «The Power of Nutrition», que llegará a 5 millones de mujeres y niños con intervenciones nutricionales.
En respuesta a una de las preguntas frecuentes de su sitio web, en la que se pregunta: «¿Qué les hace pensar que podemos acabar con la pobreza extrema?».
Global Citizen respondió: «Será un camino largo y difícil; a veces tropezaremos y fracasaremos».
Pero, al igual que los grandes movimientos por los derechos civiles y contra el apartheid que nos precedieron, lo conseguiremos, porque juntos somos más fuertes.
Janet Jackson, The Weeknd, Shawn Mendes, Cardi B y Janelle Monáe son algunos de los artistas que actuarán en la gala de este año en Nueva York, que será presentada por Deborra-Lee Furness y Hugh Jackman.
EE. UU. podría utilizar a la Armada para imponer un «bloqueo» que obstaculice las exportaciones energéticas rusas, según el secretario del Interior
Washington puede recurrir «si es necesario» a su Armada para impedir que la energía rusa llegue a los mercados, incluidos los de Oriente Medio, según ha revelado el secretario del Interior de EE. UU., Ryan Zinke, según cita el Washington Examiner.
Zinke afirmó que la intervención de Rusia en Siria —en particular, donde opera por invitación del Gobierno legítimo— es un pretexto para explorar nuevos mercados energéticos.
«Creo que la razón por la que están en Oriente Medio es que quieren actuar como intermediarios en el sector energético, tal y como hacen en Europa del Este, el corazón de Europa», habría declarado.
Y, según el funcionario, hay formas y medios para abordarlo.
«Estados Unidos tiene la capacidad, gracias a nuestra Armada, de garantizar que las rutas marítimas permanezcan abiertas y, si es necesario, de imponer un bloqueo para asegurarse de que su energía no llegue al mercado», afirmó.
Zinke se dirigía a los asistentes al acto organizado por la Consumer Energy Alliance, una organización sin ánimo de lucro que se autodenomina «la voz del consumidor de energía» en Estados Unidos.
Comparó los enfoques de Washington respecto a Rusia e Irán, señalando que, en la práctica, son idénticos.
«La opción económica respecto a Irán y Rusia consiste, más o menos, en aprovechar y sustituir los combustibles», afirmó, al tiempo que se refería a Rusia como un «país de un solo recurso», con una economía dependiente de los combustibles fósiles.
Estas declaraciones se producen en un momento en que la Administración Trump se ha propuesto impulsar la exportación de su gas natural licuado a Europa, sustituyendo a Rusia, que supone una opción mucho más económica para los consumidores europeos.
Con ese fin, los responsables de la Administración Trump, incluido el propio presidente de Estados Unidos, Donald Trump, intentan convencer a Alemania de que se retire del «inapropiado» proyecto del gasoducto Nord Stream 2, que, según Trump, ha convertido a Berlín en «rehén» de Moscú.
Moscú ha subrayado en repetidas ocasiones que el gasoducto Nord Stream 2, con un coste de 11 000 millones de dólares, que duplicará la capacidad actual del gasoducto hasta alcanzar los 110 000 millones de metros cúbicos, es un proyecto de carácter puramente económico.
El Kremlin sostiene que la ferviente oposición de Washington al proyecto obedece simplemente a motivos económicos y constituye un ejemplo de competencia desleal.
«Creo que compartimos la opinión de que la energía no puede ser un instrumento para ejercer presión y de que los consumidores deben poder elegir a sus proveedores», declaró el ministro de Energía ruso, Aleksandr Novak, tras una reunión con el secretario de Energía de EE. UU., Rick Perry, celebrada en Moscú en septiembre.
La postura de Estados Unidos ha suscitado una reacción negativa por parte de Alemania, que ha reafirmado su compromiso con el proyecto.
La principal organización industrial de Alemania, la Federación de Industrias Alemanas (BDI), ha instado a Estados Unidos a que no se entrometa en la política energética de la UE ni en los acuerdos bilaterales entre Berlín y Moscú.
«Me parece muy problemático que un tercer país interfiera en nuestro suministro energético», declaró Dieter Kempf, presidente de la Federación de Industrias Alemanas (BDI), tras una reciente reunión entre la canciller alemana, Angela Merkel, y el presidente ruso, Vladímir Putin.
Elizabeth Warren «considerará seriamente» presentarse a las elecciones presidenciales de 2020, según ha declarado la senadora por Massachusetts
La senadora de Massachusetts Elizabeth Warren declaró el sábado que estudiaría «seriamente» la posibilidad de presentarse a las elecciones presidenciales tras las elecciones de mitad de legislatura.
Durante un acto público celebrado en Holyoke, Massachusetts, Warren confirmó que se plantearía presentarse a las elecciones.
«Es hora de que las mujeres vayamos a Washington y arreglemos nuestro gobierno, que no funciona, y eso incluye tener a una mujer al frente», afirmó, según The Hill.
«A partir del 6 de noviembre, me plantearé seriamente la posibilidad de presentarme a las elecciones presidenciales».
Warren se pronunció sobre el presidente Donald Trump durante el foro público y afirmó que estaba «llevando a este país por el camino equivocado».
«Me preocupa profundamente lo que Donald Trump le está haciendo a nuestra democracia», afirmó.
Warren no ha dudado en criticar abiertamente a Trump y a su candidato al Tribunal Supremo, Brett Kavanaugh.
En un tuit publicado el viernes, Warren afirmó: «Por supuesto que necesitamos una investigación del FBI antes de votar».
Sin embargo, una encuesta publicada el jueves reveló que la mayoría de los propios electores de Warren no cree que deba presentarse a las elecciones de 2020.
El 58 % de los votantes «probables» de Massachusetts afirmó que el senador no debería presentarse, según la encuesta realizada por el Centro de Investigación Política de la Universidad de Suffolk y el Boston Globe.
El 32 % apoyaba esa candidatura.
La encuesta reveló un mayor apoyo a una posible candidatura del exgobernador Deval Patrick: el 38 % se mostraba a favor de ella y el 48 % en contra.
Otros nombres destacados del Partido Demócrata que se barajan para una posible candidatura en 2020 son el exvicepresidente Joe Biden y el senador de Vermont Bernie Sanders.
Según informó Associated Press, Biden afirmó que tomaría una decisión oficial en enero.
Sarah Palin menciona el trastorno de estrés postraumático de Track Palin en un mitin de Donald Trump
Track Palin, de 26 años, pasó un año en Irak tras alistarse el 9 de septiembre.
Fue detenido y acusado de un caso de violencia doméstica el lunes por la noche
«Lo que está pasando mi propio hijo, lo que está pasando al volver, me permite identificarme con otras familias que sufren las consecuencias del trastorno de estrés postraumático y algunas de las secuelas con las que regresan nuestros soldados», declaró ante el público en un mitin de Donald Trump en Tulsa, Oklahoma.
Palin calificó su detención como «el elefante en la habitación» y dijo sobre su hijo y otros veteranos de guerra: «Vuelven un poco cambiados, vuelven endurecidos, vuelven preguntándose si existe ese respeto por lo que sus compañeros soldados y aviadores, y todos los demás miembros de las Fuerzas Armadas, han dado al país».
Fue detenido el lunes en Wasilla (Alaska) y acusado de agresión por violencia doméstica contra una mujer, obstrucción de una denuncia de violencia doméstica y posesión de un arma en estado de embriaguez, según Dan Bennett, portavoz del Departamento de Policía de Wasilla.
18 estados y el Distrito de Columbia respaldan el recurso contra la nueva política de asilo
Dieciocho estados y el Distrito de Columbia respaldan un recurso judicial contra una nueva política estadounidense que deniega el asilo a las víctimas que huyen de la violencia de las bandas o de la violencia doméstica.
Representantes de los 18 estados y del Distrito de Columbia presentaron el viernes en Washington un escrito de amicus curiae para apoyar a un solicitante de asilo que impugna dicha política, según informó NBC News.
El nombre completo del demandante en el caso Grace contra Aún no se ha hecho pública la demanda que la Unión Americana por las Libertades Civiles presentó en agosto contra la política federal.
Ella afirmó que su pareja «y sus hijos, miembros de una banda violenta», la maltrataban, pero las autoridades estadounidenses denegaron su solicitud de asilo el 20 de julio.
La detuvieron en Texas.
Los fiscales estatales que defendían a Grace describieron a El Salvador, Honduras y Guatemala —países de donde procede un gran número de solicitantes de asilo en Estados Unidos— como naciones que se enfrentan a problemas generalizados de bandas y violencia doméstica.
La nueva política de asilo de Estados Unidos revocó una decisión de 2014 de la Junta de Apelaciones de Inmigración que permitía a los inmigrantes indocumentados que huían de la violencia doméstica solicitar asilo.
El fiscal general del Distrito de Columbia, Karl Racine, afirmó en un comunicado el viernes que la nueva política «ignora décadas de legislación estatal, federal e internacional».
«La legislación federal exige que todas las solicitudes de asilo se resuelvan en función de los hechos y circunstancias concretos de cada caso, y esa restricción vulnera ese principio», se afirma en el escrito de amicus curiae.
Los abogados argumentaron además en el escrito que la política que niega la entrada a los inmigrantes perjudica a la economía estadounidense, alegando que estos tienen más probabilidades de convertirse en empresarios y de «aportar la mano de obra necesaria».
En junio, el fiscal general Jeff Sessions ordenó a los jueces de inmigración que dejaran de conceder asilo a las víctimas que huían de la violencia doméstica y la violencia de las bandas.
«Se concede asilo a quienes abandonan su país de origen debido a la persecución o al temor por motivos de raza, religión, nacionalidad, pertenencia a un determinado grupo social u opiniones políticas», declaró Sessions en su anuncio de la política, el 11 de junio.
El asilo nunca tuvo por objeto resolver todos los problemas —ni siquiera todos los problemas graves— a los que se enfrentan las personas cada día en todo el mundo.
Esfuerzos desesperados de rescate en Palu, mientras el número de víctimas mortales se duplica en la carrera por encontrar supervivientes
Para los supervivientes, la situación se volvía cada vez más grave.
«Se respira un ambiente muy tenso», dijo Risa Kusuma, una madre de 35 años, mientras consolaba a su bebé, que tenía fiebre, en un centro de evacuación de la ciudad de Palu, reducida a escombros.
«Cada minuto llega una ambulancia con cadáveres.
«El agua potable escasea».
Se vio a los residentes regresar a sus hogares destruidos, rebuscando entre sus pertenencias empapadas, tratando de salvar todo lo que pudieran encontrar.
Cientos de personas resultaron heridas y los hospitales, dañados por el terremoto de magnitud 7,5, se vieron desbordados.
Algunos de los heridos, entre ellos Dwi Haris, que sufrió fracturas en la espalda y el hombro, descansaban frente al Hospital Militar de Palu, donde se atendía a los pacientes al aire libre debido a las fuertes réplicas que seguían produciéndose.
Se le llenaron los ojos de lágrimas al recordar cómo el violento terremoto sacudió la habitación del hotel en la quinta planta que compartía con su mujer y su hija.
«No hubo tiempo para ponernos a salvo.
«Creo que quedé atrapado entre las ruinas de la muralla», declaró Haris a Associated Press, y añadió que su familia se encontraba en la ciudad para asistir a una boda.
«Oí a mi mujer pedir ayuda, pero luego se hizo el silencio.
No sé qué les ha pasado a ella y a mi hijo.
Espero que estén bien.
El embajador de EE. UU. acusa a China de «intimidación» mediante «anuncios propagandísticos»
Una semana después de que un periódico oficial chino publicara un anuncio de cuatro páginas en un diario estadounidense en el que se ensalzaban los beneficios mutuos del comercio entre Estados Unidos y China, el embajador de Estados Unidos en China acusó a Pekín de utilizar la prensa estadounidense para difundir propaganda.
El pasado miércoles, el presidente de Estados Unidos, Donald Trump, se refirió al suplemento pagado por el China Daily que se publica en el Des Moines Register —el periódico de mayor tirada del estado de Iowa— tras acusar a China de intentar interferir en las elecciones al Congreso de Estados Unidos del 6 de noviembre, una acusación que China niega.
La acusación de Trump de que Pekín estaba intentando interferir en las elecciones estadounidenses marcó, según declararon funcionarios estadounidenses a Reuters, una nueva fase en la campaña cada vez más intensa de Washington para ejercer presión sobre China.
Aunque es habitual que los gobiernos extranjeros publiquen anuncios para promover el comercio, Pekín y Washington se encuentran actualmente enzarzados en una guerra comercial cada vez más intensa, en la que se han impuesto mutuamente sucesivas rondas de aranceles sobre sus respectivas importaciones.
Según expertos chinos y estadounidenses, los aranceles de represalia impuestos por China al inicio de la guerra comercial estaban destinados a afectar a los exportadores de estados como Iowa, que apoyaron al Partido Republicano de Trump.
Terry Branstad, embajador de Estados Unidos en China y antiguo gobernador de Iowa —uno de los principales exportadores de productos agrícolas a China—, afirmó que Pekín había perjudicado a los trabajadores, agricultores y empresas estadounidenses.
«China —escribió Branstad en un artículo de opinión publicado el domingo en el Des Moines Register— está ahora redoblando esa intimidación mediante la publicación de anuncios propagandísticos en nuestra propia prensa libre».
«Para difundir su propaganda, el Gobierno chino se está aprovechando de la preciada tradición estadounidense de la libertad de expresión y de prensa al publicar un anuncio pagado en el Des Moines Register», escribió Branstad.
«Por el contrario, en el quiosco que hay al final de la calle aquí en Pekín, «Encontrarás pocas voces discrepantes y no verás un reflejo fiel de las opiniones dispares que el pueblo chino pueda tener sobre la preocupante trayectoria económica de China, dado que los medios de comunicación están bajo el férreo control del Partido Comunista Chino», escribió.
Añadió que «uno de los periódicos más destacados de China rechazó la oferta de publicar» su artículo, aunque no especificó de qué periódico se trataba.
Los republicanos están alejando a las votantes femeninas de cara a las elecciones de mitad de legislatura debido al escándalo de Kavanaugh, advierten los analistas
Mientras muchos líderes republicanos siguen apoyando y defendiendo al candidato al Tribunal Supremo Brett Kavanaugh ante las diversas acusaciones de agresión sexual, los analistas han advertido de que se producirá una reacción negativa, especialmente por parte de las mujeres, durante las próximas elecciones de mitad de legislatura.
Las emociones que rodean este asunto han sido muy intensas, y la mayoría de los republicanos ya han dejado claro que querían seguir adelante con la votación.
«Esas cosas no se pueden deshacer», declaró Grant Reeher, profesor de Ciencias Políticas de la Escuela Maxwell de la Universidad de Siracusa, al diario The Hill para un artículo publicado el sábado.
Reeher dijo que duda de que la iniciativa de última hora del senador Jeff Flake (republicano por Arizona) para que se lleve a cabo una investigación del FBI sea suficiente para calmar a los votantes indignados.
«Las mujeres no van a olvidar lo que ocurrió ayer; no lo van a olvidar mañana ni en noviembre,«Karine Jean-Pierre, asesora principal y portavoz nacional del grupo progresista MoveOn, declaró el viernes, según el periódico de Washington D. C.».
El viernes por la mañana, Los manifestantes coreaban «¡Se acerca noviembre!» mientras se manifestaban en el pasillo del Senado, en un momento en que los republicanos que controlan la Comisión Judicial decidieron seguir adelante con la nominación de Kavanaugh a pesar del testimonio de la Dra. Christine Blasey Ford, según informó Mic.
«El entusiasmo y la motivación de los demócratas van a ser desmesurados», declaró Stu Rothenberg, analista político independiente, al sitio web de noticias.
«La gente dice que ya ha estado alto; eso es cierto.
«Pero podría ser mayor, sobre todo entre las votantes indecisas de los barrios periféricos y los votantes más jóvenes, de entre 18 y 29 años, que, aunque no les gusta el presidente, a menudo no votan».
Incluso antes de que Ford prestara testimonio público para detallar sus acusaciones de agresión sexual contra el candidato al Tribunal Supremo, los analistas ya apuntaban a que podría producirse una reacción negativa si los republicanos seguían adelante con el proceso de confirmación.
«Esto se ha convertido en un auténtico lío para el Partido Republicano», declaró Michael Steele, expresidente del Comité Nacional Republicano, a principios de la semana pasada, según NBC News.
«No se trata solo de la votación en comisión o de la votación final, ni de si Kavanaugh llega a ocupar el puesto de juez, «También tiene que ver con la forma en que los republicanos han gestionado esto y cómo la han tratado», señaló Guy Cecil, director de Priorities USA, una organización que apoya la elección de candidatos demócratas, al canal de noticias.
Sin embargo, los estadounidenses parecen estar algo divididos sobre a quién creer tras los testimonios de Ford y Kavanaugh, aunque son ligeramente más los que se inclinan por este último.
Una nueva encuesta de YouGov revela que el 41 % de los encuestados creía «definitivamente» o «probablemente» en el testimonio de Ford, mientras que el 35 % afirmó que creía «definitivamente» o «probablemente» en el de Kavanaugh.
Además, el 38 % afirmó que creía que Kavanaugh probablemente o sin duda había mentido durante su testimonio, mientras que solo el 30 % opinaba lo mismo de Ford.
Tras la presión ejercida por Flake, el FBI está investigando actualmente las denuncias presentadas por Ford y por al menos otra denunciante, Deborah Ramírez, según informó The Guardian.
Ford declaró bajo juramento ante la Comisión Judicial del Senado la semana pasada que Kavanaugh la agredió sexualmente cuando estaba ebrio y ella tenía 17 años.
Ramírez afirma que el candidato al Tribunal Supremo le mostró sus genitales mientras asistían a una fiesta durante sus años de estudios en Yale en la década de 1980.
El inventor de la World Wide Web planea lanzar una nueva red para plantar cara a Google y Facebook
Tim Berners-Lee, el inventor de la World Wide Web, está poniendo en marcha una startup que pretende competir con Facebook, Amazon y Google.
El último proyecto de esta leyenda de la tecnología, Inrupt, es una empresa que se basa en Solid, la plataforma de código abierto de Berners-Lee.
Solid permite a los usuarios elegir dónde se almacenan sus datos y qué personas pueden acceder a qué información.
En una entrevista exclusiva con Fast Company, Berners-Lee bromeó diciendo que el objetivo de Inrupt es «la dominación mundial».
«Tenemos que hacerlo ahora», dijo refiriéndose a la startup.
«Es un momento histórico».
La aplicación utiliza la tecnología de Solid para permitir a los usuarios crear su propio «almacén personal de datos en línea» o POD.
Puede incluir listas de contactos, listas de tareas pendientes, un calendario, una biblioteca musical y otras herramientas personales y profesionales.
Es como si Google Drive, Microsoft Outlook, Slack y Spotify estuvieran disponibles en un solo navegador y todos al mismo tiempo.
Lo que hace único al almacén de datos personales en línea es que es el usuario quien decide totalmente quién puede acceder a qué tipo de información.
La empresa lo denomina «empoderamiento personal a través de los datos».
Según John Bruce, director ejecutivo de la empresa, la idea de Inrupt es que la empresa aporte los recursos, los procesos y las competencias necesarias para que Solid esté al alcance de todos.
En la actualidad, la empresa está formada por Berners-Lee, Bruce, una plataforma de seguridad adquirida por IBM, algunos desarrolladores internos contratados para trabajar en el proyecto y una comunidad de programadores voluntarios.
A partir de esta semana, los desarrolladores de todo el mundo podrán crear sus propias aplicaciones descentralizadas utilizando las herramientas disponibles en el sitio web de Inrupt.
Berners-Lee afirmó que ni él ni su equipo están hablando con «Facebook y Google sobre si introducir o no un cambio radical que dé un vuelco total a todos sus modelos de negocio de la noche a la mañana».
«No les estamos pidiendo permiso».
En una entrada publicada el sábado en Medium, Berners-Lee escribió que «la misión de Inrupt es aportar el impulso comercial y un ecosistema que ayuden a proteger la integridad y la calidad de la nueva web construida sobre Solid».
En 1994, Berners-Lee revolucionó Internet al fundar el Consorcio de la World Wide Web en el Instituto Tecnológico de Massachusetts.
En los últimos meses, Berners-Lee ha sido una voz influyente en el debate sobre la neutralidad de la red.
A pesar de haber puesto en marcha Inrupt, Berners-Lee seguirá siendo fundador y director del World Wide Web Consortium, la Web Foundation y el Open Data Institute.
«Me siento increíblemente optimista respecto a esta nueva era de la web», añadió Berners-Lee.
Bernard Vann: homenaje al clérigo condecorado con la Cruz Victoria en la Primera Guerra Mundial
El único clérigo de la Iglesia de Inglaterra que recibió la Cruz Victoria durante la Primera Guerra Mundial por su participación en combate ha sido homenajeado en su ciudad natal cien años después.
El teniente coronel y reverendo Bernard Vann recibió la condecoración el 29 de septiembre de 1918 durante el ataque a Bellenglise y Lehaucourt.
Sin embargo, cuatro días después fue abatido por un francotirador y nunca llegó a saber que había recibido la más alta condecoración militar británica.
El sábado, sus dos nietos descubrieron una placa conmemorativa durante un desfile celebrado en Rushden, Northamptonshire.
Uno de sus nietos, Michael Vann, afirmó que era «magníficamente simbólico» que la lápida se inaugurara exactamente 100 años después de la hazaña galardonada de su abuelo.
Según la London Gazette, el 29 de septiembre de 1918, el teniente coronel Vann condujo a su batallón a través del Canal de Saint-Quentin «en medio de una espesa niebla y bajo un intenso fuego de cañones y ametralladoras».
Más tarde se lanzó hacia la línea de fuego y, con «gran valentía», condujo a la tropa hacia delante antes de abalanzarse en solitario contra un cañón de campaña y acabar con tres miembros del destacamento.
El teniente coronel Vann fue abatido por un francotirador alemán el 4 de octubre de 1918, poco más de un mes antes de que terminara la guerra.
Michael Vann, de 72 años, afirmó que las acciones de su abuelo eran «algo a lo que sé que nunca podría estar a la altura, pero que me hace sentir humilde».
Él y su hermano, el Dr. James Vann, también depositaron una corona de flores tras el desfile, que fue encabezado por la Brentwood Imperial Youth Band.
Michael Vann afirmó que se sentía «muy honrado de participar en el desfile» y añadió: «El valor de un auténtico héroe queda patente en el apoyo que le van a brindar tantas personas».
Los aficionados al MMA se quedaron despiertos toda la noche para ver Bellator 206, pero en su lugar se encontraron con Peppa Pig
Imagina esto: te has quedado despierto toda la noche para ver el Bellator 206, que prometía estar repleto, y al final no has podido ver el combate estelar.
La cartelera de San José incluía 13 combates, seis de ellos en la cartelera principal, y se retransmitió en directo durante toda la noche en el Reino Unido a través de Channel 5.
A las 6 de la mañana, justo cuando Gegard Mousasi y Rory MacDonald se disponían a enfrentarse, los espectadores del Reino Unido se quedaron atónitos al ver que la retransmisión pasaba a emitir «Peppa Pig».
A algunos no les hizo mucha gracia, sobre todo porque se habían quedado despiertos hasta altas horas de la madrugada expresamente para ver el combate.
Un seguidor en Twitter calificó el cambio a la serie infantil como «una especie de broma de mal gusto».
«La normativa gubernamental establece que, a las 6 de la mañana, ese contenido no era adecuado, por lo que tuvieron que pasar a emitir programación infantil», explicó Dave Schwartz, vicepresidente sénior de marketing y comunicación de Bellator, cuando se le preguntó sobre la emisión.
«"Peppa, la cerdita", sí».
El presidente de Bellator, Scott Coker, ha declarado que van a ajustar su programación para incluir a los espectadores del Reino Unido en el futuro.
«Creo que, al repasar la jugada, probablemente podamos resolverlo», dijo Coker.
«Pero allí son las seis de la mañana de un domingo y no podremos resolver esto hasta el domingo, que es lunes en su zona horaria».
Pero estamos trabajando en ello.
Créeme, cuando se produjo el cambio, hubo un montón de mensajes de un lado a otro y no todos eran precisamente amables.
Estábamos intentando solucionarlo, pensábamos que se trataba de un fallo técnico.
Pero no era así, se trataba de un asunto gubernamental.
Te prometo que la próxima vez no volverá a pasar.
Nos limitaremos a cinco combates en lugar de seis —como solemos hacer—; intentamos darlo todo para los aficionados y nos hemos pasado un poco.
«Es una situación lamentable».
Desert Island Discs: Tom Daley se sentía «inferior» por su orientación sexual
El saltador olímpico Tom Daley afirma que creció sintiéndose inferior a los demás debido a su orientación sexual, pero eso le dio la motivación necesaria para alcanzar el éxito.
El joven de 24 años dijo que no se dio cuenta hasta que llegó al instituto de que «no todo el mundo es como yo».
En su primera aparición en el programa «Desert Island Discs» de Radio 4, presentado por Lauren Laverne, afirmó que se pronunció a favor de los derechos de los homosexuales para dar «esperanza» a los demás.
También dijo que, desde que se convirtió en padre, le importaba menos ganar los Juegos Olímpicos.
La presentadora habitual del programa, que lleva muchos años en antena, Kirsty Young, se ha tomado unos meses de baja por enfermedad.
Daley, que participó como concursante en el primer programa de Laverne, dijo que de pequeño se sentía «inferior» al resto porque «no estaba socialmente aceptado que te gustaran tanto los chicos como las chicas».
Dijo: «Hasta el día de hoy, esos sentimientos de inferioridad y de ser diferente han sido precisamente lo que me ha dado el poder y la fuerza para poder triunfar».
Quería demostrar que era «alguien», dijo, para no decepcionar a nadie cuando finalmente se enteraran de su orientación sexual.
El dos veces medallista olímpico de bronce se ha convertido en un destacado activista LGBT y aprovechó su participación en los Juegos de la Commonwealth de este año, celebrados en Australia, para hacer un llamamiento a que más países despenalicen la homosexualidad.
Dijo que había decidido hablar porque se sentía afortunado de poder vivir abiertamente sin sufrir represalias y quería dar «esperanza» a los demás.
El tres veces campeón del mundo afirmó que enamorarse de un hombre —el cineasta estadounidense Dustin Lance Black, a quien conoció en 2013— «me pilló por sorpresa».
Daley se casó el año pasado con la ganadora del Óscar, veinte años mayor que él, pero afirmó que la diferencia de edad nunca había sido un problema.
«Cuando pasas por tantas cosas a una edad tan temprana» —participó en sus primeros Juegos Olímpicos con 14 años y su padre falleció de cáncer tres años después— dijo que le resultaba difícil encontrar a alguien de su misma edad que hubiera vivido altibajos similares.
La pareja tuvo un hijo en junio, al que llamaron Robert Ray Black-Daley, y Daley afirmó que su «forma de ver las cosas» había cambiado por completo.
«Si me hubieras preguntado el año pasado, lo único que me importaba era "tengo que ganar una medalla de oro"», dijo.
«¿Sabes qué? Hay cosas más importantes que las medallas de oro olímpicas.
«Mi medalla de oro olímpica es Robbie».
Su hijo se llama igual que su padre, Robert, quien falleció en 2011 a los 40 años tras serle diagnosticado un cáncer cerebral.
Daley contó que su padre no aceptaba que iba a morir y que una de las últimas cosas que había preguntado era si ya tenían las entradas para Londres 2012, ya que quería estar en primera fila.
«No podía decirle: "Papá, no vas a estar aquí para sentarte en primera fila"», dijo.
«Le cogí la mano cuando dejó de respirar, y no fue hasta que realmente dejó de respirar y ya había fallecido cuando por fin me di cuenta de que no era invencible», dijo.
Al año siguiente, Daley participó en los Juegos Olímpicos de 2012 y ganó la medalla de bronce.
«Sabía que eso era lo que había soñado toda mi vida: saltar ante mi público en unos Juegos Olímpicos; no había mejor sensación», afirmó.
Esto también inspiró su elección de la primera canción —«Proud», de Heather Small—, que le había llegado al corazón durante los preparativos para los Juegos Olímpicos y que todavía le ponía la piel de gallina.
«Desert Island Discs» se emite en BBC Radio 4 los domingos a las 11:15 (hora británica).
Mickelson, en baja forma, se queda en el banquillo el sábado de la Ryder Cup
El estadounidense Phil Mickelson batirá un récord el domingo al disputar su 47.º partido de la Ryder Cup, pero tendrá que mejorar su rendimiento para evitar que se convierta en un hito amargo.
Mickelson, que participaba en este torneo bienal por duodécima vez —un récord—, fue dejado en el banquillo por el capitán Jim Furyk para las pruebas de fourballs y foursomes del sábado.
En lugar de estar en el centro de la acción, como tantas otras veces lo ha estado para Estados Unidos, el cinco veces ganador de un Grand Slam dividió su jornada entre animar a sus compañeros y trabajar su juego en el campo de prácticas, con la esperanza de solucionar lo que le está fallando.
Aunque nunca ha destacado precisamente por la precisión de sus golpes, ni siquiera en el mejor momento de su carrera, este jugador de 48 años no es el candidato ideal para el estrecho campo de Le Golf National, donde el rough alto castiga habitualmente los golpes desviados.
Y por si el campo no fuera ya de por sí lo suficientemente intimidante, Mickelson se enfrentará, en el noveno partido del domingo, al certero campeón del Abierto Británico, Francesco Molinari, quien, junto al novato Tommy Fleetwood, ha ganado los cuatro partidos que han disputado esta semana.
Si los estadounidenses, que empiezan con cuatro puntos de desventaja al inicio de los 12 partidos individuales, logran arrancar con fuerza, el partido de Mickelson podría resultar absolutamente decisivo.
Furyk se mostró confiado en su jugador, aunque tampoco es que pudiera decir gran cosa más.
«Entendió perfectamente el papel que le correspondía hoy, me dio una palmada en la espalda, me rodeó con el brazo y me dijo que mañana estaría listo», afirmó Furyk.
«Tiene mucha confianza en sí mismo».
Es miembro del Salón de la Fama y ha aportado muchísimo a estos equipos, tanto en el pasado como esta semana.
Probablemente no me imaginaba que jugaría dos partidos.
Tenía otras ideas en mente, pero así es como salió y pensamos que teníamos que hacerlo así.
«Quiere estar ahí fuera, como todos los demás».
Mickelson superará el domingo el récord de Nick Faldo de más partidos disputados en la Ryder Cup.
Podría suponer el final de una carrera en la Ryder Cup que nunca ha llegado a alcanzar las cotas de su palmarés individual.
Mickelson cuenta con 18 victorias, 20 derrotas y siete empates, aunque Furyk afirmó que su presencia aportó ciertos valores intangibles al equipo.
«Es divertido, sarcástico, ingenioso, le gusta burlarse de la gente y es un tipo estupendo para tenerlo en la sala del equipo», explicó.
«Creo que los jugadores más jóvenes también se lo pasaron bien metiéndole caña esta semana, y fue divertido verlo».
«Ofrece mucho más que solo diversión».
El capitán del equipo europeo, Thomas Bjorn, sabe que una ventaja considerable puede desaparecer en cualquier momento
Thomas Bjorn, el capitán del equipo europeo, sabe por experiencia que una ventaja considerable al llegar a los partidos individuales del último día de la Ryder Cup puede convertirse fácilmente en una situación incómoda.
El danés debutó en la edición de 1997, disputada en Valderrama, donde el equipo capitaneado por Seve Ballesteros partía con una ventaja de cinco puntos sobre los estadounidenses, pero acabó imponiéndose por la mínima, con un resultado de 14½ a 13½.
«No dejas de recordarte a ti mismo que teníamos una gran ventaja en Valderrama; «Teníamos una gran ventaja en Brookline, donde perdimos, y en Valderrama, donde ganamos, aunque por muy poco», declaró Bjorn, en la foto, tras ver cómo la promoción de 2018 se imponía por 5-3 tanto el viernes como ayer, lo que les sitúa con una ventaja de 10-6 en Le Golf National.
Así que la historia nos demostrará a mí y a todos los miembros de ese equipo que esto no ha terminado.
Mañana vas a darlo todo.
Sal ahí fuera y haz todo lo que hay que hacer.
Esto no se acaba hasta que hayas sumado los puntos.
Tenemos un objetivo, que es intentar ganar este trofeo, y ahí es donde centramos toda nuestra atención.
«Siempre he dicho que me centro en los doce jugadores que forman parte de nuestro equipo, pero somos muy conscientes de lo que tenemos al otro lado del campo: los mejores jugadores del mundo».
Encantado con el rendimiento de sus jugadores en un campo de golf tan exigente, Bjorn añadió: «Nunca me precipitaría en esto».
Mañana será otra historia.
Mañana toca las actuaciones individuales, y eso es algo diferente.
Es fantástico jugar con un compañero cuando las cosas van bien, pero cuando juegas en solitario, se pone a prueba todo tu potencial como golfista.
Ese es el mensaje que debéis transmitir a los jugadores: que mañana den lo mejor de sí mismos.
«Ahora, tú dejas atrás a tu pareja y él también tiene que esforzarse al máximo».
A diferencia de Bjorn, su homólogo Jim Furyk esperará que sus jugadores rindan mejor a nivel individual que como pareja, con la excepción de Jordan Spieth y Justin Thomas, que sumaron tres de los cuatro puntos.
El propio Furyk ha vivido ambos extremos de esos grandes giros en la última jornada, ya que formó parte del equipo ganador en Brookline antes de acabar entre los perdedores cuando Europa logró el «Milagro de Medinah».
«Me acuerdo de cada maldita palabra», respondió cuando le preguntaron cómo había animado Ben Crenshaw, el capitán de 1999, a sus jugadores de cara a la última jornada.
«Mañana nos esperan 12 partidos importantes, pero nos gustaría empezar con ese empuje que se vio en Brookline y en Medinah».
Cuando ese impulso se inclina hacia un lado, ejerce mucha presión sobre los partidos intermedios.
«Hemos configurado nuestra alineación en consecuencia y hemos sacado a los chicos al campo tal y como nos parecía mejor; ya sabes, intentamos hacer magia mañana».
A Thomas le ha tocado el reto de intentar liderar la remontada y se enfrentará a Rory McIlroy en el partido estrella; Paul Casey, Justin Rose, Jon Rahm, Tommy Fleetwood e Ian Poulter son los demás europeos que figuran en la mitad superior del cuadro.
«He elegido a este grupo de jugadores en este orden porque creo que así se cubre todo el espectro», dijo Bjorn sobre su selección de individuales.
El nuevo buque de guerra alemán se pospone una vez más
La fragata más nueva de la Armada alemana debería haber entrado en servicio en 2014 para sustituir a los buques de guerra obsoletos de la época de la Guerra Fría, pero no estará lista hasta, como mínimo, el año que viene debido a fallos en los sistemas y a un aumento vertiginoso de los costes, según informaron los medios locales.
La puesta en servicio del «Rheinland-Pfalz», el buque insignia de la nueva clase de fragatas Baden-Wuerttemberg, se ha pospuesto hasta el primer semestre de 2019, según informa el periódico *Die Zeit* citando a un portavoz militar.
El buque debería haberse incorporado a la Armada en 2014, pero los preocupantes problemas surgidos tras su entrega lastraron el destino de este ambicioso proyecto.
Los cuatro buques de la clase Baden-Wuerttemberg que la Armada encargó en 2007 sustituirán a las fragatas de la clase Bremen, que se están quedando obsoletas.
Se da por hecho que contarán con un potente cañón, una serie de misiles antiaéreos y antibuque, así como algunas tecnologías de sigilo, como la reducción de la firma radar, infrarroja y acústica.
Otras características importantes son los periodos de mantenimiento más prolongados: debería ser posible desplegar las fragatas más modernas durante un máximo de dos años lejos de sus puertos de origen.
Sin embargo, los continuos retrasos hacen que estos buques de guerra de última generación —que, según se dice, permitirían a Alemania proyectar su poder en el extranjero— ya estén obsoletos para cuando entren en servicio, señala *Die Zeit*.
La desafortunada fragata F125 fue noticia el año pasado, cuando la Armada alemana se negó oficialmente a ponerla en servicio y la devolvió al astillero Blohm & Voss de Hamburgo.
Era la primera vez que la Armada devolvía un buque al astillero tras su entrega.
Se sabía poco sobre los motivos del regreso, pero los medios de comunicación alemanes señalaron una serie de «defectos de software y hardware» graves que hacían que el buque de guerra resultara inútil si se le asignaba una misión de combate.
Las deficiencias del software revestían especial importancia, ya que los buques de la clase Baden-Wuerttemberg serán tripulados por unos 120 marineros, apenas la mitad de la dotación de las fragatas más antiguas de la clase Bremen.
Además, se ha sabido que el buque tiene un exceso de peso considerable, lo que reduce su rendimiento y limita la capacidad de la Armada para incorporar futuras mejoras.
Se cree que el «Rheinland-Pfalz», de 7.000 toneladas, pesa el doble que los buques de clase similar utilizados por los alemanes durante la Segunda Guerra Mundial.
Además de los fallos de hardware, el coste total del proyecto —incluida la formación de la tripulación— también se está convirtiendo en un problema.
Se dice que ha alcanzado la asombrosa cifra de 3.100 millones de euros (3.600 millones de dólares), frente a los 2.200 millones de euros iniciales.
Los problemas que afectan a las fragatas más modernas cobran especial relevancia a la luz de las recientes advertencias sobre la disminución del poderío naval de Alemania.
A principios de este año, Hans-Peter Bartels, presidente de la Comisión de Defensa del Parlamento alemán, reconoció que la Armada se está quedando «sin buques aptos para el despliegue».
El funcionario señaló que el problema se ha agravado con el tiempo, ya que se retiraron de servicio los buques antiguos sin que se proporcionaran otros para sustituirlos.
Lamentó que ninguna de las fragatas de la clase Baden-Wuerttemberg pudiera incorporarse a la Armada.
El National Trust espía la vida secreta de los murciélagos
Una nueva investigación que se está llevando a cabo en una finca de las Tierras Altas de Escocia tiene como objetivo descubrir cómo utilizan los murciélagos el paisaje en su búsqueda de alimento.
Se espera que los resultados arrojen nueva luz sobre el comportamiento de estos mamíferos voladores únicos y contribuyan a orientar las futuras actividades de conservación.
El estudio, llevado a cabo por científicos del National Trust for Scotland, hará un seguimiento de los murciélagos comunes y sopranos, así como de los murciélagos orejudos pardos y los murciélagos de Daubenton, en los jardines de Inverewe, en Wester Ross.
Se instalarán grabadoras especiales en puntos estratégicos de la finca para hacer un seguimiento de la actividad de los murciélagos a lo largo de la temporada.
El personal y los voluntarios del NHS también realizarán inspecciones itinerantes utilizando detectores portátiles.
Un análisis acústico especializado de todas las grabaciones permitirá determinar la frecuencia de los ultrasonidos de los murciélagos y qué especies emiten cada tipo de sonido.
A continuación, se elaborarán un mapa de hábitats y un informe para obtener una visión detallada de su comportamiento a escala paisajística.
Rob Dewar, asesor de conservación de la naturaleza de NTS, espera que los resultados revelen qué zonas del hábitat son más importantes para los murciélagos y cómo las utiliza cada una de las especies.
Esta información ayudará a determinar los beneficios de las medidas de gestión del hábitat, como la creación de praderas, y cuál es la mejor forma de conservar los bosques para los murciélagos y otras especies asociadas.
Las poblaciones de murciélagos en Escocia y en todo el Reino Unido han disminuido considerablemente durante el último siglo.
Se ven amenazadas por las obras de construcción y urbanización, que afectan a sus lugares de descanso y provocan la pérdida de hábitat.
Las turbinas eólicas y el alumbrado también pueden suponer un riesgo, al igual que los papeles adhesivos para moscas y algunos tratamientos químicos de los materiales de construcción, así como los ataques de los gatos domésticos.
En realidad, los murciélagos no son ciegos.
Sin embargo, debido a sus hábitos de caza nocturnos, sus oídos les resultan más útiles que sus ojos a la hora de capturar presas.
Utilizan una sofisticada técnica de ecolocalización para detectar insectos y obstáculos en su trayectoria de vuelo.
El NTS, responsable del mantenimiento de más de 270 edificios históricos, 38 jardines de importancia y 76 000 hectáreas de terreno en todo el país, se toma muy en serio la cuestión de los murciélagos.
Cuenta con diez expertos cualificados que realizan periódicamente estudios, inspecciones de los lugares de descanso y, en ocasiones, rescates.
La organización ha creado incluso la primera y única reserva dedicada exclusivamente a los murciélagos de Escocia, situada en la finca de Threave, en Dumfries y Galloway, donde habitan ocho de las diez especies de murciélagos de Escocia.
El administrador de la finca, David Thompson, afirma que la finca es el lugar ideal para ellos.
«Aquí en Threave tenemos una zona estupenda para los murciélagos», dijo.
«Tenemos edificios antiguos, muchos árboles centenarios y un hábitat ideal.
«Pero aún hay mucho que desconocemos sobre los murciélagos, por lo que el trabajo que realizamos aquí y en otras fincas nos ayudará a comprender mejor qué necesitan para prosperar».
Destaca la importancia de comprobar si hay murciélagos antes de realizar trabajos de mantenimiento en las propiedades, ya que la destrucción involuntaria de un solo refugio de cría podría acabar con la vida de hasta 400 hembras y crías, lo que podría provocar la desaparición de toda una población local.
Los murciélagos están protegidos y es ilegal matarlos, acosarlos o molestarlos, así como destruir sus refugios.
Elisabeth Ferrell, responsable para Escocia de la organización Bat Conservation Trust, ha animado a la ciudadanía a colaborar.
Dijo: «Todavía nos queda mucho por aprender sobre nuestros murciélagos y, en el caso de muchas de nuestras especies, simplemente no sabemos cómo están evolucionando sus poblaciones».
Ronaldo desmiente las acusaciones de violación mientras sus abogados se disponen a demandar a una revista alemana
Cristiano Ronaldo ha calificado las acusaciones de violación en su contra de «noticias falsas» y ha afirmado que hay gente que «quiere darse a conocer» utilizando su nombre.
Sus abogados tienen previsto demandar a la revista alemana Der Spiegel, que publicó las acusaciones.
El delantero de la selección portuguesa y de la Juventus ha sido acusado de violar a una mujer estadounidense, llamada Kathryn Mayorga, en una habitación de hotel de Las Vegas en 2009.
Según informó el viernes la revista *Der Spiegel*, se le acusa de haberle pagado posteriormente 375 000 dólares para que guardara silencio sobre el incidente.
En un vídeo en directo de Instagram dirigido a sus 142 millones de seguidores, horas después de que se hicieran públicas las acusaciones, Ronaldo, de 33 años, tachó las informaciones de «noticias falsas».
«No, no, no, no, no.
«Lo que han dicho hoy son noticias falsas», afirma ante la cámara el cinco veces ganador del Balón de Oro.
«Quieren promocionarse utilizando mi nombre».
Es normal.
Quieren ser famosos para que se mencione mi nombre, pero eso forma parte del trabajo.
«Soy un hombre feliz y todo me va bien», añadió el jugador, sonriendo.
Los abogados de Ronaldo se disponen a demandar a Der Spiegel por estas acusaciones, que han calificado de «una información inadmisible sobre sospechas en el ámbito de la intimidad», según Reuters.
El abogado Christian Schertz afirmó que el jugador reclamaría una indemnización por «daños morales por un importe acorde con la gravedad de la infracción, que probablemente sea una de las violaciones más graves de los derechos personales de los últimos años».
Al parecer, el supuesto incidente tuvo lugar en junio de 2009 en una suite del Palms Hotel and Casino de Las Vegas.
Según los documentos presentados ante el Tribunal de Distrito del condado de Clark, en Nevada, tras conocerse en una discoteca, Ronaldo y Mayorga se habrían retirado a la habitación del futbolista, donde él presuntamente la violó por vía anal.
Mayorga afirma que Ronaldo se arrodilló tras el supuesto incidente y le dijo que era «en un 99 %» un «buen tipo» al que había fallado «ese 1 %».
Según los documentos, Ronaldo confirmó que mantuvieron relaciones sexuales, pero que fueron consentidas.
Mayorga también afirma que acudió a la policía y que le tomaron fotografías de sus lesiones en un hospital, pero que más tarde aceptó un acuerdo extrajudicial porque se sentía «aterrorizada ante posibles represalias» y le preocupaba «ser humillada públicamente».
Esta mujer de 34 años afirma que ahora pretende anular el acuerdo, ya que sigue traumatizada por el supuesto incidente.
En el momento de la presunta agresión, Ronaldo estaba a punto de fichar por el Real Madrid procedente del Manchester United, y este verano se incorporó al Juventus, uno de los grandes clubes italianos, en una operación de 100 millones de euros.
Brexit: el Reino Unido «lamentaría para siempre» la pérdida de los fabricantes de automóviles
El Reino Unido «se arrepentiría para siempre» si perdiera su condición de líder mundial en la fabricación de automóviles tras el Brexit, según ha afirmado el secretario de Comercio, Greg Clark.
Añadió que era «preocupante» que Toyota Reino Unido hubiera comunicado a la BBC que, si el Reino Unido abandonaba la UE sin acuerdo, detendría temporalmente la producción en su fábrica de Burnaston, cerca de Derby.
«Necesitamos llegar a un acuerdo», dijo el Sr. Clark.
El fabricante de automóviles japonés afirmó que las retrasos en las fronteras en caso de un Brexit sin acuerdo podrían provocar la pérdida de puestos de trabajo.
La planta de Burnaston —donde se fabrican los modelos Auris y Avensis de Toyota— produjo el año pasado cerca de 150 000 coches, de los cuales el 90 % se exportó al resto de la Unión Europea.
«Mi opinión es que, si el Reino Unido sale de la UE sin acuerdo a finales de marzo, se producirán paradas en nuestra fábrica», afirmó Marvin Cooke, director general de Toyota en Burnaston.
Otros fabricantes de automóviles del Reino Unido han expresado su preocupación por la posibilidad de salir de la UE sin un acuerdo sobre cómo funcionará el comercio transfronterizo, entre ellos Honda, BMW y Jaguar Land Rover.
BMW, por ejemplo, afirma que cerrará su planta de Mini en Oxford durante un mes tras el Brexit.
Las principales preocupaciones se refieren a lo que, según los fabricantes de automóviles, son riesgos en la cadena de suministro en caso de un Brexit sin acuerdo.
La línea de producción de Toyota funciona según el principio «justo a tiempo», de modo que cada 37 minutos llegan piezas de proveedores del Reino Unido y de la UE para los coches fabricados bajo pedido.
Si el Reino Unido abandona la UE sin acuerdo el 29 de marzo, podrían producirse trastornos en la frontera que, según el sector, podrían provocar retrasos y escasez de piezas.
Según la empresa, sería imposible que Toyota mantuviera en su planta de Derbyshire existencias para más de un día, por lo que se detendría la producción.
El Sr. Clark afirmó que el plan de Chequers de Theresa May para las futuras relaciones con la UE está «cuidadosamente diseñado para evitar esos controles fronterizos».
«Tenemos que llegar a un acuerdo. «Queremos conseguir el mejor acuerdo posible que nos permita, como digo, no solo disfrutar del éxito actual, sino también aprovechar esta oportunidad», declaró en el programa Today de BBC Radio 4.
«Los datos, no solo de Toyota sino también de otros fabricantes, indican que es absolutamente necesario que podamos mantener unas cadenas de suministro que han tenido un gran éxito».
Toyota no pudo precisar cuánto tiempo se interrumpiría la producción, pero, a largo plazo, advirtió de que los costes adicionales reducirían la competitividad de la planta y, con el tiempo, provocarían la pérdida de puestos de trabajo.
Peter Tsouvallaris, que lleva 24 años trabajando en Burnaston y es el delegado sindical de Unite en la planta, afirmó que sus afiliados están cada vez más preocupados: «Por mi experiencia, una vez que se pierden estos puestos de trabajo, nunca vuelven».
Un portavoz del Gobierno declaró: «Hemos presentado un plan preciso y creíble para nuestra futura relación con la UE».
La reunión de Trump con Rosenstein podría volver a posponerse, según la Casa Blanca
La reunión de alto riesgo entre Donald Trump y el fiscal general adjunto Rod Rosenstein podría «aplazarse una semana más», mientras continúa la polémica en torno al candidato al Tribunal Supremo Brett Kavanaugh, según informó la Casa Blanca el domingo.
Rosenstein supervisa el trabajo del fiscal especial Robert Mueller, quien está investigando la injerencia rusa en las elecciones, los vínculos entre los colaboradores de Trump y Rusia, y la posible obstrucción a la justicia por parte del presidente.
La posibilidad de que Trump destituya al fiscal general adjunto —y, con ello, ponga en peligro la independencia de Mueller— lleva meses alimentando los rumores en Washington.
A principios de este mes, el New York Times informó de que Rosenstein había barajado la posibilidad de llevar un micrófono oculto para grabar sus conversaciones con Trump y de destituir al presidente en virtud de la 25.ª Enmienda.
Rosenstein desmintió la noticia.
Pero el lunes pasado acudió a la Casa Blanca, en medio de rumores de que estaba a punto de dimitir.
En cambio, se anunció para el jueves una reunión con Trump, que en ese momento se encontraba en la sede de las Naciones Unidas en Nueva York.
Trump dijo que «preferiría no» despedir a Rosenstein, pero luego la reunión se pospuso para evitar que coincidiera con la audiencia de la Comisión Judicial del Senado en la que declararon tanto Kavanaugh como una de las mujeres que lo han acusado de conducta sexual inapropiada, la Dra. Christine Blasey Ford.
El viernes, Trump ordenó una investigación del FBI de una semana de duración sobre las acusaciones contra Kavanaugh, lo que retrasó aún más la votación plenaria del Senado.
La secretaria de prensa de Trump, Sarah Sanders, apareció en el programa «Fox News Sunday».
Cuando se le preguntó por la reunión con Rosenstein, respondió: «Aún no se ha fijado una fecha; podría ser esta semana, aunque no me extrañaría que se aplazara otra semana más, teniendo en cuenta todo lo que está pasando con el Tribunal Supremo».
«Pero ya veremos; a mí siempre me gusta mantener informada a la prensa».
Algunos periodistas rebatirían esa afirmación: Sanders no ha celebrado ninguna rueda de prensa en la Casa Blanca desde el 10 de septiembre.
El presentador Chris Wallace preguntó por qué.
Sanders afirmó que la escasez de ruedas de prensa no se debía a que le desagradara que los periodistas de televisión «se lucieran», aunque añadió: «No voy a negar que se lucen».
A continuación, sugirió que el contacto directo entre Trump y la prensa se intensificará.
«El presidente celebra más sesiones de preguntas y respuestas que cualquier otro presidente anterior», afirmó, y añadió, sin aportar pruebas: «Hemos analizado esas cifras».
Las ruedas de prensa seguirán celebrándose, dijo Sanders, pero «si la prensa tiene la oportunidad de hacer preguntas directamente al presidente de los Estados Unidos, eso es infinitamente mejor que hablar conmigo».
Intentamos hacerlo a menudo, y ya nos habéis visto hacerlo muchas veces en las últimas semanas; eso sustituirá a la rueda de prensa en la que se puede hablar con el presidente de los Estados Unidos.
Trump suele responder a preguntas cuando sale de la Casa Blanca o participa en sesiones abiertas o ruedas de prensa con dignatarios visitantes.
Las ruedas de prensa en solitario son poco frecuentes.
Esta semana, en Nueva York, el presidente quizá haya demostrado por qué, al hacer una comparecencia espontánea y, en ocasiones, extravagante ante los periodistas allí reunidos.
El secretario de Salud escribe a los trabajadores de la UE del NHS de Escocia ante los temores por el Brexit
El ministro de Sanidad ha enviado una carta al personal de la UE que trabaja en el Servicio Nacional de Salud de Escocia para expresar el agradecimiento del país y su deseo de que sigan en sus puestos tras el Brexit.
La diputada Jeane Freeman envió una carta cuando faltaban menos de seis meses para la salida del Reino Unido de la UE.
El Gobierno escocés ya se ha comprometido a sufragar los gastos de las solicitudes de estatus de residente permanente de los ciudadanos de la UE que trabajan en sus servicios públicos autónomos.
En su carta, la Sra. Freeman escribió: «Durante el verano han continuado las negociaciones entre el Reino Unido y la UE sobre la salida, con vistas a las decisiones previstas para este otoño».
Pero el Gobierno del Reino Unido también ha intensificado sus preparativos ante la posibilidad de un Brexit sin acuerdo.
Sé que debe de ser un momento muy difícil para todos vosotros.
Por eso quería reiterar ahora lo mucho que valoro la contribución de cada uno de los miembros del personal, independientemente de su nacionalidad.
Nuestros compañeros de toda la UE, y de otros lugares, aportan una valiosa experiencia y competencias que refuerzan y mejoran la labor del servicio sanitario, en beneficio de los pacientes y las comunidades a las que atendemos.
«Escocia es, sin duda, tu hogar y deseamos de todo corazón que te quedes aquí».
Christion Abercrombie se somete a una intervención quirúrgica de urgencia tras sufrir un traumatismo craneal
El linebacker de los Tennessee State Tigers, Christion Abercrombie, fue sometido a una intervención quirúrgica de urgencia tras sufrir una lesión en la cabeza durante la derrota del sábado por 31-27 ante los Vanderbilt Commodores, según informó Mike Organ, del diario «The Tennessean».
El entrenador jefe de Tennessee State, Rod Reed, explicó a los periodistas que la lesión se produjo poco antes del descanso.
«Se acercó a la banda y, bueno, se derrumbó allí», dijo Reed.
Los preparadores físicos y el personal médico le administraron oxígeno a Abercrombie en la banda antes de subirlo a una camilla y llevarlo al interior para realizarle más pruebas.
Un responsable de la Universidad Estatal de Tennessee comunicó a Chris Harris, de WSMV en Nashville (Tennessee), que Abercrombie había salido del quirófano en el Centro Médico Vanderbilt.
Harris añadió que «aún no se conocen los detalles sobre el tipo o la gravedad de la lesión» y que la Universidad Estatal de Tennessee está tratando de averiguar cuándo se produjo la lesión.
Abercrombie, un estudiante de segundo año con año de prórroga, está disputando su primera temporada con el Tennessee State tras haberse transferido desde Illinois.
El sábado realizó un total de cinco placajes antes de abandonar el partido, lo que elevó su total de la temporada a 18 placajes.
A los compradores extranjeros se les aplicará un impuesto de timbre más elevado cuando adquieran una vivienda en el Reino Unido
Según los nuevos planes del Partido Conservador, a los compradores extranjeros se les aplicará un impuesto de timbre más elevado cuando adquieran una vivienda en el Reino Unido, y los fondos adicionales recaudados se destinarán a ayudar a las personas sin hogar.
Esta medida contrarrestará el éxito de la campaña de Corbyn para atraer a los votantes jóvenes
El aumento del impuesto sobre actos jurídicos documentados se aplicará a quienes no paguen impuestos en el Reino Unido
El Ministerio de Hacienda prevé recaudar hasta 120 millones de libras al año para ayudar a las personas sin hogar
Theresa May anunciará hoy que a los compradores extranjeros se les aplicará un tipo impositivo más elevado en el impuesto de transmisiones patrimoniales cuando adquieran una vivienda en el Reino Unido, y que los fondos adicionales recaudados se destinarán a ayudar a las personas sin hogar.
Esta medida se interpretará como un intento de contrarrestar el éxito de la campaña de Jeremy Corbyn para atraer a los votantes jóvenes con promesas de ofrecer viviendas más asequibles y de tomar medidas contra las personas con altos ingresos.
El aumento del impuesto sobre actos jurídicos documentados se aplicará a las personas físicas y jurídicas que no paguen impuestos en el Reino Unido, y los fondos adicionales se destinarán a reforzar la iniciativa del Gobierno para combatir el fenómeno de las personas sin hogar.
El recargo —que se suma al actual impuesto de timbre, incluidos los tipos más elevados introducidos hace dos años para las segundas residencias y las viviendas destinadas al alquiler— podría llegar a ser de hasta un tres por ciento.
El Ministerio de Hacienda prevé que esta medida genere hasta 120 millones de libras al año.
Se calcula que el 13 % de las viviendas de nueva construcción en Londres son adquiridas por personas que no residen en el Reino Unido, lo que hace que los precios suban y que a los compradores primerizos les resulte más difícil acceder a la vivienda.
Muchas zonas acomodadas del país —especialmente en la capital— se han convertido en «pueblos fantasma» debido al elevado número de compradores extranjeros que pasan la mayor parte del tiempo fuera del país.
La nueva política se produce apenas unas semanas después de que Boris Johnson pidiera una reducción del impuesto sobre transmisiones patrimoniales para ayudar a más jóvenes a adquirir su primera vivienda.
Acusó a las grandes empresas constructoras de mantener altos los precios inmobiliarios al acaparar terrenos sin utilizarlos, e instó a la Sra. May a que eliminara las cuotas de viviendas asequibles para poner fin a la «vergüenza inmobiliaria» de Gran Bretaña.
El Sr. Corbyn ha anunciado una llamativa serie de propuestas de reformas en materia de vivienda, entre las que se incluyen el control de los alquileres y el fin de los desahucios «sin causa justificada».
También quiere otorgar a los ayuntamientos mayores competencias para construir nuevas viviendas.
La Sra. May afirmó: «El año pasado dije que dedicaría mi mandato como primera ministra a recuperar el sueño británico: que la vida sea mejor para cada nueva generación».
Y eso significa arreglar nuestro mercado inmobiliario, que está en crisis.
Reino Unido siempre estará abierto a quienes deseen vivir, trabajar y labrarse un futuro aquí.
Sin embargo, no puede ser justo que a las personas que no residen en el Reino Unido, así como a las empresas con sede en el extranjero, les resulte tan fácil comprar una vivienda como a los residentes británicos que trabajan duro.
«Para demasiadas personas, el sueño de tener una vivienda propia se ha convertido en algo demasiado lejano, y la humillación de dormir en la calle sigue siendo una realidad demasiado presente».
Jack Ross: «Mi mayor ambición es entrenar a la selección de Escocia»
El entrenador del Sunderland, Jack Ross, afirma que su «mayor ambición» es llegar a ser seleccionador de Escocia en algún momento.
El escocés, de 42 años, está deseando afrontar el reto de relanzar al club del noreste, que actualmente ocupa el tercer puesto de la League One, a tres puntos del líder.
Este verano fichó por el Stadium of Light tras haber logrado el ascenso del St Mirren a la Premiership escocesa la temporada pasada.
«Quería jugar con la selección de mi país como jugador.
«Me pusieron una gorra con la letra B y eso fue todo», declaró Ross al programa Sportsound de la BBC Escocia.
«Pero de niño solía ir mucho con mi padre a ver a Escocia jugar en Hampden, y eso siempre me ha hecho volver».
«Sin embargo, esa oportunidad solo se presentará si tengo éxito en la gestión del club».
Entre los predecesores de Ross al frente del Sunderland se encuentran Dick Advocaat, David Moyes, Sam Allardyce, Martin O'Neill, Roy Keane, Gus Poyet y Paulo Di Canio.
El exentrenador del Alloa Athletic afirma que no le inquietaba en absoluto tomar el relevo de figuras tan consolidadas en un club tan importante, tras haber rechazado anteriormente las ofertas del Barnsley y del Ipswich Town.
«Para mí, el éxito en este momento se medirá por si consigo que este club vuelva a la Premier League».
«Por su estructura y sus instalaciones, este club tiene sin duda un lugar en la Premier League», afirmó.
«No es tarea fácil conseguirlo, pero probablemente solo consideraría que he tenido éxito aquí si consigo que el club vuelva a ese nivel».
Ross lleva solo tres años en el mundo del entrenamiento, tras un periodo como segundo entrenador en el Dumbarton y una etapa de 15 meses en el cuerpo técnico del Hearts.
A continuación, ayudó al Alloa a recuperarse tras el descenso a la tercera división y, la temporada siguiente, llevó al St Mirren de estar al borde del descenso a proclamarse campeón de la Championship.
Y Ross afirma que ahora se siente más a gusto que en ningún otro momento de su carrera como jugador en el Clyde, el Hartlepool, el Falkirk, el St Mirren y el Hamilton Academical.
«Probablemente fue un verdadero punto de inflexión», recordó al referirse a su llegada al Alloa.
«De verdad creía que la gestión era lo que más me convenía, más que jugar».
Suena extraño porque me fue bien, me ganaba la vida de forma decente y disfruté de algunos momentos buenos.
Pero jugar puede ser difícil.
Hay muchas cosas que tienes que hacer cada semana.
Sigo pasando por eso en cuanto al estrés y la presión del trabajo, pero la gestión me parece que va bien.
«Siempre quise dedicarme a la gestión y ahora que lo estoy haciendo, me siento más a gusto conmigo mismo que en ningún otro momento de mi vida adulta».
Podrás escuchar la entrevista completa en el programa «Sportsound» el domingo 30 de septiembre en Radio Scotland, entre las 12:00 y las 13:00 (hora británica).
Según una encuesta, la hora ideal para tomarse una pinta es a las 17:30 h de un sábado
La ola de calor estival ha impulsado la facturación de los pubs británicos, que atraviesan dificultades, pero ha aumentado la presión sobre las cadenas de restaurantes.
Las cifras revelan que los grupos de pubs y bares registraron un aumento de las ventas del 2,7 % en julio, mientras que los ingresos de los restaurantes descendieron un 4,8 %.
Peter Martin, de la consultora empresarial CGA, que recopiló los datos, afirmó: «El sol que siguió brillando y la participación de Inglaterra en el Mundial, que se prolongó más de lo esperado, hicieron que julio siguiera una tendencia similar a la del mes anterior, junio, cuando los pubs registraron un aumento del 2,8 %, salvo que los restaurantes se vieron aún más afectados.
La caída del 1,8 % en la actividad de los restaurantes registrada en junio se agravó aún más en julio.
Los bares y pubs especializados en bebidas obtuvieron, con diferencia, los mejores resultados, con un aumento de las ventas en locales comparables superior al descenso registrado por los restaurantes.
Los bares especializados en comida también se vieron afectados por la crisis, aunque no tan gravemente como los restauradores.
Parece que la gente solo quería salir a tomar algo.
«En el conjunto de los bares y pubs gestionados, las ventas de bebidas aumentaron un 6,6 % durante el mes, mientras que las de comida descendieron un 3 %».
Paul Newman, de la consultora de ocio y hostelería RSM, afirmó: «Estos resultados confirman la tendencia que venimos observando desde finales de abril».
El tiempo y el impacto de los grandes eventos sociales o deportivos siguen siendo los factores más importantes en lo que respecta a las ventas en el mercado de la restauración fuera del hogar.
No es de extrañar que los grupos de restauración sigan atravesando dificultades, aunque una caída de las ventas del 4,8 % interanual resultará especialmente dolorosa, sumándose a las continuas presiones sobre los costes.
«El largo y caluroso verano no podría haber llegado en peor momento para los negocios del sector de la restauración, y el tiempo dirá si las temperaturas más moderadas que hemos tenido en agosto supondrán un respiro muy necesario».
El crecimiento total de las ventas en bares y restaurantes, incluidas las nuevas aperturas, fue del 2,7 % en julio, lo que refleja la ralentización en la expansión de las marcas.
El monitor de ventas del sector «Coffer Peach Tracker», destinado al sector de pubs, bares y restaurantes del Reino Unido, recopila y analiza datos de rendimiento de 47 grupos empresariales, con una facturación conjunta de más de 9 000 millones de libras esterlinas, y constituye el referente consolidado del sector.
Uno de cada cinco niños tiene cuentas secretas en las redes sociales que oculta a sus padres
Una encuesta revela que uno de cada cinco niños —algunos de tan solo 11 años— tiene cuentas secretas en redes sociales que ocultan a sus padres y profesores
Una encuesta realizada a 20 000 alumnos de secundaria reveló un aumento de las páginas «falsas de Instagram»
La noticia ha avivado los temores de que se esté publicando contenido sexual
El 20 % de los alumnos afirmó tener una cuenta «principal» para enseñársela a sus padres
Uno de cada cinco niños —algunos de tan solo 11 años— se crea cuentas en las redes sociales que ocultan a los adultos.
Una encuesta realizada a 20 000 alumnos de secundaria reveló un rápido aumento de las cuentas «falsas de Insta», en referencia a la red social Instagram.
La noticia ha avivado los temores de que se estén publicando contenidos de carácter sexual.
El 20 % de los alumnos afirmó que mantiene una cuenta «principal» «limpia» para enseñársela a sus padres, además de tener otras cuentas privadas.
Una madre que se topó por casualidad con la página secreta de su hija de 13 años encontró a una adolescente instando a otros a «violarme».
El estudio, realizado por Digital Awareness UK y la Conferencia de Directores y Directoras (HMC) de colegios privados, reveló que el 40 % de los jóvenes de entre 11 y 18 años tenía dos perfiles, y que la mitad de ellos admitía tener cuentas privadas.
El director de HMC, Mike Buchanan, afirmó: «Es preocupante que tantos adolescentes se vean tentados a crear espacios en línea donde sus padres y profesores no puedan encontrarlos».
Eilidh Doyle será la «voz de los atletas» en la junta directiva de Scottish Athletics
Eilidh Doyle ha sido elegida miembro del consejo de Scottish Athletics en calidad de consejera no ejecutiva durante la asamblea general anual de este organismo rector.
Doyle es la atleta de atletismo más laureada de Escocia, y el presidente Ian Beattie calificó esta decisión como una gran oportunidad para que quienes dirigen este deporte puedan beneficiarse de su amplia experiencia a nivel internacional durante la última década.
«Eilidh goza de un enorme respeto en la comunidad del atletismo escocesa, británica y mundial, y estamos seguros de que el atletismo en Escocia se beneficiaría enormemente de su incorporación a la junta», afirmó Beattie.
Doyle afirmó: «Tengo muchas ganas de ser la voz de los deportistas y espero poder aportar mi granito de arena y ayudar a orientar el deporte en Escocia».
El estadounidense, que ganó las pruebas de 200 y 400 metros en los Juegos de Atlanta de 1996 —entre sus cuatro medallas de oro olímpicas en total— y que ahora colabora habitualmente como comentarista en la BBC, quedó incapacitado para caminar tras sufrir un accidente isquémico transitorio.
Escribió en Twitter: «Hoy hace un mes que sufrí un derrame cerebral».
No podía caminar.
Los médicos dijeron que solo el tiempo dirá si me recuperaré o en qué medida.
Ha sido un trabajo agotador, pero se ha recuperado por completo, ha vuelto a aprender a caminar y hoy ya está haciendo ejercicios de agilidad.
«¡Gracias por los mensajes de ánimo!»
Un anuncio de un sacaleches que compara a las madres con vacas divide a la opinión pública en Internet
Una empresa de sacaleches ha suscitado opiniones encontradas en Internet con un anuncio que compara a las madres lactantes con vacas a las que se ordeña.
Con motivo del lanzamiento de lo que se presenta como «el primer sacaleches portátil silencioso del mundo», la empresa de tecnología de consumo Elvie ha publicado un anuncio con tono irónico, inspirado en un videoclip musical, para mostrar la libertad que ofrece este nuevo sacaleches a las madres que se extraen leche.
Cuatro madres de verdad bailan en un establo lleno de heno y vacas al son de una canción con letras como: «Sí, me ordeño a mí misma, pero no me ves la cola» y «Por si no te habías dado cuenta, esto no son ubres, son mis tetas».
El estribillo continúa: «Bombea, bombea, estoy alimentando a los bebés, bombea, bombea, estoy ordeñando a mis chicas».
Sin embargo, el anuncio, que se ha publicado en la página de Facebook de la empresa, ha suscitado polémica en Internet.
Con 77 000 visualizaciones y cientos de comentarios, el vídeo ha suscitado reacciones encontradas entre los espectadores, y muchos afirman que le resta importancia a los «horrores» de la industria láctea.
«Ha sido una decisión muy desacertada utilizar vacas para anunciar este producto.
«Al igual que nosotras, necesitan quedarse embarazadas y dar a luz para producir leche, salvo que les quitan a sus bebés a los pocos días de dar a luz», escribió una de ellas.
El sacaleches Elvie cabe discretamente dentro de un sujetador de lactancia (Elvie/Mother)
Otro comentó: «Es comprensible que haya sido traumático tanto para la madre como para el bebé».
«Pero bueno, ¿por qué no utilizarlos para anunciar un sacaleches para las madres que pueden quedarse con sus bebés?»
Alguien más añadió: «Qué anuncio tan alejado de la realidad».
Otros defendieron el anuncio, y una mujer admitió que la canción le parecía «divertidísima».
«Creo que es una idea genial.
Me habría tomado uno si todavía estuviera dando el pecho.
Al extraerme leche me sentí exactamente como una vaca.
El anuncio es un poco descabellado, pero lo tomé tal y como era.
«Es un producto genial», escribió alguien.
Otro comentó: «Es un anuncio divertido dirigido a las madres que se extraen leche (a menudo en el trabajo o en los baños) y se sienten como "vacas"».
«Esto no es un anuncio que elogie o juzgue a la industria láctea».
Al final del vídeo, el grupo de mujeres revela que todas han estado bailando con unos discretos zapatos de tacón escondidos en el sujetador.
El concepto en el que se basa la campaña parte de la idea de que muchas mujeres que se extraen leche dicen sentirse como vacas.
Sin embargo, el Elvie Pump es totalmente silencioso, no tiene cables ni tubos y se coloca discretamente dentro de un sujetador de lactancia, lo que permite a las mujeres moverse con libertad, coger a sus bebés en brazos e incluso salir mientras se extraen leche.
Ana Balarin, socia y directora creativa ejecutiva de Mother, comentó: «Elvie Pump es un producto tan revolucionario que merecía un lanzamiento atrevido y provocador».
Al establecer un paralelismo entre las mujeres lactantes y las vacas lecheras, queríamos poner de relieve el uso del sacaleches y todos los retos que conlleva, al tiempo que mostrábamos de una forma amena y cercana la increíble sensación de libertad que aportará el nuevo sacaleches.
No es la primera vez que el sacaleches Elvie aparece en los titulares.
Durante la Semana de la Moda de Londres, una madre de dos hijos desfiló para la diseñadora Marta Jakubowski mientras utilizaba el producto.
Cientos de niños migrantes han sido trasladados discretamente a un campamento de tiendas de campaña en la frontera de Texas
El número de menores migrantes detenidos se ha disparado a pesar de que el número mensual de cruces fronterizos se ha mantenido relativamente sin cambios, en parte porque la retórica y las políticas severas introducidas por la Administración Trump han dificultado la asignación de los menores a sus tutores.
Tradicionalmente, la mayoría de los patrocinadores han sido ellos mismos inmigrantes indocumentados, y han temido poner en peligro su propia posibilidad de permanecer en el país al dar un paso al frente para reclamar a un menor.
El riesgo aumentó en junio, cuando las autoridades federales anunciaron que los posibles patrocinadores y otros miembros adultos de sus hogares tendrían que facilitar sus huellas dactilares, y que esos datos se compartirían con las autoridades de inmigración.
La semana pasada, Matthew Albence, un alto cargo del Servicio de Inmigración y Control de Aduanas, declaró ante el Congreso que la agencia había detenido a decenas de personas que habían solicitado acoger a menores no acompañados.
La agencia confirmó posteriormente que el 70 % de los detenidos no tenía antecedentes penales.
«Cerca del 80 % de las personas que son patrocinadores o familiares de patrocinadores se encuentran en el país de forma ilegal, y una gran parte de ellas son extranjeros con antecedentes penales».
«Así que seguimos buscando a esas personas», afirmó el Sr. Albence.
Con el fin de agilizar la tramitación de los casos de los menores, las autoridades han introducido nuevas normas que obligarán a algunos de ellos a comparecer ante el tribunal en el plazo de un mes desde su detención, en lugar de al cabo de 60 días, que era la norma anterior, según los trabajadores de los centros de acogida.
Muchos comparecerán por videoconferencia, en lugar de hacerlo en persona, para defender su caso ante un juez de inmigración con el fin de obtener un estatus legal.
Las personas que no cumplan los requisitos para acogerse a las medidas de ayuda serán deportadas de inmediato.
Cuanto más tiempo permanecen los niños bajo custodia, mayor es la probabilidad de que sufran ansiedad o depresión, lo que puede dar lugar a arrebatos violentos o intentos de fuga, según los trabajadores de los centros de acogida y los informes que han salido a la luz en los últimos meses.
Los defensores de los derechos de los menores señalaron que estas preocupaciones se acentúan en un centro de mayor tamaño como el de Tornillo, donde es más probable que se pasen por alto las señales de que un niño está pasando por dificultades, debido a su tamaño.
Añadieron que trasladar a los niños al campamento sin darles tiempo suficiente para prepararse emocionalmente o para despedirse de sus amigos podría agravar el trauma con el que muchos ya están luchando.
Siria exige a las «fuerzas de ocupación» estadounidenses, francesas y turcas que se retiren de inmediato
En su intervención ante la Asamblea General de la ONU, el ministro de Asuntos Exteriores, Walid al-Moualem, también hizo un llamamiento a los refugiados sirios para que regresaran a casa, a pesar de que la guerra en el país ya lleva ocho años.
Moualem, que también ocupa el cargo de viceprimer ministro, afirmó que las fuerzas extranjeras se encontraban en territorio sirio de forma ilegal, con el pretexto de luchar contra el terrorismo, y que «se les tratará en consecuencia».
«Deben retirarse de inmediato y sin condiciones», declaró ante la asamblea.
Moualem insistió en que «la guerra contra el terrorismo está a punto de terminar» en Siria, donde más de 360 000 personas han perdido la vida desde 2011 y millones más se han visto obligadas a abandonar sus hogares.
Afirmó que Damasco seguiría «librando esta batalla sagrada hasta que hayamos liberado todos los territorios sirios» tanto de los grupos terroristas como de «cualquier presencia extranjera ilegal».
Estados Unidos cuenta con unos 2.000 soldados en Siria, dedicados principalmente a entrenar y asesorar tanto a las fuerzas kurdas como a los árabes sirios que se oponen al presidente Bashar al-Assad.
Francia cuenta con más de 1 000 soldados sobre el terreno en ese país devastado por la guerra.
En cuanto a la cuestión de los refugiados, Moualem afirmó que las condiciones eran adecuadas para que regresaran y culpó a «algunos países occidentales» de «difundir temores irracionales» que llevaban a los refugiados a no volver.
«Hemos hecho un llamamiento a la comunidad internacional y a las organizaciones humanitarias para que faciliten estos retornos», afirmó.
«Están politizando lo que debería ser una cuestión puramente humanitaria».
Estados Unidos y la Unión Europea han advertido de que no habrá ayuda para la reconstrucción de Siria hasta que se alcance un acuerdo político entre Assad y la oposición para poner fin a la guerra.
Según diplomáticos de la ONU, el reciente acuerdo entre Rusia y Turquía para establecer una zona de amortiguación en el último bastión rebelde importante de Idlib ha brindado una oportunidad para impulsar las conversaciones políticas.
El acuerdo entre Rusia y Turquía evitó un ataque a gran escala por parte de las fuerzas sirias respaldadas por Rusia contra la provincia, donde viven tres millones de personas.
Sin embargo, Moualem subrayó que el acuerdo tenía «plazos claros» y expresó su esperanza de que la acción militar se dirija contra los yihadistas, incluidos los combatientes del Frente Al-Nusra, vinculado a Al-Qaeda, que «serán erradicados».
El enviado especial de la ONU, Staffan de Mistura, espera convocar en breve las primeras reuniones de un nuevo comité integrado por miembros del Gobierno y de la oposición con el fin de redactar una constitución para la Siria de la posguerra y allanar el camino hacia la celebración de elecciones.
Moualem expuso las condiciones para la participación del Gobierno sirio en la comisión, afirmando que la labor de este órgano debería limitarse «a la revisión de los artículos de la Constitución vigente», y advirtió contra cualquier tipo de injerencia.
Por qué Trump ganará un segundo mandato
Según esa lógica, Trump ganaría la reelección en 2020, a menos que, como probablemente esperan muchos espectadores liberales, un proceso de destitución y un escándalo pongan fin a su presidencia antes de tiempo.
En lo que sin duda sería «¡el final más dramático de una presidencia de la historia!».
Por el momento, no hay indicios de que los espectadores se estén cansando.
Desde 2014, la audiencia en horario de máxima audiencia se ha más que duplicado hasta alcanzar los 1,05 millones en la CNN y casi se ha triplicado hasta alcanzar los 1,6 millones en la MSNBC.
Según Nielsen, Fox News tiene una media de 2,4 millones de espectadores en horario de máxima audiencia, frente a los 1,7 millones de hace cuatro años, y el programa «The Rachel Maddow Show» de MSNBC ha liderado los índices de audiencia del cable con hasta 3,5 millones de espectadores en las noches con noticias importantes.
«Se trata de un incendio que atrae a la gente precisamente porque es algo que no comprendemos», afirmó Neal Baer, productor ejecutivo de la serie dramática de ABC «Designated Survivor», que trata sobre un secretario del gabinete que se convierte en presidente tras un atentado que destruye el Capitolio.
Nell Scovell, una veterana guionista de comedia y autora de «Just the Funny Parts: And a Few Hard Truths About Sneaking Into the Hollywood Boys’ Club», tiene otra teoría.
Recuerda un viaje en taxi por Boston antes de las elecciones de 2016.
El conductor le dijo que votaría por el Sr. Trump.
¿Por qué? preguntó ella.
«Me dijo: "Porque me hace reír"», me contó la Sra. Scovell.
El caos tiene su lado divertido.
Por supuesto, a diferencia de cualquier otra cosa que se vea en la televisión, los acontecimientos que se están produciendo en Washington podrían determinar el futuro del caso Roe contra Wade. Wade, la posibilidad de que las familias inmigrantes se reúnan y la salud de la economía mundial.
Desconectar es un lujo que solo los espectadores más privilegiados pueden permitirse.
Y, sin embargo, va más allá de ser un ciudadano informado cuando llevas ya seis horas viendo a un grupo de expertos debatir sobre el uso que Bob Woodward hace de fuentes «de fondo» en su libro «Fear,«La chaqueta bomber de piel de avestruz de Paul Manafort, valorada en 15 000 dólares («una prenda que rezuma arrogancia», según The Washington Post), y las implicaciones de las escabrosas descripciones de Stormy Daniels sobre la, ejem, anatomía del Sr. Trump».
Por mi parte, nunca volveré a ver a Super Mario con los mismos ojos.
«Parte de lo que hace y que da la sensación de que se trata de un reality show es que cada noche te ofrece algo,«dijo Brent Montgomery, director ejecutivo de Wheelhouse Entertainment y creador de *Pawn Stars*, refiriéndose al reparto cambiante del programa de Trump y a sus giros argumentales diarios (como enzarzarse en una pelea con la NFL o elogiar a Kim Jong-un)».
No puedes permitirte perderte ni un solo episodio o te quedarás atrás.
Cuando me puse en contacto con el Sr. Fleiss esta semana, hacía un día soleado con 27 °C frente a su casa, en la costa norte de Kauai, pero él estaba encerrado en casa viendo MSNBC mientras grababa la CNN.
No podía apartar la vista, no con Brett Kavanaugh a punto de comparecer ante la Comisión Judicial del Senado y el futuro del Tribunal Supremo en juego.
«Recuerdo cuando hacíamos todos esos programas tan alocados en aquella época y la gente decía: "Esto es el principio del fin de la civilización occidental"», me contó el Sr. Fleiss.
«Pensé que era una especie de broma, pero resulta que tenían razón».
Amy Chozick, colaboradora especial de The Times especializada en economía, política y medios de comunicación, es la autora de la autobiografía «Chasing Hillary».
El dinero procedente del exterior inunda las contiendas más reñidas por escaños en la Cámara de Representantes en las elecciones de mitad de legislatura
No es de extrañar que el distrito 17 de Pensilvania esté recibiendo una avalancha de fondos, debido a una redistribución de los distritos electorales que ha hecho que dos titulares compitan por el mismo escaño.
En esta circunscripción suburbana de Pittsburg, recientemente rediseñada, se enfrentan el diputado demócrata Conor Lamb —que ganó su escaño en otra circunscripción en unas elecciones especiales celebradas la pasada primavera—.
Lamb se enfrenta a otro candidato que ya ocupa el cargo, el republicano Keith Rothfus, quien actualmente representa al antiguo distrito 12 de Pensilvania, que se solapa en gran medida con el nuevo distrito 17.
Los mapas se rediseñaron después de que el Tribunal Supremo de Pensilvania dictaminara en enero que los antiguos distritos habían sido manipulados de forma inconstitucional a favor de los republicanos.
La contienda en el nuevo distrito 17 ha desencadenado una encarnizada batalla por la financiación de la campaña entre los principales organismos financieros de los partidos, el Comité de Campaña Demócrata para el Congreso (DCCC) y el Comité Nacional Republicano de Campaña (NRCC).
Lamb se convirtió en un nombre conocido en Pensilvania tras una ajustada victoria en las elecciones especiales del 18.º distrito electoral de Pensilvania, celebradas en marzo y que tuvieron una gran repercusión mediática.
Ese escaño había estado ocupado por un republicano durante más de una década, y el presidente Donald Trump ganó en ese distrito por 20 puntos.
Los analistas políticos dan una ligera ventaja a los demócratas.
Estados Unidos consideró sancionar a El Salvador por su apoyo a China, pero luego desistió
Los diplomáticos señalaron que la República Dominicana y Panamá ya habían reconocido a Pekín, sin que Washington opusiera apenas resistencia.
El Sr. Trump mantuvo una cordial reunión con el presidente de Panamá, Juan Carlos Varela, en junio de 2017 y tenía un hotel en Panamá hasta que sus socios expulsaron al equipo directivo de la Organización Trump.
Los funcionarios del Departamento de Estado decidieron retirar a los jefes de las misiones diplomáticas estadounidenses en El Salvador, «la República Dominicana y Panamá, a raíz de las "recientes decisiones de dejar de reconocer a Taiwán"», declaró Heather Nauert, portavoz del Departamento, en un comunicado a principios de este mes.
Sin embargo, solo se contemplaron sanciones contra El Salvador, que recibió una ayuda estadounidense estimada en 140 millones de dólares en 2017, destinada, entre otras cosas, a la lucha contra el narcotráfico, el desarrollo y el apoyo económico.
Las sanciones propuestas, que incluían recortes en las ayudas económicas y restricciones específicas en materia de visados, habrían supuesto un duro golpe para este país centroamericano, que ya sufre unas elevadas tasas de desempleo y de homicidios.
A medida que avanzaban las reuniones internas, Las autoridades de América del Norte y América Central aplazaron una conferencia de alto nivel centrada en la seguridad y la prosperidad económica, que tenía por objeto dar continuidad a una reunión similar celebrada el año pasado y que se consideró un paso adelante en los esfuerzos por evitar que los migrantes se dirigieran a Estados Unidos.
Sin embargo, a mediados de septiembre, altos cargos del Gobierno dejaron claro que querían que la conferencia se celebrara, lo que puso fin de hecho a cualquier posibilidad de imponer sanciones a El Salvador.
Según los diplomáticos, el vicepresidente Mike Pence tiene previsto intervenir en la conferencia, que ahora está programada para mediados de octubre, lo que pone de manifiesto la importancia que el Gobierno concede a este encuentro.
Y los tres enviados estadounidenses regresaron discretamente a El Salvador, Panamá y la República Dominicana sin que Washington les hubiera transmitido ningún nuevo mensaje contundente ni les hubiera impuesto sanciones.
Un portavoz de la Casa Blanca del Sr. Bolton se negó a comentar los detalles del debate descritos por los tres funcionarios estadounidenses, entre ellos dos diplomáticos, que aceptaron hablar sobre las deliberaciones internas a condición de mantener el anonimato.
Sus declaraciones fueron corroboradas por un analista externo cercano al Gobierno, que también habló bajo condición de anonimato.
Historial académico
La próxima bomba podría ser el informe del fiscal especial Robert Mueller sobre la posible obstrucción a la justicia por parte del Sr. Trump, sobre la que ya existen pruebas muy sólidas en el dominio público.
Según se informa, el Sr. Mueller también está centrando su investigación en determinar si la campaña del Sr. Trump colaboró con Rusia en su ataque contra nuestras elecciones.
Si el Congreso cambia de manos, Trump se verá obligado a rendir cuentas ante ese órgano, justo cuando se prepara para presentarse de nuevo ante los votantes y, tal vez, en última instancia, ante un jurado compuesto por sus pares.
Son muchos «si», y no pretendo dar a entender que la caída del Sr. Trump sea inevitable, ni tampoco la de sus homólogos en Europa.
Todos nosotros, a ambos lados del Atlántico, debemos tomar decisiones que influirán en la duración de esta lucha.
En 1938, los oficiales alemanes estaban dispuestos a dar un golpe de Estado contra Hitler, si tan solo Occidente se le hubiera opuesto y hubiera respaldado a los checoslovacos en Múnich.
Fracasamos y dejamos pasar la oportunidad de evitar los años de matanza que siguieron.
El curso de la historia gira en torno a esos puntos de inflexión, y el inexorable avance de la democracia se acelera o se retrasa.
Los estadounidenses se enfrentan ahora a varios de estos puntos de inflexión.
¿Qué haremos si el Sr. Trump destituye al fiscal general adjunto Rod Rosenstein, el hombre que tiene en sus manos el destino de la investigación del Sr. Mueller?
Rosenstein se encuentra en una situación delicada desde que este periódico informara de que, el año pasado, sugirió grabar en secreto al presidente y especuló sobre su incapacidad para desempeñar el cargo.
El Sr. Rosenstein afirma que la información publicada por The Times es inexacta.
«¿Cómo reaccionaremos si la investigación del FBI sobre Brett Kavanaugh, solicitada recientemente, no es exhaustiva o imparcial, o si se le confirma como miembro del Tribunal Supremo a pesar de las acusaciones creíbles de agresión sexual y de testimonio falso?
Y, sobre todo, ¿votaremos en las elecciones de mitad de legislatura a favor de un Congreso que haga rendir cuentas al Sr. Trump?
Si no superamos esas pruebas, a la democracia le espera un largo invierno.
Pero creo que no fracasaremos, gracias a la lección que aprendí en Praga.
Mi madre era una judía checoslovaca que fue deportada a Auschwitz por el mismo régimen nazi que en su día ocupó la residencia de mi embajador.
Sobrevivió, emigró a Estados Unidos y, sesenta años después, me envió a encender las velas del sabbat en esa mesa que llevaba la esvástica.
«Con ese legado, ¿cómo no voy a ser optimista respecto a nuestro futuro?»
Norman Eisen, investigador principal de la Brookings Institution, es presidente de Ciudadanos por la Responsabilidad y la Ética en Washington y autor de «The Last Palace: Europe's Turbulent Century in Five Lives and One Legendary House».
Graham Dorrans, del Rangers, se muestra optimista de cara al partido contra el Rapid de Viena
El Rangers recibe al Rapid de Viena este jueves, consciente de que una victoria sobre los austriacos, tras el impresionante empate logrado en España contra el Villarreal a principios de este mes, le situaría en una posición privilegiada para clasificarse en el Grupo G de la Europa League.
Una lesión de rodilla impidió al centrocampista Graham Dorrans debutar esta temporada hasta el empate a 2-2 contra el Villarreal, pero cree que el Rangers puede aprovechar ese resultado como trampolín para alcanzar metas más altas.
«Ha sido un buen punto para nosotros, porque el Villarreal es un buen equipo», afirmó el jugador de 31 años.
«Salimos al campo convencidos de que podíamos sacar algo del partido y nos llevamos un punto».
Quizá podríamos haber ganado al final, pero, en general, el empate fue probablemente un resultado justo.
Probablemente ellos jugaron mejor en la primera parte, pero en la segunda salimos al campo y fuimos nosotros los que dominamos el partido.
Este jueves nos espera otra gran noche de fútbol europeo.
Esperemos que podamos sumar los tres puntos, pero será un partido difícil, ya que ellos obtuvieron un buen resultado en su último encuentro; sin embargo, con el apoyo de la afición, estoy seguro de que podremos darlo todo y conseguir un resultado positivo.
El año pasado fue sin duda difícil, entre todo lo que pasó con mis lesiones y los cambios en el propio club, pero ahora se respira un ambiente muy positivo.
El equipo está en buena forma y los chicos lo están disfrutando mucho; los entrenamientos van bien.
«Esperemos que ahora podamos seguir adelante, dejar atrás la temporada pasada y tener éxito».
Las mujeres pierden el sueño por el miedo a no tener ahorros para la jubilación
A pesar de que los participantes en la encuesta tenían una idea clara de cómo querían que se les atendiera, eran pocos los que hablaban de ello con sus familiares.
Aproximadamente la mitad de las personas que participaron en el estudio de Nationwide afirmaron que estaban hablando con sus cónyuges sobre el coste de los cuidados a largo plazo.
Solo el 10 % afirmó haber hablado con sus hijos sobre el tema.
«La gente quiere que un familiar se ocupe de ellos, pero no da los pasos necesarios para abordar el tema», afirmó Holly Snyder, vicepresidenta del área de seguros de vida de Nationwide.
Por aquí es por donde hay que empezar.
Habla con tu pareja y con los niños: no podrás preparar a tu familia para que te cuide si no les comunicas tus deseos con suficiente antelación.
Habla con tu asesor y con tu familia para decidir dónde y cómo recibir la atención médica, ya que esas decisiones pueden influir considerablemente en el coste.
Consulta a tu asesor financiero: tu asesor también puede ayudarte a encontrar una forma de hacer frente a esos gastos.
Las opciones de financiación para los cuidados a largo plazo pueden incluir una póliza tradicional de seguro de cuidados a largo plazo, una póliza híbrida de seguro de vida con valor de rescate para ayudar a cubrir estos gastos o autofinanciarse con su propio patrimonio, siempre y cuando disponga de los fondos necesarios.
Redacta tus documentos legales: evita los litigios antes de que surjan.
Redacta un poder para la atención médica a fin de designar a una persona de confianza que supervise tu atención médica y se asegure de que los profesionales respeten tus deseos en caso de que no puedas comunicarte.
Además, plantéate la posibilidad de otorgar un poder notarial para tus finanzas.
Deberías elegir a una persona de confianza para que tome decisiones financieras en tu nombre y se asegure de que se paguen tus facturas en caso de que quedes incapacitado.
No te olvides de los pequeños detalles: imagina que uno de tus padres mayores tiene una emergencia médica y se dirige al hospital.
¿Podría responder a preguntas sobre medicamentos y alergias?
Detalla todo eso en un plan por escrito para que estés preparado.
«No solo se trata de una cuestión económica, sino también de quiénes son los médicos», preguntó Martin.
«¿Cuáles son los medicamentos?
¿Quién cuidará del perro?
«Asegúrate de tener ese plan listo».
Un hombre recibe varios disparos con un rifle de aire comprimido en Ilfracombe
Un hombre ha recibido varios disparos de un rifle de aire comprimido cuando regresaba a casa tras una salida nocturna.
La víctima, de unos 40 años, se encontraba en la zona de Oxford Grove, en Ilfracombe (Devon), cuando recibió disparos en el pecho, el abdomen y la mano.
Los agentes describieron el tiroteo, que tuvo lugar alrededor de las 02:30 BST, como un «acto aleatorio».
La víctima no vio a su agresor.
Sus lesiones no ponen en peligro su vida y la policía ha pedido a los testigos que se pongan en contacto con ellos.
Terremotos y tsunamis en Indonesia
Según las autoridades, al menos 384 personas han perdido la vida a causa del potente terremoto y el tsunami que azotaron el viernes la ciudad indonesia de Palu, y se prevé que el número de víctimas mortales siga aumentando.
Debido a la interrupción de las comunicaciones, los responsables de las operaciones de socorro no han podido obtener ninguna información de la regencia de Donggala, una zona situada al norte de Palu y más cercana al epicentro del terremoto de magnitud 7,5.
En Palu, más de 16 000 personas fueron evacuadas tras producirse la catástrofe.
A continuación se presentan algunos datos clave sobre Palu y Donggala, en la isla de Sulawesi:
Palu es la capital de la provincia de Sulawesi Central, situada al final de una estrecha bahía en la costa occidental de la isla de Sulawesi, con una población estimada de 379 800 habitantes en 2017.
La ciudad estaba celebrando su 40.º aniversario cuando se produjeron el terremoto y el tsunami.
Donggala es una regencia que se extiende a lo largo de más de 300 km (180 millas) de costa en el noroeste de la isla de Sulawesi.
La regencia, una región administrativa subordinada a una provincia, tenía una población estimada de 299 200 habitantes en 2017.
La pesca y la agricultura son los pilares de la economía de la provincia de Sulawesi Central, especialmente en la región costera de Donggala.
La extracción de níquel también es importante en la provincia, pero se concentra principalmente en Morowali, en la costa opuesta de Sulawesi.
Según la Agencia de Mitigación de Desastres de Indonesia, Palu y Donggala han sufrido varios tsunamis en los últimos 100 años.
En 1938, un tsunami se cobró la vida de más de 200 personas y destruyó cientos de viviendas en Donggala.
En 1996, un tsunami también azotó el oeste de Donggala, causando la muerte de nueve personas.
Indonesia se encuentra en el Anillo de Fuego del Pacífico, una zona sísmica, y sufre terremotos con frecuencia.
Estos son algunos de los principales terremotos y tsunamis de los últimos años:
2004: Un fuerte terremoto ocurrido el 26 de diciembre en la costa occidental de la provincia indonesia de Aceh, al norte de Sumatra, provocó un tsunami que azotó 14 países y causó la muerte de 226 000 personas a lo largo de la costa del océano Índico, más de la mitad de ellas en Aceh.
2005: A finales de marzo y principios de abril, una serie de fuertes terremotos sacudió la costa occidental de Sumatra.
Cientos de personas perdieron la vida en la isla de Nias, frente a la costa de Sumatra.
2006: Un terremoto de magnitud 6,8 sacudió el sur de Java, la isla más poblada de Indonesia, y provocó un tsunami que azotó la costa sur, causando la muerte de casi 700 personas.
2009: Un terremoto de magnitud 7,6 sacudió las cercanías de la ciudad de Padang, capital de la provincia de Sumatra Occidental.
Murieron más de 1 100 personas.
2010: Un terremoto de magnitud 7,5 sacudió una de las islas Mentawai, frente a las costas de Sumatra, y provocó un tsunami de hasta 10 metros de altura que destruyó decenas de pueblos y causó la muerte de unas 300 personas.
2016: Un terremoto de poca profundidad sacudió la regencia de Pidie Jaya, en Aceh, provocando destrucción y pánico, ya que a la población le trajo a la memoria la devastación causada por el mortífero terremoto y el tsunami de 2004.
Esta vez no se produjo ningún tsunami, pero más de 100 personas perdieron la vida a causa del derrumbe de edificios.
2018: Unos fuertes terremotos sacudieron la isla turística de Lombok, en Indonesia, causando la muerte de más de 500 personas, la mayoría de ellas en la parte norte de la isla.
El terremoto destruyó miles de edificios y dejó a miles de turistas temporalmente varados.
El hijo mayor de Sarah Palin, detenido por un delito de violencia doméstica
Track Palin, el hijo mayor de la exgobernadora de Alaska y candidata a la vicepresidencia Sarah Palin, ha sido detenido acusado de agresión.
Palin, de 29 años y residente en Wasilla (Alaska), fue detenida como sospechosa de violencia doméstica, de obstrucción a la justicia en relación con una denuncia de violencia doméstica y de resistencia a la autoridad, según un comunicado publicado el sábado por la Policía Estatal de Alaska.
Según el informe policial, cuando una conocida suya intentó llamar a la policía para denunciar los presuntos delitos, él le quitó el teléfono.
Según informa KTUU, Palin se encuentra en prisión preventiva en el centro de detención preventiva de Mat-Su y su libertad está condicionada al pago de una fianza sin garantía de 500 dólares.
Según informó la cadena, el sábado compareció ante el tribunal, donde, al preguntársele por su declaración, se declaró «sin duda alguna inocente».
Palin se enfrenta a tres delitos menores de clase A, lo que significa que podría ser condenado a hasta un año de cárcel y a una multa de 250 000 dólares.
Además, se le ha imputado un delito menor de clase B, castigado con un día de cárcel y una multa de 2.000 dólares.
No es la primera vez que se presentan cargos penales contra Palin.
En diciembre de 2017, fue acusado de agredir a su padre, Todd Palin.
Su madre, Sarah Palin, llamó a la policía para denunciar la supuesta agresión.
El caso se encuentra actualmente ante el Tribunal de Veteranos de Alaska.
En enero de 2016 fue acusado de agresión doméstica, obstrucción a la justicia en relación con un delito de violencia doméstica y posesión de un arma en estado de embriaguez en relación con el incidente.
Su novia había denunciado que él le había dado un puñetazo en la cara.
Sarah Palin fue criticada por asociaciones de veteranos en 2016 tras relacionar el comportamiento violento de su hijo con un trastorno de estrés postraumático derivado de su servicio en Irak.
Terremoto y tsunami en Indonesia: cientos de muertos
Al menos 384 personas han fallecido tras el terremoto que sacudió el viernes la isla indonesia de Sulawesi.
El terremoto de magnitud 7,5 provocó un tsunami y ha destruido miles de viviendas.
Las redes eléctricas y de comunicaciones están interrumpidas y se prevé que el número de víctimas mortales aumente en los próximos días.
El terremoto se produjo frente a las costas de Sulawesi Central, al noreste de la capital de Indonesia, Yakarta.
En las redes sociales circulan vídeos que muestran el momento del impacto.
Cientos de personas se habían reunido para celebrar un festival en la playa de la ciudad de Palu cuando el tsunami azotó la costa.
Los fiscales federales solicitan la pena de muerte, algo poco habitual, para el sospechoso del atentado terrorista de Nueva York
Los fiscales federales de Nueva York solicitan la pena de muerte para Sayfullo Saipov, el sospechoso del atentado terrorista perpetrado en la ciudad de Nueva York en el que murieron ocho personas; se trata de una pena poco habitual que no se ha aplicado en el estado por un delito federal desde 1953.
Saipov, de 30 años, presuntamente utilizó un camión alquilado en Home Depot para llevar a cabo un ataque en un carril bici situado junto a la West Side Highway, en el Bajo Manhattan, arrollando a peatones y ciclistas a su paso el 10 de octubre.
Para justificar una pena de muerte, Según la notificación de intención de solicitar la pena de muerte, presentada en el Distrito Sur de Nueva York, la fiscalía tendrá que demostrar que Saipov mató «intencionadamente» a las ocho víctimas y les causó «intencionadamente» lesiones corporales graves.
Según el documento judicial, ambos cargos pueden acarrear la pena de muerte.
Varias semanas después del ataque, Un gran jurado federal presentó contra Saipov una acusación formal de 22 cargos, entre los que se incluían ocho cargos de asesinato en el marco de actividades de crimen organizado —típicamente utilizados por los fiscales federales en casos de delincuencia organizada— y un cargo de violencia y destrucción de vehículos de motor.
El ataque requirió «una planificación y una premeditación considerables», afirmaron los fiscales, quienes calificaron la forma en que Saipov lo llevó a cabo de «atroz, cruel y depravada».
«Sayfullo Habibullaevic Saipov causó lesiones, «por los daños y perjuicios causados a las familias y amigos de Diego Enrique Angelini, Nicholas Cleves, Ann-Laure Decadt, Darren Drake, Ariel Erlij, Hernán Ferruchi, Hernán Diego Mendoza y Alejandro Damián Pagnucco», reza la notificación de intención.
Cinco de las víctimas eran turistas de Argentina.
Ha pasado una década desde la última vez que el Distrito Sur de Nueva York juzgó un caso en el que se solicitaba la pena de muerte.
El acusado, Khalid Barnes, fue declarado culpable del asesinato de dos traficantes de drogas, pero finalmente fue condenado a cadena perpetua en septiembre de 2009.
La última vez que se aplicó la pena de muerte en un caso federal en Nueva York fue en 1953, en el caso de Julius y Ethel Rosenberg, un matrimonio ejecutado tras haber sido condenado dos años antes por conspiración para cometer espionaje a favor de la Unión Soviética durante la Guerra Fría.
Los dos Rosenberg fueron ejecutados en la silla eléctrica el 19 de junio de 1953.
Según los documentos judiciales, Saipov, natural de Uzbekistán, no mostró ningún arrepentimiento en los días y meses posteriores al atentado.
Según la policía, declaró a los investigadores que se sentía bien por lo que había hecho.
Según la acusación, Saipov declaró a las autoridades que se sintió impulsado a cometer el atentado tras ver vídeos del ISIS en su teléfono.
Según la policía, también pidió que se colocara la bandera del ISIS en su habitación del hospital.
Se ha declarado inocente de los 22 cargos que se le imputan.
David Patton, uno de los defensores públicos federales que representan a Saipov, afirmó que están «evidentemente decepcionados» con la decisión de la fiscalía.
«Creemos que la decisión de solicitar la pena de muerte en lugar de aceptar una declaración de culpabilidad que conllevaría cadena perpetua sin posibilidad de libertad condicional solo prolongará el trauma de estos hechos para todos los implicados», afirmó Patton.
La defensa de Saipov ya había solicitado a la fiscalía que no solicitara la pena de muerte.
Un diputado conservador afirma que NIGEL FARAGE debería encargarse de las negociaciones del Brexit
Nigel Farage prometió hoy «movilizar al ejército popular» durante una protesta celebrada en el congreso del Partido Conservador.
El exlíder del UKIP afirmó que los políticos tenían que «sentir la presión» de los euroescépticos, al tiempo que uno de los propios diputados de Theresa May sugería que él debería encargarse de las negociaciones con la UE.
El diputado conservador Peter Bone declaró ante los manifestantes en Birmingham que el Reino Unido «ya habría salido» de la UE si Farage fuera el ministro del Brexit.
Sin embargo, el reto al que se enfrenta la Sra. May para reconciliar a sus filas, profundamente divididas, ha quedado patente con la participación de conservadores partidarios de la permanencia en una manifestación independiente contra el Brexit celebrada en la ciudad.
La primera ministra está luchando por mantener a flote su plan de compromiso de Chequers ante los ataques de los partidarios del Brexit, los partidarios de la permanencia y la UE.
Allies insistió en que seguirá adelante con sus intentos de llegar a un acuerdo con Bruselas a pesar de las críticas, y obligará a los euroescépticos y al Partido Laborista a elegir entre su paquete de medidas y el «caos».
El Sr. Bone declaró en la concentración de «Leave Means Leave» celebrada en Solihull que quería «deshacerse de Chequers».
Sugirió que se debería haber nombrado a Farage miembro de la Cámara de los Lores y se le debería haber encomendado la responsabilidad de las negociaciones con Bruselas.
«Si él hubiera estado al mando, ya nos habríamos ido», dijo.
El diputado por Wellingborough añadió: «Defenderé el Brexit, pero tenemos que descartar el plan de Chequers».
Al expresar su oposición a la UE, afirmó: «No luchamos en las guerras mundiales para acabar siendo subordinados».
«Queremos hacer nuestras propias leyes en nuestro propio país».
El Sr. Bone desestimó las sugerencias de que la opinión pública hubiera cambiado desde la votación de 2016: «La idea de que los británicos hayan cambiado de opinión y quieran quedarse es totalmente falsa».
La conservadora partidaria del Brexit Andrea Jenkyns también participó en la marcha y declaró a los periodistas: «Solo digo una cosa: primera ministra, escuche a la gente».
«El plan de Chequers no gusta al público en general, la oposición no va a votarlo a favor, y tampoco gusta a nuestro partido ni a nuestros militantes, que son los que realmente se dejan la piel en la calle y nos hacen ganar las elecciones».
«Por favor, dejad de lado Chequers y empezad a escuchar».
En un mensaje dirigido directamente a la señora May, añadió: «Los primeros ministros conservan su cargo cuando cumplen sus promesas».
Farage declaró ante los asistentes al mitin que había que hacer que los políticos «sintieran la presión» si estaban a punto de traicionar la decisión tomada en el referéndum de 2016.
«Ahora se trata de una cuestión de confianza entre nosotros —el pueblo— y nuestra clase política», afirmó.
«Están intentando traicionar el Brexit y hoy estamos aquí para decirles: "No dejaremos que se salgan con la suya"».
En un mensaje dirigido a la multitud entusiasmada, añadió: «Quiero que hagáis sentir la presión a nuestra clase política, que está a punto de traicionar el Brexit».
«Estamos movilizando al ejército popular de este país que nos dio la victoria en el Brexit y no descansaremos hasta que nos hayamos convertido en un Reino Unido independiente, autónomo y orgulloso».
Mientras tanto, los partidarios de la permanencia se manifestaron por Birmingham antes de celebrar un mitin de dos horas en el centro de la ciudad.
Un pequeño grupo de activistas ondeó pancartas de «Tories Against Brexit» tras la presentación del grupo este fin de semana.
Lord Adonis, miembro laborista de la Cámara de los Lores, se burló de los conservadores por los problemas de seguridad que tuvieron con una aplicación del partido al inicio del congreso.
«Son estas personas las que nos dicen que pueden poner en marcha los sistemas informáticos y toda la tecnología necesaria para un Canadá «plus plus», para una frontera sin trabas, para el libre comercio sin fronteras en Irlanda», añadió.
«Es una auténtica farsa».
«No existe tal cosa como un buen Brexit», añadió.
Warren tiene previsto estudiar seriamente la posibilidad de presentarse a las elecciones presidenciales
La senadora estadounidense Elizabeth Warren afirma que «considerará seriamente la posibilidad de presentarse a las elecciones presidenciales» tras las elecciones de noviembre.
Según informa The Boston Globe, la política demócrata de Massachusetts habló sobre su futuro durante un acto público celebrado el sábado en el oeste de Massachusetts.
Warren, una crítica habitual del presidente Donald Trump, se presenta a la reelección en noviembre contra el diputado estatal republicano Geoff Diehl, quien fue copresidente de la campaña de Trump en Massachusetts en 2016.
Ha sido objeto de especulaciones sobre la posibilidad de que se enfrente a Trump en 2020.
El acto celebrado el sábado por la tarde en Holyoke fue su 36.º encuentro con los electores en formato de asamblea pública desde que Trump asumió el cargo.
Una de las asistentes le preguntó si tenía pensado presentarse a las elecciones presidenciales.
Warren respondió que ya es hora de que «las mujeres vayan a Washington para arreglar nuestro gobierno, que está en crisis, y eso incluye tener a una mujer al frente».
Detienen a un sospechoso por el asesinato a tiros de Sims, de la LSU
La policía de Baton Rouge (Luisiana) anunció el sábado que se ha detenido a un sospechoso por el asesinato a tiros del jugador de baloncesto de la LSU Wayde Sims, ocurrido el viernes.
El Departamento de Policía de Baton Rouge anunció la detención de Dyteon Simpson, de 20 años, a las 11 de la mañana. Rueda de prensa de ET.
El viernes habían publicado un vídeo del tiroteo, en el que pedían ayuda para identificar a un hombre que aparecía en las imágenes.
Sims, de 20 años, fue asesinado a tiros cerca del campus de la Universidad Southern en la madrugada del viernes.
«Wayde Sims sufrió una herida de bala en la cabeza y finalmente falleció a causa de ella», declaró el sábado el jefe de policía Murphy J. Paul a los medios de comunicación, según 247sports.
Wayde intervino para defender a su amigo y Simpson le disparó.
Simpson fue interrogado y reconoció haber estado en el lugar de los hechos, haber estado en posesión de un arma y haber disparado a Wayde Sims.
Simpson fue detenido sin incidentes y puesto bajo custodia en el Departamento de Policía de la parroquia de East Baton Rouge.
Sims, un estudiante de tercer año que mide 1,98 metros y se crió en Baton Rouge, disputó 32 partidos la temporada pasada, 10 de ellos como titular, con un promedio de 17,4 minutos, 5,6 puntos y 2,9 rebotes por partido.
Gran Premio de Rusia: Lewis Hamilton se acerca al título mundial tras imponerse a Sebastian Vettel gracias a las órdenes de equipo
Desde el momento en que Valtteri Bottas se clasificó por delante de Lewis Hamilton el sábado, quedó claro que las órdenes de equipo de Mercedes tendrían un papel fundamental en la carrera.
Desde la pole, Bottas hizo una buena salida y casi dejó a Hamilton en la estacada al defender su posición en las dos primeras curvas, lo que invitó a Vettel a atacar a su compañero de equipo.
Vettel entró primero en boxes, lo que dejó a Hamilton atrapado en el tráfico al final del pelotón, algo que debería haber sido decisivo.
El Mercedes entró en boxes una vuelta más tarde y salió por detrás de Vettel, pero Hamilton se puso en cabeza tras un duelo rueda a rueda en el que el piloto de Ferrari se vio obligado a ceder el interior a regañadientes, a pesar de haber intentado aguantar tras una doble maniobra defensiva en la tercera curva.
Max Verstappen salió desde la última fila de la parrilla y, al terminar la primera vuelta, ya ocupaba la séptima posición, justo el día en que cumplía 21 años.
A continuación, lideró la carrera durante gran parte de la misma, cuidando los neumáticos para intentar un final rápido y adelantar a Kimi Raikkonen y hacerse con el cuarto puesto.
Finalmente entró en boxes en la vuelta 44, pero no pudo aumentar el ritmo en las ocho vueltas restantes, mientras que Raikkonen se hizo con el cuarto puesto.
Es un día difícil porque Valtteri ha hecho un trabajo fantástico durante todo el fin de semana y se ha comportado como un auténtico caballero al dejarme pasar.
«El equipo ha hecho un trabajo excepcional para conseguir un doblete», dijo Hamilton.
Ese lenguaje corporal fue realmente malo
El presidente Donald Trump se burló de la senadora Dianne Feinstein en un mitin celebrado el sábado por su insistencia en que ella no había filtrado la carta de Christine Blasey Ford en la que acusaba al candidato al Tribunal Supremo Brett Kavanaugh de agresión sexual.
En un mitin celebrado en Virginia Occidental, el presidente no se refirió directamente al testimonio prestado por Ford ante la Comisión Judicial del Senado, sino que comentó que lo que estaba ocurriendo en el Senado demostraba que la gente era «malvada, desagradable y mentirosa».
«Lo único que podría pasar y lo maravilloso que está ocurriendo estos últimos días en el Senado, cuando ves la ira, cuando ves a gente enfadada, maliciosa, desagradable y mentirosa», dijo.
«Cuando ves las filtraciones y luego dicen: "Oh, yo no he sido"».
«Yo no lo hice».
¿Te acuerdas?
Dianne Feinstein, ¿has filtrado la información?
Recuerda su respuesta... ¿filtraste el documento? —«Oh, oh, ¿qué?».
¡Ay, no!
«Yo no filtré nada».
Bueno, espera un momento.
¿Se nos ha filtrado...?«No, no se nos filtró nada», añadió, imitando al senador.
Feinstein recibió en julio la carta en la que Ford detallaba las acusaciones contra Kavanaugh, y esta se filtró a principios de septiembre, pero Feinstein negó que la filtración procediera de su oficina.
«No oculté las acusaciones de la Dra. Ford, ni filtré su historia», declaró Feinstein ante la comisión, según informó The Hill.
«Me pidió que mantuviera la confidencialidad y yo la mantuve, tal y como me pidió».
Pero su negación no pareció sentarle bien al presidente, quien comentó durante el mitin del sábado por la noche: «Te diré una cosa: ese lenguaje corporal fue realmente malo».
«Quizá no fuera así, pero ese es el peor lenguaje corporal que he visto en mi vida».
Continuando con su defensa del candidato al Tribunal Supremo, acusado de conducta sexual inapropiada por tres mujeres, el presidente insinuó que los demócratas estaban utilizando las acusaciones en su propio beneficio.
«Están decididos a recuperar el poder por todos los medios necesarios».
«Se ve la mezquindad, la maldad; no les importa a quién hagan daño, a quién tengan que pisotear para conseguir poder y control», informó Mediaite que dijo el presidente.
Liga Elite: Dundee Stars 5-3 Belfast Giants
Patrick Dwyer marcó dos goles con los Giants contra el Dundee
El Dundee Stars se resarció de la derrota del viernes en la Elite League ante el Belfast Giants al ganar el partido de vuelta por 5-3 en Dundee el sábado.
Los Giants se adelantaron pronto en el marcador con dos goles de Patrick Dwyer y Francis Beauvillier.
Mike Sullivan y Jordan Cownie empataron el partido para el equipo local antes de que Dwyer volviera a poner en ventaja a los Giants.
François Bouchard empató para el Dundee, antes de que dos goles de Lukas Lundvald Nielsen sentenciaran la victoria de su equipo.
Fue la tercera derrota de la temporada en la Elite League para los hombres de Adam Keefe, que el viernes por la noche habían remontado para vencer al Dundee por 2-1 en Belfast.
Era el cuarto enfrentamiento de la temporada entre ambos equipos, y los Giants habían ganado los tres partidos anteriores.
El primer gol de Dwyer llegó en el minuto 4, a los 3:35, tras una asistencia de Kendall McFaull, mientras que David Rutherford dio la asistencia que permitió a Beauvillier doblar la ventaja cuatro minutos después.
En una primera parte muy animada, Sullivan volvió a meter al equipo local en el partido en el minuto 13:10, antes de que Matt Marquardt asistiera a Cownie para que este marcara el empate en el minuto 15:16.
Dwyer se aseguró de que los Giants llegaran al primer descanso con ventaja al marcar su segundo gol de la noche al final del primer periodo.
El equipo local se recompuso y Bouchard volvió a empatar el partido con un gol en superioridad numérica a los 27:37.
Cownie y Charles Corcoran se unieron para ayudar a Nielsen a dar a Dundee la ventaja por primera vez en el partido a finales del segundo periodo, y él mismo sentenció la victoria con el quinto gol de su equipo a mitad del último periodo.
Los Giants, que han perdido cuatro de sus últimos cinco partidos, recibirán al Milton Keynes en su próximo encuentro, el viernes.
Un controlador aéreo pierde la vida para que cientos de pasajeros puedan escapar del terremoto
Un controlador aéreo de Indonesia está siendo aclamado como un héroe tras perder la vida mientras se aseguraba de que un avión con cientos de personas a bordo despegara sin incidentes.
Más de 800 personas han fallecido y muchas están desaparecidas tras el fuerte terremoto que sacudió la isla de Sulawesi el viernes y provocó un tsunami.
La zona sigue sufriendo fuertes réplicas y hay muchas personas atrapadas entre los escombros en la ciudad de Palu.
Pero, a pesar de que sus compañeros huían para salvar el pellejo, Anthonius Gunawan Agung, de 21 años, se negó a abandonar su puesto en la torre de control del aeropuerto Mutiara Sis Al Jufri de Palu, que se balanceaba violentamente.
Se quedó allí para asegurarse de que el vuelo 6321 de Batik Air, que se encontraba en la pista en ese momento, pudiera despegar sin problemas.
Entonces saltó de la torre de control del tráfico cuando creyó que se estaba derrumbando.
Falleció más tarde en el hospital.
El portavoz de Air Navigation Indonesia, Yohannes Sirait, afirmó que la decisión podría haber salvado cientos de vidas, según informó la cadena australiana ABC News.
Organizamos un helicóptero desde Balikpapan, en Kalimantan, para trasladarlo a un hospital más grande en otra ciudad.
Por desgracia, lo perdimos esta mañana antes de que el helicóptero llegara a Palu.
«Nos parte el corazón saber esto», añadió.
Mientras tanto, las autoridades temen que el número de víctimas mortales pueda ascender a miles, y la agencia nacional de prevención de desastres ha señalado que el acceso a las localidades de Donggala, Sigi y Boutong es limitado.
«Se cree que el número de víctimas sigue aumentando, ya que muchos cadáveres siguen bajo los escombros y aún no se ha podido llegar a muchos de ellos», declaró el portavoz de la agencia, Sutopo Purwo Nugroho.
Las olas, que alcanzaron los seis metros de altura, han devastado Palu, donde el domingo tendrá lugar un entierro colectivo.
Aviones militares y comerciales están trayendo ayuda y suministros.
Risa Kusuma, una madre de 35 años, declaró a Sky News: «Cada minuto llega una ambulancia con cadáveres».
El agua potable escasea.
«Por todas partes están saqueando las tiendas de conveniencia».
Jan Gelfand, responsable de la Cruz Roja Internacional en Indonesia, declaró a la CNN: «La Cruz Roja Indonesia se está apresurando a ayudar a los supervivientes, pero no sabemos qué se van a encontrar allí».
«Esto ya es una tragedia, pero podría empeorar mucho más».
El presidente de Indonesia, Joko Widodo, llegó a Palu el domingo y dijo a las fuerzas armadas del país: «Les pido a todos que trabajen día y noche para completar todas las tareas relacionadas con la evacuación».
¿Estás listo? Según informó la CNN.
A principios de este año, Indonesia se vio afectada por los terremotos de Lombok, en los que murieron más de 550 personas.
Accidente aéreo en Micronesia: Air Niugini confirma ahora que hay un hombre desaparecido tras el accidente de avión en la laguna
La aerolínea que operaba el vuelo que se estrelló en una laguna del Pacífico en Micronesia afirma ahora que hay un hombre desaparecido, tras haber comunicado anteriormente que los 47 pasajeros y miembros de la tripulación habían sido evacuados sanos y salvos del avión que se hundía.
Air Niugini informó en un comunicado que, a partir del sábado por la tarde, no se tenía constancia de un pasajero de sexo masculino.
La aerolínea afirmó que estaba colaborando con las autoridades locales, los hospitales y los investigadores para intentar localizar al hombre.
La aerolínea no respondió de inmediato a las solicitudes de más detalles sobre el pasajero, como su edad o nacionalidad.
Unas embarcaciones locales ayudaron a rescatar al resto de pasajeros y a la tripulación después de que el avión se estrellara contra el agua al intentar aterrizar en el aeropuerto de la isla de Chuuk.
Las autoridades informaron el viernes de que siete personas habían sido trasladadas al hospital.
La aerolínea informó de que el sábado seis pasajeros seguían ingresados en el hospital y que todos se encontraban en estado estable.
Aún no se sabe con certeza qué provocó el accidente ni cuál fue la secuencia exacta de los hechos.
Tanto la aerolínea como la Marina de los Estados Unidos afirmaron que el avión aterrizó en la laguna, antes de llegar a la pista.
Algunos testigos creyeron que el avión se había salido de la pista.
El pasajero estadounidense Bill Jaynes dijo que el avión volaba muy bajo.
«Eso es algo muy bueno», dijo Jaynes.
Jaynes contó que él y otras personas lograron avanzar vadeando por agua que les llegaba hasta la cintura hasta las salidas de emergencia del avión que se estaba hundiendo.
Dijo que los auxiliares de vuelo estaban en pánico y gritando, y que él sufrió una lesión leve en la cabeza.
La Armada de los Estados Unidos informó de que los marineros que trabajaban en las inmediaciones en la mejora de un muelle también colaboraron en el rescate utilizando una lancha neumática para trasladar a las personas a tierra antes de que el avión se hundiera a unos 30 metros (100 pies) de profundidad.
Los datos de la Red de Seguridad Aérea indican que 111 personas han fallecido en accidentes de aerolíneas matriculadas en Papúa Nueva Guinea en las últimas dos décadas, pero ninguno de ellos afectó a Air Niugini.
Un analista detalla el cronograma de la noche en que una mujer fue quemada viva
La fiscalía concluyó el sábado la presentación de sus pruebas en el nuevo juicio contra un hombre acusado de quemar viva a una mujer de Misisipi en 2014.
Paul Rowlett, analista del Departamento de Justicia de Estados Unidos, declaró durante horas en calidad de perito en el ámbito del análisis de inteligencia.
Explicó al jurado cómo utilizó los registros del teléfono móvil para reconstruir los movimientos del acusado Quinton Tellis, de 29 años, y de la víctima, Jessica Chambers, de 19, la noche en que ella murió.
Rowlett afirmó que había recibido datos de localización de varios teléfonos móviles que indicaban que Tellis estaba con Chambers la noche de su muerte, lo que contradice sus declaraciones anteriores, según informó The Clarion Ledger.
Cuando los datos revelaron que su teléfono móvil estaba con Chambers en el momento en que él dijo que estaba con su amigo Michael Sanford, la policía fue a hablar con Sanford.
Sanford subió al estrado el sábado y declaró que ese día no se encontraba en la ciudad.
Cuando los fiscales le preguntaron si Tellis decía la verdad al afirmar que estaba en la camioneta de Sanford aquella noche, Sanford respondió que «mentía, porque mi camioneta estaba en Nashville».
Otra incongruencia fue que Tellis afirmó que llevaba conociendo a Chambers unas dos semanas cuando ella falleció.
Los registros del móvil indicaban que solo se conocían desde hacía una semana.
Rowlett afirmó que, algún tiempo después de la muerte de Chambers, Tellis borró de su teléfono los mensajes de texto, las llamadas y los datos de contacto de Chambers.
«La borró de su vida», dijo Hale.
Está previsto que la defensa comience sus alegatos finales el domingo.
El juez dijo que esperaba que el caso pasara a manos del jurado más tarde ese mismo día.
The High Breed: ¿Qué es el hip hop consciente?
Un trío de hip hop quiere contrarrestar la imagen negativa que se tiene del género llenando su música de mensajes positivos.
The High Breed, de Bristol, afirman que el hip hop se ha alejado de sus orígenes, caracterizados por los mensajes políticos y el compromiso con los problemas sociales.
Quieren volver a sus raíces y hacer que el hip hop comprometido vuelva a ser popular.
Artistas como The Fugees y Common han experimentado recientemente un resurgimiento en el Reino Unido gracias a artistas como Akala y Lowkey.
¡¿Otra persona negra?!
Una niñera de Nueva York demanda a una pareja por despedirla tras un mensaje de texto «racista»
Una niñera de Nueva York ha demandado a una pareja por despido discriminatorio tras recibir un mensaje de texto enviado por error por parte de la madre, en el que esta se quejaba de que ella era «otra persona negra».
La pareja niega ser racista y califica la demanda de «chantaje».
Lynsey Plasco-Flaxman, madre de dos hijos, se sintió consternada al descubrir que la nueva cuidadora, Giselle Maurice, era negra, cuando llegó a su primer día de trabajo en 2016.
«NOOOOOOOOOOO, OTRA PERSONA DE RAZA NEGRA», escribió la Sra. Plasco-Flaxman a su marido en un mensaje de texto.
Sin embargo, en lugar de enviárselo a su marido, se lo envió a la Sra. Maurice, dos veces.
Al darse cuenta de su metedura de pata, una «incómoda» Plasco-Flaxman despidió a la Sra. Maurice, alegando que la niñera que se marchaba, que era afroamericana, había hecho mal su trabajo y que, en su lugar, ella esperaba a una filipina, según el New York Post.
A la Sra. Maurice le pagaron por su jornada de trabajo y luego la enviaron a casa en un Uber.
Ahora, Maurice ha demandado a la pareja para reclamar una indemnización por el despido y solicita una compensación de 350 dólares diarios por los seis meses de trabajo a domicilio para los que había sido contratada inicialmente, aunque sin contrato.
«Quiero demostrarles que eso no se hace», declaró el viernes al Post, y añadió: «Sé que es discriminación».
La pareja ha respondido a las acusaciones de racismo, alegando que despedir a Maurice era lo más razonable, ya que temían no poder confiar en ella tras haberla ofendido.
«Mi mujer le había enviado algo que no quería decir».
No es racista.
«No somos racistas», declaró el marido, Joel Plasco, al Post.
«Pero, ¿dejarías a tus hijos al cuidado de alguien a quien le has faltado al respeto, aunque fuera por error?
¿Tu bebé recién nacido?
«Vamos».
Comparando la demanda con una «extorsión», Plasco afirmó que a su esposa le faltaban solo dos meses para dar a luz y que se encontraba en una «situación muy difícil».
«¿Vas a ir a por alguien así?
«Eso no está muy bien», añadió el banquero de inversiones.
Aunque el proceso judicial aún está en curso, la opinión pública no ha tardado en condenar a la pareja en las redes sociales, criticándolos duramente por su comportamiento y su razonamiento.
Una nueva carta revela que los editores de Paddington temían que los lectores no se identificaran con un oso que habla
Karen Jankel, la hija de Bond, que nació poco después de que se aceptara el libro, dijo sobre la carta: «Es difícil ponerse en el lugar de alguien que la leyera por primera vez antes de su publicación».
«Es muy divertido saberlo ahora, sabiendo todo lo que sabemos sobre el enorme éxito de Paddington».
Al hablar de su padre, «Quien había trabajado como cámara de la BBC antes de que un pequeño osito de peluche le inspirara a escribir el libro infantil», añadió, «se habría tomado con optimismo el rechazo de su obra»; sin embargo, el 60.º aniversario de la publicación del libro resultó «agridulce» tras su fallecimiento el año pasado.
Sobre Paddington, a quien ella describe como «un miembro muy importante de nuestra familia», añadió que su padre se sentía discretamente orgulloso de su éxito final.
«Era un hombre bastante callado y no solía presumir», dijo ella.
«Pero como Paddington era tan real para él, era casi como cuando un hijo consigue algo: te sientes orgulloso de él aunque, en realidad, no sea mérito tuyo».
Creo que él veía el éxito de Paddington más o menos así.
«Aunque fuera una creación suya y fruto de su imaginación, siempre solía atribuirle el mérito al propio Paddington».
Mi hija se estaba muriendo y tuve que despedirme de ella por teléfono
Al aterrizar, su hija fue trasladada de urgencia al Hospital Louis Pasteur 2 de Niza, donde los médicos intentaron en vano salvarle la vida.
«Nad llamaba con frecuencia para decir que estaba muy mal, que no creían que fuera a sobrevivir», dijo la señora Ednan-Laperouse.
«Entonces recibí la llamada de Nad para decirme que iba a morir en los siguientes dos minutos y que tenía que despedirme de ella.
Y así lo hice.
Le dije: «Tashi, te quiero muchísimo, cariño».
Ahora mismo voy.
Estaré contigo.
Los medicamentos que los médicos le habían recetado para mantener su corazón latiendo estaban desapareciendo poco a poco de su organismo.
Ella había fallecido hacía ya algún tiempo y todo estaba llegando a su fin.
No me quedó más remedio que quedarme allí sentado y esperar, sabiendo que todo aquello estaba sucediendo.
No podía aullar, gritar ni llorar porque estaba rodeada de familias y gente.
«Tuve que hacer un gran esfuerzo para mantener la compostura».
Finalmente, la señora Ednan-Laperouse, que para entonces ya estaba de luto por la pérdida de su hija, subió al avión junto con el resto de pasajeros, ajena al calvario que estaba viviendo.
«Nadie lo sabía», dijo ella.
«Tenía la cabeza gacha y no paraba de llorar».
Es difícil de explicar, pero fue durante el vuelo cuando sentí una profunda empatía por Nad.
Que necesitaba mi amor y mi comprensión.
«Sabía lo mucho que la quería».
Mujeres afligidas envían tarjetas postales para prevenir los suicidios en el puente
Dos mujeres que han perdido a seres queridos por suicidio se han comprometido a evitar que otras personas se quiten la vida.
Sharon Davis y Kelly Humphreys han estado colocando carteles en un puente de Gales con mensajes motivadores y números de teléfono a los que la gente puede llamar para pedir ayuda.
El hijo de la Sra. Davis, Tyler, tenía 13 años cuando empezó a sufrir depresión y se quitó la vida a los 18 años.
«No quiero que ningún padre o madre tenga que pasar por lo mismo que yo paso cada día», dijo.
La Sra. Davis, de 45 años, que vive en Lydney, dijo que su hijo era un prometedor chef con una sonrisa contagiosa.
«Todo el mundo lo conocía por su sonrisa».
«Siempre decían que su sonrisa iluminaba cualquier estancia».
Sin embargo, dejó de trabajar antes de morir, ya que se encontraba «en una situación realmente difícil».
En 2014, fue el hermano de Tyler, que entonces tenía 11 años, quien encontró a su hermano después de que este se hubiera quitado la vida.
La Sra. Davis dijo: «No dejo de preocuparme por las posibles repercusiones».
La Sra. Davis creó las tarjetas «para que la gente sepa que hay personas a las que puede acudir y con las que puede hablar, aunque solo sea un amigo».
«No te quedes callado, tienes que hablar».
La Sra. Humphreys, amiga de la Sra. Davies desde hace años, perdió a Mark, su pareja durante 15 años, poco después de la muerte de la madre de él.
«No dijo que se sintiera triste, deprimido ni nada por el estilo», dijo ella.
«Un par de días antes de Navidad notamos que había cambiado de actitud».
«El día de Navidad estaba por los suelos: cuando los niños abrieron sus regalos, ni siquiera les miró a los ojos ni nada por el estilo».
Dijo que su muerte había sido un trauma enorme para ellos, pero que tenían que superarlo: «Ha dejado un vacío en la familia».
Nos parte el corazón.
«Pero todos tenemos que seguir adelante y luchar».
Si te cuesta sobrellevar la situación, puedes llamar gratis a Samaritans al 116 123 (Reino Unido e Irlanda), enviar un correo electrónico a jo@samaritans.org o visitar la página web de Samaritans aquí.
El futuro de Brett Kavanaugh pende de un hilo mientras el FBI inicia una investigación
«Pensé: si pudiéramos conseguir algo parecido a lo que él pedía: una investigación de duración limitada, «Aunque sea de alcance limitado, quizá podamos aportar un poco de unidad», afirmó el Sr. Flake el sábado, y añadió que temía que la comisión se estuviera «desmoronando» en medio de un estancamiento partidista profundamente arraigado.
¿Por qué el Sr. Kavanaugh y sus partidarios republicanos no querían que el FBI investigara?
Su reticencia se debe exclusivamente al momento elegido.
Faltan solo cinco semanas para las elecciones de mitad de legislatura, que se celebrarán el 6 de noviembre; si, como se espera, los republicanos obtienen malos resultados, sus intentos por conseguir que el candidato de su elección sea nombrado para el tribunal más alto del país se verán gravemente debilitados.
George W. Bush ha estado llamando por teléfono a los senadores para presionarlos a que apoyen al Sr. Kavanaugh, quien trabajó en la Casa Blanca para el Sr. Bush y, a través de él, conoció a su esposa Ashley, que era la secretaria personal del Sr. Bush.
¿Qué ocurre una vez que el FBI presenta su informe?
Se celebrará una votación en el Senado, donde actualmente hay 51 republicanos y 49 demócratas.
Aún no está claro si el Sr. Kavanaugh podrá conseguir al menos 50 votos en el pleno del Senado, lo que permitiría a Mike Pence, el vicepresidente, desempatar y confirmar su nombramiento para el Tribunal Supremo.
El número de desertores de Corea del Norte «disminuye» bajo el mandato de Kim
Según un diputado surcoreano, el número de norcoreanos que se han refugiado en Corea del Sur ha disminuido desde que Kim Jong-un llegó al poder hace siete años.
Park Byeong-seug, citando datos del Ministerio de Unificación de Corea del Sur, afirmó que el año pasado se registraron 1.127 deserciones, frente a las 2.706 de 2011.
El Sr. Park señaló que el endurecimiento de los controles fronterizos entre Corea del Norte y China y el aumento de las tarifas que cobran los traficantes de personas fueron factores clave.
Pionyang no ha hecho declaraciones públicas al respecto.
A la gran mayoría de los desertores del Norte se les acaba ofreciendo la ciudadanía surcoreana.
Seúl afirma que más de 30 000 norcoreanos han cruzado ilegalmente la frontera desde el final de la Guerra de Corea en 1953.
La mayoría huye a través de China, que tiene la frontera más extensa con Corea del Norte y es más fácil de cruzar que la Zona Desmilitarizada (DMZ), fuertemente vigilada, que separa a las dos Coreas.
China considera a los desertores migrantes ilegales en lugar de refugiados y, a menudo, los repatría por la fuerza.
Las relaciones entre el Norte y el Sur —que, técnicamente, siguen en guerra— han mejorado notablemente en los últimos meses.
A principios de este mes, los líderes de ambos países se reunieron en Pyongyang para mantener conversaciones centradas en las negociaciones sobre la desnuclearización, que se encuentran estancadas.
Esto se produjo tras la histórica reunión celebrada en junio en Singapur entre el presidente de Estados Unidos, Donald Trump, y Kim Jong-un, en la que acordaron, en términos generales, trabajar para lograr una península coreana libre de armas nucleares.
Sin embargo, el sábado, el ministro de Asuntos Exteriores de Corea del Norte, Ri Yong-ho, achacó a las sanciones estadounidenses la falta de avances desde entonces.
«Sin confianza en Estados Unidos, no habrá confianza en nuestra seguridad nacional y, en tales circunstancias, es imposible que desarmemos unilateralmente primero», afirmó el Sr. Ri en un discurso pronunciado ante la Asamblea General de las Naciones Unidas en Nueva York.
Nancy Pelosi tilda a Brett Kavanaugh de «histérico» y afirma que no es apto para formar parte del Tribunal Supremo
La líder de la minoría en la Cámara de Representantes, Nancy Pelosi, calificó al candidato al Tribunal Supremo Brett Kavanaugh de «histérico» y afirmó que, por su temperamento, no era apto para formar parte del Tribunal Supremo.
Pelosi hizo estas declaraciones en una entrevista el sábado en el Festival del Texas Tribune, celebrado en Austin, Texas.
«No pude evitar pensar que, si una mujer se hubiera comportado así, la habrían tachado de "histérica"», afirmó Pelosi al referirse a su reacción ante el testimonio de Kavanaugh ante la Comisión Judicial del Senado el jueves.
Kavanaugh negó con gran emoción las acusaciones de que hubiera agredido sexualmente a la Dra. Christine Blasey Ford cuando ambos eran adolescentes.
Durante su declaración inicial, Kavanaugh se mostró muy emocionado; en algunos momentos, casi gritaba y se le hacía un nudo en la garganta al hablar de su familia y de sus años de instituto.
Además, condenó explícitamente a los demócratas de la comisión, calificando las acusaciones en su contra de «difamación grotesca y coordinada» organizada por liberales enfadados porque Hillary Clinton perdiera las elecciones presidenciales de 2016.
Pelosi afirmó que, en su opinión, el testimonio de Kavanaugh demostraba que no podía formar parte del Tribunal Supremo, ya que ponía de manifiesto su parcialidad contra los demócratas.
«Creo que él mismo se descalifica con esas declaraciones y con la forma en que se ha ensañado con los Clinton y los demócratas», afirmó.
Pelosi se mostró evasiva cuando se le preguntó si intentaría iniciar un proceso de destitución contra Kavanaugh en caso de que fuera confirmado y de que los demócratas obtuvieran la mayoría en la Cámara de Representantes.
«Diré esto: si no está diciendo la verdad al Congreso o al FBI, entonces no es apto no solo para formar parte del Tribunal Supremo, sino tampoco para formar parte del tribunal en el que se encuentra ahora mismo», afirmó Pelosi.
Kavanaugh es actualmente juez del Tribunal de Apelación del Distrito de Columbia.
Pelosi añadió que, como demócrata, le preocupaban las posibles sentencias de Kavanaugh contra la Ley de Asistencia Asequible o el caso Roe contra Wade. Wade, ya que se le considera un juez conservador.
En sus audiencias de confirmación, Kavanaugh eludió las preguntas sobre si revocaría determinadas sentencias del Tribunal Supremo.
«No es el momento de que una persona histérica y parcial acuda a los tribunales y espere que digamos: "¿No es maravilloso?"», afirmó Pelosi.
Y las mujeres deben hacer uso de él.
Es una diatriba justificada, meses y años de rabia que se desbordan, y no puede expresarlo sin llorar.
«Lloramos cuando nos enfadamos», me dijo la Sra. Steinem 45 años después.
«No creo que sea algo raro, ¿verdad?»
Y continuó diciendo: «Me ayudó mucho una mujer que ocupaba un puesto directivo en alguna empresa, que dijo que ella también lloraba cuando se enfadaba, pero que había desarrollado una técnica por la que, cuando se enfadaba y empezaba a llorar, le decía a la persona con la que hablaba: «Quizá pienses que estoy triste porque estoy llorando».
«Estoy enfadado».
Y luego siguió adelante sin más.
«Y me pareció genial».
Las lágrimas se permiten como vía de escape para la ira, en parte porque se malinterpretan profundamente.
Uno de los recuerdos más vívidos que tengo de uno de mis primeros trabajos, En una oficina dominada por hombres, donde una vez me encontré llorando de una rabia indescriptible, una mujer mayor —una jefa fría a la que siempre había temido un poco— me agarró por el cuello y me arrastró hasta la escalera.
«Nunca dejes que te vean llorar», me dijo.
«No saben que estás furioso».
«Creen que estás triste y se alegrarán de haberte afectado».
Patricia Schroeder, por entonces congresista demócrata por Colorado, había colaborado con Gary Hart en sus campañas presidenciales.
En 1987, cuando el Sr. Hart fue sorprendido manteniendo una relación extramatrimonial a bordo de un barco llamado Monkey Business y se retiró de la carrera electoral, la Sra. Schroeder, profundamente frustrada, pensó que no había motivo para que ella no se planteara presentarse a la presidencia.
«No fue una decisión muy meditada», me dijo riendo treinta años después.
«Ya había otros siete candidatos en liza, y lo último que necesitaban era uno más».
Alguien lo llamó «Blancanieves y los siete enanitos».
Como ya estábamos en la recta final de la campaña, iba rezagada en la recaudación de fondos, por lo que se comprometió a no presentarse a las elecciones a menos que recaudara dos millones de dólares.
Era una batalla perdida.
Descubrió que algunos de sus seguidores, que donaban 1000 dólares a los hombres, a ella solo le daban 250 dólares.
«¿Acaso creen que me hacen descuento?», se preguntó.
Cuando pronunció su discurso en el que anunciaba que no iba a presentar su candidatura oficialmente, Estaba tan abrumada por las emociones —la gratitud hacia las personas que la habían apoyado, la frustración con un sistema que dificultaba tanto la recaudación de fondos y dirigirse a los votantes en lugar de a los delegados, y la ira por el sexismo— que se le hizo un nudo en la garganta.
«Se diría que había sufrido una crisis nerviosa», recordaba la Sra. Schroeder al referirse a la reacción de la prensa ante su caso.
«Se diría que Kleenex fuera mi patrocinador».
Recuerdo que pensé: «¿Qué pondrán en mi lápida?».
«¿Lloró?»
Por qué la guerra comercial entre EE. UU. y China podría beneficiar a Pekín
Los primeros disparos de la guerra comercial entre Estados Unidos y China fueron ensordecedores y, aunque la contienda está lejos de haber terminado, los expertos señalan que una ruptura entre ambos países podría resultar beneficiosa para Pekín a largo plazo.
Donald Trump, presidente de Estados Unidos, lanzó la primera advertencia a principios de este año al imponer aranceles a productos chinos clave, como los paneles solares, el acero y el aluminio.
La escalada más significativa se produjo esta semana con la imposición de nuevos aranceles que afectan a productos por valor de 200 000 millones de dólares (150 000 millones de libras), lo que supone gravar, en la práctica, la mitad de todos los productos que llegan a Estados Unidos procedentes de China.
Pekín ha respondido cada vez con medidas similares, y recientemente ha impuesto aranceles de entre el 5 % y el 10 % a productos estadounidenses por valor de 60 000 millones de dólares.
China se ha comprometido a responder a cada medida de Estados Unidos, y no parece que la segunda economía más grande del mundo vaya a ceder en breve.
Hacer que Washington ceda implica aceptar sus exigencias, pero doblegarse públicamente ante Estados Unidos resultaría demasiado vergonzoso para Xi Jinping, el presidente de China.
No obstante, los expertos afirman que, si Pekín sabe jugar bien sus cartas, las presiones de la guerra comercial estadounidense podrían beneficiar a China a largo plazo, al reducir la interdependencia entre ambas economías.
«El hecho de que una decisión política precipitada, ya sea en Washington o en Pekín, pueda crear las condiciones que desencadenen una espiral económica descendente en cualquiera de los dos países es, en realidad, mucho más peligroso de lo que los observadores habían reconocido hasta ahora,«dijo Abigail Grace, investigadora asociada especializada en Asia del Centro para la Nueva Seguridad Estadounidense, un grupo de expertos».
Siria está «preparada» para el regreso de los refugiados, afirma el ministro de Asuntos Exteriores
Siria afirma que está preparada para el retorno voluntario de los refugiados y solicita ayuda para reconstruir el país, devastado por una guerra que dura ya más de siete años.
En su intervención ante la Asamblea General de las Naciones Unidas, el ministro de Asuntos Exteriores, Walid al-Moualem, afirmó que la situación en el país está mejorando.
«Hoy en día, la situación sobre el terreno es más estable y segura gracias a los avances logrados en la lucha contra el terrorismo», afirmó.
El Gobierno sigue rehabilitando las zonas destruidas por los terroristas para restablecer la normalidad.
Ya se dan todas las condiciones para el retorno voluntario de los refugiados al país que se vieron obligados a abandonar a causa del terrorismo y de las medidas económicas unilaterales que afectaban a su vida cotidiana y a sus medios de subsistencia.
La ONU calcula que más de 5,5 millones de sirios han huido del país desde que comenzó la guerra en 2011.
Otros seis millones de personas que aún viven en el país necesitan ayuda humanitaria.
Al-Moualem afirmó que el régimen sirio agradecería cualquier ayuda para reconstruir el país devastado.
Sin embargo, subrayó que no aceptaría ayuda condicionada ni asistencia de países que apoyaran a la insurgencia.
Europa se lleva la victoria en la Ryder Cup en París
El Equipo Europa ha ganado la Ryder Cup 2018 tras derrotar al Equipo EE. UU. por un marcador final de 16,5 a 10,5 en Le Golf National, a las afueras de París (Francia).
Estados Unidos lleva ya seis derrotas consecutivas en suelo europeo y no ha ganado una Ryder Cup en Europa desde 1993.
Europa recuperó el título cuando el equipo del capitán danés Thomas Bjorn alcanzó los 14,5 puntos necesarios para imponerse a Estados Unidos.
El estadounidense Phil Mickelson, que tuvo dificultades durante la mayor parte del torneo, lanzó su golpe de salida al agua en el hoyo 16, un par 3, y cedió el partido a Francesco Molinari.
El golfista italiano Molinari brilló en todas sus rondas, convirtiéndose en uno de los cuatro jugadores que han logrado un récord de 5-0-0 desde que se instauró el formato actual del torneo en 1979.
El estadounidense Jordan Spieth cayó derrotado por 5 y 4 ante el jugador con peor clasificación del equipo europeo, el danés Thorbjorn Olesen.
El número uno del mundo, Dustin Johnson, cayó por 2 y 1 ante el inglés Ian Poulter, quien podría haber disputado su última Ryder Cup.
El español Sergio García, veterano de ocho ediciones de la Ryder Cup, se ha convertido en el europeo con más victorias de la historia del torneo, con 25,5 puntos en su carrera.
«Normalmente no lloro, pero hoy no puedo evitarlo.
Ha sido un año difícil.
Estoy muy agradecida a Thomas por haberme elegido y por creer en mí.
Estoy tan feliz, tan feliz de haber recuperado la copa.
«Lo importante es el equipo, y me alegro de haber podido ayudar», declaró un emocionado García tras la victoria en Europa.
Le pasa el testigo a su compatriota John Ram, quien derrotó el domingo a la leyenda del golf estadounidense Tiger Woods por 2 y 1 en los partidos individuales.
«El increíble orgullo que siento por haber vencido a Tiger Woods... Crecí viéndole jugar», declaró Rahm, de 23 años.
Woods perdió sus cuatro partidos en Francia y ahora tiene un balance de 13 victorias, 21 derrotas y 3 empates en su trayectoria en la Ryder Cup.
Una estadística sorprendente de uno de los mejores jugadores de todos los tiempos, que ha ganado 14 títulos de Grand Slam, solo superado por Jack Nicklaus.
El equipo estadounidense tuvo dificultades durante todo el fin de semana para acertar en las calles, con la excepción de Patrick Reed, Justin Thomas y Tony Finau, que jugaron un golf de gran nivel durante todo el torneo.
El capitán del equipo estadounidense, Jim Furyk, declaró tras la decepcionante actuación de su equipo: «Estoy orgulloso de estos chicos, han luchado».
Esta mañana hubo un momento en el que le dimos un buen susto a Europa.
Nos peleamos.
Hay que quitarse el sombrero ante Thomas.
Es un gran capitán.
Los doce jugadores de su equipo jugaron muy bien.
Nos reorganizaremos, trabajaré con la PGA de Estados Unidos y nuestro Comité de la Ryder Cup, y seguiremos adelante.
Me encantan estos 12 chicos y estoy orgulloso de ser su capitán.
Hay que quitarse el sombrero.
«Nos han superado».
Últimas noticias sobre la marea roja: disminuyen las concentraciones en Pinellas, Manatee y Sarasota
El último informe de la Comisión de Pesca y Vida Silvestre de Florida muestra una disminución general de las concentraciones de marea roja en algunas zonas de la bahía de Tampa.
Según la FWC, se están registrando condiciones de floración más dispersas en zonas de los condados de Pinellas, Manatee, Sarasota, Charlotte y Collier, lo que sugiere una disminución de las concentraciones.
La marea roja se extiende a lo largo de unos 210 kilómetros de costa, desde el norte del condado de Pinellas hasta el sur del condado de Lee.
Se pueden encontrar bancos de peces a unas 10 millas de la costa del condado de Hillsborough, aunque en menos lugares que la semana pasada.
También se ha observado una marea roja en el condado de Pasco.
Durante la última semana se han registrado concentraciones moderadas tanto en el condado de Pinellas como en sus aguas costeras, concentraciones que van de bajas a altas en la costa del condado de Hillsborough, antecedentes de las altas concentraciones registradas en el condado de Manatee, niveles de fondo hasta concentraciones elevadas en el condado de Sarasota y en sus aguas costeras, niveles de fondo hasta concentraciones medias en el condado de Charlotte, niveles de fondo hasta concentraciones elevadas en el condado de Lee y en sus aguas costeras, y concentraciones bajas en el condado de Collier.
Se siguen registrando casos de irritación respiratoria en los condados de Pinellas, Manatee, Sarasota, Lee y Collier.
Durante la última semana no se han registrado casos de irritación respiratoria en el noroeste de Florida.
