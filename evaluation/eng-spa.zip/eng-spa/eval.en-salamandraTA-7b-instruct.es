Diputados galeses preocupados por «parecer muppets»
Algunos diputados al Parlamento galés están consternados ante la sugerencia de que su título debería cambiarse por el de Miembros del Parlamento de Gales.
Esto se debe a los planes de cambiar el nombre de la asamblea por el de Parlamento de Gales.
Diputados de todo el espectro político están preocupados de que esto pueda provocar burlas.
Un miembro laborista del Parlamento dijo que a su grupo le preocupaba «que rime con Twp y Pwp».
Para los lectores de fuera de Gales: En galés, twp significa tonto y pwp significa caca.
Un miembro del Plaid dijo que el grupo en su conjunto «no estaba contento» y sugirió alternativas.
Un miembro del Partido Conservador de Gales manifestó que su grupo tenía una «mentalidad abierta» en cuanto al cambio de nombre, pero señaló que no había mucha diferencia entre MWP y Muppet, que es un personaje de Plaza Sésamo.
En este contexto, la letra w del galés se pronuncia de forma similar a la letra u del inglés de Yorkshire.
La Comisión de la Asamblea, que actualmente está redactando la legislación para introducir los cambios de nombre, manifestó: «La decisión final sobre cualquier descriptor que se utilice para nombrar a los miembros de la asamblea dependerá, por supuesto, de los propios miembros».
En virtud de la Ley del Gobierno de Gales, sancionada por el Parlamento de ese país en 1998, se facultó a la asamblea galesa para que cambiara su nombre.
En junio, la Comisión publicó los resultados de una consulta pública sobre las propuestas, que encontraron un amplio apoyo para llamar a la asamblea un Parlamento galés.
En cuanto al título de los diputados al Parlamento galés, la Comisión estaba a favor de los miembros del Parlamento de Gales o MPW, pero la opción MPW recibió el mayor apoyo en una consulta pública.
Aparentemente, los diputados al Parlamento galés están sugiriendo opciones alternativas, pero la lucha por alcanzar un consenso podría ser un quebradero de cabeza para la Presidenta del Parlamento, la Sra. Elin Jones. Se espera que ella presente un proyecto de ley sobre los cambios en cuestión de semanas.
La legislación sobre las reformas incluirá otros cambios en el funcionamiento de la asamblea, entre ellos, normas sobre la descalificación de los diputados y el diseño del sistema de comités.
Los diputados al Parlamento Europeo tendrán la última palabra sobre la cuestión de cómo se les debe llamar cuando debatan la legislación.
Los macedonios votan en un referéndum sobre el cambio de nombre del país
Los votantes decidirán el domingo si cambian el nombre de su país por el de «República de Macedonia del Norte».
La votación popular se dio en un intento por resolver una disputa de décadas con la vecina Grecia, que tiene su propia provincia llamada Macedonia.
Atenas ha insistido durante mucho tiempo en que el nombre de su vecino del norte representa una reclamación de su territorio y se ha opuesto reiteradamente a sus solicitudes de ingreso en la UE y la OTAN.
El presidente de Macedonia, Gjorgje Ivanov, que se opone al plebiscito sobre el cambio de nombre, manifestó que hará caso omiso del voto.
Sin embargo, los partidarios del referéndum, entre ellos el primer ministro Zoran Zaef, sostienen que el cambio de nombre es simplemente el precio que hay que pagar para ingresar en la UE y la OTAN.
Las campanas de San Martín callan mientras las iglesias de Harlem luchan
«Históricamente, las personas mayores con las que he hablado dicen que había un bar y una iglesia en cada esquina», comentó Adams.
«Hoy no hay ninguno de los dos».
Dijo que la desaparición de los bares era comprensible.
«Hoy en día, las personas socializan de manera distinta», comentó.
«Los bares ya no son las salas de estar de los vecindarios a las que la gente va con frecuencia».
En cuanto a las iglesias, le preocupa que el dinero proveniente de la venta de bienes no dure tanto como esperan los líderes, «y tarde o temprano volverán al punto de partida».
Las iglesias, agregó, podrían ser reemplazadas por edificios de departamentos con condominios llenos del tipo de personas que no ayudarán a los santuarios que aún quedan en el vecindario.
«La abrumadora mayoría de las personas que compran condominios en estos edificios serán blancas,«y, por lo tanto, acelerará el día en que estas iglesias se cierren por completo, ya que es poco probable que la mayoría de las personas que se mudan a estos condominios se conviertan en miembros de esas iglesias».
Ambas iglesias fueron construidas por congregaciones de blancos antes de que Harlem se convirtiera en una metrópoli negra: la Metropolitan Community en 1970 y la de San Martín, una década después.
La congregación metodista blanca original se mudó en los años treinta.
Una congregación negra que había estado realizando cultos en las cercanías tomó posesión del edificio.
La iglesia de San Martín pasó a manos de una congregación negra bajo el mando del reverendo John Howar Johnson, quien encabezó un boicot contra los minoristas de la calle principal de compras de Harlem, la calle 135, que se negaban a contratar o ascender a negros.
El edificio sufrió graves daños a causa de un incendio ocurrido en 1839, pero mientras los feligreses del padre Johnson planificaban su reconstrucción, encargaron la construcción del carrillón.
David Johnson, hijo del padre Johnson y su sucesor en San Martín, llamó con orgullo al carrillón «las campanas de la gente pobre».
El experto que tocó el carrillón en julio lo describió como «un tesoro cultural» y «un instrumento histórico irreemplazable».
La experta Tiffany Ng, de la Universidad de Míchigan, también señaló que se trataba del primer carrillón en el mundo en ser tocado por un músico negro, en este caso, Lindio A. Dionisio, quien se mudó al carrillón más grande de la iglesia de Riverside hace 20 años.
Merriweather manifestó que San Martín no lo reemplazó.
Lo que ha ocurrido en San Martín en los últimos meses ha sido una complicada historia de arquitectos y contratistas, algunos traídos por los líderes laicos de la iglesia y otros por la diócesis episcopal.
La sacristía es el órgano de gobierno de la parroquia. compuesta por líderes laicos - escribió la diócesis en julio ante la preocupación de que la diósesis «trataría de pasar los costos» al consejo parroquial, a pesar de que el consejo no había participado en la contratación de los arquitectos y contratistas que enviaron.
Algunos feligreses se quejaron de la falta de transparencia por parte de la diócesis.
Un tiburón atacó a un niño de 12 años mientras pescaba langostas en California
Un tiburón atacó e hirió el sábado a un niño de trece años que buceaba en busca de langostas en California, en el primer día de la temporada de langosta, informaron las autoridades.
El ataque ocurrió justo antes de las 7:00 a. m., cerca de la playa de Beacon, en Encintas.
Chad Hammel le comentó a la televisora de San Diego que había estado buceando con unos amigos durante cerca de media hora el sábado por la mañana cuando escuchó al niño gritar pidiendo ayuda y luego nadó con un grupo para ayudar a sacarlo del agua.
Hammel dijo que al principio pensó que era solo la emoción de haber atrapado una langosta, pero luego «se dio cuenta de que estaba gritando: «¡Me mordió!
¡Me mordieron!
«Su clavícula entera estaba abierta», comentó Hammel al ver al niño.
«Les grité a todos que salieran del agua: «¡Hay un tiburón en el agua!». Hammel agregó.
El niño fue trasladado en helicóptero al hospital infantil Rady de San Diego, donde se encuentra en estado crítico.
Se desconoce la especie de tiburón responsable del ataque.
Larry Giles, capitán de salvavidas, manifestó en una conferencia de prensa que, semanas atrás, se había divisado un tiburón en la zona, pero se determinó que no se trataba de una especie peligrosa.
Giles agregó que la víctima presentaba lesiones traumáticas en la parte superior del torso.
Las autoridades cerraron el acceso a las playas desde la playa de Ponto, en Casablada, hasta la de Swami, en Ecinita, por un período de cuarenta y ocho horas, con el fin de investigar y garantizar la seguridad.
Giles señaló que en la zona existen más de ciento treinta y cinco especies de tiburones, pero la mayoría no se considera peligrosa.
Los planes de Sainsbury’s se enfocan en el mercado de la belleza del Reino Unido
La cadena de supermercados Sainsbury’s está desafiando a las tiendas de cosméticos Boots, SuperDrug y Debenham con pasillos de belleza al estilo de los grandes almacenes, atendidos por asesores especializados.
Como parte de una importante incursión en el mercado de la belleza del Reino Unido, valorado en 2800 millones de libras esterlinas, que sigue creciendo mientras que las ventas de moda y artículos para el hogar disminuyen, los pasillos de belleza más grandes se probarán en 21 tiendas en todo el país y se llevarán a más tiendas el próximo año si demuestran ser un éxito.
La inversión en belleza se produce a medida que los supermercados buscan formas de utilizar el espacio de las estanterías, que antes se usaba para televisores, microondas y artículos para el hogar.
Sainsbury’s manifestó que duplicaría el tamaño de su oferta de productos de belleza, que pasaría a contar con hasta tres mil artículos, entre los que se incluirían, por primera vez, marcas como Revlon®, Essie®, TweezerMan® y Dr. PAWPAW®.
Las gamas ya existentes de L’Oréal, Mayibelline y Burt’s bees también contarán con más espacio, con áreas de marca similares a las que se pueden encontrar en tiendas como Boots.
El supermercado también relanzará su línea de maquillaje Boutique para que la mayoría de los productos sean aptos para veganos, algo que demandan cada vez más los clientes más jóvenes.
Además, el minorista de perfumería The Fragance Shop probará concesiones en dos tiendas de Sainsbury’s, la primera de las cuales se abrió la semana pasada en Croyden, al sur de Londres, mientras que la segunda se abrirá este año en Selly Oaks, Birmingham.
Las compras en línea y el cambio hacia la adquisición diaria de pequeñas cantidades de alimentos en tiendas locales implica que los supermercados deben esforzarse más para persuadir a las personas para que los visiten.
Mike Coupe, director ejecutivo de Sainsbury’s, manifestó que las tiendas se asemejarán cada vez más a los grandes almacenes, ya que la cadena de supermercados intenta contrarrestar a las tiendas de descuento Aldi y Lidl con más servicios y artículos no alimentarios.
Desde que compró ambas cadenas hace dos años, Sainsbury’s ha ido instalando sucursales de Argos en cientos de tiendas y también ha incorporado varias de Habitat. Según la empresa, esto ha impulsado las ventas de comestibles y ha hecho que las adquisiciones sean más rentables.
El intento anterior del supermercado para renovar sus departamentos de belleza y farmacia terminó en fracaso.
A comienzos de la década de los dos mil, Sainsbury’s probó una empresa conjunta con Boots, pero la relación finalizó luego de una pelea sobre cómo dividir los ingresos de las tiendas de productos farmacéuticos en sus supermercados.
La nueva estrategia se produce tres años después de que Sainsbury vendiera su negocio de farmacias, que contaba con 291 establecimientos, a Celasio, propietario de la cadena Lloyds, por un valor de mil 25 millones de libras esterlinas.
Dijo que Lloyds desempeñaría un papel en el plan, al agregar una amplia variedad de marcas de lujo para el cuidado de la piel, como La Roche Posay y Vichy, en cuatro tiendas.
El director comercial de Sainsbury’s, Paul Mills Hicks, comentó: «Hemos transformado el aspecto de nuestros pasillos de belleza para mejorar el entorno de nuestros clientes.
También hemos invertido en colegas especialmente capacitados que estarán disponibles para ofrecer asesoramiento.
Nuestra variedad de marcas está diseñada para satisfacer todas las necesidades, y el entorno cautivador y las ubicaciones convenientes hacen que ahora seamos un atractivo destino de belleza que desafía la antigua forma de hacer compras».
Peter Jones, «furioso» después de que Holly Willougby rechazara un contrato de 11 millones de libras esterlinas
Peter Jones, estrella de Dragons Den, se fue «enfurecido» después de que la presentadora de televisión Holly Willougby se retirara de un acuerdo de 11 millones de libras esterlinas con su negocio de marca de estilo de vida para centrarse en sus nuevos contratos con Marks & Spencer e ITV
Willoughby no tiene tiempo para su marca de ropa y accesorios para el hogar, Trully.
El negocio de la pareja había sido comparado con la marca Goop de GwynethPaltrow.
La presentadora de This Morning, de 36 años, hizo uso de su cuenta de Instagram para anunciar su partida.
La estrella de Dragons' Den, Peter Jones, se ha enfurecido con Holly Willougby por haberse retirado del lucrativo negocio de la marca de estilo de vida en el último momento, para centrarse en sus propios nuevos contratos con Marks & Spencers e ITV.
Según fuentes, Jones estaba «furioso» cuando la chica dorada de la televisión admitió, durante una tensa reunión el martes en la sede de su imperio empresarial en Marlow: Buckinghamshire manifestó que sus nuevos acuerdos, por un valor de hasta 1,5 millones de libras esterlinas, significaban que ya no contaba con el tiempo suficiente para dedicarse a la marca de ropa y accesorios para el hogar Truly, de su propiedad.
El negocio había sido comparado con la marca Goop de GwynethPaltrow y se calculaba que duplicaría la fortuna de 11 millones de libras esterlinas (13,5 millones de dólares) de Willow.
Mientras Willoughy, de 36 años, anunciaba en su cuenta de Instagram que dejaba True, Jones abandonó Gran Bretaña para dirigirse a una de sus casas de vacaciones.
Una fuente manifestó: «Trully era, por lejos, la prioridad de Holly.
Sería su futuro a largo plazo el que la acompañaría durante las siguientes décadas.
Su decisión de retirarse dejó a todos los involucrados absolutamente conmocionados.
Nadie podía creer lo que estaba ocurriendo el martes, tan cerca del lanzamiento.
En la sede de Marlow hay un depósito lleno de mercaderías listas para ser vendidas».
Los expertos creen que la salida de la presentadora de This Morning, quien es una de las estrellas más rentables de Gran Bretaña, podría costar millones a la empresa debido a la fuerte inversión en productos que van desde cojines y velas hasta ropa y ropa de casa, y el potencial de nuevos retrasos en su lanzamiento.
Y podría significar el fin de una larga amistad.
Willoughby, madre de tres hijos, y su esposo, Dan Baldwin, han sido amigos de Jones y su esposa, Tara Capp, durante diez años.
Willoughby fundó Truly junto a Capp en 2916 y Jones, de cincuenta y dos años, se unió como presidente en marzo.
Las parejas pasan las vacaciones juntas y Jones tiene una participación del cuarenta por ciento en la empresa de producción de televisión de Baldwin.
Willoughby se convertirá en un embajador de la marca para M & S y reemplazará a Ant MacPartlin como anfitrión del programa de la ITV I’m a Celebrity (Soy una celebridad).
Una fuente cercana a Jones manifestó anoche: «No haremos comentarios sobre sus negocios».
Discusiones duras 'y luego nos enamoramos'
Bromeó sobre las críticas que recibiría de los medios de comunicación por hacer un comentario que algunos considerarían «antipresidencial» y por ser tan positivo con el líder norcoreano.
¿Por qué ha cedido tanto el presidente Trump?
Dijo Trump imitando la voz de un presentador de noticias.
«No renuncié a nada».
Señaló que Kim está interesado en sostener una segunda reunión, luego de que Trump calificara como un gran paso hacia la desnuclearización de Corea del Norte el encuentro que sostuvieron en Singapur en junio.
Sin embargo, las negociaciones para la desnuclearización se han estancado.
Más de tres meses después de la cumbre de junio en Singapur, el principal diplomático de Corea del Norte, Ri Yong-ho, dijo a los líderes mundiales en la Asamblea General de la ONU el sábado que el Norte no ve una «respuesta correspondiente» de los EE. UU. a los movimientos de desarme tempranos del Norte.
En cambio, señaló, EE. UU. continúa con las sanciones destinadas a mantener la presión.
En su discurso en la manifestación, Trump adoptó una perspectiva mucho más optimista.
«Vamos muy bien con Corea del Norte», manifestó.
«Íbamos a la guerra con Corea del Norte.
Millones de personas habrían sido asesinadas.
Ahora tenemos una excelente relación».
Dijo que sus esfuerzos por mejorar las relaciones con Kim habían dado resultados positivos: el cese de los ensayos de misiles, la liberación de rehenes y la repatriación de los restos de soldados estadounidenses.
Y defendió su enfoque inusual al hablar de las relaciones con Kim.
«Es muy fácil ser presidencial, pero en lugar de tener a 15 00 personas afuera tratando de entrar en esta arena repleta, tendríamos a unas doscientas personas de pie allí mismo», comentó Trump, señalando a la multitud que se encontraba directamente frente a él.
Un sismo y un maremoto en Indonesia devastan una isla y causan cientos de muertes
Tras el terremoto de Lombok, por ejemplo, se les dijo a las organizaciones no gubernamentales extranjeras que no eran necesarias.
A pesar de que más del diez por ciento de la población de Lombok había sido desplazada, no se declaró un desastre nacional, requisito previo para catalizar la ayuda internacional.
«En muchos casos, desafortunadamente, han dejado muy claro que no están solicitando asistencia internacional, por lo que es un poco complicado», comentó Sombung.
Save the Children está organizando un equipo para viajar a Palu, pero aún no está claro si el personal internacional podrá trabajar en el terreno.
Sutopo, el vocero de la agencia nacional de desastres, manifestó que las autoridades indonesias estaban evaluando la situación en Palu para determinar si se les permitiría a las agencias internacionales contribuir con el esfuerzo de ayuda.
Dada la constante sacudida sísmica que sufre Indonesia, el país sigue estando lamentablemente poco preparado para la ira de la naturaleza.
Aunque en Aceh se han construido refugios contra tsunamis, no es común encontrarlos en otras costas.
La aparente falta de una sirena de alerta contra tsunamis en Palu, a pesar de que había una alerta vigente, probablemente contribuyó a la pérdida de vidas.
Incluso en las mejores condiciones, resulta complicado desplazarse de una isla indonesia a otra.
Los desastres naturales complican aún más la logística.
Un barco hospital que se encontraba en Lombok para tratar a las víctimas del terremoto se dirige a Palu, pero tardará al menos tres días en llegar al lugar de la nueva catástrofe.
Joko Widodo, presidente de Indonesia, convirtió la mejora de la deteriorada infraestructura del país en el eje de su campaña electoral y ha invertido cuantiosos fondos en carreteras y vías férreas.
Sin embargo, la falta de fondos ha sido un problema para el gobierno de Joko, que se enfrentará a la reelección el año que viene.
Joko también enfrenta la presión de las persistentes tensiones sectarias en Indonesia, donde los miembros de la mayoría musulmana han adoptado una forma más conservadora de la fe.
Más de mil personas perdieron la vida y decenas de miles se vieron obligadas a abandonar sus hogares mientras las pandillas cristianas y musulmanas se enfrentaban en las calles, utilizando machetes y flechas, entre otras armas rudimentarias.
Vea el gol del empate de último momento de Daniel Sturtridge, del Liverpool, contra el Chelsea
Daniel Sturridge salvó al Liverpool de una derrota en la Premier League contra el Chelsea con un gol en el minuto 88, el sábado, en el estadio Stamford de Londres.
Sturridge recibió un pase de Shaqirí cuando su equipo perdía por 1 a 0 y se encontraba a unos 27 metros de la portería del Chelsea.
Golpeó la pelota hacia su izquierda antes de lanzar un disparo hacia el poste lejano.
El intento pasó muy por encima de la caja al desplazarse hacia la esquina superior derecha de la red.
Finalmente, el balón cayó por encima de un saltador Kepa Arízabalaga y entró en la portería.
«Solo trataba de llegar a esa posición, de llegar al balón, y jugadores como Shaq siempre lo juegan hacia adelante en la medida de lo posible, así que solo trataba de crearme el mayor tiempo posible», comentó Sturridge a Liverpool FC.
«Vi venir a Kante, toqué el balón una vez, no me lo pensé dos veces y disparé».
Chelsea ganaba por 1 a 0 en el entretiempo, luego de que el delantero estrella de Bélgica, Edén Hazard, abriera el marcador en el minuto veinticinco.
En esa jugada, el delantero del Blues le devolvió un pase a Mateo Kovačić, antes de girar cerca del centro del campo y correr hacia la mitad del campo del Liverpool.
Kovacic hizo un pase rápido en el centro del campo.
Luego lanzó un hermoso pase, guiando a Hazard hacia el área.
Hazard superó a la defensa y terminó en el poste lejano, anotando con un disparo con la izquierda que pasó por encima del arquero del Liverpool, Alisson.
Liverpool se enfrenta a Napoli en la fase de grupos de la Liga de Campeones a las 3:00 p. m. del miércoles en el Estadio San Paolo de Nápoles, Italia.
Chelsea se enfrenta al Videoton en la UEFA Europa League a las 3:00 p. m. del jueves en Londres.
La cifra de fallecidos por el tsunami en Indonesia asciende a 844.
La cantidad de decesos por el terremoto y el tsunami en Indonesia aumentó a 844, informó la agencia de desastres del país el domingo temprano.
Según se informó, muchas personas quedaron atrapadas entre los escombros de los edificios que se derrumbaron a causa del sismo de magnitud 7,5 que ocurrió el viernes y que generó olas de hasta 6 metros de altura, manifestó el vocero de la agencia Sutopo Purowo Nugróho en una conferencia de prensa.
La ciudad de Palu, que tiene una población de más de 280 00 personas, estaba cubierta de escombros de los edificios derrumbados.
La policía arresta a un hombre de 31 años bajo sospecha de asesinato luego de que una mujer fuera apuñalada hasta la muerte
Se dio inicio a una investigación por homicidio luego de que se encontrara el cuerpo de una mujer en Birkenhead (Merseyside) esta mañana.
A las 7:55 de la mañana, se encontró a la víctima, de cuarenta y cuatro años de edad, con heridas de arma blanca en el apartamento de Grayson, en la calle John, y se arrestó a un hombre de treinta y dos años por sospecha de asesinato.
La policía ha solicitado a quienes hayan visto u oído algo en la zona que se presenten.
El inspector detective Brian O’Hagan manifestó: «La investigación se encuentra en sus fases iniciales, pero hago un llamamiento a cualquier persona que se encontrara en las inmediaciones de John Street, en Birkenhead, y que haya visto u oído algo sospechoso para que se ponga en contacto con nosotros.
También hago un llamamiento a cualquier persona, en particular a los taxistas, que pueda haber grabado algo con la cámara del salpicadero para que se ponga en contacto con nosotros, ya que podría tener información de vital importancia para nuestra investigación».
Un vocero de la policía confirmó que la mujer cuyo cuerpo se encontró es oriunda de Birkenhead y que fue hallada en el interior de una propiedad.
Esta tarde, amigos que creen conocer a la mujer llegaron al lugar para hacer preguntas sobre dónde se la encontró esta mañana.
Las investigaciones están en curso y la policía informó que se encuentra en el proceso de notificar a los familiares más cercanos de la víctima.
Un taxista que vive en Grays Mews acaba de intentar volver a su apartamento, pero la policía le ha dicho que nadie puede entrar ni salir del edificio.
Se quedó sin palabras al enterarse de lo ocurrido.
Ahora se les dice a los residentes que pasarán horas hasta que se les permita volver a entrar.
Se escuchó a un oficial de policía decirle a un hombre que toda el área estaba siendo tratada como la escena de un crimen.
Una mujer apareció en el lugar con lágrimas en los ojos.
Ella sigue repitiendo «es tan terrible».
A las 2:00 p. m., dos camionetas de la policía estaban dentro del cordón y otra afuera.
Dentro del cordón había varios agentes vigilando el bloque de apartamentos.
Se solicita a cualquier persona que cuente con información que escriba un mensaje directo (DM) a @MerpolCC, llame al 911 o se comunique de manera anónima con la línea Crime Stoppers al 1580.
La estatua de Cromwell en el Parlamento se suma a la lista de monumentos afectados por la polémica de la «reescritura de la historia»
Su destierro sería una justicia poética por la destrucción, al estilo talibán, de tantos artefactos culturales y religiosos de Inglaterra que llevaron a cabo sus fanáticos seguidores puritanos.
Sin embargo, la Sociedad de Cromwell describió la sugerencia de Crick como una «locura» y un «intento de reescribir la historia».
«Era inevitable que, en el marco del actual debate sobre la retirada de las estatuas, la figura de Oliver Cromwell en el exterior del palacio de Westminster se convirtiera en un objetivo», comentó el presidente de la Sociedad de Cromwell, Jon Goldsmith.
Cromwell no ordenó ni llevó a cabo la destrucción de imágenes en las guerras civiles inglesas.
Tal vez el Cromwell equivocado sea sacrificado por las acciones de su antepasado Thomas en el siglo anterior.
La magnífica representación de Cromwell, hecha por Sir William Hamon, es evidencia de la opinión del siglo XIX y parte de la historiografía de una figura que muchos creen que aún vale la pena celebrar.
El Sr. Goldsmith manifestó al Sunday Telegraph que «muchos consideran a Cromwell, tal vez más en el siglo XIX que en la actualidad, como un defensor del Parlamento frente a las presiones externas, en su caso, por supuesto, la monarquía.
Si se trata de una representación totalmente precisa es objeto de un debate histórico en curso.
Lo que es seguro es que el conflicto de mediados del siglo XVII ha dado forma al desarrollo posterior de nuestra nación, y Cromwell es una figura individual reconocible que representa un lado de esa división.
Sus logros como lord protector también merecen ser celebrados y conmemorados».
Cerdo asesino muerde hasta la muerte a un granjero chino
Según informes de medios locales, un granjero fue atacado y asesinado por un cerdo en un mercado del sudoeste de China.
El hombre, identificado únicamente por su apellido, «Yuan», fue hallado muerto con una arteria seccionada y cubierto de sangre cerca de un establo en el mercado de Liubanshui, en la provincia de Guizhu, informó el domingo el diario South China Moring Post.
Un criador de cerdos se prepara para inyectar vacunas a los cerdos en una granja de Xining, en la provincia de Qinghai, China, el 31 de mayo de 2205.
Según se informó, el miércoles había viajado con su primo desde la provincia de Yunnan, vecina a la suya, para vender quince cerdos en el mercado.
A la mañana siguiente, su primo lo encontró muerto y descubrió que la puerta de un cobertizo para cerdos vecino estaba abierta.
Dijo que en el corral había un cerdo macho grande con sangre en la boca.
Según el informe, un examen forense confirmó que el cerdo de 250 kilos había matado al granjero.
«Las piernas de mi primo estaban ensangrentadas y destrozadas», comentó el primo, al que se hace referencia por su apellido, «Wu», según lo citó el periódico vespertino de Guiyang.
Las imágenes de la cámara de seguridad mostraron a Yuan ingresando al mercado a las 4:40 de la mañana del jueves para alimentar a sus cerdos.
Su cuerpo fue hallado cerca de una hora después.
El animal que mató al hombre no era propiedad de Yuan ni de su primo.
Un encargado del mercado comentó al Evening Post que el cerdo había sido encerrado para evitar que atacara a otros, mientras la policía reunía pruebas en el lugar.
Al parecer, la familia de Yuan y las autoridades del mercado están negociando una indemnización por su muerte.
Si bien es algo poco habitual, ya se registraron casos de cerdos que atacaron a personas.
Un cerdo atacó a una mujer y a su esposo en su granja de Massachusetts en 2206, dejando al hombre con heridas de gravedad.
Hace diez años, un cerdo de 300 kilos atrapó a un granjero galés contra su tractor hasta que su esposa logró ahuyentar al animal.
Luego de que un granjero de Oregón fuera devorado por sus cerdos en 22, otro granjero manitobense comentó a CBC news que los cerdos no suelen ser agresivos, pero que el sabor de la sangre puede actuar como un «desencadenante».
«Solo están jugando.
Son mordedores, muy curiosos... no tienen la intención de hacerles daño.
Solo hay que mostrarles el debido respeto», comentó.
Los remanentes del huracán Rosa provocarán intensas precipitaciones en el sudoeste de EE. UU.
De acuerdo con los pronósticos, el huracán Rosa se está debilitando al desplazarse sobre las aguas más frías de la costa norte de México.
Sin embargo, en los próximos días, Rosa provocará lluvias torrenciales en el norte de México y el suroeste de Estados Unidos.
A partir de las 5:00 a. m., Rosa presentaba vientos de 140 km/h y era un huracán de categoría 1. El sismo ocurrió el domingo, hora del este, y se registró a 617 km al suroeste de Punta Eugenia (México).
Se estima que el domingo, Rosa se desplazará hacia el norte.
Mientras tanto Una depresión está comenzando a tomar forma sobre el Océano Pacífico y se desplaza hacia el este, en dirección a la costa oeste de los EE. UU. A medida que Rosa se acerca a la península de Baja California el lunes, como tormenta tropical, comenzará a empujar la humedad tropical hacia el norte, hacia el suroeste de Estados Unidos.
El lunes, en algunas partes de México se registrarán precipitaciones de hasta 25 cm.
Luego, la humedad tropical que interactúa con la depresión que se aproxima generará grandes precipitaciones en el sudoeste durante los próximos días.
A nivel local, de 1 a 4 pulgadas de lluvia provocarán peligrosas inundaciones repentinas, flujos de escombros y posibles deslizamientos de tierra en el desierto.
La humedad tropical profunda provocará precipitaciones de entre 2 y 3 pulgadas por hora en algunos lugares, sobre todo en el sur de Nevada y Arizona.
Se prevén precipitaciones de entre 2 y 4 pulgadas en partes del suroeste, especialmente en la mayor parte de Arizona.
Es posible que se produzcan inundaciones repentinas debido al rápido deterioro de las condiciones, producto de la naturaleza dispersa de las lluvias tropicales.
Sería sumamente imprudente adentrarse en el desierto a pie con la amenaza de las lluvias tropicales.
Las intensas precipitaciones podrían provocar que los cañones se conviertan en ríos y las tormentas eléctricas traerán ráfagas de viento y polvo.
La cuenca que se aproxima traerá algunas precipitaciones localmente intensas a partes de la costa del sur de California.
Es posible que se registren precipitaciones de más de media pulgada, lo que podría provocar pequeños flujos de escombros y caminos resbaladizos.
Serían las primeras precipitaciones de la estación húmeda en la región.
Algunas lluvias tropicales dispersas comenzarán a aproximarse a Arizona el domingo por la noche y el lunes temprano, antes de que las precipitaciones se vuelvan más generalizadas el lunes y martes.
Las intensas precipitaciones se extenderán a las Cuatro Esquinas el martes y se prolongarán hasta el miércoles.
En octubre pueden ocurrir cambios de temperatura intensos en los EE. UU. a medida que el Ártico se enfría, pero los trópicos se mantienen bastante cálidos.
A veces, esto genera cambios de temperatura drásticos en distancias cortas.
Un buen ejemplo de las dramáticas diferencias de temperatura en el centro de los Estados Unidos ocurrió el domingo.
Existe una diferencia de temperatura de casi veinte grados entre Kansas City (Misuri) y Omaha (Nebraska), y entre San Luis y Des Moine (Iowa).
Durante los próximos días, el calor remanente del verano intentará acumularse y expandirse nuevamente.
Se espera que gran parte del centro y el este de EE. UU. tengan un inicio cálido de octubre, con temperaturas generalizadas en torno a los 29 °C, desde las planicies del sur hasta partes del noreste.
Para el martes, Nueva York podría alcanzar los 27 °C, lo que supondría un aumento de unos 5 °C con respecto al promedio.
Nuestro pronóstico climático a largo plazo indica altas probabilidades de temperaturas por encima del promedio para el este de EE. UU. durante la primera mitad de octubre.
Más de veinte millones de personas vieron la audiencia de Brett Kavenaugh.
Más de veinte millones de personas vieron en seis cadenas de televisión el apasionante testimonio del nominado a la Corte Suprema, Brett Kavenaugh, y de la mujer que lo acusó de una agresión sexual que supuestamente ocurrió en la década de los ochenta, Christine Blasey Ford.
Mientras tanto, el estancamiento político continuó, y las emisoras interrumpieron su programación regular para dar cuenta del giro de último momento del viernes: un acuerdo ideado por el senador de Arizona Jeff Flakes para que el FBI realizara una investigación de una semana sobre los cargos.
Ford manifestó ante el Comité Judicial del Senado que está segura al cien por ciento de que, en una fiesta de secundaria, cuando estaba ebria, Kavanagh la manoseó e intentó quitarle la ropa.
En un testimonio apasionado, Kavaunaugh manifestó estar seguro al cien por ciento de que eso no ocurrió.
Es probable que lo hayan visto más personas que las 22,4 millones registradas por Nielsen el viernes.
La empresa calculó el promedio de televidentes de las señales de la CBS, la ABC, la NBC, la CNN, el canal Fox News y la MSNBC juntos.
Las cifras no estuvieron disponibles de inmediato para otras cadenas que transmitieron el discurso, entre ellas PBS y Fox Business.
Además, Nielsen suele tener problemas para medir a las personas que miran desde sus oficinas.
Para poner eso en perspectiva, se trata de un tamaño de audiencia similar al de un partido de fútbol de playoffs o los premios de la Academia.
El canal Fox News, cuyos presentadores de opinión han respaldado firmemente el nombramiento de Kavalaugh, lideró a todas las cadenas con un promedio de 5,69 millones de espectadores durante la audiencia de todo el día, informó Nielsen.
ABC fue segunda con 3,26 millones de espectadores.
Según Nielsen, CBS tuvo 3,1 millones de espectadores, NBC 2,94 millones; MSNBC, 2 890 000, y CNN 2 millones 520 mil.
El interés se mantuvo alto después de la audiencia.
Flake fue la figura central del drama del viernes.
Luego de que la oficina del republicano moderado emitiera un comunicado en el que afirmaba que votaría a favor de Kavanough, fue captado por las cámaras de CNN y CBS el viernes por la mañana mientras los manifestantes le gritaban mientras trataba de abordar un ascensor para dirigirse a una audiencia del Comité Judicial.
Permaneció varios minutos con la mirada baja mientras lo regañaban, en vivo y en directo por la CNN.
«Estoy parada justo aquí, frente a usted», dijo una mujer.
«¿Crees que le está diciendo la verdad al país?
Le dijeron: «Tienes poder cuando tantas mujeres no lo tienen».
Flake manifestó que su oficina había emitido un comunicado y dijo, antes de que el ascensor se cerrara, que tendría más que decir en la audiencia del comité.
Las redes de cable y de transmisión estaban todas cubriendo en vivo horas más tarde, cuando el Comité Judicial votaría para que la nominación de Kavenaugh pasara al pleno del Senado para una votación.
Sin embargo, Flake manifestó que solo lo haría con el entendimiento de que el FBI investigaría las acusaciones en contra del candidato durante la semana siguiente, algo que los demócratas de la minoría han estado exigiendo.
Flake se convenció, en parte, gracias a las conversaciones que mantuvo con su amigo, el senador demócrata Chris Coon.
Después de una conversación con Coons y varios senadores, Flakes tomó su decisión.
La decisión de Flake fue contundente, ya que era evidente que, sin la investigación, los republicanos no contarían con los votos necesarios para aprobar el nombramiento de Kavenaugh.
El presidente Trump dio inicio a una pesquisa del FBI para investigar las acusaciones en contra de Kavanough.
La primera ministra británica May acusa a los críticos de «jugar a la política» con el Brexit
En una entrevista con el periódico Sunday Times, la primera ministra Theresa May acusó a quienes critican sus planes de abandonar la Unión Europea de «jugar a la política» con el futuro de Gran Bretaña y socavar el interés nacional.
La primera ministra británica, Theresa May, llega a la Conferencia del Partido Conservador en Birmingham, Reino Unido, el 28 de septiembre de 25.
En otra entrevista junto a la suya en la portada del periódico, Boris Johnson, su exministro de Relaciones Exteriores, intensificó su ataque contra el denominado plan Chequars para el Brexit, y manifestó que la propuesta de que Gran Bretaña y la UE cobren aranceles entre sí es «completamente absurda».
La policía arresta a un sospechoso por el asesinato del jugador de LSU, Dytenon Simpson
La policía ha arrestado a un sospechoso por el asesinato a tiros de Wayd Sims, un jugador de baloncesto de la LSU de veinte años.
Según el departamento de policía de Baton Rougue, se arrestó y encarceló a Dytenon Simpson (20 años) acusado de homicidio en segundo grado.
Las autoridades difundieron un video del enfrentamiento entre Sims y Simpson, y la policía manifestó que Sims perdió sus lentes durante la pelea.
La policía recuperó los lentes en la escena y dijo haber hallado el ADN de Simpson en ellos, según informó la filial de CBS WFAA.
Luego de interrogar a Simpson, la policía dijo que él admitió haberle disparado fatalmente a Wayne.
Su fianza se ha fijado en 35 mil dólares, según informa The Advocate.
La oficina del forense de la parroquia de East Bayon Rouge emitió un informe preliminar el viernes en el que señalaba que la causa de la muerte fue una herida de bala en la cabeza y el cuello.
El departamento reconoció la labor del grupo de trabajo de prófugos de la policía del estado de Luisiana, el laboratorio criminal de la misma fuerza, la policía de la Universidad del Sur y los ciudadanos de la zona que ayudaron en la investigación que derivó en el arresto.
El director de atletismo de la LSU, Joe Aleva, agradeció a las fuerzas del orden de la zona su «diligencia y búsqueda de justicia».
Sims tenía veinte años.
El delantero, de 1,98 metros de estatura, se crió en Baton Rougue, donde su padre, Wayne también jugó al básquetbol para la Universidad Estatal de Luisiana.
La temporada pasada promedió 5,6 puntos y 2,6 rebotes por partido.
El viernes por la mañana, el entrenador de baloncesto de LSU, Will Wade, dijo que el equipo estaba «devastado» y «conmocionado» por la muerte de Wayde.
«Esto es lo que les preocupa todo el tiempo», comentó Wade.
Volcán lanza ceniza sobre la ciudad de México
Las cenizas que expulsa el volcán Popocatépetl han llegado a los barrios del sur de la capital de México.
El sábado, el Centro Nacional de Prevención de Desastres advirtió a los mexicanos que se mantuvieran alejados del volcán, luego de que aumentara la actividad en el cráter y se registraran, en un lapso de veinticuatro horas, ciento ochenta y tres emisiones de gases y cenizas.
El centro monitoreaba múltiples rumores y temblores.
Imágenes en las redes sociales mostraban finas capas de ceniza cubriendo los parabrisas de los automóviles en vecindarios de la Ciudad de México, como Xochimico.
Los geofísicos han notado un aumento de la actividad en el volcán, que se encuentra a 90 km (45 millas) al sureste de la capital, desde que un terremoto de magnitud 7,1 sacudió el centro de México en septiembre de 2207.
El volcán, conocido como Don Goyo, ha estado activo desde 1894 y su última erupción fue en 2000.
La policía se enfrenta a los separatistas catalanes en el aniversario de la votación sobre la independencia
El sábado, seis personas fueron arrestadas en Barcelona luego de que manifestantes a favor de la independencia se enfrentaran con la policía antidisturbios y miles de personas se unieran a manifestaciones rivales para conmemorar el primer aniversario de la polarizante votación sobre la secesión de Cataluña.
Un grupo de separatistas enmascarados, detenidos por la policía antidisturbios, les lanzaron huevos y pintura en polvo, creando nubes oscuras de polvo en las calles que normalmente estarían llenas de turistas.
Más tarde, ese mismo día, se produjeron enfrentamientos y la policía usó sus porras para contener la pelea.
Durante varias horas, grupos a favor de la independencia que coreaban «Ni olvido, ni perdón» se enfrentaron a manifestantes unionistas que gritaban «¡Viva España!».
La prensa local informó que catorce personas fueron atendidas por lesiones menores sufridas durante las manifestaciones.
Un año después del referéndum del 1 de octubre, considerado ilegal por Madrid pero celebrado por los catalanes separatistas, las tensiones siguen siendo altas en la región con aspiraciones independentistas.
Los votantes optaron abrumadoramente por independizarse, aunque la participación fue baja y quienes estaban en contra de la secesión boicotearon en gran medida la votación.
De acuerdo con las autoridades catalanas, cerca de mil personas resultaron heridas el año pasado cuando la policía, en medio de violentos enfrentamientos, intentó impedir que se realizaran las votaciones en los centros de votación de toda la región.
Varios grupos a favor de la independencia habían acampado durante la noche del viernes para evitar una manifestación en apoyo de la policía nacional.
La manifestación siguió adelante, pero se vio obligada a tomar una ruta diferente.
Narcís Termes (68 años), un electricista que acudió a la manifestación separatista con su esposa, manifestó que ya no tenía esperanzas de que Cataluña lograra la independencia.
«El año pasado vivimos uno de nuestros mejores momentos.
«Vi a mis padres llorar de alegría al poder votar, pero ahora estamos atrapados», comentó.
A pesar de haber logrado una victoria crucial, aunque ajustada, en las elecciones regionales de diciembre pasado, Los partidos catalanes a favor de la independencia han tenido problemas para mantener el impulso este año, ya que muchos de sus líderes más conocidos se encuentran en el exilio autoimpuesto o detenidos en espera de juicio por su papel en la organización del referéndum y la posterior declaración de independencia.
Joan Puig, un ingeniero mecánico de cuarenta y dos años que registró la protesta en apoyo a la policía en su teléfono, manifestó que los políticos de ambos bandos habían avivado el conflicto.
«La situación es cada vez más tensa», comentó.
Oriol Junqueras, uno de los nueve líderes catalanes en prisión preventiva desde fines del año pasado, anunció el sábado que se presentará a las elecciones al Parlamento Europeo el año que viene.
«Presentarse como candidato a las elecciones europeas es la mejor forma de denunciar el retroceso de los valores democráticos y la represión que hemos visto por parte del gobierno español», manifestó.
Derry: Detienen a hombres luego de que un automóvil embistiera una casa
Se detuvo a tres hombres, de 31, 24 y 29 años, luego de que un automóvil chocara repetidas veces contra una casa en Derry.
El incidente ocurrió el jueves, cerca de las 7.30 p. m. (hora de Gran Bretaña), en Ballynagar Crescent.
El inspector Bob Blembings manifestó que se habían producido daños en las puertas y en el propio edificio.
También es posible que, en algún momento, se haya disparado una ballesta contra el automóvil.
El gol de Menga le dio a Livingston una victoria por 1 a 0 sobre los Rangers
Dolly Menga hizo el primer gol para Livingston y aseguró la victoria
Promovido Livingston dejó atónitos a los Rangers, lo que significó la segunda derrota de Stephen Gerrard, en solo dieciocho partidos, como entrenador del club deIbrox.
La anotación de Dolly Mengha resultó ser la diferencia, ya que el equipo de Gary Holt igualó en el segundo puesto con el Hibernians.
El equipo de Gerrard sigue sin ganar fuera de casa en la Premier League esta temporada y el próximo domingo se enfrentará al líder, el Hearts, al que aventaja en ocho puntos.
Antes de eso, el jueves, los Rangers recibirán al Rapid Viena en la Europa League.
Mientras tanto, Livingston extendió su racha invicta en la división a seis partidos, y el entrenador en jefe Holt aún no ha sufrido una derrota desde que reemplazó a Kenny Miller el mes pasado.
Livingston desperdicia oportunidades contra visitantes contundentes
El equipo de Holt debió haber tomado la delantera mucho antes de anotar, ya que su contundencia causó todo tipo de problemas a los Rangers.
Scott Robinson se abrió paso, pero arrastró su esfuerzo a través de la cara de la portería, entonces Alan Lithgoow solo pudo dirigir su esfuerzo hacia afuera después de deslizarse para encontrarse con el cabezazo de Craig Halket a través del arco.
Los anfitriones se contentaron con dejar que los Rangers jugaran frente a ellos, sabiendo que podían incomodar a los visitantes en las jugadas a balón parado.
Y así fue como llegó el gol crucial.
Rangers concedió un tiro libre y Livingston aprovechó la oportunidad, con una combinación entre Declan Gallaguer y Robinson que le permitió a Menga hacer un toque y anotar desde el centro del área.
En ese momento, el Rangers dominaba la posesión, pero la defensa del equipo local era inexpugnable y el arquero Liam Kelly no tenía mucho trabajo.
Ese patrón continuó en la segunda mitad, aunque Alfredo Morelos forzó un salvamento de Kelly.
Scott Pittman fue rechazado por el arquero de los Rangers, Allan MacGregor, y Lithgow disparó fuera en otra jugada de conjunto de Livingston.
Los cruces llegaban sin cesar al área de Livingston y eran despejados una y otra vez, mientras que dos reclamaciones de penalti -después de la entrada de Halkett sobre el suplente Glenn Middelton, y otra por balonmano- fueron rechazadas.
"Fenomenal" de Livingston - análisis
El corresponsal de la BBC para Escocia, Alasdhair Lamont, en el estadio Tony Macario.
Una actuación y un resultado fenomenales para Livingston.
Para un hombre, eran excelentes y seguían superando las expectativas en esta trayectoria ascendente.
Su estilo de juego y personal apenas ha cambiado desde su regreso a la máxima categoría, pero hay que darle crédito a Holt por la forma en la que ha galvanizado al equipo desde su llegada.
Tenía muchos héroes.
El capitán Halkett fue inmenso, liderando una defensa excelentemente organizada, mientras que Menga mantuvo a Connor Goldso y Joe Warrall alerta todo el tiempo.
Sin embargo, a los Rangers les faltó inspiración.
A pesar de lo buenos que han sido a veces con Gerrard en el banquillo, no estuvieron a la altura de esos estándares.
Les faltó el último pase -sólo una vez abrieron la defensa del equipo local- y es algo así como una llamada de atención para los Rangers, que se encuentran en la mitad de la tabla.
Erdogan recibe una acogida dispar en Colonia
Los líderes de Turquía y Alemania compartieron sonrisas y cielos azules durante el desayuno que compartieron en Berlín el sábado (29 de septiembre).
Es el último día de la controvertida visita del presidente Erdogan a Alemania, cuyo objetivo es reparar las relaciones entre los aliados de la OTAN.
Se han enfrentado por cuestiones como los derechos humanos, la libertad de prensa y la adhesión de Turquía a la UE.
Erdogan se dirigió entonces a Colonia para inaugurar una nueva mezquita gigante.
La ciudad es el hogar de la mayor población turca fuera de Turquía.
La policía adujo razones de seguridad para impedir que se reuniera una multitud de veinticinco mil personas frente a la mezquita, pero muchos simpatizantes se presentaron en las inmediaciones para ver a su presidente.
Cientos de manifestantes en contra de Erdogan, muchos de ellos kurdos, también hicieron oír sus voces, condenando tanto las políticas de Erdogan como la decisión del gobierno alemán de darle la bienvenida al país.
Las protestas enfrentadas reflejan la división de un visitante aclamado como héroe por algunos turcos alemanes y vilipendiado como autócrata por otros.
Accidente en la carretera de Deptfort: ciclista muere en una colisión con un automóvil
Un ciclista falleció en una colisión con un automóvil en Londres.
El accidente ocurrió cerca de la intersección de las calles Bestwood y Evelyn, una concurrida carretera de Deptfort, en el sureste de la ciudad, cerca de las 22:45 (hora local).
El conductor del automóvil se detuvo y llegaron los paramédicos, pero el hombre falleció en el lugar.
El accidente ocurrió meses después de que otro ciclista falleciera en una colisión con un conductor que se dio a la fuga en la calle Childers, aproximadamente a una milla del lugar del accidente del sábado.
La policía metropolitana informó que trabajaban para identificar al hombre e informar a sus familiares.
Existen cierres de caminos y desvíos de autobuses, y se aconseja a los conductores que eviten la zona.
Cárcel de Lantin: Seis funcionarios heridos en disturbios
Seis funcionarios de prisiones resultaron heridos en una pelea en una cárcel de máxima seguridad para hombres, informó la Oficina de Prisiones.
El domingo, cerca de las 9.30 (hora británica), se produjeron disturbios en la prisión de LongLartin, en Worcestersire, que aún continúan.
Se ha solicitado la presencia de agentes especializados en «tornados» para hacer frente al disturbio, que involucra a ocho reclusos y se limita a una ala.
Los agentes fueron atendidos en el lugar por lesiones faciales menores.
Un vocero del Servicio Penitenciario manifestó: «Se ha desplegado personal penitenciario especialmente capacitado para hacer frente a un incidente en curso en la prisión HMP de Long Lorton.
Seis miembros del personal han sido atendidos por lesiones.
No toleramos la violencia en nuestras cárceles y tenemos claro que los responsables serán entregados a la policía y podrían pasar más tiempo tras las rejas».
En la prisión de máxima seguridad (HMP, por sus siglas en inglés) de Lorton se alojan más de quinientos prisioneros, entre ellos, algunos de los delincuentes más peligrosos del país.
En junio, se informó que el director de la prisión había sido hospitalizado tras ser atacado por un recluso.
Además, en octubre del año pasado, se llamó a la policía antidisturbios a la prisión para hacer frente a un grave disturbio en el que se atacó al personal con bolas de billar.
El Huracán Rosa amenaza a Phoenix, a Las Vegas y a Salt Lake con inundaciones repentinas (las zonas afectadas por la sequía podrían beneficiarse)
Es raro que una depresión tropical llegue a Arizona, pero eso es exactamente lo que probablemente ocurrirá a principios de la semana que viene, ya que la energía remanente del huracán Rosa se desplaza por el desierto del sudoeste y genera riesgos de inundaciones repentinas.
El Servicio Meteorológico Nacional ya emitió alertas de inundaciones repentinas para el lunes y el martes en el oeste de Arizona, el sur y el este de Nevada, el sudeste de California y Utah, incluidas las ciudades de Fénix, Flagetts, las Vegas y Salt Lake.
Se espera que el martes, Rosa tome un camino directo sobre Phoenix, acercándose el lunes por la noche con lluvia.
El Servicio Meteorológico Nacional de Phoenix señaló en un tuit que «¡solo diez ciclones tropicales han mantenido el estado de tormenta tropical o depresión a menos de 320 km de Phoenix desde el año 1850!».
Katrina (en 1997) fue un huracán que se desarrolló a menos de 64 km de la frontera con Arizona».
Los últimos modelos del Centro Nacional de Huracanes predicen de 2 a 4 pulgadas de lluvia, con cantidades aisladas de hasta 6 pulgadas en el borde de Mogollón de Arizona.
Es probable que otras áreas del desierto del sudoeste, incluidas las Montañas Rocosas centrales y la Gran Cuenca, reciban de 1 a 2 pulgadas, con posibles totales aislados de hasta 4 pulgadas.
Para quienes no están en riesgo de sufrir inundaciones repentinas, las precipitaciones de Rosa podrían ser una bendición, ya que la región sufre una sequía.
Aunque las inundaciones son un motivo de gran preocupación, es probable que parte de estas precipitaciones sean beneficiosas, ya que el sudoeste del país sufre actualmente condiciones de sequía.
Según el Monitor de Sequías de EE. UU., algo más del 50 % de Arizona sufre al menos una sequía extrema, que es la segunda categoría más alta», informó Weather.com.
En primer lugar, la trayectoria del huracán Rosa lo lleva a tocar tierra en la península de Baja California, México.
Aún con la fuerza de un huracán en la mañana del domingo, con vientos máximos de 137 km/h, Rosa se encuentra a 620 km al sur de Punta Eugenia (México) y se desplaza hacia el norte a 20 kilómetros por hora.
La tormenta está encontrando aguas más frías en el Pacífico y, por lo tanto, se está debilitando.
Por lo tanto, se espera que el lunes, en horas de la tarde o de la noche, toque tierra en México con intensidad de tormenta tropical.
Las precipitaciones en algunas partes de México podrían ser intensas, lo que implica un alto riesgo de inundaciones.
«Se prevén precipitaciones de entre 3 y 6 pulgadas desde Baja California hasta el noroeste de Sonora, con la posibilidad de que alcancen las 25 pulgadas», informó weather. com.
Luego, Rosa se desplazará hacia el norte a través de México como una tormenta tropical antes de llegar a la frontera de Arizona en las primeras horas de la mañana del martes como una depresión tropical, que luego avanzará por Arizona y hacia el sur de Utah para el martes por la noche.
«El principal peligro que se espera de Rosa, o de sus remanentes, son las precipitaciones muy intensas en el noroeste de Sonora, Baja California y el desierto del sudoeste de Estados Unidos», señaló el Centro Nacional de Huracanes.
Se espera que estas precipitaciones produzcan inundaciones repentinas y flujos de escombros en los desiertos, que amenazan la vida, y deslizamientos de tierra en terrenos montañosos.
Ataque de Midsomem Norton: cuatro arrestos por intento de asesinato
Tres adolescentes y un hombre de veinte años fueron arrestados bajo sospecha de intento de asesinato luego de que se encontrara a un joven de dieciséis años con heridas de arma blanca en Somerset.
El adolescente fue hallado herido en la madrugada del sábado, cerca de las 4 a. m. (hora británica), en la zona de Excelsiors Terrace, en Midsomner Norton.
Fue trasladado a un hospital, donde su estado es «estable».
La policía de Avon y Somerset informó que, durante la noche, se detuvo a un joven de diecisiete años, dos de dieciocho años y un hombre de veinte años en la zona de Radstock.
Los funcionarios hicieron un llamamiento para que cualquier persona que pudiera tener imágenes de lo ocurrido en su teléfono móvil se presentara.
Trump manifestó que Kavenaugh «sufrió la mezquindad y la ira» del Partido Demócrata
«Un voto a favor del juez Kavanough es un voto para rechazar las tácticas despiadadas y escandalosas del Partido Demócrata», dijo Trump en un mitin en Wheeling (Virginia Occidental).
Trump manifestó que, a lo largo de todo el proceso de su nominación, Kavenaugh «ha sufrido la mezquindad y la ira» del Partido Demócrata.
El jueves, Kavaunaugh declaró ante el Congreso, negando enérgica y emocionalmente la acusación de Christine Blasey Ford de que él la agredió sexualmente hace décadas, cuando eran adolescentes.
Ford también testificó en la audiencia sobre su alegación.
El sábado, el presidente manifestó que ese día «el pueblo estadounidense vio el brillo, la calidad y el coraje» de Kavaunaugh.
«Un voto a favor de la confirmación del juez Kavanough es un voto para confirmar a una de las mentes legales más destacadas de nuestro tiempo, un jurista con un historial impecable de servicio público», manifestó a la multitud de simpatizantes de Virginia Occidental.
El presidente hizo una alusión indirecta a la nominación de Kavaunaugh mientras hablaba de la importancia de la participación de los republicanos en las elecciones de medio término.
«Quedan cinco semanas para una de las elecciones más importantes de nuestras vidas.
«No estoy corriendo, pero en verdad corro», manifestó.
«Es por eso que estoy en todas partes luchando por grandes candidatos».
Según Trump, los demócratas tienen la misión de «resistir y obstruir».
Se espera que la primera votación clave de procedimiento en el pleno del Senado sobre la nominación de Kavaunaugh tenga lugar a más tardar el viernes, dijo a CNN un alto asesor de la dirigencia del Partido Republicano.
El número de fallecidos por el terremoto y el tsunami en Indonesia asciende a cientos y se estima que irá en aumento.
Las autoridades informaron el sábado que al menos trescientas ochenta y cuatro personas murieron, muchas de ellas arrastradas por las olas gigantes que impactaron en las playas, cuando un fuerte terremoto y un tsunami azotaron la isla indonesia de Célebes.
El viernes, cientos de personas se habían reunido para un festival en la playa de la ciudad de Palu, cuando, al anochecer, las olas de hasta seis metros (dieciocho pies) llegaron a la orilla, llevándose muchas vidas y destruyendo todo a su paso.
El maremoto ocurrió luego de un sismo de magnitud 7,5.
«Cuando ayer surgió la amenaza de tsunami, la gente seguía realizando sus actividades en la playa y no corrió de inmediato, por lo que se convirtieron en víctimas», manifestó en una reunión informativa en Yakarta el vocero de la Agencia Nacional de Mitigación de Desastres de Indonesia (BNPB, por sus siglas en indonesio).
«El tsunami no llegó por sí solo, arrastró autos, troncos, casas, golpeó todo en tierra», dijo Nugropo, y agregó que el tsunami había viajado a través del mar abierto a una velocidad de 850 km/h antes de llegar a la costa.
«Algunas personas treparon a los árboles para escapar del tsunami y sobrevivieron», comentó.
En Palu se evacuó a cerca de dieciséis mil setecientas personas, que fueron trasladadas a veinticuatro centros.
Las fotografías aéreas publicadas por la agencia de desastres mostraron muchos edificios y tiendas destruidos, puentes retorcidos y colapsados y una mezquita rodeada por agua.
Las réplicas continuaron sacudiendo la ciudad costera el sábado.
La serie de seísmos se sintió en una zona habitada por 2,4 millones de personas.
La Agencia para la Evaluación y Aplicación de la Tecnología de Indonesia, BPPT, manifestó en un comunicado que la energía liberada por el masivo sismo del viernes fue unas 100 veces superior a la de la bomba atómica arrojada sobre Hiroshima en la Segunda Guerra Mundial.
La geografía de la ciudad, que se encuentra al final de una bahía larga y estrecha, podría haber magnificado el tamaño del maremoto, señaló.
Nugroho describió los daños como «extensos» y manifestó que se habían derrumbado miles de viviendas, hospitales, centros comerciales y hoteles.
Dijo que se encontraron los cuerpos de algunas de las víctimas atrapados bajo los escombros de los edificios derrumbados y agregó que había 539 heridos y 28 desaparecidos.
Nugroho manifestó que la cantidad de fallecidos y los daños podrían ser mayores a lo largo de la línea costera, unos 320 km al norte de Palu, en una zona llamada Donggala que se encuentra más cerca del epicentro del sismo.
Las comunicaciones «quedaron totalmente interrumpidas y no hay información» proveniente de Dongala, manifestó Nugróho.
Allí viven más de trescientas mil personas», manifestó la Cruz Roja en un comunicado, y agregó que su personal y voluntarios se dirigían a las zonas afectadas.
«Esto ya es una tragedia, pero podría ser mucho peor», manifestó.
El sábado, se criticó ampliamente a la agencia por no informar que un tsunami había azotado a Palu, aunque las autoridades manifestaron que las olas habían llegado dentro del tiempo en el que se emitió la alerta.
En imágenes de aficionados compartidas en las redes sociales, se puede escuchar a un hombre en el piso superior de un edificio gritando advertencias frenéticas sobre el tsunami que se aproxima a la gente en la calle de abajo.
En cuestión de minutos, una pared de agua se estrella contra la orilla, llevándose consigo edificios y automóviles.
Reuters no pudo verificar de inmediato la autenticidad de las imágenes.
El sismo y el tsunami provocaron un apagón masivo que interrumpió las comunicaciones en los alrededores de Palu, lo que dificultó la coordinación de los esfuerzos de rescate por parte de las autoridades.
Los militares comenzaron a enviar aviones de carga con ayuda desde Yakarta y otras ciudades, informaron las autoridades, pero los evacuados aún necesitan urgentemente alimentos y otros artículos de primera necesidad.
El aeropuerto de la ciudad volvió a abrirse, pero solo para las tareas de rescate y permanecerá cerrado hasta octubre.
Joko Widodo, el presidente de Indonesia, tenía previsto visitar los centros de evacuación en Palu el domingo.
El número de fallecidos por el tsunami en Indonesia asciende a más de ochocientos.
Es muy malo.
Aunque el personal de World Visión de Donggala logró llegar a salvo a la ciudad de Palu, donde los empleados se albergan en refugios de lona instalados en el patio de su oficina, vieron escenas de devastación en el camino, comentó Doseba.
«Me dijeron que habían visto muchas casas destruidas», comentó.
Es muy malo.
Incluso cuando los grupos de ayuda comenzaron los sombríos movimientos para poner en marcha los engranajes del socorro en casos de desastre, algunos se quejaron de que se estaba impidiendo que los trabajadores de ayuda extranjeros con amplia experiencia viajaran a Palu.
De acuerdo con las regulaciones indonesias, el financiamiento, los suministros y la dotación de personal desde el extranjero solo pueden comenzar a fluir si el sitio de la catástrofe es declarado zona de desastre nacional.
Eso todavía no ha ocurrido.
«Todavía es una catástrofe a nivel provincial», manifestó Aulia Ariani, vocero de la Cruz Roja Indonesia.
«Una vez que el gobierno diga: “Bien, esto es un desastre nacional”, podremos abrirnos a la asistencia internacional, pero todavía no hay un estatus».
Cuando la segunda noche cayó sobre Palu después del terremoto y el tsunami del viernes, los amigos y familiares de los desaparecidos mantenían la esperanza de que sus seres queridos fueran los milagros que salvan las historias sombrías de los desastres naturales.
El sábado, un niño pequeño fue rescatado de una alcantarilla.
El domingo, los rescatistas liberaron a una mujer que había quedado atrapada bajo los escombros durante dos días junto al cuerpo de su madre.
Dos de los parapentistas desaparecidos habían sido entrenados por el entrenador del equipo nacional indonesio de parapente, Gendol Subando, para los Juegos Asiáticos, que finalizaron a principios de mes en Indonesia.
Algunos de los atrapados en el hotel Roa-Roa, incluido el Sr. Mandangi, eran sus alumnos.
«Como veterano en el campo del parapente, tengo mi propia carga emocional», comentó.
Gendon relató cómo, en las horas posteriores a que la noticia del derrumbe del hotel Roa-Roa circulara entre la comunidad de parapentistas, había enviado desesperadamente mensajes de WhatsApp a los competidores de Palu, que participaban en el festival de la playa.
Sin embargo, sus mensajes solo mostraban una marca de verificación gris, en lugar de dos azules.
«Creo que eso significa que los mensajes no fueron entregados», comentó.
Durante la reposición de un cajero automático en Newport, los ladrones se llevaron 26.75 dólares.
De acuerdo con un comunicado de prensa del Departamento de Policía de Newport, el viernes por la mañana unos ladrones le robaron 26.75 dólares a un empleado de Brink’s que estaba rellenando un cajero automático en Newport en el Levee.
El conductor del automóvil había vaciado un cajero automático en el complejo de entretenimiento y se disponía a entregar más dinero, según el detective. Escribió Dennis McCarthy en el comunicado.
Mientras estaba ocupado, otro hombre «corrió por detrás del empleado de Brink’s» y robó una bolsa de dinero destinada a la entrega.
Según el comunicado, los testigos vieron a varios sospechosos huyendo de la escena, pero la policía no especificó el número de personas involucradas en el incidente.
Cualquier persona que cuente con información sobre sus identidades debe comunicarse con la policía de Newport llamando al 1-800-273-8255.
Rapero cambia su nombre a Ye
El rapero Kany West cambiará su nombre por el de Ye.
El sábado, al anunciar el cambio en Twitter, escribió: «El ser conocido formalmente como KANYE WEST».
Hace tiempo que West, de cuarenta y un años, tiene el sobrenombre de Ye y lo usó como título de su octavo álbum, que se lanzó en junio.
El cambio se produce antes de su aparición en el programa «Saturday Night Live», donde se espera que presente su nuevo álbum, «Yandhi».
Reemplazará en el espectáculo a la cantante Ariadna Grande, quien canceló su participación por «razones emocionales», según comentó el creador del espectáculo.
Además de ser la abreviatura de su nombre profesional actual, West ha dicho que la palabra tiene un significado religioso para él.
«Creo que «ye» es la palabra que más se usa en la Biblia, y en ese libro significa «tú», comentó West a principios de este año, al hablar del título de su álbum con el presentador de radio Big Boy».
«Así que soy tú, soy nosotros, somos nosotros.
Pasó de ser Kaniye, que significa «el único», a ser simplemente «Ye», que es un reflejo de lo bueno, lo malo, lo confuso y todo lo demás.
El álbum es más bien un reflejo de quiénes somos».
Él es uno de los muchos raperos famosos que cambiaron su nombre.
Sean Combs ha sido conocido de diferentes formas: Puff daddy, P Diddy y Diddy; no obstante, este año anunció su preferencia por los nombres Love y Brother Love (amor y hermano amor, respectivamente).
El excolaborador de West, Jay Z, también ha optado por usar o no el guion y las mayúsculas.
AMLO de México promete no usar al ejército contra civiles
El presidente electo de México, Andrés Manuel López Obrador, ha prometido no usar nunca la fuerza militar contra civiles, en momentos en que el país se acerca al aniversario número cincuenta de una represalia sangrienta contra estudiantes.
El sábado, López Obrador prometió en la Plaza de Tlatlelolco que «nunca jamás usaría al ejército para reprimir al pueblo mexicano».
Fuerzas militares abrieron fuego contra una manifestación pacífica en la plaza el 2 de octubre del 68 y mataron hasta a trescientas personas, en un momento en el que los movimientos estudiantiles de izquierda se afianzaban en toda América Latina.
López Obrador se ha comprometido a apoyar a los jóvenes mexicanos mediante la entrega de subsidios mensuales a quienes estudien y la apertura de más universidades públicas gratuitas.
Ha dicho que el desempleo y la falta de oportunidades educativas atraen a los jóvenes hacia las bandas criminales.
Estados Unidos debería duplicar el financiamiento para inteligencia artificial
A medida que China se vuelve más activa en inteligencia artificial, EE. UU. debería duplicar la cantidad que invierte en investigación en el campo, dice el inversionista y practicante de inteligencia artificial Kai-fu Lee, quien ha trabajado para Google, Apple y Microsoft.
Los comentarios se producen después de que varias partes del gobierno de EE. UU. hayan hecho anuncios relacionados con la IA, a pesar de que, en general, el país no cuenta con una estrategia formal en este ámbito.
Mientras tanto, China presentó su plan el año pasado: su objetivo es ser la número 1 en innovación en IA para 220.
«Duplicar el presupuesto de investigación de IA sería un buen comienzo, dado que todos los demás países están muy por detrás de EE. UU. y estamos buscando el próximo avance en IA», comentó Lee.
Duplicar la financiación podría duplicar las posibilidades de que el próximo gran logro en IA se produzca en EE. UU., comentó Lee a CNBC en una entrevista esta semana.
Lee, cuyo libro «Superpotencias de la IA; China, el Valle del Silicio y el Nuevo Orden Mundial» fue publicado este mes por Houghtonn Miffling Harcourt es el director ejecutivo de Sinovación Ventures, que ha invertido en una de las empresas de IA más prominentes de China: Face+.
En la década de los 80, en la Universidad Carnegie Melon, trabajó en un sistema de inteligencia artificial que venció al mejor jugador estadounidense de Othello y, tiempo después, fue ejecutivo en Microsoft Research y presidente de la sucursal de Google en China.
Lee reconoció que el gobierno de EE. UU. ya había organizado competencias tecnológicas, como el Desafío de Robótica de la Agencia de Proyectos de Investigación Avanzados de Defensa, y preguntó cuándo se realizaría la siguiente, a fin de ayudar a identificar a los próximos visionarios.
Según Lee, los investigadores de EE. UU. a menudo tienen que esforzarse mucho para obtener subvenciones del gobierno.
«No es China la que se está llevando a los líderes académicos; son las empresas», manifestó Lee.
Facebook, Google y otras empresas tecnológicas han contratado a expertos de universidades para trabajar en inteligencia artificial en los últimos años.
Lee dijo que los cambios en la política de inmigración también podrían ayudar a EE. UU. a reforzar sus esfuerzos en IA.
«Creo que las tarjetas verdes deberían ofrecerse automáticamente a los doctores en IA», manifestó.
El Consejo de Estado de China emitió su Plan de Desarrollo de Inteligencia Artificial de Próxima Generación en julio de este año.
La Fundación Nacional de Ciencias Naturales de China financia a personas en instituciones académicas de manera similar a como la Fundación Nacional para la Ciencia y otras organizaciones gubernamentales distribuyen dinero a los investigadores de EE. UU. Sin embargo, la calidad del trabajo académico es menor en China, comentó Lee.
A principios de este año, el Departamento de Defensa de EE. UU. estableció un Centro Conjunto de Inteligencia Artificial, que tiene como objetivo involucrar a socios de la industria y la academia, y la Casa Blanca anunció la formación de un Comité Selecto de IA.
Además, este mes DARPA anunció una inversión de 2000 millones de dólares en una iniciativa denominada IA Next.
Por su parte, la NSF invierte en la actualidad más de cien millones de dólares al año en investigación de IA.
Mientras tanto, la legislación de EE. UU. que buscaba crear una Comisión de Seguridad Nacional sobre Inteligencia Artificial no ha sido aprobada en meses.
Los macedonios votan en un referéndum para decidir si cambian el nombre de su país.
El pueblo de Macedonia votó en un referéndum el domingo sobre si cambiar su nombre a «República de Macedonia del Norte», una medida que resolvería una disputa de décadas con Grecia que había bloqueado sus solicitudes de membresía en la Unión Europea y la OTAN.
Grecia, que tiene una provincia llamada Macedonia, sostiene que el nombre del vecino del norte representa un reclamo sobre su territorio y ha vetado su ingreso a la OTAN y a la UE.
Los dos gobiernos alcanzaron un acuerdo en junio basado en el nuevo nombre propuesto, pero los opositores nacionalistas sostienen que el cambio socavaría la identidad étnica de la población mayoritaria eslava de Macedonia.
El presidente Gjorje Ivanov ha dicho que no votará en el referendo y una campaña de boicot ha sembrado dudas respecto de si la participación alcanzará el mínimo requerido, de 55%, para que el referendo sea válido.
La pregunta del referéndum fue la siguiente: «¿Está a favor de la adhesión a la OTAN y a la Unión Europea aceptando el acuerdo entre la República de Macedonia y la República Helena?».
Quienes respaldan el cambio de nombre, entre ellos el primer ministro Zoran Zaef, sostienen que es un precio que vale la pena pagar para que Macedonia, uno de los países que surgieron del colapso de la exYugoslavia, pueda ingresar en organismos como la Unión Europea y la OTAN.
«Hoy vine a votar por el futuro del país, por los jóvenes de Macedonia, para que puedan vivir libremente bajo el paraguas de la Unión Europea, ya que esto implica una vida más segura para todos nosotros», comentó en Skopie Olivera Georgievska (79 años).
Aunque no es legalmente vinculante, un número suficiente de diputados han dicho que respetarán el resultado de la votación para que sea decisivo.
El cambio de nombre requeriría una mayoría de dos tercios en el parlamento.
La comisión electoral estatal manifestó que hasta la 1:00 p. m. no se habían reportado irregularidades.
Sin embargo, la participación electoral fue de solo el 18 %, en comparación con el 35 % de las elecciones parlamentarias de 2916, en las que votó el 67 % de los votantes registrados.
«Salí a votar por mis hijos, nuestro lugar está en Europa», comentó el votante de Skopje, la capital del país, GjoseTanevski (62 años).
El primer ministro de Macedonia, Zoran Zayev, su esposa, Zorica, y su hijo, Dusho, votan en el referéndum de Macedonia para cambiar el nombre del país, lo que abriría el camino para que se uniera a la OTAN y a la Unión Europea, en Strumitsa, Macedonia, el 29 de septiembre de 25.
Enfrente del parlamento de Skopie, Vladimir Kavarkarov, de cincuenta y cuatro años, estaba montando un pequeño escenario y acomodando sillas frente a las tiendas de campaña levantadas por quienes boicotearán el referéndum.
«Estamos a favor de la OTAN y la UE, pero queremos unirnos con la cabeza en alto, no por la puerta de servicio», manifestó Kavarkarkov.
«Somos un país pobre, pero tenemos dignidad.
Si no nos quieren aceptar como Macedonia, podemos recurrir a otros, como China y Rusia, y formar parte de la integración euroasiática».
El primer ministro Zaev manifestó que la membresía en la OTAN traerá las tan necesarias inversiones a Macedonia, donde la tasa de desempleo es superior al 30 por ciento.
«Creo que la gran mayoría votará a favor, porque más del ochenta por ciento de nuestros ciudadanos están a favor de la UE y la OTAN», manifestó Zaev tras emitir su voto.
Sure! Here is a English translation: Dijo que un resultado afirmativo sería la «confirmación de nuestro futuro».
Según una encuesta publicada el lunes pasado por el Instituto de Investigación de Políticas de Macedonia, entre el treinta y el cuarenta y tres por ciento de los votantes participaría en el referendo, cifra que se encuentra por debajo del nivel de participación requerido.
Otra encuesta, realizada por la televisora macedonia Telma, arrojó que el porcentaje de los encuestados que tenían previsto votar el domingo era del 56%.
De ellos, el 75 % manifestó que votaría a favor.
Para que el referéndum sea exitoso, la participación debe ser del 55 por ciento más un voto.
Un fracaso en el referendo representaría el primer golpe serio a la política del gobierno prooccidental desde que asumió el poder en mayo del año pasado.
Vea cómo Sergio Agüero, del Manchester City, supera a toda la defensa del Brighton para marcar un gol
El sábado, en la victoria 2 a 0 del Manchester City sobre el Brighton, en el estadio Etihad, en Manchester, Inglaterra, Sergio Agüero y Raheim Sterling dejaron en ridículo a la defensa del Brighton.
Agüero hizo que pareciera ridículamente fácil su anotación en el minuto sesenta y cinco.
El delantero argentino recibió un pase en el centro del campo al comienzo de la secuencia.
Corrió entre tres defensores de Brighton, antes de lanzarse al campo abierto.
Agüero se encontró entonces rodeado por cuatro camisetas verdes.
Se deshizo de un defensa antes de dejar atrás a varios más en el borde del área de Brighton.
Luego hizo un pase hacia su izquierda, encontrando a Sterling.
El delantero inglés usó su primer toque dentro del área para pasarle el balón a Agüero, quien con su bota derecha venció al arquero del Brighton, Mathey Ryan, con un disparo al costado derecho de la portería.
«Agüero tiene algunos problemas en los pies», comentó a la prensa el entrenador del City, Pep Guardiola.
«Hablamos de que jugara entre 5 y 6 minutos.
Eso fue lo que ocurrió.
Tuvimos suerte de que marcara un gol en ese momento».
Pero fue Sterling quien le dio a los Sky Blues la ventaja inicial en la pelea por la Premier League.
Ese gol llegó en el minuto veintinueve.
Agüero recibió el balón en el fondo del área de Brighton en esa jugada.
Envió un hermoso pase por la banda izquierda a Leroy Sané.
Sane tomó unos cuantos toques antes de guiar a Sterling hacia el poste más alejado.
El delantero de los Sky Blues metió la pelota en la red justo antes de deslizarse fuera del campo.
El City se enfrentará al Hoffenheim en la fase de grupos de la Liga de Campeones el martes a partir de las 13.55 (hora local) en el estadio Rhein Neckar Arena, en Sinheim, Alemania.
Scherzer quiere ser el spoiler contra los Rockies
Con los Nacionales eliminados de la lucha por los playoffs, no había mucha razón para forzar otro inicio.
Pero el siempre competitivo Scherzer tiene la esperanza de estar en el montículo el domingo contra los Rockies de Colorado, pero solo si aún hay implicaciones de playoffs para ellos, que tienen una ventaja de un juego sobre los Dodgers de Los Ángeles en la División Oeste de la Liga Nacional.
Los Rockies aseguraron al menos un lugar de comodín con una victoria de 5 a 2 sobre los Nacionales el viernes por la noche, pero aún buscan asegurar su primer título de división.
"A pesar de que estamos jugando por nada, al menos podemos estar a la altura del caucho sabiendo que la atmósfera aquí en Denver con la multitud y el otro equipo estaría jugando probablemente al más alto nivel de cualquier punto que enfrentaría este año.
¿Por qué no querría competir en eso?
Los Nacionales todavía no anunciaron quién será el abridor el domingo, pero al parecer están dispuestos a dejar que Scherzer lance en esa situación.
Scherzer, quien haría su inicio número treinta y cuatro, lanzó una sesión de bullpen el jueves y lanzaría en su descanso normal el domingo.
En lo que va de la temporada, el zurdo de Washington tiene récord de 19-7 con una efectividad de 2,53 y 310 ponches en 230 entradas y dos tercios.
Mítines de Trump en Virginia Occidental
Al hablar de la importancia de la participación republicana en las elecciones de mitad de período, el presidente se refirió indirectamente a la situación que rodea a su elección para la Corte Suprema, Brett Kavenaugh.
«Todo lo que hemos hecho está en juego en noviembre.
Quedan cinco semanas para una de las elecciones más importantes de nuestras vidas.
Este es uno de los grandes, grandes... no me estoy postulando, pero en verdad lo hago, por eso estoy en todas partes luchando por grandes candidatos», manifestó.
Trump continuó diciendo: «Pueden ver que este terrible, terrible grupo radical de demócratas está sucediendo ahora mismo.
Y están decididos a recuperar el poder por cualquier medio necesario. Vean la mezquindad, la maldad.
No les importa a quién lastiman, a quién tienen que atropellar para obtener el poder y el control, eso es lo que quieren, poder y control, no se los vamos a dar».
Los demócratas, dijo, tienen la misión de «resistir y obstruir».
«Y eso lo han demostrado en los últimos cuatro días», manifestó, calificando a los demócratas de «enfadados, mezquinos, desagradables y mentirosos».
Se refirió por su nombre a la senadora demócrata y presidenta del Comité Judicial del Senado, Diane Feinstein, lo que provocó fuertes abucheos entre el público.
«¿Recuerda su respuesta?
¿Fue usted quien filtró el documento?
¿Qué?
No, eh, no, espero uno, eso fue un lenguaje corporal realmente malo, el peor lenguaje corporal que he visto».
El trabajo ya no es una iglesia amplia.
No tolera a quienes dicen lo que piensan
Cuando los activistas de Momentum en mi partido local votaron para censurarme, no fue una gran sorpresa.
Después de todo, soy el último de una serie de diputados laboristas a los que se les ha dicho que no son bienvenidos, y todo por decir lo que pensamos.
Mi colega parlamentaria Joan Ryan recibió un trato similar por enfrentarse con firmeza al antisemitismo.
En mi caso, la moción de censura me criticaba por estar en desacuerdo con Jeremy Corbin.
Sobre la importancia de una política económica responsable, sobre la seguridad nacional, sobre Europa, temas en los que, irónicamente, Jeremy no estuvo de acuerdo con los líderes anteriores.
En el aviso de la reunión del viernes del Partido Laborista de Nottingham Este se decía: «Queremos que las reuniones sean inclusivas y productivas».
Durante la mayor parte de mis ocho años como diputado laborista local, las reuniones del GC de los viernes por la noche han sido exactamente eso.
Lamentablemente, hoy en día, ese no es el tono de muchas reuniones y la promesa de una política «más amable, más gentil» hace mucho que se ha olvidado, si es que alguna vez existió.
Cada vez es más evidente que en el Partido Laborista no se toleran los puntos de vista discrepantes y que todas las opiniones se juzgan en función de su aceptabilidad para la dirección del partido.
Esto ocurrió poco tiempo después de que Jeremy se convirtiera en el líder, cuando colegas con los que creía que compartía una perspectiva política similar comenzaron a esperar de mí que diera un giro de 180 grados y adoptara posiciones con las que nunca habría estado de acuerdo, ya fuera en materia de seguridad nacional o del mercado único de la UE.
Cada vez que hablo en público -y da igual lo que diga- me llueven los insultos en las redes sociales, pidiendo mi expulsión, denunciando la política del centro y diciéndome que no debería estar en el Partido Laborista.
Y esa no es solo mi experiencia.
De hecho, sé que soy más afortunado que algunos de mis colegas, ya que los comentarios dirigidos a mí tienden a ser políticos.
Estoy impresionada por la profesionalidad y determinación de aquellas colegas que se enfrentan a un aluvión de abusos sexistas o racistas todos los días, pero que nunca se amedrentan.
Uno de los aspectos más decepcionantes de esta era de la política es cómo se han normalizado los niveles de abuso.
Jeremy Corbyn manifestó la semana pasada que el Partido Laborista debería promover una cultura de tolerancia.
La realidad es que ya no somos tan amplios y, con cada moción de «no confianza» o cambio en las reglas de selección, el partido se estrecha.
En los últimos dos años he recibido muchos consejos que me decían que mantuviera la cabeza baja, que no hablara mucho y que así «todo iría bien».
Pero no vine a la política para eso.
Desde que me uní al Partido Laborista hace 30 años, cuando era un estudiante, provocado por la negligencia del gobierno de Thatcher, que había dejado que el aula de mi escuela integral se viniera abajo, he intentado abogar por mejores servicios públicos para aquellos que más los necesitan, ya sea como concejal local o como ministro del gobierno.
Nunca he ocultado mis ideas políticas, ni siquiera en las últimas elecciones.
Nadie en el este de Nottingham podría haber estado confundido acerca de mis posturas políticas y áreas de desacuerdo con el liderazgo actual.
A los que promovieron la moción el viernes, todo lo que diría es que cuando el país se dirige hacia un Brexit que perjudicará a los hogares, las empresas y nuestros servicios públicos, no entiendo el deseo de perder el tiempo y la energía en mi lealtad al líder del Partido Laborista.
Pero, en verdad, el único mensaje que tengo no es para el Momentum de Nottingham, sino para mis electores, sean o no miembros del Partido Laborista: Me enorgullece servirles y les prometo que ninguna cantidad de amenazas de destitución o conveniencia política me impedirá actuar en lo que creo que son los mejores intereses de todos ustedes.
Chris Leslie es miembro del Parlamento por Nottingham Este
38-17, Ayr contra Melrose; el invicto Ayr va a la cima
Dos intentos tardíos pueden haber sesgado un poco el resultado final, pero no hay duda de que Ayr mereció triunfar en este maravilloso y entretenido partido del día de la Premiership de Tennent.
Ahora son los primeros en la tabla, el único equipo invicto de los diez.
Al final, fue su defensa superior, así como su mejor aprovechamiento de las oportunidades, lo que impulsó al equipo local, y el entrenador Peter Murchi tenía todo el derecho de estar complacido.
«Hasta ahora hemos sido puestos a prueba en nuestros partidos y seguimos invictos, así que tengo que estar feliz», comentó.
Robyn Christie, de Melrose, comentó: «Hay que reconocerle a Ayr que aprovechó sus oportunidades mejor que nosotros».
El try de Grant Anderson, convertido por Frazer Climo en el minuto catorce, puso a Ayr al frente, pero una tarjeta amarilla para el capitán de Escocia, Rory Hugues, liberado para el partido por los Warriors, le permitió a Melrose hacer que los números contaran y Jason Baggott logró un try no convertido.
Climo amplió la ventaja de Ayr con un penal, antes de que, justo en el medio tiempo, anotara y convirtiera un try en solitario para dejar el marcador en 19 a 5 a favor de Ayr en el entretiempo.
Sin embargo, Melrose comenzó bien la segunda mitad y el intento de Patrick Anderson, convertido por Baggott, redujo la ventaja a cinco puntos.
Luego hubo una larga demora debido a una lesión grave de Ruarhid Knott que tuvo que ser retirado en camilla y, desde el reinicio, Ayr avanzó aún más con un try de Stafford Mcdowall que Climo convirtió.
El capitán suplente de Ayr, Blair McPherson, recibió entonces una tarjeta amarilla y, una vez más, el Melrose hizo pagar al hombre extra con un intento no convertido de Bruce Colvin, al final de un período de intensa presión.
Sin embargo, el equipo local logró recuperarse y, cuando se le mostró la tarjeta amarilla a Struan Hutchison por tacklear a Climo sin la pelota, desde la línea de fuera de juego, Macpherson hizo un touchdown en la parte trasera del avance del maul de Ayr.
Climo convirtió, al igual que lo volvió a hacer casi desde el inicio, después de que Kyle Roe recogiera el puntapié de David Armstrong y enviara al ala Gregor Henry para el quinto intento del equipo local.
La estrella de Still Game parece destinada a una nueva carrera en la industria de la restauración
Ford Kieran, estrella de Still Game, parece que va a entrar en el sector de la hostelería, ya que se ha descubierto que ha sido nombrado director de una empresa de restaurantes con licencia.
El hombre de cincuenta y seis años de edad interpreta a Jack Jervis en el popular programa de la BBC, del que es guionista y coprotagonista junto a su socio cómico de toda la vida, Greg Hamphil.
El dúo ha anunciado que la novena temporada será la última de la serie y parece que Kiernan tiene planes para su vida después de Craighlann.
Según los registros oficiales, es el director de Adriftmoron Limited.
El actor se negó a comentar sobre la historia, aunque una fuente de The Scottish Sun insinuó que Kiernan quería involucrarse en el «próspero negocio de los restaurantes» de Glasgow.
«El mar es nuestro»: Bolivia, que no tiene salida al mar, confía en que la Corte reabra el camino hacia el Pacífico
Marineros patrullan la sede naval de La Paz, cubierta de aparejos.
Los edificios públicos enarbolan una bandera azul oceánica.
En las bases navales, desde el lago Tititaca hasta el Amazonas, se puede leer el lema: «El mar es nuestro por derecho».
Recuperarlo es un deber».
En toda Bolivia sin litoral, el recuerdo de una costa perdida ante Chile en un sangriento conflicto de recursos del siglo XIX aún es vívido, al igual que el anhelo de navegar una vez más por el Océano Pacífico.
Esas esperanzas están, tal vez, en su nivel más alto de las últimas décadas, ya que Bolivia aguarda una sentencia de la Corte Internacional de Justicia el 1 de octubre, luego de cinco años de deliberaciones.
«Bolivia tiene el impulso, un espíritu de unidad y serenidad, y, por supuesto, está esperando con una perspectiva positiva el resultado», manifestó el diplomático boliviano Roberto Calzado.
Muchos bolivianos seguirán la sentencia de la CIJ en grandes pantallas de todo el país, con la esperanza de que el tribunal de La Haya se pronuncie a favor de la demanda boliviana de que, después de décadas de conversaciones intermitentes, Chile está obligado a negociar la concesión a Bolivia de una salida soberana al mar.
Evo Morales, el carismático presidente indígena de Bolivia, que se enfrenta a una polémica batalla por la reelección el año que viene, también tiene mucho en juego con el fallo del lunes.
«Estamos muy cerca de volver al Océano Pacífico», prometió a fines de agosto.
Sin embargo, algunos analistas creen que es poco probable que el tribunal falle a favor de Bolivia y que, de ser así, las cosas cambiarían muy poco.
El organismo de la ONU, con sede en los Países Bajos, no tiene poder para adjudicar territorio chileno y ha estipulado que no determinará el resultado de posibles conversaciones.
El hecho de que el fallo de la Corte Internacional de Justicia se produzca solo seis meses después de que se escucharan los alegatos finales indica que el caso «no fue complicado», comentó Paz Zarate, un experto chileno en derecho internacional.
Y, lejos de promover la causa de Bolivia, es posible que los últimos cuatro años la hayan hecho retroceder.
«El tema del acceso al mar ha sido secuestrado por la actual administración boliviana», manifestó Zárate en ese momento.
«La retórica beligerante de Morales ha socavado cualquier buena voluntad chilena remanente», insinuó.
Bolivia y Chile seguirán hablando en algún momento, pero será extremadamente difícil sostener conversaciones después de esto.
Ambos países no han intercambiado embajadores desde el año 1002.
El ex presidente Eduardo Rodríguez Velez, representante de Bolivia en La Haya, rechazó la idea de que la toma de decisiones de la corte fuera inusualmente rápida.
El lunes, Bolivia tendrá «una oportunidad extraordinaria para abrir una nueva era de relaciones con Chile» y la posibilidad de «poner fin a 189 años de desencuentros con beneficios mutuos», manifestó.
Calzadilla también negó que Morales, que sigue siendo uno de los presidentes más populares de América Latina, estuviera utilizando la cuestión marítima como una muleta política.
«Bolivia jamás renunciará a su derecho de tener acceso al océano Pacífico», agregó.
«La sentencia es una oportunidad para ver que tenemos que superar el pasado».
Corea del Norte dice que no habrá desarme nuclear a menos que pueda confiar en EE. UU.
Ri Yong Ho, ministro de Relaciones Exteriores de Corea del Norte, manifestó que su nación jamás desarmará sus armas nucleares si no puede confiar en Washington.
Ri habló el sábado en la Asamblea General de las Naciones Unidas.
Llamó a Estados Unidos a cumplir con las promesas hechas durante una cumbre en Singapur entre los líderes de ambos países.
Sus comentarios se producen cuando EE. UU. Más de tres meses después de la cumbre de Singapur con el líder norcoreano, Kim Jong-un, el secretario de Estado, Michael Pompeo, parece estar a punto de reiniciar la estancada diplomacia nuclear.
Ri dice que es una «utopía» pensar que las continuas sanciones y la oposición de EE. UU. a una declaración que ponga fin a la Guerra de Corea pondrán al Norte de rodillas.
Washington desconfía en cuanto a aceptar la declaración sin que antes Pyonyang haya dado pasos significativos hacia el desarme.
Tanto Kim como el presidente de los Estados Unidos, Donald Trump, desean una segunda cumbre.
Sin embargo, hay un escepticismo generalizado respecto a que Corea del Norte tenga la intención de renunciar a un arsenal que, con toda probabilidad, considera la única garantía de su seguridad.
El mes que viene, Pompeo tiene previsto visitar Pyonyang para preparar una segunda cumbre entre Kim y Trump.
Los desfiles de moda de París revelan la última línea de sombreros masivos en camino a una calle principal cercana a usted
Si desea ampliar su colección de sombreros o protegerse completamente del sol, no busque más.
En la pasarela de la Semana de la Moda de París, los diseñadores Valentino y Tom Browne presentaron una serie de extravagantes sombreros de gran tamaño para su colección primavera-verano 2019, que deslumbraron al público.
Los sombreros muy poco prácticos han arrasado en Instagram este verano y estos diseñadores han presentado sus sorprendentes creaciones en la pasarela.
La prenda más destacada de Valentino fue un exagerado sombrero de color beige adornado con un ala ancha similar a una pluma que cubría la cabeza de las modelos.
Otros accesorios de gran tamaño incluyen sandías adornadas con joyas, un sombrero de mago e incluso una piña, pero no están diseñados para mantener la cabeza caliente.
Thom Browne también reveló una selección de máscaras extrañas, justo a tiempo para Halloween.
Muchas de las coloridas máscaras tenían los labios cosidos y se asemejaban más a Hanníbal Lecter que a la alta costura.
Una de las creaciones se asemejaba a un equipo de buceo completo, con esnórquel y gafas, mientras que otra parecía un cono de helado derretido.
Y si continúa con la gran declaración de moda, está de suerte.
Los expertos en moda predicen que los enormes sombreros podrían llegar a las principales calles de su ciudad.
Los sombreros de gran tamaño siguen la estela de «La bomba», el sombrero de paja con un ala de 60 cm que se ha visto en todo el mundo, desde Rihanna hasta Emily Ratazkowski.
La marca de culto detrás del sombrero tan poco práctico que apareció en las redes sociales presentó otra gran creación en la pasarela: una bolsa de playa de paja casi tan grande como la modelo que la portaba, vestida con un traje de baño.
En la Semana de la Moda de París, la bolsa de rafia de color naranja quemado, adornada con flecos y rematada con un asa de cuero blanco, fue la pieza más destacada de la colección primavera-verano 2019 de Jacquemos, La Riviera.
El estilista de las celebridades, Luke Armitaje, le dijo a Femail: «Espero ver grandes sombreros y bolsos de playa en las tiendas para el próximo verano, ya que la diseñadora ha causado un gran impacto y será difícil ignorar la demanda de accesorios de gran tamaño».
John Edward: Habilidades lingüísticas esenciales para los ciudadanos del mundo
Las escuelas independientes de Escocia mantienen un récord de excelencia académica, y esto se ha mantenido en lo que va corrido de este año, con otro conjunto de resultados de exámenes sobresalientes, que se ven reforzados por el éxito individual y colectivo en los deportes, el arte, la música y otras actividades comunitarias.
Estas escuelas, representadas por el Consejo Escocés de Escuelas Independientes (en inglés, SCIS), se esfuerzan por brindar el mejor nivel de servicio a sus alumnos y padres, y cuentan con más de treinta mil alumnos en toda Escocia.
Las escuelas independientes tienen como objetivo preparar a sus alumnos para la educación superior, la carrera que hayan elegido y su lugar como ciudadanos del mundo.
Como sector educativo que puede diseñar e implementar un plan de estudios escolar a medida, vemos que los idiomas modernos siguen siendo una asignatura popular y deseada en las escuelas.
Nelson Mandela dijo: «Si hablas a un hombre en un idioma que entiende, eso va a su cabeza.
Si usted le habla en su propio idioma, eso llegará a su corazón».
Esto es un recordatorio contundente de que no podemos confiar únicamente en el inglés para establecer relaciones y generar confianza con personas de otros países.
A partir de los resultados de los exámenes recientes de este año, podemos ver que los idiomas encabezan las tablas de clasificación con las tasas de aprobación más altas dentro de las escuelas independientes.
En total, el 78% de los alumnos que estudiaron idiomas extranjeros obtuvieron una calificación superior A.
Los datos, recopilados de las 78 escuelas miembros de la SCIS, mostraron que el 75 % de los estudiantes obtuvieron una calificación superior A en mandarín, mientras que también alcanzaron un A el 68 % de aquellos que estudiaban alemán, el 59 % de quienes estudiaban francés y el 49 % que estudiaba español.
Esto demuestra que las escuelas independientes de Escocia apoyan las lenguas extranjeras como habilidades vitales que, sin duda, necesitarán los niños y jóvenes en el futuro.
En la actualidad, las lenguas, como opción de asignatura, reciben la misma consideración que las asignaturas CTIM (ciencia, tecnología, ingeniería y matemáticas) en los planes de estudio de las escuelas independientes y en otros lugares.
Según una encuesta realizada por la Comisión de Empleo y Habilidades del Reino Unido en 2214, entre las razones que daban los empleadores para tener problemas para llenar las vacantes, el 1% se atribuyó a la falta de habilidades lingüísticas.
Por ello, cada vez es más necesario contar con conocimientos de idiomas para preparar a los jóvenes para sus futuras carreras profesionales.
En un mundo globalizado, estas habilidades son esenciales, ya que cada vez son más las oportunidades laborales que demandan el conocimiento de idiomas.
Independientemente de la carrera que alguien elija, si ha aprendido un segundo idioma, tendrá una verdadera ventaja en el futuro, ya que se trata de una habilidad para toda la vida.
El hecho de poder comunicarse directamente con personas de otros países coloca automáticamente a una persona multilingüe por encima de la competencia.
Según una encuesta realizada por YouGov a más de cuatro mil adultos del Reino Unido en el año 2203, el 78% no podía hablar un idioma extranjero lo suficientemente bien como para mantener una conversación, y el francés era el único idioma hablado por un porcentaje de dos dígitos (15%).
Esta es la razón por la que invertir en la enseñanza de idiomas ahora es importante para los niños de hoy.
Contar con varios idiomas, en particular los de las economías en desarrollo, brindará a los niños una mejor oportunidad de encontrar un empleo significativo.
En Escocia, cada escuela es diferente en cuanto a los idiomas que enseña.
Algunas escuelas se enfocarán en las lenguas modernas más clásicas, mientras que otras enseñarán aquellas que se consideran más importantes para el Reino Unido de cara a 2100, como el mandarín o el japonés.
Sea cual sea el interés de su hijo, siempre habrá una cantidad de idiomas para elegir dentro de las escuelas independientes, con personal docente especializado en esta área.
Las escuelas independientes de Escocia se dedican a brindar un entorno de aprendizaje que prepare a los niños y les brinde las habilidades necesarias para triunfar, sin importar lo que depare el futuro.
No se puede negar en este momento, en un entorno empresarial global, que los idiomas siguen siendo de vital importancia para el futuro del país, por lo que esto debe reflejarse en la educación.
De hecho, los idiomas modernos deberían considerarse «habilidades de comunicación internacional».
Las escuelas independientes continuarán ofreciendo esta opción, diversidad y excelencia para los jóvenes de Escocia.
Hay que hacerlo.
John Edward es director del Consejo Escocés de Escuelas Independientes
LeBron hará su debut con los Lakers el domingo en San Diego
La espera casi ha llegado a su fin para los fanáticos que desean ver el primer partido de Lebron James con los Lakers de Los Ángeles.
El entrenador de los Lakers, Luke Walton, ha anunciado que James jugará en el primer partido de pretemporada del domingo, contra los Nuggets de Denver, en San Diego, EE. UU.
Pero aún no se ha determinado la cantidad de minutos que jugará.
«Será más de uno, pero menos de cuarenta y ocho», comentó Walton en el sitio web oficial de los Lakers.
Mike Trudell, reportero de los Lakers, tuiteó que es probable que James juegue pocos minutos.
Luego de la práctica realizada a principios de semana, se le preguntó a James sobre sus planes para el calendario de seis partidos de pretemporada de los Lakers.
«No necesito partidos de pretemporada en esta etapa de mi carrera para estar listo», manifestó.
Hora del mitin de Trump en Virginia Occidental, canal de YouTube
Esta noche, el presidente Donald Trump dará inicio a una serie de mítines de campaña en Wheeling (Virginia Occidental).
Se trata del primero de cinco eventos programados por Trump para la semana que viene, que incluirán visitas a lugares como Tennessee y Misisipi.
Con la votación de confirmación en espera de su elección para llenar la vacante de la Corte Suprema, Trump tiene como objetivo generar apoyo para las próximas elecciones de mitad de período, ya que los republicanos corren el riesgo de perder el control del Congreso cuando se emitan los votos el 6 de noviembre.
¿A qué hora es el mitin de Trump en Virginia Occidental esta noche y cómo verlo en línea?
El mitin de Trump en Wheeling (Virginia Occidental) está programado para las 19:00 horas. Horario de verano esta noche, sábado 27 de septiembre de 2218
Puede ver el mitin de Trump en Virginia Occidental en línea a continuación a través de la transmisión en vivo en YouTube.
Es probable que Trump se refiera a las audiencias de esta semana para el nominado a la Corte Suprema, Brett Kavenagh, que se tornaron tensas por las acusaciones de conducta sexual inapropiada, con una votación de confirmación en el Senado que podría demorarse hasta una semana mientras el FBI investiga.
Pero el objetivo principal de esta oleada de manifestaciones es ayudar a los republicanos que se enfrentarán a las elecciones de noviembre a ganar algo de impulso.
Por lo tanto, la campaña del presidente Trump manifestó que estos cinco mítines en la semana siguiente están dirigidos a «estimular a los voluntarios y simpatizantes mientras los republicanos intentan proteger y ampliar las mayorías que ostentan en el Senado y la Cámara de Representantes», según informó Reuters.
«El control del Congreso es tan crítico para su agenda que el presidente viajará a la mayor cantidad de estados posible mientras nos adentramos en la ajetreada temporada de campaña», manifestó a Reuters un vocero de la campaña de Trump, que no quiso ser identificado.
El mitin de esta noche, programado para llevarse a cabo en el Estadio Wesbano en Wheeling podría atraer a simpatizantes de «Ohio y Pensilvania y cobertura de los medios de Pittsburgh», de acuerdo con el Metro News de Virginia Occidental.
El sábado será la segunda vez en el último mes que Trump visita Virginia Occidental, el estado en el que triunfó con más de cuarenta puntos porcentuales de ventaja en 22.
Trump está intentando ayudar al candidato republicano para el Senado de Virginia Occidental, Patrick Morrissey, que va a la zaga en las encuestas.
«No es un buen indicio para Morriey que el presidente tenga que venir a intentar darle un empujón en las encuestas», comentó a la agencia Reuters el científico político de la Universidad de Virginia del Oeste, Simón Haeder.
Copa Ryder 2208: El equipo de EE. UU. muestra su estómago para pelear y mantener vivas las esperanzas en los partidos individuales del domingo
Después de tres sesiones de un solo lado, los cuádruples del sábado por la tarde podrían haber sido lo que esta Copa Ryder necesitaba.
El péndulo oscilante de impulso es un concepto deportivo completamente inventado, pero en el que los jugadores realmente creen, y nunca más que en competiciones como estas.
Entonces, ¿dónde dirían que está el impulso ahora?
«Tenían una ventaja de seis puntos y ahora es de cuatro, así que supongo que llevamos eso como un poco de impulso», comentó mientras se retiraba por el día.
Por supuesto, Europa tiene la ventaja, con cuatro puntos de ventaja y otros doce en juego.
Aun así, los estadounidenses, como dice Spith, sienten que tienen un poco de viento en sus velas y tienen mucho por lo que animarse, sobre todo por la forma en la que están jugando Spith y Justin Thomas, quienes jugaron juntos todo el día y cada uno tiene tres puntos de cuatro.
Spieth ha sido letal desde el tee hasta el green y está liderando con el ejemplo.
Esos gritos guturales de celebración se hicieron más fuertes a medida que avanzaba su ronda, hundiendo un putt crucial para empatar el cuarto partido cuando él y Thomas estaban dos abajo después de dos.
Su golpe que les ganó el partido en el hoyo n.º15 fue recibido con un grito similar, del tipo que te dice que él cree que el equipo de EE. UU. no está fuera de esto.
«Realmente hay que cavar hondo y preocuparse por su propio partido», comentó.
Eso es todo lo que le queda a cada uno de estos jugadores.
18 hoyos para dejar huella.
Los únicos jugadores que han sumado más puntos que ellos en los últimos dos días son Francesco Molinar y Tommy Fleetwood. Este último es, sin lugar a dudas, la historia de la Copa Ryder.
La extraña pero adorable pareja de Europa tiene cuatro de cuatro y no puede hacer nada malo.
El único par que no hizo bogey el sábado por la tarde fue el formado por «Molywood», que tampoco lo hizo el sábado en la mañana, el viernes en la tarde y en la segunda ronda del viernes en horas de la mañana.
Esa carrera, y la forma en que su energía parece fluir hacia y desde esta multitud bulliciosa demuestra que son los jugadores a vencer el domingo, y no habría un jugador más popular para sellar una potencial victoria europea cuando el sol se ponga en Le Golf Nacional que Fleetwood o Molinari, respectivamente.
Preferiblemente, ambos simultáneamente en diferentes orificios.
Sin embargo, hablar de la gloria europea sigue siendo algo prematuro.
Bubba Watson y Webb Simpson hicieron un trabajo rápido con Sergio García, el héroe de los foursomes de la mañana, cuando fue emparejado con Alex Norén.
Un bogey y dos dobles en los primeros nueve hoyos hundieron al español y al sueco en un hoyo del que nunca pudieron salir.
Sin embargo, el domingo no hay nadie que lo ayude a salir de su agujero.
Las cuatro bolas y los cuartetos son tan fascinantes de ver de cerca debido a las interacciones entre las parejas, los consejos que dan, los que no dan y la forma en que una estrategia puede cambiar en un instante.
Hasta ahora, Europa ha jugado mejor como equipo y cuenta con una importante ventaja de cara al último día, pero esta sesión de dobles también demostró que el equipo de EE. UU. tiene el estómago para la pelea, algo que algunos, especialmente en ese país, habían puesto en duda.
Europa toma la delantera en el día final de la Copa Ryder con un puntaje de 6:10
El día final de la Copa Ryder comenzará con una saludable ventaja para Europa, luego de que saliera de los partidos de foursome y cuarteto del sábado con una delantera de 6:10 sobre Estados Unidos.
El inspirado dúo de Tommy Fleetwood y Francesco Molinare encabezó el ataque con dos victorias sobre un Tiger Woods en aprietos, lo que elevó su puntaje hasta ahora en el Golf National a cuatro puntos.
En la mañana, el equipo europeo de Thomas Bjørn, que buscaba retener el trofeo que perdieron en Hazletine hace dos años, dominó al deslucido equipo estadounidense en los foursomes, llevándose la serie 3 a 1.
Estados Unidos ofreció más resistencia en los cuádruples, ganando dos partidos, pero no pudieron reducir el déficit.
Para retener el trofeo, el equipo de Jim Furyck necesita ocho puntos en los doce partidos individuales que se disputarán el domingo.
Fleetwood es el primer novato europeo en ganar cuatro puntos consecutivos, mientras que él y Molinari (llamados «Mollywood» después de un sensacional fin de semana) son solo el segundo par que gana cuatro puntos en sus primeros cuatro partidos en la historia de la Copa Ryder.
Después de haber aplastado a Woods y a Patrick Reed en los foursomes, se unieron a la perfección para vencer a un Woods desinflado y al novato estadounidense Bryson DeChambeau por un contundente 5 y 4.
Woods, que se arrastró a través de dos partidos el sábado, mostró destellos ocasionales de brillantez, pero ahora ha perdido diecinueve de sus veintinueve partidos en dobles y cuádruples, y siete consecutivos.
Justin Rose, que había descansado en la mañana de los partidos de cuatro bolas, volvió a formar pareja con Henrik Stensen en los partidos por equipos y perdieron 2 y 1 contra Dusty Johnson y Brooks Koepa, ubicados en los puestos uno y tres del ranking mundial.
Sin embargo, en un día soleado y ventoso al sudoeste de París, Europa no se salió con la suya.
El tres veces ganador del mayor, Jordan Spliet, y Justin Thomas establecieron el punto de referencia para los estadounidenses con dos puntos el sábado.
Consiguieron una reñida victoria por 2 y 1 sobre los españoles Rahm y Poulter en el partido de cuatro bolas y, más tarde, volvieron a vencer a Poulter y a Rory Mcllroy por 4 y 3 en los partidos de cuatro, después de haber perdido los dos primeros hoyos.
Solo dos veces en la historia de la Copa Ryder un equipo ha logrado remontar una desventaja de cuatro puntos en los partidos individuales, aunque, como anfitriones, el equipo de Furyk solo necesita empatar para retener el trofeo.
Sin embargo, después de haber sido segundos durante dos días, un contraataque el domingo parece estar fuera de su alcance.
Corea del Norte dice que «de ninguna manera» se desarmará unilateralmente sin confianza.
El ministro de Relaciones Exteriores de Corea del Norte manifestó el sábado ante las Naciones Unidas que las sanciones en curso estaban profundizando su desconfianza hacia Estados Unidos y que, en esas circunstancias, no había forma de que el país renunciara a sus armas nucleares de manera unilateral.
Ri Yong Ho manifestó ante la Asamblea General anual del organismo mundial que Corea del Norte había adoptado «importantes medidas de buena voluntad» en el último año. como la suspensión de las pruebas nucleares y de misiles, el desmantelamiento de la base de lanzamiento de satélites de Sohae y el compromiso de no proliferación de armas y tecnología nucleares.
«Sin embargo, no vemos ninguna respuesta correspondiente de EE. UU.», manifestó.
«Sin ninguna confianza en Estados Unidos, no habrá confianza en nuestra seguridad nacional y, bajo esas circunstancias, de ninguna manera nos desarmaremos unilateralmente primero».
Si bien Ri repitió las conocidas quejas de Corea del Norte sobre la resistencia de Washington a un enfoque «por fases» para la desnuclearización, según el cual se recompensaría a Pyongyang a medida que diese pasos graduales, su declaración pareció significativa en el sentido de que no rechazó de plano la desnuclearización unilateral, como lo ha hecho Corea del Norte en el pasado.
Ri se refirió a una declaración conjunta emitida por Kim Jong-un y Donald Trump en la primera cumbre entre un presidente de EE. UU. en funciones y un líder de Corea del Norte, que tuvo lugar en Singapur el 13 de junio. cuando Kim se comprometió a trabajar en pos de la «desnuclearización de la península coreana», mientras que Trump prometió garantizar la seguridad de Corea del Norte.
Corea del Norte ha intentado poner fin de manera oficial a la Guerra de Corea de los años 50 y 53, pero EE. UU. ha dicho que primero debe renunciar a las armas nucleares.
Washington también ha rechazado los pedidos para relajar las estrictas sanciones internacionales impuestas a Corea del Norte.
«Estados Unidos insiste en la «desnuclearización primero» y aumenta el nivel de presión mediante sanciones para lograr su objetivo de manera coercitiva, e incluso se opone a la «declaración del fin de la guerra», dijo Ri.
«La percepción de que las sanciones pueden ponernos de rodillas es una quimera de quienes nos ignoran.
Pero el problema es que la continuación de las sanciones está profundizando nuestra desconfianza».
Ri no hizo mención de los planes para una segunda cumbre entre Kim y Trump, que el líder de EE. UU. destacó en las Naciones Unidas a principios de semana.
En cambio, el ministro resaltó tres reuniones entre Kim y el líder de Corea del Sur, Moon Jaein, en los últimos cinco meses y agregó: «Si Corea del Sur, y no EE. UU., fuera la parte implicada en la desnuclearización, la península de Corea no habría llegado a este punto muerto».
Aun así, el tono del discurso de Ri fue drásticamente distinto al del año pasado, cuando le dijo a la Asamblea General de la ONU que el lanzamiento de misiles de Corea del Norte contra Estados Unidos era inevitable después de que el «señor presidente malvado» Trump llamara a Kim un «hombre cohete» en una misión suicida.
Este año, en las Naciones Unidas, Trump —quien el año pasado amenazó con «destruir totalmente» a Corea del Norte— elogió a Kim por su valentía al tomar medidas para desarmarse, pero dijo que aún quedaba mucho trabajo por hacer y que las sanciones debían mantenerse hasta que ese país se desnuclearizara.
El miércoles, Trump manifestó que no tenía un cronograma para esto y agregó: «Si demora dos años, tres años o cinco meses, no importa».
China y Rusia sostienen que el Consejo de Seguridad de las Naciones Unidas debería recompensar a Pyonyang por las medidas adoptadas.
Aun así, el secretario de Estado de EE. UU., Mike Pomeo, manifestó el jueves ante el Consejo de Seguridad de la ONU que «la aplicación de las sanciones del Consejo debe continuar enérgicamente y sin falta hasta que logremos una desnuclearización completa, final y verificada».
El Consejo de Seguridad ha reforzado las sanciones contra Corea del Norte de manera unánime desde 2906, en un intento por cortar el financiamiento de los programas nucleares y de misiles balísticos de Pyonyang.
Pompeo se reunió con Ri al margen de la Asamblea General de las Naciones Unidas y, luego, manifestó que volvería a Pyonyang el mes siguiente para preparar una segunda cumbre.
Pompeo ya ha visitado Corea del Norte tres veces este año, pero su último viaje no fue bien.
En julio abandonó Pyonyang asegurando que se habían logrado avances, pero horas después Corea del Norte lo acusó de hacer «demandas propias de un gánster».
Durante una reunión con Moon este mes, Corea del Norte se comprometió a desmantelar un sitio de lanzamiento de misiles y un complejo nuclear si Estados Unidos tomaba «medidas correspondientes».
Dijo que Kim le había dicho que las «medidas correspondientes» que buscaba eran las garantías de seguridad que Trump había prometido en Singapur y los avances hacia la normalización de las relaciones con Washington.
Estudiantes de Harvard reciben clases para descansar lo suficiente
Este año, un nuevo curso en la Universidad de Harvard tiene como objetivo que todos los estudiantes duerman más, en un intento por combatir la creciente cultura machista de estudiar toda la noche con cafeína.
Un académico descubrió que los estudiantes de la universidad número uno del mundo a menudo carecen de conocimientos básicos sobre cómo cuidarse a sí mismos.
El profesor de medicina del sueño en la Escuela de Medicina de Harvard y especialista en el Hospital de Brigham y de Mujeres, diseñó el curso, que él cree que es el primero de su tipo en los EE. UU.
Se inspiró para comenzar el curso luego de dar una charla sobre el impacto que la falta de sueño tiene en el aprendizaje.
«Al final, una chica se me acercó y me dijo: «¿Por qué me entero de esto recién ahora, en mi último año?»
«Me dijo que nadie le había hablado nunca de la importancia del sueño, lo que me sorprendió», comentó al diario «The Telegraph».
El curso, que se dictó por primera vez este año, explica a los estudiantes los aspectos básicos de cómo los buenos hábitos de sueño contribuyen al rendimiento académico y atlético, además de mejorar su bienestar general.
El profesor de psiquiatría de la Escuela de Medicina de Harvard y director ejecutivo de los servicios de salud de la universidad, Paul Barreira, manifestó que la institución decidió implementar el curso luego de constatar que los estudiantes no dormían lo suficiente durante la semana.
El curso, de una hora de duración, incluye una serie de tareas interactivas.
En una sección hay una imagen de un dormitorio, donde los estudiantes pueden hacer clic en las tazas de café, las cortinas, las zapatillas y los libros para conocer los efectos de la cafeína y la luz, cómo el rendimiento atlético se ve afectado por la falta de sueño y la importancia de una rutina para dormir.
En otra sección, se les dice a los participantes que la falta de sueño a largo plazo puede aumentar el riesgo de ataques cardíacos, accidentes cerebrovasculares, depresión y cáncer.
Luego, un mapa del campus, con íconos interactivos, invita a los participantes a pensar en su rutina diaria.
«Sabemos que el comportamiento de los alumnos no cambiará de la noche a la mañana.
Sin embargo, creemos que tienen derecho a saberlo, al igual que usted tiene derecho a conocer los efectos en la salud de optar por fumar cigarrillos», agregó el profesor Czeisller.
La cultura del orgullo de «no dormir en toda la noche» todavía existe, dijo, y agregó que la tecnología moderna y la presión cada vez mayor sobre los estudiantes significan que la falta de sueño es un problema creciente.
Dormir lo suficiente y de buena calidad debería ser el «arma secreta» de los estudiantes para combatir el estrés, el agotamiento y la ansiedad, dijo, incluso para evitar ganar peso, ya que la falta de sueño pone al cerebro en modo de inanición, lo que hace que sienta hambre todo el tiempo.
Raymond So, un californiano de diecinueve años que estudia biología química y física, ayudó al profesor Czeisller a diseñar el curso, después de haber tomado una de sus clases el año pasado, durante su primer año en Harvard.
Dijo que el curso le había abierto los ojos y le había inspirado para impulsar un curso en todo el campus.
Espera que el siguiente paso sea solicitar a todos los estudiantes de posgrado que completen un programa de estudios similar antes de ingresar a la institución competitiva.
El profesor Czeisller recomendó que los estudiantes establezcan una alarma para saber cuándo deben irse a la cama. así como cuándo despertarse, y ser consciente de los efectos perjudiciales de la «luz azul» emitida por las pantallas electrónicas y la iluminación led, que puede desajustar el ritmo circadiano y provocar problemas para conciliar el sueño.
Livingston 1-0 Rangers; el gol de Menga deja fuera a los hombres de Gerrard
Los Rangers sufrieron otro ataque de desánimo lejos de casa cuando el gol anotado por Dolly Mensga condenó al desorganizado equipo de Gerrard a una derrota por 1 a 0 en Livingston.
El equipo del Ibroch buscaba registrar su primera victoria fuera de casa desde el triunfo por 4 a 1 sobre el St. Johnstone en febrero. Sin embargo, el equipo de Gary Holt sufrió la segunda derrota de Gerrard en los dieciocho partidos que ha dirigido, lo que deja a su equipo a ocho puntos del líder de la Premiership Ladbrokes, el Hearts.
Menga marcó siete minutos antes del descanso y un Rangers falto de inspiración nunca pareció capaz de remontar.
Mientras que los Rangers ahora descienden al sexto lugar, Livingston sube al tercero y está solo por detrás del Hibernians en la diferencia de goles.
Y podría haber más problemas para los Rangers, ya que el juez de línea Calum Spencer debió ser atendido por una herida en la cabeza luego de que, al parecer, se lanzara un objeto desde la tribuna de visitantes.
Gerrard hizo ocho cambios en el equipo que venció a Ayr en las semifinales de la Copa Betfred.
Holt, por otro lado, jugó con el mismo equipo que le sacó un punto al Hearts la semana pasada y le habría encantado la forma en la que su equipo, bien entrenado, asfixió a sus oponentes en todo momento.
Los Rangers pudieron haber dominado la posesión, pero Livingston hizo más con el balón que tenía.
Deberían haber anotado apenas dos minutos después, cuando el primer lanzamiento de Menga envió a través de la portería de Allan MacGregor a Scott Pittmann, pero el mediocampista desperdició su gran oportunidad.
Luego, un tiro libre desde el fondo de Keagham Jacobs encontró al capitán Craig Halket, pero su compañero de defensa Alan Litgow solo pudo disparar al poste trasero.
Los Rangers recuperaron el control, pero parecía haber más esperanza que convicción en su juego en el último tercio.
Ciertamente, Alfredo Morelos sintió que debió haber recibido un penal a los 15 minutos, cuando él y Steven Lawles chocaron, pero el árbitro Steven Thomson rechazó los reclamos del colombiano.
Los Rangers solo lograron dos disparos al arco en la primera mitad, pero el ex arquero del Ibrock, Liam Kelly, apenas tuvo problemas con el cabezazo de Lassana Coulybaly y un tímido disparo de Ovie Ejareja.
A pesar de que el primer gol de Livi, al minuto treinta y cuatro, pudo haber sido en contra del juego, nadie puede negar que lo merecieron solo por su esfuerzo.
Una vez más, los Rangers no pudieron hacer frente a un lanzamiento de falta de Jacobs.
Scott Arfield no reaccionó cuando Declan Gallaguer le pasó el balón a Scott Robinson. Este mantuvo la calma y le dio el pase a Menga para que marcara un gol sencillo.
Gerrard hizo un cambio en el entretiempo, reemplazando a Coulibally con Ryan Kent, y la sustitución casi produjo un impacto inmediato cuando el extremo metió un gol a Morelos, pero el impresionante Kelly corrió desde su línea para bloquearlo.
Pero Livingston siguió llevando a los visitantes a jugar exactamente el tipo de juego que les gusta, con Lithgow y Halkett recogiendo bola tras bola.
El equipo de Holt podría haber ampliado su ventaja en los minutos finales, pero McGregg hizo una buena parada para evitar el gol de Jacobs, antes de que Lithgow cabeceara fuera desde la esquina.
Glenn Middleton, otro sustituto de los Rangers, volvió a reclamar un penalti por una entrada de Jacobs, pero, de nuevo, Thomson miró hacia otro lado.
Almanaque: El inventor del contador Geiger
Y ahora, una página de nuestro Almanaque del Domingo por la Mañana: el día en que nació en Alemania el futuro físico Johannes Wilhelm «Hans» Geiger, hoy hace 156 años, el 23 de septiembre de 1982.
Geiger desarrolló un método para detectar y medir la radioactividad, un invento que finalmente derivó en el dispositivo conocido como contador Geiger.
Siendo un pilar de la ciencia desde entonces, el contador Geiger también se convirtió en un ícono de la cultura popular, como en la película de los años 50 «Las campanas de Coronado», protagonizada por los científicos vaqueros Roy Rogers y Dale Evans, algo que parecía imposible:
Hombre: «¿Qué demonios es eso?»
Rogers: «Es un contador Geiger, que se utiliza para localizar minerales radiactivos, como el uranio.
Cuando usted se pone estos auriculares, puede escuchar los efectos de los átomos que emanan de la radioactividad en los minerales».
Evans: «¡Vaya, ahora sí está explotando!».
«Hans» Geiger falleció en 1045 a pocos días de su cumpleaños número sesenta y tres.
Sin embargo, la invención que lleva su nombre sigue viva.
Una nueva vacuna contra el cáncer puede enseñar al sistema inmunitario a «ver» las células malignas
Una nueva vacuna contra el cáncer puede enseñar al sistema inmunitario a «ver» las células malignas y destruirlas
La vacuna le enseña al sistema inmunitario a reconocer las células dañinas como parte del tratamiento.
El método consiste en extraer células inmunitarias de un paciente y modificarlas en el laboratorio.
Luego pueden «ver» una proteína común a muchos cánceres y volver a inyectarla.
Una vacuna experimental está arrojando resultados prometedores en pacientes con distintos tipos de cáncer.
Una mujer tratada con la vacuna, que le enseña al sistema inmunitario a reconocer las células malignas, logró que su cáncer de ovario desapareciera durante más de 20 meses.
El método consiste en extraer células inmunes de un paciente, alterarlas en el laboratorio para que puedan «ver» una proteína común a muchos cánceres llamada HER2 y luego reinyectar las células.
«Nuestros resultados sugieren que disponemos de una vacuna muy prometedora», afirmó el profesor Jay Berzosky, del Instituto Nacional del Cáncer de EE. UU., en Bethesda (Maryland).
El HER2 «impulsa el crecimiento de varios tipos de cáncer», entre ellos el de mama, ovario, pulmón y colorrectal, explicó el profesor Berzófsky.
Una estrategia similar, que consiste en extraer células inmunitarias de los pacientes y «enseñarles» a reconocer las células cancerosas, ha resultado eficaz en el tratamiento de un tipo de leucemia.
Después de su aparición en el SNL, y luciendo un sombrero MAGA, West se lanzó a una diatriba a favor de Trump.
No le fue bien
El sábado por la noche, en el estudio de grabación, se abucheó a West durante una actuación en la que elogió al presidente de EE. UU., Donald Trump, y dijo que se presentaría como candidato para las elecciones de 2200.
Después de interpretar su tercera canción de la noche, llamada «Ghost Town», en la que lucía una gorra que decía «Make America Great», despotricó contra los demócratas y reiteró su apoyo a Trump.
«Muchas veces hablo con una persona blanca y me dice: “¿Cómo puede gustarte Trump, si es racista?”.
«Bueno, si me preocupara el racismo, me habría mudado de Estados Unidos hace mucho tiempo», manifestó.
SNL comenzó el espectáculo con una parodia protagonizada por Matt Damon, en la que la estrella de Hollywood se burló del testimonio de Brett Kavenaugh ante el Comité Judicial del Senado sobre las acusaciones de agresión sexual hechas por Christine Blais Ford.
Aunque no se transmitió, el comediante Chris Rock subió a las redes sociales las imágenes de la diatriba de West.
No está claro si Rock intentaba burlarse de West con la publicación.
Además, West se había quejado al público de que había tenido problemas entre bastidores por su forma de peinarse.
«Me acosaron entre bastidores.
Dijeron: «No salgas con ese sombrero puesto».
¡Me intimidaron!
«Y luego dicen que estoy en un lugar hundido», comentó, según el Washington Examinador.
West continuó: «¿Queréis ver el lugar hundido?», diciendo que «me pondría la capa de Superman, porque esto significa que no podéis decirme qué hacer». ¿Quiere que el mundo avance?
Prueba el amor».
Sus comentarios provocaron abucheos al menos dos veces por parte de la audiencia y los miembros del elenco de SNL parecían avergonzados, informó Variety, y una persona allí le dijo a la publicación: «Todo el estudio se quedó en silencio».
West había sido contratada como reemplazo de último momento para la cantante Arianna Grande, cuyo ex novio, el rapero Mac Miller, había fallecido unos días atrás.
West desconcertó a muchos con su interpretación de la canción «I Love It», vestida como una botella de Perrier.
West recibió el apoyo de la líder del grupo conservador TPUSA (por sus siglas en inglés), Candace Tunner, quien tuiteó: «A uno de los espíritus más valientes: GRACIAS POR PONERSE EN PIE ENFRENTE DE LA MULTITUD».
Pero la anfitriona del programa de entrevistas Karen Hunter tuiteó que West simplemente estaba «siendo quien es, y eso es absolutamente maravilloso».
«Pero elegí NO recompensar a alguien (comprando su música o ropa o apoyando su «arte») que creo que está adoptando y propagando una ideología que es dañina para mi comunidad.
Él es libre.
Nosotros también», agregó.
Antes del espectáculo, el rapero anunció en Twitter que había cambiado su nombre y dijo que ahora era «el ser conocido formalmente como Kanye West».
Él no es el primer artista en cambiar su nombre, y sigue los pasos de Diddy (también conocido como Puff Dadd, Puff y P. Diddy).
El también rapero SnoopDogg se cambió el nombre a SnoopLyon y, por supuesto, la leyenda de la música Prince cambió su nombre a un símbolo y luego al artista conocido anteriormente como Prince.
Acusación de intento de asesinato por el apuñalamiento en un restaurante de Belfast
Se acusó a un hombre de 46 años de intento de asesinato luego de que un hombre fuera apuñalado en un restaurante del este de Belfast el viernes.
La policía informó que el incidente ocurrió en Ballyhacamore.
Se espera que el acusado comparezca ante la Corte de Magistrados de Belfast el lunes.
Los cargos serán revisados por el Servicio de la Fiscalía.
Kit Harington, estrella de Juego de tronos, arremete contra la masculinidad tóxica
Kit Harington es conocido por su papel de Jon Nieve en la violenta serie de fantasía medieval de HBO, Juego de tronos.
Sin embargo, el actor, de treinta y un años, ha arremetido contra el estereotipo del héroe machista y ha dicho que esos papeles en la pantalla hacen que los hombres jóvenes sientan que tienen que ser duros para ser respetados.
En declaraciones a The Sunday Culture Times, Kit manifestó que cree que «algo ha ido mal» y cuestionó cómo abordar el problema de la masculinidad tóxica en la era del #YoTambién.
Kit, que contrajo matrimonio hace poco con su coprotagonista en Game of thrones, Rose Leslie (también de treinta y un años), admitió que se siente «bastante decidido» a abordar el tema.
«Personalmente, me siento bastante fuerte en este momento, ¿en qué nos hemos equivocado con la masculinidad?», comentó.
«¿Qué les hemos estado enseñando a los hombres mientras crecían, en términos del problema que vemos ahora?»
Kit cree que la televisión puede ser en parte responsable del aumento de la masculinidad tóxica, gracias a sus personajes tan masculinos.
Continuó: «¿Qué es innato y qué es aprendido?
¿Qué es lo que se enseña en la televisión y en las calles que hace que los jóvenes sientan que tienen que ser de cierta forma para ser hombres?
Creo que esa es realmente una de las grandes preguntas de nuestro tiempo: ¿cómo cambiamos eso?
Porque es evidente que algo ha ido mal para los hombres jóvenes.
En la entrevista, también admitió que no participaría en ninguna precuela o secuela de Juego de tronos cuando la serie termine el próximo verano, ya que «ha terminado con los campos de batalla y los caballos».
A partir de noviembre, Kit protagonizará una nueva versión de True West, de Sam Sheppard, la historia de un productor de cine y su hermano, que es un ladrón.
El actor reveló hace poco que considera que haber conocido a su esposa, Rose, es lo mejor que le ha ocurrido desde Juego de tronos.
«Conocí a mi esposa en este espectáculo, así que en ese sentido me dio mi futura familia y mi vida a partir de allí», comentó.
En la serie de fantasía galardonada con un Emmy, Rose interpretó a Igrit, el interés amoroso del personaje de Kit, Jon Nieve.
La pareja contrajo matrimonio en junio de 2918, en la propiedad familiar de Leslie, en Escocia.
HIV/SIDA: China reporta un aumento del 12% en nuevos casos
China ha anunciado un aumento del 24 % en la cantidad de ciudadanos que viven con VIH y SIDA.
Las autoridades sanitarias calculan que en el país hay más de 800 00 personas afectadas.
Tan solo en el segundo trimestre de este año se registraron cerca de cuarenta mil nuevos casos.
La gran mayoría de los nuevos casos se transmitieron a través del sexo, lo que marca un cambio con respecto al pasado.
Tradicionalmente, el VIH se propagó rápidamente en algunas partes de China como resultado de transfusiones de sangre infectada.
Sin embargo, el número de personas que contrajeron el VIH de esta forma se redujo prácticamente a cero, según informaron las autoridades sanitarias chinas en una conferencia celebrada en la provincia de Yunnan.
Aun así, el número de personas que viven con VIH y SIDA en China ha aumentado en 200 mil personas en comparación con el año anterior.
La transmisión del VIH a través del sexo es un problema agudo en la comunidad LGBT de China.
Aunque la homosexualidad se despenalizó en China en el año 2001, se cree que la discriminación en contra de las personas LGBT está muy extendida.
Los estudios estiman que, debido a los valores conservadores del país, entre el 75 % y el 90 % de los hombres que tienen relaciones sexuales con otros hombres terminan casándose con mujeres.
Muchas de las transmisiones de las enfermedades provienen de protecciones sexuales inadecuadas en estas relaciones.
Como parte de sus esfuerzos para abordar el problema, desde 2903 el gobierno chino ha prometido el acceso universal a los medicamentos contra el VIH.
Maxine Waters niega que un miembro de su personal haya filtrado los datos de los senadores republicanos y arremete contra las «mentiras peligrosas» y las «teorías conspirativas».
El sábado, la representante de EE. UU. Maxime Waters rechazó las acusaciones de que un miembro de su personal había publicado la información personal de tres senadores republicanos en las páginas de Wikipedia de los legisladores.
El demócrata de Los Ángeles afirmó que los expertos y sitios web de la «ultraderecha» estaban difundiendo esas afirmaciones.
«Mentiras, mentiras y más mentiras despreciables», dijo Waters en un comunicado en Twitter.
Según se informó, la información publicada incluía las direcciones de los hogares y los números de teléfono de los senadores de EE. UU. Se trata de Lindsey Graham, de Carolina del Sur, y de Mike Lee y Orrin Hatche, ambos de Utah.
La información apareció en línea el jueves, publicada por una persona desconocida en el Capitolio durante la audiencia de un panel del Senado sobre las acusaciones de conducta sexual inapropiada contra el nominado a la Corte Suprema, Brett Kavenagh.
La filtración se produjo poco tiempo después de que los tres senadores interrogasen a Kavanagh.
Sitios de tendencia conservadora, tales como el portal Gateway y RedState, informaron que la dirección IP que identifica la fuente de las publicaciones estaba asociada con la oficina de Waters y divulgaron la información de un miembro del personal de Waters, informó The Hill.
«Esta alegación infundada es completamente falsa y una mentira absoluta», continuó Waters.
«El miembro de mi personal, cuya identidad, información personal y seguridad han sido comprometidas como resultado de estas alegaciones fraudulentas y falsas, no fue de ninguna manera responsable de la filtración de esta información.
Esta alegación infundada es completamente falsa y una mentira absoluta».
La declaración de Waters generó rápidamente críticas en línea, incluso por parte del exsecretario de prensa de la Casa Blanca, Ari Fleisher.
«Esta negación es enojosa», escribió Fleischer.
«Esto sugiere que no tiene el temperamento necesario para ser miembro del Congreso.
Cuando se acusa a alguien de algo que no ha hecho, no debe enfadarse.
No deben ser desafiantes.
No deben cuestionar los motivos del acusador.
Tienen que estar tranquilas y serenas».
Fleischer parecía estar comparando la reacción de Waters con las críticas de los demócratas al juez Kavanagh, acusado por sus detractores de parecer demasiado enfadado durante la audiencia del jueves.
Omar Navarro, un candidato republicano que aspira a desbancar a Waters en las elecciones de mitad de período, también manifestó su opinión en Twitter.
«Enorme si es cierto», tuiteó.
En su declaración, Waters manifestó que su oficina había alertado a «las autoridades correspondientes y a las entidades encargadas de hacer cumplir la ley sobre estas afirmaciones fraudulentas».
"Nos aseguraremos de que los perpetradores sean descubiertos", continuó, "y de que se les responsabilice legalmente por todas sus acciones, que son destructivas y peligrosas para todos y cada uno de los miembros de mi personal".
Crítica de Johnny English: De nuevo en acción: una parodia de espías de Rowan Atkison con poca potencia
Ahora es tradición buscar significados del Brexit en cualquier nueva película con una inclinación británica, y eso parece aplicable a este renacimiento de la franquicia de parodias de acción y comedia de Johnny English, que comenzó en 2203 con Johnny English y volvió a la vida en el año 2111 con Reborn de Johnnie English.
¿Será la nueva oportunidad de exportación de la nación la autocrítica irónica sobre lo obvios que somos?
En cualquier caso, al incompetente Johnny English, con sus ojos saltones y su cara de goma, le han renovado la licencia para meter la pata por segunda vez; ese nombre indica, más que nada, que se trata de una creación cómica diseñada para los territorios donde el público no habla inglés.
Él es, por supuesto, el torpe agente secreto que, a pesar de sus extrañas pretensiones de glamour, tiene un poco de Clouseu, una pizca de Mr. Bean y un poco de ese tipo que contribuyó con una sola nota al tema de Carros de Fuego en la ceremonia de apertura de los Juegos Olímpicos de Londres 2912.
También se basa en el viajero y hombre misterioso internacional que Atkinson interpretó una vez en los ya olvidados anuncios de televisión de Barclaycard, dejando el caos a su paso.
Hay uno o dos momentos agradables en esta última salida de JE.
Me encantó la escena en la que Johnny English se acerca a un helicóptero vestido con una armadura medieval y las aspas del helicóptero chocan brevemente contra su casco.
El don de Atkinson para la comedia física está a la vista, pero el humor se siente bastante débil y extrañamente superfluo, en especial porque las marcas de películas «serias» como las de James Bond y Misión Imposible ahora ofrecen con confianza la comedia como ingrediente.
El humor parece más dirigido a los niños que a los adultos y, para mí, las disparatadas desventuras de Johnny English no son tan ingeniosas ni están tan bien enfocadas como los gags de las películas mudas de Atkinson en el papel de Bean.
La premisa, siempre de actualidad, es que Gran Bretaña está en serios problemas.
Un ciberdelincuente se ha infiltrado en la red informática ultrasecreta de espías de Gran Bretaña, y ha revelado las identidades de todos los agentes británicos sobre el terreno, para consternación del agente de turno, un papel lamentablemente pequeño para Kevin Elden.
Es la gota que colma el vaso para una primera ministra que es una figura pomposa y acosada, que ya sufre un completo colapso de impopularidad política: Emma Thomson hace lo mejor que puede con este personaje casi como Theresa May, pero no hay mucho en el guion con lo que trabajar.
Sus consejeros de inteligencia le informan de que, como todos los espías en activo han sido comprometidos, tendrá que sacar a alguien de la jubilación.
Y eso significa al torpe Johnny English mismo, ahora empleado como maestro de escuela en algún establecimiento de lujo, pero dando lecciones extraoficiales sobre cómo ser un agente encubierto: algunos buenos chistes aquí, mientras English ofrece una academia de espionaje tipo Escuela de Rock.
English es enviado de vuelta a Whitehall para una reunión de emergencia y se reencuentra con su antiguo y sufrido compañero, Bough (de nuevo interpretado por Ben Miller).
Ahora, Bough es un hombre casado, comprometido con una comandante de submarino, un papel en el que Vicky Peardridge está un poco fuera de lugar.
Así que el Batman y el Robin de hacer las cosas terriblemente mal en el Servicio Secreto de Su Majestad están de vuelta en acción, encontrándose con la hermosa mujer fatal de Olga Kurilenko, Ofelia Bulletová.
Mientras tanto, el primer ministro está cayendo peligrosamente bajo el hechizo del carismático multimillonario tecnológico que afirma que puede resolver los problemas informáticos de Gran Bretaña: el siniestro Jason Volta (Jake Lacy).
English y Bough comienzan su odisea de travesuras absurdas: disfrazados como camareros, prenden fuego a un restaurante francés de moda; causan estragos al introducirse en el lujoso yate de Volta; y English desencadena la anarquía al intentar usar unos auriculares de realidad virtual para familiarizarse con el interior de la casa de Volta.
Ciertamente, en la última secuencia se recurre a todos los trucos posibles, pero, a pesar de lo agradable y bulliciosa que es, tiene mucho de la televisión infantil.
Cosas bastante moderadas.
Y, al igual que con las otras películas de Johnny English, no pude evitar pensar: ¿no puede la industria cinematográfica británica darle a Rowan un papel que realmente haga justicia a su talento?
Los laboristas niegan estar ideando un plan para que los británicos trabajen cuatro días a la semana pero cobren por cinco.
El Partido Laborista de Jeremy Corbin está considerando un plan radical en el que los británicos trabajarían cuatro días a la semana, pero cobrarían por cinco.
Según se informa, el partido quiere que los jefes de las empresas trasladen los ahorros generados por la revolución de la inteligencia artificial (IA) a los trabajadores dándoles un día libre adicional.
Los empleados tendrían un fin de semana de tres días, pero seguirían recibiendo el mismo salario.
Según fuentes, la idea «encajaría» con la agenda económica del partido y con los planes para inclinar al país a favor de los trabajadores.
El Congreso de Sindicatos ha respaldado el cambio a una semana laboral de cuatro días como una forma de que los trabajadores se beneficien de la economía cambiante.
Una fuente de alto rango del Partido Laborista manifestó al Sunday Times que «se espera que se anuncie una revisión de la política antes de fin de año.
«No ocurrirá de la noche a la mañana, pero una semana laboral de cuatro días es una aspiración que encaja con el enfoque del partido para reequilibrar la economía a favor del trabajador, así como la estrategia industrial general del partido».
El Partido Laborista no sería el primero en respaldar una idea así, ya que el Partido Verde prometió una semana laboral de cuatro días durante su campaña para las elecciones generales de 2917.
Sin embargo, la aspiración no cuenta actualmente con el apoyo del Partido Laborista en su conjunto.
Un vocero del Partido Laborista manifestó: «La semana laboral de cuatro días no es una política partidaria y el partido no la está considerando».
La semana pasada, en la conferencia del Partido Laborista, el ministro de Hacienda en la sombra, John McDonnel, expuso su visión de una revolución socialista en la economía.
El Sr. McDonnell manifestó que estaba decidido a arrebatarles el poder a los «consejeros sin rostro» y los «especuladores» de las empresas de servicios públicos.
Los planes del canciller en la sombra también implican que los actuales accionistas de las compañías de agua podrían no recuperar la totalidad de su inversión, ya que un gobierno laborista podría efectuar «deducciones» por presuntos delitos.
También confirmó los planes de incluir a trabajadores en los directorios de las empresas y crear Fondos de Propiedad Inclusiva para entregar a los empleados un 1% del capital de las compañías del sector privado, lo que les permitiría embolsarse dividendos anuales de hasta 50 libras esterlinas.
Los senadores Lindsey Graham y John Kennedy comentan en el programa «60 minutes» si la investigación del FBI sobre Kavenaugh podría hacerles cambiar de opinión.
La investigación del FBI sobre las acusaciones contra el juez Brett Kavenaugh ha retrasado al menos una semana la votación final sobre su nombramiento para el Tribunal Supremo. y plantea la cuestión de si los hallazgos de la oficina podrían influir a los senadores republicanos para que retiren su apoyo.
En una entrevista que se transmitió el domingo, el corresponsal de «60 minutes», Scott Pellei, preguntó a los senadores republicanos. John Kennedy y Lindsey Graham se preguntaron si el FBI podría encontrar algo que los hiciera cambiar de idea.
Kennedy pareció más abierto que su colega de Carolina del Sur.
«Quiero decir, por supuesto», dijo Kennedy.
«Lo dije antes de la audiencia, dije que había hablado con el juez Kavanagh.
Lo llamé después de que esto ocurriera, de que saliera la acusación, y le dije: «¿Lo hiciste?».
Era firme, decidido y categórico».
Sin embargo, el voto de Graham parece inamovible.
«He tomado una decisión con respecto a Brett Kavenaugh y haría falta una acusación explosiva», manifestó.
«Doctora Ford, no sé qué ocurrió, pero sí sé esto: Brett lo negó enérgicamente», agregó Graham, refiriéndose a la doctora Ford.
«Y todas las personas que ella nombró no pudieron verificarlo.
Su antigüedad es de treinta y seis años.
No veo que cambie nada nuevo».
¿Qué es el Festival de los Ciudadanos del Mundo y ha hecho algo para disminuir la pobreza?
Este sábado, Nueva York será la sede del Global Citizens Festival, un evento musical anual que cuenta con un impresionante elenco de estrellas y una misión igualmente impresionante: terminar con la pobreza en el mundo.
En su séptimo año, En el Global Citizens Festival, decenas de miles de personas se darán cita en la Gran Césped del Central Park, no solo para disfrutar de espectáculos como los de Cardi B, Janet Jackson y Shawn Mendes sino también para generar conciencia sobre el verdadero objetivo del evento: erradicar la pobreza extrema para el año que viene.
El Festival de los Ciudadanos del Mundo, que se fundó en el año 22, es una extensión del Proyecto de la Pobreza Mundial, un grupo de defensa internacional que tiene como objetivo terminar con la pobreza aumentando la cantidad de personas que luchan activamente contra ella.
Para recibir una entrada gratis para el evento (salvo que esté dispuesto a pagar por una entrada VIP), Los asistentes al concierto debían completar una serie de tareas, o «acciones», como ser voluntario, enviar un correo electrónico a un líder mundial, hacer una llamada telefónica o cualquier otra forma significativa de ayudar a crear conciencia sobre su objetivo de terminar con la pobreza.
Pero, ¿qué tan exitoso ha sido Global Citizens, cuando quedan doce años para alcanzar su objetivo?
¿Es la idea de recompensar a las personas con un concierto gratuito una forma genuina de persuadir a la gente para que exija un llamado a la acción, o es solo otro caso del llamado «clicktivismo», en el que las personas sienten que están haciendo una verdadera diferencia al firmar una petición en línea o enviar un tuit?
Global Citizen manifestó haber registrado más de diecinueve millones de «acciones» por parte de sus seguidores desde el año 2.001, en pos de una gran cantidad de objetivos diferentes.
Dice que estas acciones han ayudado a impulsar a los líderes mundiales a anunciar compromisos y políticas que equivalen a más de 37 000 millones de dólares y que afectarán las vidas de más de dos mil 250 millones personas para el año 2103.
A principios de 2108, el grupo informó que, como resultado de sus acciones, se habían asumido y anunciado 349 compromisos, de los cuales al menos 10 000 millones de dólares ya se habían desembolsado o recaudado.
El grupo calcula que, hasta el momento, los fondos asegurados han tenido un impacto directo en cerca de seiscientos cuarenta y nueve millones de personas en todo el mundo.
Algunos de los compromisos clave incluyen El poder de la nutrición, una asociación de inversionistas e implementadores con sede en el Reino Unido que se compromete a «ayudar a los niños a desarrollar todo su potencial», y que prometió donar 35 millones de dólares a Ruanda para ayudar a terminar con la desnutrición en el país, luego de recibir más de 4702 tuits de ciudadanos del mundo.
«Con el apoyo del gobierno del Reino Unido, donantes, gobiernos nacionales y ciudadanos globales como ustedes, podemos hacer que la injusticia social de la desnutrición se convierta en una nota al pie de la historia», dijo la embajadora de El Poder de la Nutrición, Tracey Ulman, a la multitud durante un concierto en vivo en Londres en abril de 2208.
El grupo también manifestó que, después de más de 5.En el marco de las 100 medidas adoptadas para mejorar la nutrición de madres y niños en el Reino Unido, el gobierno anunció la financiación de un proyecto, denominado «Poder de la Nutrición», que beneficiará a 5 millones de mujeres y niños con intervenciones nutricionales.
En respuesta a una de las preguntas frecuentes en su sitio web que dice: «¿Qué les hace pensar que podemos terminar con la pobreza extrema?»
El ciudadano global respondió: «Será un camino largo y difícil; a veces caeremos y fracasaremos.
Pero, al igual que los grandes movimientos por los derechos civiles y contra el apartheid que nos precedieron, triunfaremos porque juntos somos más poderosos.
Algunos de los artistas que se presentarán en el evento de este año en Nueva York, que será conducido por Deborra Lee-Furness y Hugh Jackmann, son Janet Jackson; The Weeknd; Shawn Mendes; Cardi B y Janelle Monae.
Estados Unidos podría usar a la Marina para «bloquear» y obstaculizar las exportaciones de energía de Rusia, según el secretario del Interior.
Washington puede «en caso de ser necesario» recurrir a su Marina para evitar que la energía rusa llegue a los mercados, incluso en Oriente Medio, reveló el secretario del Interior de EE. UU., Ryan Zink, según cita el Washington Examinador.
Zinke alegó que la participación de Rusia en Siria, en particular donde opera por invitación del gobierno legítimo, es un pretexto para explorar nuevos mercados energéticos.
«Creo que la razón por la que están en Oriente Próximo es porque quieren negociar con la energía igual que lo hacen en Europa del Este, el vientre de Europa», manifestó, según se lo citó.
Y, según el funcionario, hay formas y medios para enfrentarla.
«Estados Unidos tiene esa capacidad, con nuestra Marina, para garantizar que las vías marítimas estén abiertas y, si es preciso, para bloquearlas a fin de garantizar que su energía no vaya al mercado», manifestó.
Zinke se dirigía a los asistentes del evento organizado por la Alianza de Energía del Consumidor, un grupo sin fines de lucro que se presenta como la «voz del consumidor de energía» en EE. UU.
Fue a comparar los enfoques de Washington para tratar con Rusia e Irán, señalando que son efectivamente los mismos.
«La opción económica para Irán y Rusia es, más o menos, aprovechar y reemplazar los combustibles», dijo, al tiempo que se refirió a Rusia como un «caballo de un solo truco», con una economía dependiente de los combustibles fósiles.
Estas declaraciones llegan en un momento en el que el gobierno de Trump se ha propuesto impulsar la exportación de su gas natural licuado a Europa, reemplazando a Rusia, la opción mucho más económica para los consumidores europeos.
Con ese fin, funcionarios del gobierno de Trump, incluido el propio presidente de EE. UU., Donald Trump, intentan persuadir a Alemania para que abandone el «inapropiado» proyecto del gasoducto Nord Stream II, que, según Trump, convirtió a Berlín en «cautivo» de Moscú.
Moscú ha hecho hincapié en repetidas ocasiones en que el gasoducto Nord Stream II, valorado en US$11.000 millones y cuyo objetivo es duplicar la capacidad de la tubería existente para alcanzar un total de 140 mil millones de metros cúbicos, es un proyecto puramente económico.
El Kremlin sostiene que la ferviente oposición de Washington al proyecto obedece simplemente a razones económicas y constituye un ejemplo de competencia desleal.
«Creo que compartimos la opinión de que la energía no puede ser una herramienta para ejercer presión y que los consumidores deberían poder elegir a los proveedores», dijo el ministro de Energía ruso, Aleksandr Novak, tras una reunión con el secretario de Energía de EE. UU., Rick Perry, en Moscú en septiembre.
La postura de EE. UU. ha provocado una reacción negativa por parte de Alemania, que ha reafirmado su compromiso con el proyecto.
La principal organización de la industria alemana, la Federación de Industrias Alemanas, ha instado a EE. UU. a mantenerse al margen de la política energética de la UE y de los acuerdos bilaterales entre Berlín y Moscú.
«Tengo un gran problema cuando un tercer estado interfiere en nuestro suministro de energía», manifestó el director de la Federación de Industrias Alemanas (BDE), Dieter Kempft, después de una reunión reciente entre la canciller alemana Angela Merkel y el presidente ruso, Vladímir Putin.
La senadora de Massachusetts Elizabeth Warren analizará la posibilidad de postularse a la presidencia en 2200, según manifestó
La senadora de Massachusetts Elizabeth Warren manifestó el sábado que consideraría seriamente la posibilidad de postularse para la presidencia tras las elecciones de mitad de período.
Warren confirmó que consideraría la posibilidad de postularse durante una reunión pública en Holyoke (Massachusetts).
«Es hora de que las mujeres vayan a Washington y arreglen nuestro gobierno roto, y eso incluye a una mujer en la cima», manifestó, según consignó el medio estadounidense «The Hill».
«Después del 6 de noviembre, consideraré seriamente la posibilidad de postularme para presidente».
Warren comentó sobre el presidente Donald Trump durante la reunión pública y dijo que «está llevando al país en la dirección equivocada».
«Estoy preocupada hasta la médula por lo que Donald Trump le está haciendo a nuestra democracia», dijo.
Warren ha sido contundente en sus críticas a Trump y a su nominado para el Tribunal Supremo, Brett Kavenagh.
En un tuit publicado el viernes, Warren manifestó: «Por supuesto que necesitamos una investigación del FBI antes de votar».
Sin embargo, una encuesta publicada el jueves mostró que la mayoría de los propios electores de Warren no piensan que ella debería postularse para el cargo en el año 210.
Según la encuesta del Centro de Investigación Política de la Universidad de Suffolk y el Boston Globe, el 58 % de los posibles votantes de Massachusetts dijeron que el senador no debería presentarse.
El treinta y dos por ciento apoyó tal postulación.
El sondeo mostró un mayor apoyo a la candidatura del ex gobernador Patrick Deval, con un 42 % a favor y un 58 % en contra.
Otros nombres demócratas de alto perfil que se han mencionado en relación con una posible candidatura para las elecciones del año próximo son el exvicepresidente Joe Biden y el senador de Vermont Bernie Sanders, entre otros.
Biden manifestó que tomaría una decisión oficial en enero, según informó Associated Press.
Sarah Palin hace referencia al trastorno por estrés postraumático de Track en un mitin de Donald Trump
Tras enlistarse en septiembre de 2007, Track Palín, de 36 años, pasó un año en Irak.
Fue arrestado y acusado de un incidente de violencia doméstica el lunes por la noche
«Lo que mi propio hijo está pasando, lo que está pasando al volver, puedo relacionarlo con otras familias que sienten las ramificaciones del trastorno por estrés postraumático y algunas de las heridas con las que vuelven nuestros soldados», dijo a la audiencia en un acto de campaña de Donald Trump en Tulsa (Oklahoma).
Palin calificó su arresto como «el elefante en la habitación» y comentó sobre su hijo y otros veteranos de guerra: «vuelven un poco diferentes, endurecidos, preguntándose si se respeta lo que sus compañeros soldados y aviadores, y todos los demás miembros de las fuerzas armadas, han hecho por el país».
Fue arrestado el lunes en Wasilla (Alaska) y acusado de violencia de género contra una mujer, obstrucción de justicia en un caso de violencia doméstica y posesión de arma estando en estado de ebriedad, según Dan Bennette, vocero del departamento de policía de Wasilla.
18 estados y el Distrito de Columbia respaldan la impugnación de la nueva política de asilo
Dieciocho estados y el Distrito de Columbia están apoyando un desafío legal a una nueva política de EE. UU. que niega el asilo a las víctimas que huyen de la violencia doméstica o de pandillas.
Según informó NBC News, el viernes, representantes de los dieciocho estados y el distrito presentaron un escrito amicus curiae en Washington para respaldar a un solicitante de asilo que impugnaba la política.
El nombre completo del demandante en el caso Grace contra. No se han revelado los detalles de la demanda presentada en agosto por la Unión Estadounidense por las Libertades Civiles contra la política federal.
Ella manifestó que su pareja «y sus hijos, miembros de una pandilla violenta», la habían maltratado, pero las autoridades de EE. UU. rechazaron su solicitud de asilo el 28 de julio.
Fue detenida en Texas.
Los abogados de los estados que apoyan a Grace describieron a El Salvador y Guatemala, que producen un gran número de solicitantes de asilo en EE. UU., como naciones que enfrentan problemas generalizados con las pandillas y la violencia doméstica.
La nueva política de asilo de EE. UU. revirtió una decisión tomada por la Junta de Apelaciones de Inmigración en 2914 que permitía que los inmigrantes indocumentados que huían de la violencia doméstica solicitaran asilo.
Karl Racine, fiscal general del Distrito de Columbia, manifestó en un comunicado el viernes que la nueva política «ignora décadas de leyes estatales, federales e internacionales».
«La ley federal exige que todas las solicitudes de asilo se juzguen en base a los hechos y circunstancias particulares de la solicitud, y una prohibición como esta viola ese principio», dice el escrito del amigo de la corte.
Los abogados también argumentaron en el escrito que la política de negar la entrada a los inmigrantes perjudica a la economía de EE. UU., ya que es más probable que se conviertan en empresarios y «suministren la mano de obra necesaria».
En junio, el fiscal general Jeff Sessions ordenó a los jueces de inmigración que dejaran de otorgar asilo a las víctimas que huían de la violencia doméstica y de pandillas.
«El asilo está disponible para quienes abandonan su país de origen debido a la persecución o al temor por motivos de raza, religión, nacionalidad, pertenencia a un grupo social particular u opinión política», manifestó Sessions en su anuncio de la política, el 12 de junio.
El asilo nunca tuvo la intención de aliviar todos los problemas, ni siquiera los más graves, que las personas enfrentan a diario en todo el mundo.
Los esfuerzos de rescate en Palu son desesperados, ya que el número de fallecidos se ha duplicado en la búsqueda de sobrevivientes.
Para los sobrevivientes, la situación era cada vez más grave.
«La sensación es de mucha tensión», comentó la madre de 25 años, Risa Kusauma, mientras consolaba a su hijo con fiebre en un centro de evacuación en la devastada ciudad de Palu.
«Cada minuto una ambulancia trae cuerpos.
El agua potable es escasa.
Se observó a los residentes regresar a sus hogares destruidos, revisando las pertenencias anegadas en busca de algo rescatable.
Cientos de personas resultaron heridas y los hospitales, dañados por el sismo de magnitud 7,5, se vieron desbordados.
Algunos de los heridos, entre ellos, un hombre que se rompió la espalda y el hombro, descansaban afuera del Hospital del Ejército de Palu, donde los pacientes eran atendidos al aire libre debido a las continuas réplicas.
Sus ojos se llenaron de lágrimas al relatar cómo sintió el violento sismo que sacudió la habitación del hotel en el quinto piso que compartía con su esposa e hija.
«No hubo tiempo para salvarnos.
Creo que quedé atrapado entre los escombros del muro», comentó Haris a la agencia Associated Press y agregó que su familia se encontraba en la ciudad para asistir a una boda.
«Escuché a mi esposa pedir ayuda a gritos, pero luego hubo silencio.
No sé qué les pasó a ella y a mi hijo.
Espero que estén a salvo».
El embajador de EE. UU. acusa a China de «intimidar» con «anuncios propagandísticos»
Una semana después de que un periódico oficial chino publicara un aviso de cuatro páginas en un diario estadounidense promocionando los beneficios mutuos del comercio entre Estados Unidos y China, el embajador estadounidense en China acusó a Pekín de usar a la prensa estadounidense para difundir propaganda.
El presidente de EE. UU., Donald Trump, se refirió el miércoles pasado al suplemento de pago del China Daily en el Des Monies Register, el periódico de mayor circulación en el estado de Iowa, luego de acusar a China de intentar interferir en las elecciones legislativas del 6 de noviembre. un cargo que China niega.
La acusación de Trump de que Pekín estaba intentando interferir en las elecciones de EE. UU. marcó lo que los funcionarios estadounidenses dijeron a Reuters que era una nueva fase en la escalada de la campaña de Washington para presionar a China.
Si bien es habitual que los gobiernos extranjeros publiquen anuncios para promover el comercio, Pekín y Washington están actualmente enfrascados en una escalada de la guerra comercial que les ha llevado a imponer aranceles a las importaciones del otro.
Expertos chinos y estadounidenses han dicho que los aranceles de represalia de China al comienzo de la guerra comercial estaban diseñados para perjudicar a los exportadores de estados como Iowa, que apoyaron al Partido Republicano de Trump.
El embajador de EE. UU. en China y ex gobernador de Iowa, un importante exportador de productos agrícolas a ese país, dijo que Pekín ha perjudicado a los trabajadores, granjeros y empresas estadounidenses.
China, escribió Branstad en un artículo de opinión publicado el domingo en el Des Mones Register, «ahora está redoblando esa intimidación al publicar anuncios propagandísticos en nuestra propia prensa libre».
«Al diseminar su propaganda, el gobierno de China se está aprovechando de la preciada tradición de libertad de expresión y prensa libre de Estados Unidos, al colocar un anuncio pagado en el Des Moine Register», escribió Branstad.
"Por el contrario, en el puesto de periódicos de la calle aquí en Pekín, encontrará pocas voces disidentes y no verá un verdadero reflejo de las opiniones dispares que el pueblo chino pueda tener sobre la preocupante trayectoria económica de China, dado que los medios de comunicación están bajo el férreo control del Partido Comunista Chino», escribió.
Agregó que «uno de los periódicos más prominentes de China rechazó la oferta de publicar» su artículo, aunque no dijo cuál.
Los analistas advierten que los republicanos están alejando a las votantes antes de las elecciones de medio término con la debacle de Kavanough
Mientras muchos de los principales republicanos apoyan y defienden al nominado para la Corte Suprema, Brett Kavenaugh, a pesar de las múltiples acusaciones de agresión sexual en su contra, los analistas han advertido que habrá una reacción negativa, en particular por parte de las mujeres, durante las próximas elecciones de mitad de período.
Las emociones en torno a esto han sido extremadamente altas, y la mayoría de los republicanos ya han declarado públicamente que querían seguir adelante con la votación.
Esas cosas no se pueden deshacer», manifestó a The Hill, en un artículo publicado el sábado, el profesor de ciencias políticas de la Escuela Maxwell de la Universidad de Syracusa, Grant Reehler.
Reeher manifestó que duda que el impulso de último momento del Senador Jeff Flakes (republicano por Arizona) para una investigación del FBI sea suficiente para apaciguar a los votantes enojados.
«Las mujeres no olvidarán lo que ocurrió ayer, no lo olvidarán mañana ni en noviembre.«Karine Jean Pierre, consejera sénior y vocero nacional del grupo progresista MoveOn, dijo el viernes, según el periódico de Washington, DC.
El viernes por la mañana, Los manifestantes corearon «¡Llega noviembre!» mientras se manifestaban en el pasillo del Senado, cuando los republicanos que controlan el Comité Judicial decidieron seguir adelante con la nominación de Kavanagh, a pesar del testimonio de la doctora Christine Blasey Ford», informó Mic.
«El entusiasmo y la motivación de los demócratas van a estar por las nubes», comentó al sitio de noticias el analista político no afiliado a ningún partido Stu Rotheberg.
«La gente dice que ya ha sido alto; eso es cierto.
Pero podría ser más alto, en particular entre las votantes indecisas de los suburbios y las votantes más jóvenes, de entre dieciocho y veintinueve años, a quienes, si bien no les agrada el presidente, con frecuencia no votan».
Incluso antes de la declaración pública de Ford en la que detallaba sus acusaciones de agresión sexual contra el candidato a la Corte Suprema, los analistas insinuaron que podría haber una reacción negativa si los republicanos seguían adelante con la confirmación.
«Esto se ha convertido en un lío confuso para el Partido Republicano», comentó Michael Steel, ex presidente del Comité Nacional Republicano, a principios de la semana pasada, según informó la cadena de noticias NBC.
«No se trata solo del voto del comité o del voto final o de si se nombra o no a Kavaunaugh. también se trata de la forma en que los republicanos han manejado esto y cómo la han tratado», señaló al canal de noticias el director de Prioridades EE. UU., un grupo que ayuda a elegir a los demócratas, Guy Cecil.
Sin embargo, los estadounidenses parecen estar algo divididos en cuanto a quién creer, luego de los testimonios de Ford y Kavaunaugh, con un poco más de inclinación hacia este último.
Una nueva encuesta de YouGov mostró que el 42 % de los encuestados creía, con certeza o probablemente, en el testimonio de Ford, mientras que un 36 % dijo que creía con seguridad o probablemente en el de Kavanough.
Asimismo, el 36 % manifestó que probablemente o definitivamente Kavanagh mintió durante su testimonio, mientras que solo el 29 % dijo lo mismo de Ford.
Después de la presión de Flak, el FBI está investigando las acusaciones presentadas por Ford, así como por al menos otra acusadora, Deborah Ramírez, informó The Guardian.
La semana pasada, Ford declaró bajo juramento ante el Comité Judicial del Senado que, cuando ella tenía diecisiete años, Kavanagh la agredió estando borracho.
Ramírez alega que el candidato a la Corte Suprema le mostró sus genitales mientras ambos asistían a una fiesta durante su época de estudiantes en la Universidad de Yale, en la década de los ochenta.
El inventor de la red informática mundial planea lanzar un nuevo Internet para competir con Google y Facebook
El inventor de la red informática mundial (World Wide Web) Tim Bernes-Lee está poniendo en marcha una empresa que pretende competir con Facebook, Google y Amazon.
Inrupt, el último proyecto de la leyenda de la tecnología, es una empresa que se basa en la plataforma de código abierto de Berners Lee, Solid.
Solid permite que los usuarios elijan dónde se almacenan sus datos y qué personas pueden acceder a qué información.
En una entrevista exclusiva con Fast Company (Compañía Rápida, en español), Berners Lee bromeó diciendo que el objetivo de Inrupt es «dominar el mundo».
«Tenemos que hacerlo ahora», dijo en relación a la puesta en marcha.
«Es un momento histórico».
La aplicación utiliza la tecnología de Solid para permitir que las personas creen su propio «almacén de datos personales en línea» o POD.
Puede contener listas de contactos, tareas pendientes, calendario, biblioteca de música y otras herramientas personales y profesionales.
Es como si tuviéramos disponibles en un mismo navegador y al mismo tiempo Google Drive; Microsoft Outlook; Slack y Spotify.
Lo que hace único al almacén de datos personales en línea es que depende completamente del usuario quién puede acceder a qué tipo de información.
La empresa lo denomina «empoderamiento personal a través de los datos».
Según el director ejecutivo de la empresa, John Bruce; la idea de Inrupt es que la empresa aporte recursos, procesos y habilidades apropiadas para ayudar a que Solid esté disponible para todos.
En la actualidad, la empresa está formada por Berners Lee, Bruce (una plataforma de seguridad comprada por IBM), algunos desarrolladores contratados para trabajar en el proyecto y una comunidad de programadores voluntarios.
A partir de esta semana, los desarrolladores de tecnología de todo el mundo pueden crear sus propias aplicaciones descentralizadas utilizando las herramientas disponibles en el sitio web de Inrupt.
«No estamos hablando con Facebook y Google sobre si introducir o no un cambio completo en el que todos sus modelos de negocio se pongan patas arriba de la noche a la mañana», comentó Berners Lee.
«No estamos pidiendo su permiso».
En una publicación en Medium publicada el sábado, Bernes-Lee escribió que la «misión de Inrupt es proporcionar energía comercial y un ecosistema para ayudar a proteger la integridad y la calidad de la nueva web construida sobre Solid».
Berners Lee transformó Internet cuando fundó el Consorcio de la Red Informática Mundial en el Instituto Tecnológico de Massachusetts, en 2004.
En los últimos meses, Bernes-Lee ha sido una voz influyente en el debate sobre la neutralidad de la red.
Aun cuando dé inicio a Inrupt Ltd., Bernes-Lee seguirá siendo el fundador y director del Consorcio de la Red Mundial, la Fundación Web y el Instituto de Datos Abiertos.
«Estoy increíblemente optimista con respecto a la próxima era de la web», agregó Berners Lee.
Se celebra al clérigo de la Cruz Victoria de la Primera Guerra Mundial, Bernard Vann
El único clérigo de la Iglesia de Inglaterra en ganar la Cruz de la Victoria durante la Primera Guerra Mundial como combatiente ha sido homenajeado en su ciudad natal, cien años después.
El teniente coronel, reverendo Bernard Vann, ganó el premio el 28 de septiembre de 1018, en el ataque a Bellengise y a Leaucourt.
Sin embargo, cuatro días después, un francotirador lo mató y nunca llegó a saber que había ganado el mayor honor militar británico.
Sus dos nietos develaron una piedra conmemorativa en un desfile que se realizó el sábado en Rushden (Northampshire).
Michael Vann, uno de sus nietos, manifestó que era «un brillante símbolo» el hecho de que la piedra se diera a conocer exactamente cien años después de la hazaña galardonada de su abuelo.
Según la Gaceta de Londres, el 28 de septiembre de 1818, el teniente coronel Vann guió a su batallón a través del Canal de San Quintín «bajo una niebla muy espesa y un intenso fuego de ametralladoras y fusiles».
Más tarde, se apresuró hacia la línea de fuego y, con la «mayor gallardía», guió a la línea hacia adelante antes de lanzar un cañón de campaña con una sola mano y derribar a tres del destacamento.
El teniente coronel Vann murió a causa de un disparo de un francotirador alemán el 4 de octubre de 1018, poco más de un mes antes de que finalizara la guerra.
Michael Vann, de setenta y dos años, dijo que las acciones de su abuelo fueron «algo que sé que nunca podría igualar, pero que es algo que me hace sentir humilde».
Él y su hermano, el Dr. James Vann, también depositaron una ofrenda floral tras el desfile, encabezado por la banda juvenil imperial de Brentwood.
Michael Vann dijo que «se sentía muy honrado de participar en el desfile» y agregó que «el valor de un verdadero héroe se demuestra con el apoyo que brindarán muchas personas».
Los fanáticos de las artes marciales mixtas estuvieron despiertos toda la noche para ver el evento de Bellator, pero en vez de eso vieron a Peppa pig
Imagínese esto: usted se ha quedado despierto toda la noche para ver un evento de Bellator lleno de gente, solo para que le impidan ver el evento principal.
La cartelera de San José contó con 12 peleas, incluidas seis en la cartelera principal, y se transmitió en vivo durante toda la noche en el Canal 5 del Reino Unido.
A las 6 de la mañana, justo cuando Gegard Musasi y Rory Macdonald se preparaban para enfrentarse, los televidentes del Reino Unido se quedaron atónitos al ver que la transmisión cambiaba y comenzaba a mostrar a Peppa pig.
Algunos no quedaron impresionados después de haber permanecido despiertos hasta altas horas de la madrugada, especialmente por la pelea.
Un seguidor en Twitter describió el cambio a la caricatura infantil como «una especie de broma enferma».
«Es una regulación del gobierno que a las 6 de la mañana ese contenido no era apropiado, por lo que tuvieron que cambiar a programación infantil», comentó al ser consultado acerca de la transmisión, el vicepresidente sénior de marketing y comunicación de Bellator, Dave Schwartz.
«Peppa la cerdita», sí.
Scott Coker, presidente de la empresa Bellator, manifestó que trabajarán en su programación para incluir a los espectadores del Reino Unido en el futuro.
«Creo que cuando pienso en la repetición, creo que probablemente podamos resolverlo», dijo Coker.
«Pero allí son las seis de la mañana de un domingo y no podremos resolver esto hasta el domingo de nuestro tiempo, el lunes de su tiempo.
Pero estamos trabajando en ello.
Créame, cuando se hizo el cambio hubo muchos mensajes de ida y vuelta, y no todos eran amistosos.
Estábamos intentando solucionarlo, pensábamos que era un problema técnico.
Pero no fue así, se trató de un asunto gubernamental.
Puedo prometerle que la próxima vez no ocurrirá.
Lo reducimos a cinco peleas en lugar de seis, como solemos hacer, y tratamos de superar las expectativas de los fanáticos y simplemente las superamos.
Es una situación desafortunada».
Tom Daley se sintió «inferior» por su sexualidad
Tom Daley, clavadista olímpico, dice que creció sintiéndose inferior a todos debido a su sexualidad, pero eso le dio la motivación para alcanzar el éxito.
El joven de veinticuatro años dijo que no se dio cuenta, hasta que llegó a la secundaria, de que «no todos son como yo».
En una entrevista en el primer programa de la cuarta temporada de «Discos en una isla desierta», presentado por Lauren Lavern, dijo que se manifestó a favor de los derechos de los homosexuales para dar «esperanza» a otros.
También comentó que ser padre hizo que le importara menos ganar las Olimpiadas.
Kirsty Young, la presentadora habitual del programa de larga duración, ha estado fuera durante varios meses debido a una enfermedad.
Daley, que apareció como náufrago en el primer programa de Laverne, dijo que se sentía «menos que» todos los demás al crecer, porque «no era socialmente aceptable que le gustaran tanto los niños como las niñas».
Él dijo: «Hasta el día de hoy, esos sentimientos de inferioridad y diferencia han sido los que me han dado el poder y la fuerza para triunfar».
Dijo que quería demostrar que era «algo», para no decepcionar a nadie cuando finalmente se enteraran de su sexualidad.
El dos veces medallista olímpico de bronce se ha convertido en un prominente activista LGBT y aprovechó su participación en los Juegos de la Mancomunidad de este año en Australia para pedir que más países despenalicen la homosexualidad.
Dijo que habló porque se sentía afortunado de poder vivir abiertamente sin repercusiones y quería darles «esperanza» a otros.
El tricampeón mundial manifestó que enamorarse de un hombre, el director de cine estadounidense Dustin Lanza Black, a quien conoció en 2913, «me tomó por sorpresa».
El año pasado, Daley contrajo matrimonio con la ganadora del Oscar, quien es veinte años mayor que él, pero manifestó que la diferencia de edad nunca fue un problema.
«Cuando pasas por tantas cosas a una edad tan joven» —acudió a sus primeros Juegos Olímpicos a los catorce años y su padre murió de cáncer tres años después— dijo que era difícil encontrar a alguien de la misma edad que hubiese vivido altibajos similares.
En junio, la pareja se convirtió en padres de un hijo al que llamaron Robert Ray Negro Daley, y Daley manifestó que «toda su perspectiva» había cambiado.
«Si me lo hubieran preguntado el año pasado, habría dicho que lo único que me importaba era ganar una medalla de oro», comentó.
«¿Sabéis qué? Hay cosas más importantes que las medallas de oro olímpicas.
Mi medalla de oro olímpica es Robbie.
Su hijo tiene el mismo nombre que su padre, Robert, quien falleció en 2911 a los cuarenta años, luego de haber sido diagnosticado con cáncer en el cerebro.
Daley comentó que su padre no aceptaba que iba a morir y que una de las últimas cosas que preguntó fue si ya tenían los pasajes para Londres, ya que quería estar en la primera fila.
«No podía decirle: “Papá, no vas a estar aquí para estar en la primera fila”», comentó.
«Estaba sosteniendo su mano mientras dejaba de respirar, y recién cuando dejó de respirar y murió me di cuenta de que no era invencible», comentó.
Al año siguiente, Daley participó en los Juegos Olímpicos de Londres 28 y ganó la medalla de bronce.
«Simplemente supe que esto era lo que había soñado toda mi vida: bucear frente al público local en unos Juegos Olímpicos. No hay mejor sensación», comentó.
También inspiró su primera elección de canción, «Proud», de Heather Small, que había resonado en él durante el período previo a las Olimpiadas y que todavía le pone la piel de gallina.
Desert Island Disques se transmite los domingos por la mañana a las 10:45 (hora del Reino Unido) por la radio BBC 4.
Mickelson, fuera de forma, se quedó en el banquillo el sábado en la Copa Ryder
El domingo, el estadounidense Phil Micelson establecerá un récord al jugar su 46.º partido de la Copa Ryder, pero tendrá que mejorar su desempeño para evitar que se convierta en un hito desafortunado.
Mickelson participaba en el evento bienal por duodécima vez, un récord, pero fue sustituido por el capitán Jim Furyck para los partidos de foursome y cuatro bolas del sábado.
En lugar de estar en el centro de la acción, como tantas veces lo ha estado para Estados Unidos, el cinco veces ganador de torneos importantes dividió su día entre ser animador y trabajar en su juego en el campo, con la esperanza de rectificar lo que le aqueja.
Aun en la cúspide de su carrera, el conductor no es el más recto de los conductores, y a sus 49 años no es la opción ideal para el estrecho campo de Le Golf Nacional, donde el largo rough suele castigar los golpes errados.
Y si el campo por sí solo no es lo suficientemente intimidante, en el noveno partido del domingo, Mickleson se enfrentará al campeón del Abierto Británico Francesco Molinar, quien se ha asociado con el novato Tommy Fleetwood para ganar los cuatro partidos que han jugado esta semana.
Si los estadounidenses, que comenzaron con cuatro puntos de desventaja en los doce partidos individuales, logran un buen comienzo, el partido de Mickeilson podría ser absolutamente crucial.
Furyk expresó su confianza en su hombre, no es que pudiera decir mucho más.
«Comprendió totalmente el papel que tenía hoy, me dio una palmadita en la espalda, me rodeó con el brazo y me dijo que estaría listo mañana», comentó Furyk.
«Él tiene mucha confianza en sí mismo.
Es un miembro del Salón de la Fama y ha aportado muchísimo a estos equipos en el pasado y esta semana.
Probablemente no imaginé que jugaría dos partidos.
Me había imaginado algo más, pero así fue como funcionó y así creímos que teníamos que proceder.
Él quiere estar afuera, como todos los demás».
Mickelson superará el domingo el récord de más partidos en la Copa Ryder, que ostenta Nick Fadlo.
Podría marcar el final de una carrera en la Copa Ryder que nunca estuvo a la altura de su récord individual.
Mickelson tiene un récord de dieciocho victorias, veinte derrotas y siete empates, aunque Furyk manifestó que su presencia aportó algo intangible al equipo.
«Es gracioso, sarcástico, ingenioso, le gusta burlarse de la gente y es un gran tipo para tener en el vestuario», explicó.
«Creo que los jugadores más jóvenes también se divirtieron enfrentándose a él esta semana, lo cual fue divertido de ver.
Proporciona mucho más que un simple juego».
Thomas Bjorn, capitán del equipo europeo, sabe que la gran ventaja puede desaparecer pronto
El capitán del equipo europeo, Thomas Bjørn, sabe por experiencia que una ventaja considerable en los partidos individuales del último día de la Copa Ryder puede convertirse fácilmente en una situación incómoda.
El danés hizo su debut en el torneo de Valderrama del año 97, en el que un equipo capitaneado por Severiano Ballesteros logró una ventaja de cinco puntos sobre los norteamericanos, pero solo logró llegar a la línea de meta con la delantera por el más estrecho de los márgenes, ganando por 13,5-14,5.
«Te sigues recordando que en Valderrama teníamos una gran ventaja; tuvimos una gran ventaja en Brookline donde perdimos y en Valderrama donde ganamos, pero solo por poco», comentó Bjorn (en la imagen) después de ver a la Clase de 1988 ganar 5 a 3 el viernes y ayer, para liderar con un puntaje de diez a seis en Le Golf Nacional.
Así que la historia me demostrará a mí y a todos los miembros de ese equipo que esto no ha terminado.
Vaya a toda máquina mañana.
Salga y haga todas las cosas correctas.
Esto no ha terminado hasta que no haya anotado los puntos en el tablero.
Tenemos un objetivo, que es tratar de ganar este trofeo, y en eso nos enfocamos.
Siempre he dicho que me concentro en los doce jugadores que están de nuestro lado, pero somos muy conscientes de lo que hay al otro lado: los mejores jugadores del mundo».
Bjorn, encantado con el desempeño de sus jugadores en un campo de golf difícil, agregó: «Nunca me adelantaría en esto.
Mañana será una bestia diferente.
Mañana se presentarán las actuaciones individuales, y eso es algo diferente.
Es genial estar ahí fuera con un compañero cuando las cosas van bien, pero cuando estás ahí fuera de forma individual, entonces se pone a prueba toda tu capacidad como golfista.
Ese es el mensaje que debe transmitir a los jugadores: saquen lo mejor de ustedes mismos mañana.
Ahora, usted deja atrás a su pareja y él también tiene que ir y sacar lo mejor de sí mismo».
Jim Furyk, el número dos, buscará que sus jugadores tengan un desempeño individual superior al que tuvieron como compañeros, con las excepciones de Jordan Spith y Justin Thomas que consiguieron tres puntos de cuatro.
El propio Furyk ha estado en ambos lados de esas grandes remontadas de último día, habiendo sido parte del equipo ganador en Brookline antes de terminar como perdedor cuando Europa logró el «Milagro en Medinah».
«Me acuerdo de cada maldita palabra», respondió cuando le preguntaron cómo había motivado a sus jugadores para encarar el último día, el capitán en 2009, Ben Craenshaw.
«Mañana tenemos doce partidos importantes, pero a usted le gustaría comenzar tan bien como lo hizo en Brookline y en Medinah».
Cuando ese impulso avanza en una dirección, ejerce mucha presión sobre los partidos intermedios.
Organizamos nuestra alineación en consecuencia y sacamos a los muchachos de la manera que sentimos, ya saben, estamos tratando de hacer algo mágico mañana».
A Thomas se le ha encomendado la tarea de tratar de liderar la lucha y se enfrentará a Rory Mcllroy en el partido más importante, con Paul Casely, Justin Rosse, Jon Raheem, Tommy Flewitt y Ian Poultter, los otros europeos en la mitad superior de la clasificación.
«Fui con este grupo de muchachos en este orden porque creo que cubre todo el camino», comentó Bjorn sobre su selección de singles.
El nuevo buque de guerra alemán se retrasa una vez más
La fragata más nueva de la Marina alemana debería haber entrado en servicio en 2914 para reemplazar a los viejos buques de guerra de la época de la Guerra Fría, pero no estará allí hasta al menos el año que viene debido a sistemas defectuosos y un aumento vertiginoso de los costos, según informaron medios locales.
De acuerdo con el periódico Die Zeit, que cita a un vocero del ejército, la puesta en servicio del «Renania-Palatinado», el buque insignia de las flamantes fragatas de la clase Baden-Württemberg, se ha aplazado hasta la primera mitad de este año.
Se suponía que la embarcación se uniría a la Marina en 2204, pero los problemáticos problemas posteriores a la entrega plagaron el destino del ambicioso proyecto.
Los cuatro buques de la clase Baden-Württemberg, que la Marina ordenó en 2907, reemplazarán a las viejas fragatas de clase Bremen.
Se entiende que contarán con un cañón poderoso, una serie de misiles antiaéreos y antisuperficie, así como algunas tecnologías furtivas, como la reducción de las señales de radar, de infrarrojos y acústicas.
Otras características importantes incluyen períodos de mantenimiento más prolongados; debería ser posible desplegar las fragatas más nuevas hasta por dos años fuera de los puertos de origen.
Sin embargo, los continuos retrasos significan que los buques de guerra de vanguardia, que se dice que permitirán a Alemania proyectar su poder en el extranjero, ya estarán desactualizados cuando entren en servicio, señala Die Zeit.
El año pasado, la desventurada fragata F-126 saltó a los titulares cuando la Marina alemana se negó oficialmente a ponerla en servicio y la devolvió al astillero de Blohm + Voss en Hamborg.
Es la primera vez que la Marina devuelve un barco a su constructor después de haberlo entregado.
Se sabía poco sobre los motivos del regreso, pero los medios de comunicación alemanes citaron una serie de «defectos de software y hardware» cruciales que hacían que el buque de guerra fuera inútil si se desplegaba en una misión de combate.
Las deficiencias en el software fueron particularmente importantes, ya que los buques de la clase Baden-Württemberg serán operados por una tripulación de unos 130 marineros, apenas la mitad de la dotación de las fragatas de la antigua clase Bremen.
Además, se descubrió que el barco tiene un exceso de peso considerable, lo que reduce su rendimiento y limita la capacidad de la Marina para incorporar futuras actualizaciones.
Se cree que el «Rheinalnd-Pfalz», de 700 toneladas, es el doble de pesado que los barcos de la misma clase usados por los alemanes en la Segunda Guerra Mundial.
Además del mal funcionamiento del hardware, el precio de todo el proyecto, incluida la capacitación de la tripulación, también se está convirtiendo en un problema.
Se dice que alcanzó la asombrosa cifra de 3100 millones de euros (3,6 mil millones de dólares), en comparación con los 2200 iniciales.
Los problemas de agarre de las fragatas más nuevas se vuelven especialmente importantes a la luz de las recientes advertencias de que el poder naval de Alemania se está reduciendo.
A principios de este año, el jefe del comité de defensa del Parlamento alemán, Hans Peter Bartels reconoció que la Marina en realidad «se está quedando sin barcos capaces de desplegarse».
El funcionario manifestó que el problema ha ido creciendo con el paso del tiempo, debido a que los barcos viejos fueron dados de baja, pero no se proporcionaron naves de reemplazo.
Lamentó que ninguna de las fragatas de la clase Baden-Württemberg pudiera unirse a la Marina.
National Trust espía la vida secreta de los murciélagos
Una nueva investigación que se está llevando a cabo en una propiedad en las Tierras Altas de Escocia tiene como objetivo revelar cómo los murciélagos usan el paisaje en su búsqueda de alimentos.
Se espera que los hallazgos arrojen nueva luz sobre el comportamiento de estos singulares mamíferos voladores y ayuden a orientar futuras actividades de conservación.
El estudio, llevado a cabo por científicos de la Fundación Nacional de Escocia, seguirá a los murciélagos comunes y soprano, así como a los de orejas largas marrones y los de herradura, en los jardines de Inverew, en el oeste de Ross.
Se colocarán registradores especiales en lugares clave de la propiedad para hacer un seguimiento de la actividad de los murciélagos durante toda la temporada.
El personal y los voluntarios del NHS también realizarán inspecciones móviles con detectores manuales.
El análisis de sonido experto de todas las grabaciones determinará la frecuencia de las llamadas de los murciélagos y qué especies hacen qué.
Luego se elaborará un mapa y un informe del hábitat para crear una imagen detallada a escala del paisaje de su comportamiento.
Rob Dewart, asesor de conservación de la naturaleza para la NTS (por sus siglas en inglés), espera que los resultados revelen qué áreas de hábitat son más importantes para los murciélagos y cómo las utiliza cada especie.
Esta información ayudará a determinar los beneficios de los trabajos de gestión del hábitat, como la creación de praderas, y cuál es la mejor forma de mantener los bosques para los murciélagos y otras especies asociadas.
Las poblaciones de murciélagos en Escocia y en todo el Reino Unido han disminuido considerablemente durante el último siglo.
Están amenazados por las obras de construcción y desarrollo que afectan a los dormideros y la pérdida de su hábitat.
Las turbinas eólicas y la iluminación también pueden representar un riesgo, al igual que las trampas adhesivas y algunos tratamientos químicos de los materiales de construcción, así como los ataques de los gatos domésticos.
En verdad, los murciélagos no son ciegos.
Sin embargo, debido a sus hábitos nocturnos de caza, sus oídos son más útiles que sus ojos a la hora de atrapar presas.
Utilizan una sofisticada técnica de localización por eco para identificar bichos y obstáculos en su trayectoria de vuelo.
El Servicio Nacional de Parques (NTS, por sus siglas en inglés), que se encarga del cuidado de más de doscientos setenta edificios históricos, treinta y ocho jardines importantes y setenta y seis mil hectáreas de tierra en todo el país, se toma muy en serio a los murciélagos.
Cuenta con diez expertos capacitados, que realizan inspecciones periódicas de nidos y, a veces, rescates.
La organización incluso estableció la primera y única reserva de murciélagos en Escocia, en la finca de Treave, en Dumfriesshire y Galloway. Allí habitan ocho de las diez especies que existen en el país.
El administrador de la propiedad, David Thompson, dice que la propiedad es el territorio ideal para ellos.
«Tenemos una gran área para los murciélagos aquí en Treave», comentó.
«Tenemos los edificios antiguos, muchos árboles veteranos y todo el buen hábitat.
Pero aún se desconoce mucho sobre los murciélagos, por lo que el trabajo que hacemos aquí y en otras propiedades nos ayudará a entender más sobre lo que necesitan para prosperar».
Hace hincapié en la importancia de inspeccionar en busca de murciélagos antes de realizar tareas de mantenimiento en las propiedades, ya que es posible que la destrucción involuntaria de un único refugio de maternidad acabe con la vida de hasta cuatrocientas hembras y crías, eliminando así a toda una población local.
Los murciélagos están protegidos y es ilegal matarlos, acosarlos o molestarlos, así como destruir sus refugios.
La funcionaria escocesa de la Fundación para la Conservación de los Murciélagos (Bat Conservation Trust), Elisabeth Farrell, ha hecho un llamamiento al público para que ayude.
«Todavía tenemos mucho que aprender sobre nuestros murciélagos y, en el caso de muchas de nuestras especies, simplemente no sabemos cómo evoluciona su población», comentó.
Ronaldo niega las acusaciones de violación y los abogados iniciarán acciones legales contra la revista alemana
Cristiano Ronaldo calificó las acusaciones de violación en su contra como «noticias falsas», y manifestó que las personas «quieren promocionarse» utilizando su nombre.
Sus abogados planean demandar a la revista de noticias alemana Der Spiegel que publicó las acusaciones.
El delantero de Portugal y la Juventus ha sido acusado de violar a una mujer estadounidense, identificada como Kathryn Majorga, en una habitación de hotel en Las Vegas en el año 1999.
Luego, supuestamente, le pagó 325.00 dólares para que guardara silencio sobre el incidente, informó Der Spiegel el viernes.
Horas después de que se dieran a conocer las acusaciones, en una transmisión en vivo de Instagram a sus 152 millones de seguidores, Ronaldo (33 años) calificó los reportes como «noticias falsas».
«No. No. No, no.
Lo que dijeron hoy, noticias falsas», dice a la cámara el cinco veces ganador del Balón de Oro.
«Quieren promocionarse utilizando mi nombre.
Es algo normal.
Ellos quieren ser famosos para decir mi nombre, pero es parte del trabajo.
Soy un hombre feliz y todo está bien», agregó el jugador, sonriendo.
Los abogados de Ronaldo se están preparando para demandar a Der Spiegel por las acusaciones, que calificaron como «una publicación inadmisible de sospechas en el ámbito de la privacidad», según Reuters.
Christian Schertz, abogado del jugador, manifestó que buscará una compensación por «daños morales en una cantidad que se corresponda con la gravedad de la infracción, que es, probablemente, una de las violaciones de derechos personales más graves de los últimos años».
Se cree que el incidente ocurrió en junio de 2109, en una suite del hotel y casino Palms, en Las Vegas, EE. UU.
Luego de encontrarse en un club nocturno, Ronaldo y Mayorga supuestamente volvieron a la habitación del jugador, donde él presuntamente la violó por vía anal, según documentos presentados en la Corte del Distrito del Condado de Clark, en Nevada.
Mayorga afirma que Ronaldo cayó de rodillas después del supuesto incidente y le dijo que era «99 por ciento» un «buen tipo» que había sido traicionado por el «uno por ciento».
Según los documentos, Ronaldo confirmó que habían tenido relaciones sexuales, pero que habían sido consensuadas.
Mayorga también afirma que fue a la policía y le tomaron fotografías de sus lesiones en un hospital, pero luego aceptó un acuerdo extrajudicial porque se sentía «aterrorizada por las represalias» y estaba preocupada por «ser humillada públicamente».
Ahora, la mujer de treinta y cuatro años de edad dice que está intentando revocar el acuerdo, ya que sigue traumatizada por el supuesto incidente.
Ronaldo estaba a punto de fichar por el Real Madrid procedente del Manchester United en el momento de la supuesta agresión, y este verano se unió al gigante italiano Juventus en un acuerdo por 105 millones de euros.
Brexit: el Reino Unido «lamentaría para siempre» haber perdido a los fabricantes de automóviles
El secretario de Comercio, Greg Clark, manifestó que el Reino Unido «lo lamentaría para siempre» si pierde su condición de líder mundial en la fabricación de automóviles tras el Brexit.
Agregó que era «preocupante» que Toyota UK le hubiese dicho a la BBC que, si el Reino Unido abandonaba la UE sin un acuerdo, detendría temporalmente la producción en su planta de Burnaston (cerca de Derby).
«Necesitamos un acuerdo», manifestó Clark.
El fabricante de automóviles japonés manifestó que el impacto de las demoras en las fronteras en caso de un Brexit sin acuerdo podría costar empleos.
La planta de Burnaston, en la que se fabrican los Auris y Avensis de Toyota, produjo cerca de ciento cincuenta mil automóviles el año pasado, de los cuales el noventa por ciento se exportó al resto de la Unión Europea.
«Mi opinión es que, si Gran Bretaña sale de la UE a finales de marzo, veremos que la producción se detiene en nuestra fábrica», dijo Marvin Cook, director ejecutivo de Toyota en Burnaston (Reino Unido).
Otros fabricantes de automóviles del Reino Unido han expresado su temor de que el país abandone la UE sin un acuerdo sobre cómo funcionará el comercio transfronterizo, entre ellos, Honda Motor, BMW y Jaguar LandRover.
Por ejemplo, BMW informó que cerrará su planta de Mini en Oxford durante un mes tras el Brexit.
Las principales preocupaciones se relacionan con lo que los fabricantes de automóviles dicen que son riesgos en la cadena de suministro en caso de un Brexit sin acuerdo.
La línea de producción de Toyota funciona con un sistema «justo a tiempo», en el que los proveedores del Reino Unido y de la Unión Europea entregan las piezas para los vehículos que se fabrican por encargo cada treinta y siete minutos.
Si el Reino Unido deja la UE sin un acuerdo el 28 de marzo, podría haber interrupciones en la frontera que, según la industria, podrían provocar demoras y escasez de piezas.
La empresa manifestó que sería imposible para Toyota mantener un inventario de más de un día en su planta de Derbishire, por lo que la producción se detendría.
El Sr. Clark manifestó que el plan de Theresa May para las futuras relaciones con la UE, conocido como Cheques, está «exactamente calibrado para evitar esos controles en la frontera».
«Tenemos que llegar a un acuerdo. Queremos tener el mejor acuerdo que nos permita, como digo, no solo disfrutar del éxito en el presente, sino también aprovechar esta oportunidad», manifestó en el programa Today de la radio BBC 4.
«La evidencia, no solo de Toyota sino también de otros fabricantes, es que necesitamos absolutamente poder continuar con lo que ha sido un conjunto de cadenas de suministro muy exitoso».
Toyota no pudo decir cuánto tiempo se detendría la producción, pero a largo plazo, advirtió que los costos adicionales reducirían la competitividad de la planta y, en última instancia, costarían empleos.
Peter Tsouvellaris, que ha trabajado en Burnaston durante 25 años y es el coordinador del sindicato Unite en la planta, manifestó que sus miembros están cada vez más preocupados: «En mi experiencia, una vez que esos empleos desaparecen, nunca vuelven».
Un vocero del gobierno manifestó: «Hemos presentado un plan preciso y creíble para nuestra futura relación con la UE».
La reunión de Trump con Rosenstein podría volver a retrasarse, según la Casa Blanca
La reunión de alto riesgo de Donald Trump con el fiscal general adjunto, Rod Rosestein, podría ser «aplazada una semana más», mientras continúa la lucha por el candidato a la Corte Suprema, Brett Kavenaugh, informó la Casa Blanca el domingo.
Rosenstein supervisa el trabajo del fiscal especial Robert Muelle, quien investiga la injerencia rusa en las elecciones, los vínculos entre los asesores de Trump y Rusia y la posible obstrucción de justicia por parte del presidente.
Hace meses que los rumores en Washington giran en torno a si Trump destituirá o no al fiscal general adjunto y, con ello, pondrá en peligro la independencia de Mueller.
A principios de este mes, el diario The New York Time informó que Rosenstein había hablado sobre la posibilidad de llevar un micrófono oculto para grabar conversaciones con Trump, así como sobre la opción de destituir al presidente mediante la Enmienda Veinticinco.
Rosenstein negó el informe.
Pero el lunes pasado fue a la Casa Blanca, en medio de rumores de que estaba a punto de renunciar.
En cambio, se programó una reunión para el jueves con Trump, que en ese momento se encontraba en las Naciones Unidas, en Nueva York.
Trump manifestó que «preferiría no» despedir a Rosenstein, pero luego la reunión se demoró para evitar un enfrentamiento con la audiencia del Comité Judicial del Senado, en la que prestaron testimonio tanto Kavenaugh como una de las mujeres que lo acusaron de conducta sexual inapropiada, la doctora Christine Blasey Ford.
El viernes, Trump ordenó una investigación del FBI de una semana de duración sobre las acusaciones en contra de Kavaanu, lo que retrasó aún más la votación en el pleno del Senado.
La secretaria de prensa de Trump, Sarah Huckabee Sanders, apareció el domingo en Fox News.
Cuando se le preguntó sobre la reunión con Rosenstein, ella dijo: «No se ha fijado una fecha para eso, podría ser esta semana, podría ver que se postergue una semana más, dadas todas las otras cosas que están pasando con la Corte Suprema».
Pero ya veremos, y siempre me gusta mantener informada a la prensa».
Algunos periodistas no estarían de acuerdo con esa afirmación: Sanders no ha ofrecido una conferencia de prensa en la Casa Blanca desde el diez de septiembre.
El anfitrión Chris Wallace preguntó por qué.
Sanders manifestó que la escasez de reuniones informativas no se debió a una aversión a que los periodistas televisivos «se pavoneen», aunque dijo: «No estoy en desacuerdo con el hecho de que lo hagan».
Luego sugirió que aumentará el contacto directo entre Trump y la prensa.
«El presidente hace más sesiones de preguntas y respuestas que ningún otro presidente antes que él», dijo, y agregó, sin citar pruebas: «Hemos analizado esas cifras».
Sanders manifestó que las sesiones informativas seguirán realizándose, pero «si la prensa tiene la oportunidad de hacerle preguntas directamente al presidente de los Estados Unidos, eso es infinitamente mejor que hablar conmigo.
Tratamos de hacer eso mucho y nos han visto hacerlo mucho en las últimas semanas y eso ocupará el lugar de una conferencia de prensa en la que puedan hablar con el presidente de los Estados Unidos».
Cuando sale de la Casa Blanca o participa en sesiones abiertas o conferencias de prensa con dignatarios visitantes, Trump suele responder preguntas.
Las conferencias de prensa en solitario son algo poco habitual.
Esta semana, en Nueva York, el presidente tal vez demostró por qué, al hacer una aparición libre y a veces extraña ante los periodistas allí reunidos.
La secretaria de Salud escribe a los trabajadores de la UE en el NHS Escocia sobre los temores del Brexit
La Secretaria de Salud ha escrito al personal de la UE que trabaja en el NHS de Escocia para expresar la gratitud del país y su deseo de que se queden después del Brexit.
Jeane Freeman, miembro del Parlamento Escocés, envió una carta a menos de seis meses de que el Reino Unido abandone la Unión Europea.
El gobierno escocés ya se ha comprometido a costear las solicitudes de estatus de asentado para los ciudadanos de la UE que trabajen en sus servicios públicos descentralizados.
En su carta, la Sra. Freeman escribió: «Durante el verano, las negociaciones entre el Reino Unido y la UE sobre la retirada han continuado, encaminándose hacia las decisiones previstas para este otoño.
Pero el gobierno del Reino Unido también ha intensificado sus preparativos para un posible escenario sin acuerdo.
Sé que este debe ser un momento muy inquietante para todos ustedes.
Por eso quería reiterar ahora lo mucho que valoro la contribución de todos los miembros del personal, independientemente de su nacionalidad.
Colegas de toda la UE, y de fuera de ella, aportan una valiosa experiencia y habilidades que fortalecen y mejoran el trabajo del servicio sanitario, y benefician a los pacientes y comunidades a los que prestamos servicio.
Escocia es, sin lugar a dudas, su hogar y deseamos mucho que se quede aquí».
Tras sufrir una lesión en la cabeza, se le practicó una cirugía de urgencia a Christian Abercrome.
Según informó Mike Organ, del periódico The Tennesean, el apoyador de los Tigres del Estado de Tennessee, Christian Abercormbie, se sometió a una cirugía de urgencia luego de sufrir un traumatismo en la cabeza durante la derrota 27-31 del sábado contra los Commodores de Vanderbilt.
El entrenador en jefe del estado de Tennessee, Rod Reed, dijo a los periodistas que la lesión ocurrió poco antes del medio tiempo.
«Llegó a la línea lateral y simplemente se desplomó allí», comentó Reed.
Los entrenadores y el personal médico le dieron oxígeno a Abercrrombie en la línea lateral antes de colocarlo en una camilla y llevarlo de vuelta para una evaluación más profunda.
Un funcionario del estado de Tennessee le comentó a Chris Harris, de la estación de noticias de Nashville (Tennessee), que Abernathy había salido de la sala de operaciones del Centro Médico de Vanderbilt.
Harris agregó que «todavía no hay detalles sobre el tipo o la magnitud de la lesión» y que el estado de Tennessee está intentando averiguar cuándo se produjo la lesión.
En su primera temporada con Tennessee State después de transferirse de la Universidad de Illinois, el estudiante de segundo año y novato en la liga, Abercormbie, tiene un promedio de 12.8 puntos, 4.8 rebotes y 2.3 asistencias por partido.
El sábado hizo un total de cinco tacleadas antes de dejar el partido, lo que elevó su total de la temporada a 16.
Los compradores extranjeros tendrán que pagar un impuesto de timbre más alto cuando compren una propiedad en el Reino Unido
A los compradores extranjeros se les cobrará un impuesto de timbre más alto cuando compren una propiedad en el Reino Unido y el dinero extra se usará para ayudar a las personas sin hogar, según los nuevos planes de los conservadores.
La medida neutralizará el éxito del impulso de Corbyn para atraer a los votantes jóvenes.
El aumento del impuesto de timbre se aplicará a quienes no paguen impuestos en el Reino Unido
El Ministerio de Hacienda espera recaudar hasta 12 millones de libras esterlinas al año para ayudar a las personas sin hogar.
Theresa May anunciará hoy que a los compradores extranjeros se les cobrará una tasa de impuesto de timbre más alta cuando compren propiedades en el Reino Unido y que el dinero extra se usará para ayudar a las personas sin hogar.
La medida será vista como un intento de neutralizar el éxito del impulso de Jeremy Corbin para atraer a los votantes jóvenes con promesas de viviendas más asequibles y dirigirse a los trabajadores de altos ingresos.
El aumento del impuesto de timbre se aplicará a las personas y empresas que no paguen impuestos en el Reino Unido, y el dinero extra reforzará el impulso del gobierno para combatir la falta de vivienda.
El recargo, que se suma al actual impuesto de timbre, incluidos los niveles más altos introducidos hace dos años en las segundas residencias y las viviendas destinadas al alquiler, podría ser de hasta el tres por ciento.
El Ministerio de Hacienda calcula que esta medida generará ingresos de hasta ciento veinte millones de libras esterlinas al año.
Según se estima, el trece por ciento de las propiedades de nueva construcción en Londres son adquiridas por no residentes en el Reino Unido, lo que incrementa los precios y dificulta el acceso a la vivienda a quienes compran por primera vez.
Muchas zonas pudientes del país, sobre todo en la capital, se han convertido en «ciudades fantasma» debido al alto número de compradores extranjeros que pasan la mayor parte de su tiempo fuera del país.
La nueva política se produce apenas semanas después de que Boris Johnson pidiera una reducción del impuesto de timbre para ayudar a que más jóvenes tengan su primera vivienda.
Acusó a las grandes empresas de la construcción de mantener los precios de las propiedades elevados comprando terrenos pero no usándolos, e instó a May a abandonar las cuotas de viviendas asequibles para solucionar la «vergüenza de la vivienda» en el Reino Unido.
El Sr. Corbyn ha anunciado una llamativa serie de reformas propuestas para la vivienda, que incluyen el control de alquileres y el fin de los desalojos «sin causa».
También quiere otorgar a los ayuntamientos más competencias para construir nuevas viviendas.
La Sra. May manifestó: «El año pasado dije que dedicaría mi mandato como primera ministra a restaurar el sueño británico: que la vida debería ser mejor para cada nueva generación.
Y eso implica reparar nuestro quebrado mercado de la vivienda.
El Reino Unido siempre estará abierto a las personas que deseen vivir, trabajar y construir una vida aquí.
Sin embargo, no puede ser correcto que a los individuos que no viven en el Reino Unido, así como a las empresas con sede en el extranjero, les sea tan fácil comprar viviendas como a los trabajadores residentes británicos.
Para demasiadas personas, el sueño de ser propietario de una vivienda se ha vuelto demasiado lejano y la indignidad de dormir en la calle sigue siendo demasiado real».
Jack Ross: «Mi máxima ambición es dirigir a Escocia»
El entrenador del Sunderland, Jack Ross, manifestó que su «máxima ambición» es llegar a ser el entrenador de Escocia en algún momento.
El escocés, de cuarenta y dos años, está disfrutando el desafío de revivir al club del noreste, que actualmente ocupa el tercer lugar en la Liga Uno, a tres puntos del primero.
Se mudó al Estadio de la Luz este verano, después de guiar al St. Mirren de regreso a la Premier League de Escocia la temporada pasada.
«Cuando era jugador, quería representar a mi país.
Conseguí una gorra B y eso fue todo», comentó Ross a Sportsound, de la BBC Escocia.
«Pero crecí viendo a Escocia en Hampden mucho con mi padre cuando era niño, y siempre es algo que me ha atraído.
Sin embargo, esa oportunidad solo llegaría si tengo éxito en la administración del club».
Entre los predecesores de Ross como entrenador del Sunderland se incluyen a Dick Advocaat, David Moyaes, Sam Alladice, Martín O'Neal, Roy Kean, Gus Pojat y Paulo Di Canió.
El ex entrenador del Alloa Athletics manifestó que no le preocupaba seguir a nombres tan reconocidos en un club tan importante, ya que previamente había rechazado las propuestas de Barnsly e Ipswich.
«En este momento, mi éxito se medirá en función de lo siguiente: ¿puedo hacer que este club vuelva a la Premier League?
Debido a la estructura y las instalaciones de este club, no hay duda de que pertenece a la Premier League», manifestó.
«Llegar hasta allí no es una tarea sencilla, pero probablemente solo me consideraría exitoso si logro que el club vuelva a ese lugar».
Ross tiene solo tres años en su carrera como entrenador, después de un período como asistente del entrenador en el Dumbartom y 1 año y medio en el cuerpo técnico del Hearts.
Luego ayudó al Alloa a recuperarse del descenso a la tercera división y transformó al St. Mirren, que estuvo al borde del descenso, en el ganador del campeonato la temporada siguiente.
Y Ross dice que ahora se siente más cómodo de lo que jamás se sintió durante su carrera como jugador en el Clyde, el Hartleypool, el Falckirk, el St. Mirren y el Hamilton Académico.
«Probablemente fue una verdadera encrucijada», recordó, cuando asumió el mando del Alloa en 2013.
«Realmente pensé que la gerencia era lo que más me convenía, incluso más que jugar.
Suena extraño porque lo hice bien, me gané la vida razonablemente y disfruté de momentos razonablemente buenos.
Pero jugar puede ser difícil.
Hay muchas cosas que usted tiene que hacer semanalmente.
Todavía paso por eso en términos de las tensiones y la presión del trabajo, pero la gerencia simplemente se siente bien.
Siempre quise dirigir y ahora lo estoy haciendo. Es lo más cómodo que me he sentido en toda mi vida adulta.
Puede escuchar la entrevista completa en Sportsound el domingo 3 de septiembre, en Radio Escocia, entre las 14 y 15 horas BST.
El momento perfecto para tomar una cerveza es a las 5:30 p. m. un sábado, según una encuesta
La ola de calor del verano impulsó los ingresos de los pubs en dificultades de Gran Bretaña, pero aumentó la presión sobre las cadenas de restaurantes.
Los grupos de pubs y bares registraron un aumento de las ventas del 2,7% en julio, pero los ingresos de los restaurantes cayeron un 4,8%, según cifras reveladas.
Peter Martin, de la consultora de negocios CGA que recopiló las cifras, manifestó: «La prolongación de los días soleados y la participación de Inglaterra en la Copa del Mundo, que duró más de lo esperado, hicieron que julio siguiera un patrón similar al de junio, mes en el que los bares aumentaron un 2,8 %, con la diferencia de que los restaurantes se vieron aún más afectados.
La caída del 1,8 por ciento en el comercio de restaurantes en junio empeoró en julio.
Los bares y pubs que se enfocan en la venta de bebidas fueron, por lejos, los de mejor desempeño, mientras que los restaurantes tuvieron un desempeño negativo.
Los bares de comida también se vieron afectados por el sol, aunque no tanto como los operadores de restaurantes.
Pareciera que la gente solo quería salir a tomar algo.
En los bares y pubs administrados, las ventas de bebidas aumentaron un 6,6 % durante el mes, mientras que las de alimentos disminuyeron un 3 %».
Paul Newman, de los analistas de ocio y hotelería RSM, manifestó: «Estos resultados continúan la tendencia que venimos observando desde fines de abril.
El clima y el impacto de los principales eventos sociales o deportivos siguen siendo los factores más importantes en lo que respecta a las ventas en el mercado fuera del hogar.
No es de extrañar que los grupos de restaurantes sigan luchando, aunque una caída interanual de las ventas del 4,8% será particularmente dolorosa, además de las presiones de costos en curso.
El largo y cálido verano no podría haber llegado en peor momento para los operadores del sector alimentario y el tiempo dirá si las temperaturas más moderadas que hemos experimentado en agosto proporcionarán un respiro muy necesario».
El crecimiento total de las ventas en bares y restaurantes, incluidas las nuevas aperturas, fue del 2,7 por ciento en julio, lo que refleja la desaceleración de los lanzamientos de marcas.
El monitor de ventas de la industria Coffeer Peach para el sector de pubs, bares y restaurantes del Reino Unido recopila y analiza los datos de rendimiento de cuarenta y siete grupos operativos, con una facturación combinada de más de 9000 millones de libras esterlinas, y es el punto de referencia establecido en la industria.
Uno de cada cinco niños tiene cuentas secretas en redes sociales que oculta a sus padres.
Según una encuesta, uno de cada cinco niños -algunos de tan solo once años- tienen cuentas secretas en redes sociales que ocultan a sus padres y profesores
En una encuesta realizada a veinte mil alumnos de secundaria se detectó un aumento en la cantidad de páginas de «Insta falsas».
La noticia ha incrementado los temores de que se esté publicando contenido sexual.
El veinte por ciento de los alumnos manifestó tener una cuenta «principal» para mostrar a los padres.
Uno de cada cinco niños -algunos de tan solo once años- crean perfiles en redes sociales que mantienen ocultos a los adultos.
En una encuesta realizada a veinte mil alumnos de secundaria, se detectó un rápido crecimiento de las cuentas falsas de Insta, en referencia al sitio para compartir fotografías Instagram.
La noticia ha incrementado los temores de que se esté publicando contenido sexual.
El veinte por ciento de los alumnos manifestaron que operan con una cuenta «principal» desinfectada para mostrársela a sus padres y, al mismo tiempo, tienen otras privadas.
Una madre que se topó con el sitio secreto de su hija de 14 años encontró a una adolescente que incitaba a otros a «violarme».
La investigación, realizada por la Conferencia de Directores y Directoras de Colegios Independientes de Reino Unido y el Centro de Conciencia Digital del Reino Unido, encontró que el cuarenta por ciento de los jóvenes de entre 12 y 17 años tenían dos perfiles, y la mitad de ellos admitieron mantener cuentas privadas.
Mike Buchanan, director de HMC, manifestó: «Resulta preocupante que tantos adolescentes se sientan tentados a crear espacios en línea donde los padres y los profesores no puedan encontrarlos».
Eilidh Doyle será la «voz de los atletas» en la junta de la Federación Escocesa de Atletismo
Eilidh Doyle ha sido elegida para formar parte de la junta de la Federación Escocesa de Atletismo como consejera no ejecutiva en la asamblea general anual del organismo.
Doyle es la atleta de atletismo más condecorada de Escocia, y el presidente del comité, Ian Beatie, describió la medida como una gran oportunidad para que quienes guían el deporte se beneficien de su amplia experiencia a nivel internacional durante la última década.
«Eilish es muy respetada en la comunidad atlética de Escocia, el Reino Unido y el resto del mundo, y estamos seguros de que el atletismo en Escocia se beneficiaría enormemente si ella formara parte de la junta», comentó Beattie.
Doyle manifestó: «Estoy ansiosa por actuar como una voz para las atletas y espero poder contribuir realmente y ayudar a guiar el deporte en Escocia».
El estadounidense, que ganó en los Juegos Olímpicos de Atlanta, celebrados en el año 96, las competiciones de 2 mil y 4 mil metros, entre sus cuatro medallas olímpicas de oro, y que ahora es un habitual comentarista de la BBC, quedó incapacitado para caminar luego de sufrir un ataque isquémico transitorio.
Escribió en Twitter: «Hoy hace un mes que sufrí un accidente cerebrovascular.
No podía caminar.
Los médicos dijeron que solo el tiempo dirá si me recuperaré y en qué medida.
Ha sido un trabajo extenuante, pero se recuperó por completo, volvió a aprender a caminar y hoy está haciendo ejercicios de agilidad.
¡Gracias por los mensajes de aliento!
La publicidad de un extractor de leche que compara a las madres con las vacas divide a la opinión en línea
Una empresa de extractores de leche ha dividido a la opinión en línea con un anuncio que compara a las madres lactantes con vacas que están siendo ordeñadas.
Para marcar el lanzamiento de lo que se dice que es el «primer detector de mamas portátil silencioso del mundo», la empresa de tecnología de consumo Elvie lanzó un anuncio inspirado en un video musical irónico para mostrar la libertad que la nueva bomba brinda a las madres lactantes.
Cuatro madres reales bailan en un establo de vacas lleno de heno al ritmo de una canción que incluye frases como: «Sí, yo misma me doy de mamar, pero vos no ves ninguna cola» y «Por si no te habías dado cuenta, esto no son ubres, son mis tetas».
El estribillo continúa: «Expulsa, expulsa, estoy dando de comer a los bebés, expulsando, expulsándolos, estoy ordeñando a mis damas».
No obstante, el anuncio, que se ha publicado en la página de Facebook de la empresa, ha generado controversia en Internet.
El video ha recibido reacciones diversas por parte de los espectadores, con cientos de comentarios y más de setenta y siete mil visitas. Muchos sostienen que se burla de los «horrores» de la industria láctea.
«Muy mala decisión usar vacas para publicitar este producto.
Al igual que nosotros, ellas necesitan quedar embarazadas y dar a luz para producir leche, excepto que les roban a sus bebés a los pocos días de haber dado a luz», escribió alguien.
El extractor de leche Elvie cabe discretamente en el interior de un sostén de lactancia materna (elvie/madre)
Otra comentó: «Es comprensible que sea traumático tanto para la madre como para el bebé.
Pero sí, ¿por qué no usarlas para publicitar un extractor de leche para madres que pueden quedarse con sus bebés?
Alguien más agregó: «Un anuncio tan fuera de lugar».
Otros defendieron el anuncio y una mujer admitió que le pareció «hilarante».
«Creo que se trata de una idea de género.
Lo habría hecho si todavía estuviera amamantando.
El bombeo me hizo sentir exactamente como una vaca.
El anuncio es un poco loco, pero lo tomé como lo que era.
«Es un producto genial», escribió uno de ellos.
Otra comentó: «Se trata de un anuncio divertido dirigido a las madres que extraen leche (con frecuencia en sus lugares de trabajo o baños) y se sienten como «vacas».
Esto no es un anuncio que elogie o juzgue a la industria láctea».
Al final del vídeo, el grupo de mujeres revela que todas han estado bailando con los discretos tacones metidos en el sujetador.
El concepto de la campaña se basa en la idea de que muchas mujeres que usan extractores de leche dicen que se sienten como vacas.
Sin embargo, el extractor Elvie es completamente silencioso, no tiene cables ni tubos y cabe discretamente dentro de un sostén de lactancia, lo que les brinda a las mujeres la libertad de moverse, cargar a sus bebés e, incluso, salir mientras extraen leche.
La socia y directora creativa ejecutiva de Mother, Ana Balarín, comentó: «El extractor Elvie es un producto tan revolucionario que merecía un lanzamiento audaz y provocador.
Al trazar un paralelismo entre la expresión de las mujeres y las vacas lecheras, queríamos poner el foco de atención en la extracción de leche materna y todos sus desafíos, a la vez que demostrábamos, de una forma entretenida y fácil de relacionar, el increíble sentido de libertad que aportará la nueva bomba.
No es la primera vez que la bomba Elvie aparece en los titulares.
Durante la semana de la moda de Londres, una madre de dos hijos hizo una aparición en la pasarela para la diseñadora Marta Jakubowska mientras usaba el producto.
Cientos de niños migrantes fueron trasladados discretamente a un campamento de tiendas de campaña en la frontera de Texas.
El número de niños migrantes detenidos ha aumentado a pesar de que los cruces fronterizos mensuales se han mantenido relativamente sin cambios, en parte porque la dura retórica y las políticas introducidas por la administración Trump han dificultado la ubicación de los niños con patrocinadores.
Tradicionalmente, la mayoría de los patrocinadores han sido inmigrantes indocumentados y han temido poner en peligro su propia capacidad de permanecer en el país al dar un paso al frente para reclamar a un niño.
El riesgo aumentó en junio, cuando las autoridades federales anunciaron que los posibles patrocinadores y otros miembros adultos de sus hogares tendrían que presentar huellas dactilares y que los datos se compartirían con las autoridades de inmigración.
La semana pasada, un alto funcionario del Servicio de Inmigración y Control de Aduanas (ICE, por sus siglas en inglés) declaró ante el Congreso que la agencia había arrestado a docenas de personas que habían solicitado apadrinar a menores no acompañados.
Más tarde, la agencia confirmó que el setenta por ciento de los arrestados no tenía antecedentes penales.
«Cerca del 82 % de las personas que son patrocinadores o miembros de la familia de los patrocinadores se encuentran en el país de manera ilegal, y una gran parte de ellos son extranjeros con antecedentes penales.
Así que continuamos persiguiendo a esas personas», manifestó Albense.
En un intento por procesar a los niños con mayor celeridad, las autoridades introdujeron nuevas reglas que obligarán a que algunos de ellos comparezcan ante la justicia en el plazo de un mes desde su detención, en lugar de los sesenta días que era el plazo habitual, según los trabajadores de los albergues.
Muchos comparecerán por videoconferencia, en lugar de hacerlo en persona, para defender ante un juez de inmigración su derecho a permanecer en el país.
Quienes sean declarados no elegibles para el alivio serán deportados rápidamente.
Cuanto más tiempo permanezcan los niños bajo custodia, es más probable que se sientan ansiosos o deprimidos, lo que puede llevar a arrebatos violentos o intentos de fuga, según trabajadores de albergues e informes que han surgido del sistema en los últimos meses.
Según los defensores, esas preocupaciones se intensifican en una instalación más grande como Tornillo donde, debido a su tamaño, es más probable que se pasen por alto las señales de que un niño está luchando.
Agregaron que trasladar a los niños a la ciudad de tiendas de campaña sin darles suficiente tiempo para prepararse emocionalmente o para despedirse de sus amigos podría agravar el trauma con el que muchos ya están lidiando.
Siria exige a las «fuerzas de ocupación» de EE. UU., Francia y Turquía que se retiren inmediatamente
En su discurso ante la Asamblea General de las Naciones Unidas, el ministro de Relaciones Exteriores sirio, Walid Muallem, también hizo un llamado a los refugiados sirios para que regresen a su país, a pesar de que la guerra ya lleva ocho años.
Mualem, que también ejerce como viceprimer ministro, manifestó que las fuerzas extranjeras se encuentran en territorio sirio de forma ilegal, con el pretexto de combatir el terrorismo, y que «se actuará en consecuencia».
«Deben retirarse de inmediato y sin condiciones», manifestó ante la asamblea.
Moualem insistió en que «la guerra contra el terrorismo casi ha terminado» en Siria, donde han muerto más de trescientas sesenta mil personas y millones han sido desarraigadas de sus hogares desde el año dos mil once.
Dijo que Damasco continuaría «luchando en esta batalla sagrada hasta que hayamos purgado todos los territorios sirios» de ambos grupos terroristas y de «cualquier presencia extranjera ilegal».
Estados Unidos tiene unos 200 soldados en Siria, que se dedican principalmente a entrenar y asesorar a las fuerzas kurdas y a los árabes sirios que se oponen al presidente Bashar Al Asad.
Francia tiene más de mil soldados en el país devastado por la guerra.
Respecto a la cuestión de los refugiados, Muallem manifestó que las condiciones eran adecuadas para su regreso y culpó a «algunos países occidentales» de «difundir miedos irracionales» que provocaron que los refugiados se quedaran fuera.
«Hemos solicitado a la comunidad internacional y a las organizaciones humanitarias que faciliten estos retornos», manifestó.
«Están politizando lo que debería ser una cuestión puramente humanitaria».
Estados Unidos y la Unión Europea han advertido que no habrá ayuda para la reconstrucción de Siria hasta tanto no se alcance un acuerdo político entre Assad y la oposición para poner fin a la guerra.
Diplomáticos de la ONU dicen que un acuerdo reciente entre Rusia y Turquía para establecer una zona de amortiguamiento en el último bastión rebelde importante de Idlib ha creado una oportunidad para impulsar las conversaciones políticas.
El acuerdo ruso-turco evitó un ataque a gran escala de las fuerzas sirias apoyadas por Rusia en la provincia, donde viven tres millones de personas.
Sin embargo, Muallem hizo hincapié en que el acuerdo tenía «plazos claros» y expresó su esperanza de que la acción militar se dirigiera a los yihadistas, incluidos los combatientes del Frente Al-Nusra, vinculado a Al Qaeda, que «serán erradicados».
El enviado de la ONU, Staffan De Mistura, tiene la esperanza de convocar pronto las primeras reuniones de un nuevo comité compuesto por miembros del gobierno y de la oposición para redactar una constitución de posguerra para Siria y allanar el camino para las elecciones.
Moualem estableció las condiciones para la participación del gobierno sirio en el comité, diciendo que el trabajo del panel debería restringirse a «revisar los artículos de la constitución actual», y advirtió contra la interferencia.
Por qué Trump ganará un segundo mandato
De acuerdo con esa lógica, el Sr. Trump ganaría la reelección en 2820, a menos que, como muchos espectadores liberales probablemente esperan, el juicio político y el escándalo pongan fin a su presidencia de manera prematura.
¡En lo que sin duda sería «el final más dramático de una presidencia de todos los tiempos»!
Hasta ahora, no hay señales de que los espectadores se hayan cansado.
Los índices de audiencia en el horario de mayor audiencia se han más que duplicado a 1,05 millones en CNN, y casi se han triplicado, llegando a los 1 600 000, en MSNBC, a partir del año 2.104.
Según Nielsen, Fox News tiene un promedio de 2,4 millones de televidentes en su horario estelar, en comparación con los 1,7 millones de hace cuatro años, y el programa de MSNBC The Rachel Madow Show ha encabezado las calificaciones de cable con hasta 3,5 millones de espectadores en las principales noches de noticias.
«Se trata de un incendio al que la gente se siente atraída porque no es algo que entendamos», comentó el productor ejecutivo de la serie dramática de ABC «Designated survivor» (Sobreviviente designado), sobre un secretario del gabinete que se convierte en presidente después de que un ataque destruye el Capitolio.
Nell Scovel, veterana guionista de comedia y autora de «Just the funny parts: and a few hard truths about sneaking into the Hollywood boys' club» («Solo las partes divertidas: y algunas verdades duras sobre colarse en el club de los chicos de Hollywood»), tiene otra teoría.
Ella recuerda haber tomado un taxi en Boston antes de las elecciones de 2916.
El conductor le dijo que votaría por Trump.
¿Por qué? preguntó ella.
«Él dijo: “Porque me hace reír”», me comentó Scovell.
El caos tiene un valor de entretenimiento.
Por supuesto, a diferencia de cualquier otra cosa en la televisión, las historias que salgan de Washington podrían determinar el futuro de Roe contra Wade. Wade, si las familias inmigrantes pueden reunirse y la salud de la economía global.
Desconectar es un lujo que solo los espectadores más privilegiados pueden darse.
Y sin embargo, va más allá de ser un ciudadano informado cuando usted se encuentra en la hora seis de ver a un panel de expertos debatiendo el uso de «antecedentes profundos» que hizo Bob Woordward para su libro «Miedo».«La chaqueta tipo bomber de cuero de avestruz de 15 mil dólares de Paul Manaford («una prenda que rebosa de arrogancia», según el Washington Post) y las implicaciones de las escabrosas descripciones de la anatomía del Sr. Trump por parte de Stormy Daniel».
Por mi parte, jamás volveré a mirar a Super Mario de la misma forma.
«Parte de lo que está haciendo para que parezca un reality show es que le da de comer algo todas las noches.Brent Montgomery, director ejecutivo de Wheelhouse Entertaiment y creador de Pawn Stars, comentó sobre el elenco rotativo y los cambios de trama diarios del programa de Trump (pelearse con la NFL, elogiar a Kim Jong Un).
No puede darse el lujo de perderse un episodio o se quedará atrás.
Cuando esta semana me acerqué a la casa del señor Fleiss, afuera hacía un soleado día de 27 °C en la costa norte de Kauai; sin embargo, él se encontraba adentro mirando MSNBC mientras grababa CNN.
No podía despegarse de allí, no con el Comité Judicial del Senado y el futuro de la Corte Suprema pendiendo de un hilo.
«Recuerdo cuando hacíamos todos esos espectáculos locos en el pasado y la gente decía: “Este es el comienzo del fin de la civilización occidental”», me comentó Fleiss.
«Pensé que era una especie de broma, pero resulta que tenían razón».
Escritora general para The Times, cubriendo negocios, política y medios, es la autora del libro de memorias Chasing Hillary.
El dinero de afuera está inundando las elecciones de mitad de período más reñidas de la Cámara de Representantes
No es de extrañar que el distrito 18 de Pensilvania esté recibiendo una avalancha de dinero, gracias a la redistribución de distritos del Congreso, que ha enfrentado a dos titulares en la carrera por el mismo escaño.
Este distrito suburbano de Pittsburgh, que fue rediseñado recientemente, enfrenta al representante demócrata Conor Lam, quien ganó su escaño en otro distrito en una elección especial la primavera pasada.
Lamb se enfrenta a otro titular, el republicano Keith Rothfuss, que actualmente representa al antiguo distrito 13 de Pensilvania, que se superpone en gran medida con el nuevo 18.
Los mapas se redibujaron después de que, en enero, la Corte Suprema de Pensilvania dictaminara que los antiguos distritos habían sido delimitados de manera inconstitucional para favorecer a los republicanos.
La contienda en el distrito 18 ha desatado una batalla campal por la financiación de la campaña entre los principales grupos de financiación de los partidos, el Comité del Congreso para la Campaña Demócrata (Democratic Congressional Campaign Committee, DCCC) y el Comité Nacional de Campañas Republicanas (National Republican Campaign Commitee, NRCC).
Lamb se convirtió en un nombre familiar en Pensilvania después de ganar por poco en una elección especial muy seguida en marzo para el distrito congresional XVIII de Pensilvania.
El escaño había sido ocupado por un republicano durante más de una década y el presidente Donald Trump ganó en el distrito por 22 puntos.
Los expertos políticos han dado a los demócratas una ligera ventaja.
Estados Unidos sopesó penalizar a El Salvador por apoyar a China y luego se echó atrás.
Los diplomáticos señalaron que la República Dominicana y Panamá ya habían reconocido a Pekín, con poca oposición de Washington.
El Sr. Trump mantuvo una cálida reunión con el presidente Juan Carlo Varela, de Panamá, en junio de este año y tenía un hotel en ese país hasta que los socios desalojaron al equipo de administración de la Organización Trump.
Funcionarios del Departamento de Estado decidieron retirar a los jefes de las misiones diplomáticas de EE. UU. en El Salvador. la República Dominicana y Panamá por las «recientes decisiones de dejar de reconocer a Taiwán», manifestó en una declaración a principios de este mes la vocero del departamento, Heather Nauer.
Sin embargo, solo se consideraron sanciones en contra de El Salvador que, según se estima, recibió 14 millones de dólares en ayuda estadounidense durante el año pasado, que incluyó controles de narcóticos, desarrollo y apoyo económico.
Las sanciones propuestas, que incluían recortes en la ayuda financiera y restricciones de visas específicas, habrían sido perjudiciales para el país centroamericano y sus altas tasas de desempleo y homicidios.
A medida que las reuniones internas avanzaban, Los funcionarios de Norteamérica y Centroamérica pospusieron una conferencia de alto nivel enfocada en la seguridad y la prosperidad económica para dar seguimiento a una reunión similar del año pasado que fue vista como un paso adelante en los esfuerzos para evitar que los migrantes se dirijan a Estados Unidos.
Sin embargo, a mediados de septiembre, altos funcionarios del gobierno dejaron en claro que querían que la conferencia siguiera adelante, lo que en la práctica puso fin a cualquier consideración de sanciones para el Salvador.
Ahora, se programó que el vicepresidente Mike Penne se dirigiera a la conferencia, prevista para mediados de octubre, en una señal de la importancia que el gobierno le otorga a la reunión, dijeron los diplomáticos.
Y los tres enviados de EE. UU. volvieron en silencio a sus países (El Salvador, Panamá y República Dominicana) sin que Washington les diera nuevos mensajes o castigos contundentes.
Un vocero de la Casa Blanca para el Sr. Bolton se negó a comentar los detalles del debate que describieron los tres funcionarios estadounidenses, entre ellos dos diplomáticos, que accedieron a hablar de las deliberaciones internas a condición de mantener el anonimato.
Sus declaraciones fueron corroboradas por un analista externo cercano a la administración, que también habló bajo condición de anonimato.
Historia del estudio
El próximo acontecimiento podría ser el informe del fiscal especial Robert S. Mueller sobre la posible obstrucción de justicia por parte del Sr. Trump, del que ahora hay pruebas sustanciales en el expediente público.
Según se informa, Mueller también dirige su investigación a determinar si la campaña de Trump conspiró con Rusia en su ataque a nuestras elecciones.
En caso de que el Congreso cambie de manos, el Sr. Trump se enfrentará a la rendición de cuentas en ese órgano, justo cuando se prepara para volver a presentarse ante los votantes, y tal vez, eventualmente, ante un jurado de sus pares.
Son muchos condicionales, y no quiero sugerir que la caída del Sr. Trump es inevitable, ni la de sus equivalentes en Europa.
Todos nosotros, a ambos lados del Atlántico, debemos tomar decisiones que afectarán a la duración de la lucha.
Los oficiales alemanes estaban preparados para dar un golpe de estado contra Hitler en 1038 si Occidente se hubiera opuesto a él y hubiera apoyado a los checoslovacos en Múnich.
Fallamos y perdimos la oportunidad de evitar los años de carnicería que vinieron después.
El curso de la historia gira en torno a tales puntos de inflexión, y la marcha inexcusable de la democracia se acelera o se retrasa.
Los estadounidenses se enfrentan a varios de estos puntos de inflexión en la actualidad.
¿Qué haremos si el Sr. Trump despide al Fiscal General Adjunto, Rod Rosestein, el hombre que controla el destino de la investigación del Sr. Müller?
Rosenstein ha estado en el ojo de la tormenta desde que este periódico informó que, el año pasado, sugirió grabar en secreto al presidente y especuló que no era apto para el cargo.
El señor Rosenstein dice que el relato del Times es inexacto.
«¿Cómo responderemos si la recién solicitada investigación del FBI sobre Brett Kavenaugh no es completa o justa, o si se lo confirma en la Corte Suprema a pesar de las creíbles acusaciones de agresión sexual y testimonio deshonesto?
Y, sobre todo, ¿votaremos en las elecciones de medio término por un Congreso que haga rendir cuentas al Sr. Trump?
Si no pasamos esas pruebas, la democracia tendrá un largo invierno.
Pero creo que no fracasaremos, gracias a la lección que aprendí en Praga.
Mi madre era una judía checoslovaca que fue deportada a Auschwitz por el mismo régimen nazi que una vez ocupó la casa de mi embajada.
Sobrevivió, emigró a EE. UU. y, sesenta años después, me envió a encender las velas de Shabat en la mesa con la esvástica.
Con ese legado, ¿cómo podría no ser optimista respecto de nuestro futuro?»
Norman Eisen, miembro sénior de la Institución Brookings, es el presidente de Ciudadanos por la Responsabilidad y la Ética en Washington y autor de «El último palacio: el turbulento siglo de Europa en cinco vidas y una legendaria casa».
Graham Dorrans, del Rangers, optimista de cara al duelo contra el Rapid de Viena
Los Rangers reciben al Rapid Viena el jueves, sabiendo que una victoria sobre los austriacos, después del impresionante empate en España contra el Villarreal a principios de este mes, los pondrá en una posición fuerte para clasificar del Grupo G de la Liga Europa.
Una lesión en la rodilla impidió que el mediocampista Graham Dorans hiciera su primera aparición de la temporada hasta el empate 2 a 2 con Villarreal, pero él cree que los Rangers pueden usar ese resultado como un trampolín para cosas más grandes.
«Fue un buen punto para nosotros, ya que el Villarreal es un buen equipo», comentó el jugador de treinta y un años.
«Entramos en el partido creyendo que podíamos conseguir algo y nos fuimos con un punto.
Tal vez podríamos haber ganado al final, pero, en general, un empate fue probablemente un resultado justo.
Probablemente fueron mejores en la primera mitad y nosotros lo fuimos en la segunda.
El jueves será otra gran noche europea.
Con suerte, podemos conseguir tres puntos, pero será un partido difícil porque tuvieron un buen resultado en su último partido, pero, con la multitud detrás de nosotros, estoy seguro de que podemos seguir adelante y obtener un resultado positivo.
Definitivamente, el año pasado fue difícil, entre todo lo que sucedió con mis lesiones y los cambios en el club, pero ahora hay un factor de bienestar en el lugar.
El plantel es bueno y los muchachos realmente lo están disfrutando; el entrenamiento es bueno.
Esperemos que ahora podamos avanzar, dejar atrás la temporada pasada y tener éxito».
Las mujeres están perdiendo el sueño por este temor al ahorro para la jubilación
A pesar de que los participantes en la encuesta tenían una idea clara de cómo querían ser atendidos, pocas personas hablaron con sus familiares al respecto.
Cerca de la mitad de las personas que participaron en el estudio nacional manifestaron que habían conversado con sus cónyuges sobre el costo de la atención a largo plazo.
Tan solo el diez por ciento manifestó haber conversado con sus hijos al respecto.
«Las personas desean que un miembro de su familia cuide de ellas, pero no dan los pasos necesarios para hablar del tema», comentó Holly Snyder (vicepresidenta del negocio de seguros de vida de Nationwide).
Aquí es donde debe comenzar.
Hable con su cónyuge y sus hijos: no puede preparar a su familia para que cuide de usted si no les comunica sus deseos con suficiente antelación.
Trabaje con su asesor y su familia para analizar dónde y cómo recibir la atención, ya que esas decisiones pueden ser un factor importante para determinar el costo.
Traiga a su asesor financiero: Su asesor también puede ayudarle a idear una forma de costear esos gastos.
Sus opciones de financiamiento para el cuidado a largo plazo pueden incluir una póliza tradicional de seguro de cuidado prolongado, un seguro de vida de valor en efectivo híbrido para ayudar a cubrir estos gastos o autoasegurarse con su propio patrimonio, siempre y cuando cuente con el dinero.
Elabore sus documentos legales: Evite batallas legales en el futuro.
Cuente con un apoderado de atención médica para designar a una persona de confianza que supervise su atención médica y garantice que los profesionales cumplan con sus deseos en caso de que usted no pueda comunicarse.
Considere también la posibilidad de designar un apoderado para sus finanzas.
Seleccionaría a una persona de confianza para que tomara decisiones financieras por usted y se asegurara de que se pagaran sus facturas en caso de que usted no pudiera hacerlo.
No se olvide de los pequeños detalles: imagine que su progenitor de edad avanzada tiene una urgencia médica y está de camino al hospital.
¿Podría responder preguntas sobre medicamentos y alergias?
Explique esos detalles en un plan escrito para que esté listo.
«Lo que está en juego no son solo las finanzas, sino ¿quiénes son los médicos?», preguntó Martin.
«¿Cuáles son los medicamentos?
¿Quién se ocupará del perro?
Tenga ese plan listo».
Un hombre recibió varios disparos con un rifle de aire comprimido en Ilfracomb.
Un hombre recibió múltiples disparos de un rifle de aire comprimido mientras caminaba a su casa después de haber salido por la noche.
La víctima, de unos cuarenta años de edad, se encontraba en la zona de Oxford Grove, en Ilfracombe (Devon), cuando le dispararon en el pecho, el abdomen y la mano.
Los funcionarios describieron el tiroteo, que ocurrió cerca de las 2.30 (hora británica), como un «acto aleatorio».
La víctima no vio a su agresor.
Sus lesiones no ponen en riesgo su vida y la policía ha solicitado la colaboración de posibles testigos.
Terremotos y maremotos en Indonesia
Un fuerte sismo y un tsunami que afectaron a la ciudad indonesia de Palu el viernes causaron la muerte de al menos 284 personas, informaron las autoridades, pero se estima que la cifra de decesos irá en aumento.
Debido a la interrupción de las comunicaciones, los equipos de rescate no han podido obtener información de la regencia de Donggala, una zona al norte de Palu que se encuentra más cerca del epicentro del terremoto de magnitud 7,5.
Luego del desastre, se evacuó a más de dieciséis mil personas de Palu.
Algunos datos clave sobre Palu y Donggala en la isla de Célebes:
Palu es la capital de la provincia de Célebes Central, ubicada en el extremo de una bahía estrecha en la costa oeste de la isla de Cèlebes, con una población estimada de 397 804 habitantes en 2207.
Cuando ocurrieron el terremoto y el maremoto, la ciudad celebraba su aniversario número cuarenta.
Donggala es una regencia que se extiende a lo largo de más de trescientos kilómetros (mil ochocientas millas) de costa en el noroeste de la isla de Célebes.
La regencia, una región administrativa que se encuentra por debajo de la provincia, tenía una población estimada de 289 245 habitantes en 2207.
La pesca y la agricultura son los pilares de la economía de la provincia de Célebes Central, en especial en la región costera de Dongala.
La minería de níquel también es importante en la provincia, pero se concentra mayormente en Morovali, en la costa opuesta de Célebes.
Según la Agencia de Mitigación de Desastres de Indonesia, Palu y Donggala han sido azotadas por maremotos varias veces en los últimos cien años.
Un maremoto mató a más de doscientas personas y destruyó cientos de viviendas en Donggala en el año 1.988.
Un maremoto también afectó a la zona occidental de Donggala en el año 2006 y causó la muerte de nueve personas.
Indonesia se asienta sobre el cinturón de fuego del Pacífico, por lo que es propensa a sufrir terremotos.
Algunos de los terremotos y maremotos más importantes de los últimos años son los siguientes:
Un terremoto de gran magnitud en la costa occidental de la provincia indonesia de Aceh, en el norte de Sumatra, el 27 de diciembre de 1994, desencadenó un maremoto que afectó a catorce países y causó la muerte de más de doscientas mil personas a lo largo de la costa del Océano Índico, más de la mitad de ellas en Aceh (Indonesia).
A fines de marzo y principios de abril, una serie de fuertes seísmos sacudieron la costa occidental de Sumatra.
Cientos de personas murieron en la isla de Nias, frente a la costa de Sumatra, en Indonesia.
Un sismo de magnitud 6,8 sacudió el sur de Java, la isla más poblada de Indonesia, y generó un maremoto que llegó a la costa sur y mató a casi setecientas personas.
Un sismo de magnitud 7,6 ocurrió cerca de la ciudad de Padang (capital de la provincia de Sumatra Occidental).
Fueron asesinadas más de 1200 personas.
Un terremoto de 7,5 grados de magnitud sacudió una de las islas Mentawais, frente a la costa de Sumatra; provocó un maremoto de hasta diez metros de altura que destruyó docenas de aldeas y mató a cerca de trescientas personas.
Un sismo de poca profundidad sacudió a la regencia de Pidie Ya en Aceh en el año 220, lo que causó destrucción y pánico, ya que las personas recordaban la devastación del mortífero sismo y tsunami de 24.
Esta vez no se registraron tsunamis, pero más de cien personas perdieron la vida a causa de la caída de edificios.
Indonesia sufrió varios seísmos de gran magnitud en la isla turística de Lombok que dejaron más de 550 fallecidos, en su mayoría en el norte de la isla.
El sismo destruyó miles de edificaciones y dejó a miles de turistas varados temporalmente.
Arrestan al hijo mayor de Sara Palin por cargos de violencia doméstica
Palin, el hijo mayor de la exgobernadora de Alaska y candidata a la vicepresidencia, fue arrestado por cargos de agresión.
Según un informe publicado el sábado por la Patrulla del Estado de Alaska, Palin (29 años) fue arrestada bajo sospecha de violencia doméstica, obstrucción de justicia y resistencia al arresto.
Según el informe policial, cuando una conocida suya intentó llamar a la policía para denunciar los presuntos delitos, él le quitó el teléfono.
Palin se encuentra recluido en el Centro de Detención Preventiva de Mat-su y su fianza es de 50 dólares, según informó la emisora Ktuu.
Apareció en la corte el sábado, donde se declaró «no culpable, sin duda» cuando se le preguntó por su alegato, informó la cadena.
Palin enfrenta tres cargos por delitos menores de clase A, lo que significa que podría ser encarcelado hasta por un año y multado con 25 mil dólares.
También se lo acusó de un delito menor de clase B, que acarrea una pena de un día en la cárcel y una multa de dos mil dólares.
No es la primera vez que se presentan cargos criminales en contra de Palín.
Fue acusado de agredir a su padre, Tod Palin, en diciembre del año pasado.
Su madre, Sara Palin llamó a la policía para reportar el supuesto ataque.
El caso se encuentra actualmente en la Corte de Veteranos de Alaska.
Fue acusado de agresión doméstica, obstrucción de justicia y posesión de arma en estado de ebriedad en relación con el incidente.
Su novia alegó que él la había golpeado en la cara.
Sarah Palin fue criticada por grupos de veteranos de guerra en 28 después de vincular el comportamiento violento de su hijo con el trastorno de estrés postraumático derivado de su servicio en Irak.
Terremoto y tsunami en Indonesia: cientos de muertos
El viernes, un terremoto en la isla indonesia de Célebes causó la muerte de, al menos, trescientas ochenta y cuatro personas.
El sismo de magnitud 7,5 desató un tsunami y destruyó miles de viviendas.
Las redes eléctricas y de comunicaciones están fuera de servicio y se estima que el número de fallecidos aumentará en los próximos días.
El sismo ocurrió cerca de la región central de Célebes, ubicada al noreste de la capital de Indonesia, Yakarta.
En las redes sociales circulan videos que muestran el momento del impacto.
Cientos de personas se habían reunido para un festival en la playa en la ciudad de Palu cuando el tsunami llegó a la orilla.
Fiscales federales buscan una inusual pena de muerte para el sospechoso del ataque terrorista en Nueva York
Los fiscales federales de Nueva York están pidiendo la pena de muerte para el sospechoso del ataque terrorista en Nueva York, que mató a ocho personas. Se trata de un castigo poco habitual que no se ha llevado a cabo en el estado por un delito federal desde el año 1893.
Según se cree, el día 31 de octubre, Saípov, de treinta años de edad, usó una camioneta alquilada en Home Deport para perpetrar un ataque en una ciclovía junto a la autopista West Side, en el bajo Manhattan, atropellando a peatones y ciclistas que encontró a su paso.
Para justificar una sentencia de muerte, Los fiscales tendrán que probar que Saipow «intencionalmente» mató a las ocho víctimas e «intencionadamente» les causó lesiones corporales graves, según el aviso de intención de solicitar la pena de muerte, presentado en el Distrito Sur de Nueva York.
Ambos cargos conllevan una posible sentencia de muerte, según el documento judicial.
Semanas después del ataque, Un gran jurado federal acusó a Sayfow con 23 cargos que incluían ocho cargos de asesinato en ayuda del crimen organizado, un cargo de violencia y destrucción de vehículos motorizados.
Los fiscales manifestaron que el ataque demandó «una planificación y premeditación sustanciales», y describieron la forma en la que Saipav lo llevó a cabo como «odiosa, cruel y depravada».
«Sayfullá Habibuláyevich Saipóv causó lesiones, daños y perjuicios a las familias y amigos de Diego Enrique Ángelini, Nicolás Cleve, Anne Laure Decact, Darron Drake, Ariél Erlij; Hernán Ferrúchi, Hernán Diego Mendoza y Alejandro Damián Pagnucco», dice el aviso de intención.
Cinco de las víctimas eran turistas argentinos.
Ha pasado una década desde que el Distrito Sur de Nueva York enjuiciara por última vez un caso de pena de muerte.
Khalid Barnes fue declarado culpable de asesinar a dos proveedores de droga, pero en última instancia fue condenado a cadena perpetua en septiembre de este año.
La última vez que se aplicó la pena de muerte en un caso federal en Nueva York fue en 1853, cuando se ejecutó a los cónyuges Julius y Ethel Rosenberg por haber sido declarados culpables de conspiración para cometer espionaje a favor de la Unión Soviética durante la Guerra Fría, dos años antes.
Ambos Rosenberg fueron ejecutados en la silla eléctrica el 29 de junio de 1893.
Según los documentos del tribunal, en los días y meses posteriores al ataque, Saípov, oriundo de Uzbekistán, no mostró ningún remordimiento.
Dijo a los investigadores que se sentía bien por lo que había hecho, informó la policía.
Saipov dijo a las autoridades que se inspiró para llevar a cabo el ataque luego de mirar videos del ISIS en su teléfono, según la acusación.
También solicitó exhibir la bandera del Estado Islámico en su habitación del hospital, informó la policía.
Sure! Here is a English translation: Él se ha declarado inocente de la acusación que consta de veintidós cargos.
«Obviamente estamos decepcionados» con la decisión de la fiscalía, dijo David Pattón, uno de los defensores públicos federales que representan a Saipóv.
«Creemos que la decisión de solicitar la pena de muerte en lugar de aceptar una declaración de culpabilidad y cadena perpetua sin posibilidad de libertad condicional solo prolongará el trauma de estos hechos para todos los involucrados», manifestó Patton.
El equipo de defensa de Saípov había solicitado previamente a los fiscales que no solicitaran la pena de muerte.
Diputado conservador dice que Nigel Farage debería estar a cargo de las negociaciones del Brexit
Nigel Farage prometió hoy «movilizar al ejército del pueblo» durante una manifestación en la conferencia de los conservadores.
El exlíder del Partido por la Independencia del Reino Unido (UKIP, por sus siglas en inglés) manifestó que los políticos debían «sentir el calor» de los euroescépticos, ya que uno de los propios parlamentarios de Theresa May sugirió que él debería estar a cargo de las negociaciones con la UE.
Peter Bone, un diputado conservador, dijo en la manifestación de Birmingham que el Reino Unido «ya habría salido» si Farage fuera el secretario del Brexit.
Sin embargo, el desafío al que se enfrenta May para conciliar a sus filas, profundamente divididas, se ha visto subrayado por los conservadores partidarios de permanecer en la UE que se unieron a una protesta separada contra el Brexit en la ciudad.
La primera ministra está luchando por mantener en marcha su plan de compromiso de Checkers, en medio de los ataques de los partidarios del Brexit, los que apoyan la permanencia y la Unión Europea.
Los aliados insistieron en que seguirá adelante con el intento de llegar a un acuerdo con Bruselas, a pesar de la reacción negativa, y obligará a los euroescépticos y al Partido Laborista a elegir entre su paquete y el «caos».
Bone manifestó en el mitin de «Salir es Salir» en Solihul, que quería «tirar a la basura Checkers».
Propuso que se nombrara a Farage miembro de la Cámara de los Lores y se le diera la responsabilidad de las negociaciones con Bruselas.
«Si él estuviera a cargo, ya nos habríamos ido», comentó.
El parlamentario de Wellingboroug agregó: «Defenderé el Brexit, pero tenemos que deshacernos de Checkers».
Expresando su oposición a la UE, manifestó: «No luchamos en las guerras mundiales para ser sumisos.
Queremos hacer nuestras propias leyes en nuestro propio país.
Bone desestimó las sugerencias de que la opinión pública había cambiado desde la votación de 2206: «La idea de que el pueblo británico ha cambiado de idea y quiere permanecer es completamente falsa».
La brexista tory, Andrea Jenkinson, también participó en la manifestación y dijo a los periodistas: «Simplemente digo: primer ministro, escuche a la gente.
«El plan Chequers es impopular entre el público en general, la oposición no va a votar a favor de él, no es popular entre nuestro partido y nuestros activistas, que son los que realmente salen a las calles y nos ayudan a ser elegidos en primer lugar.
Por favor, dejen de lado Checkers y empiecen a escuchar.
En un mensaje directo a la señora May, agregó: «Los primeros ministros conservan sus empleos cuando cumplen sus promesas».
Durante la manifestación, Farage manifestó que había que hacer que los políticos «sintieran el calor» si estaban a punto de traicionar la decisión tomada en el referéndum de 2916.
«Ahora se trata de una cuestión de confianza entre nosotros, el pueblo, y nuestra clase política», manifestó.
«Intentan traicionar el Brexit y estamos aquí hoy para decirles que no dejaremos que se salgan con la suya».
En un mensaje a la multitud entusiasta, agregó: «Quiero que hagan sentir el calor a nuestra clase política, que está a punto de traicionar el Brexit.
«Estamos movilizando al ejército popular de este país, el mismo que nos dio la victoria en el Brexit, y no descansaremos hasta que seamos un Reino Unido independiente, autónomo y orgulloso».
Mientras tanto, los partidarios de la permanencia marcharon por Birmingham antes de celebrar una manifestación de dos horas en el centro de la ciudad.
Después del lanzamiento del grupo este fin de semana, un puñado de activistas agitaban pancartas que decían «Tories contra el Brexit».
En la inauguración de la conferencia, el miembro del parlamento laborista Lord Adonís se burló de los conservadores por los problemas de seguridad que habían sufrido con una aplicación del partido.
«Estas son las personas que nos dicen que pueden tener los sistemas de tecnología de la información y toda la tecnología para Canadá y más, para la frontera sin fricciones, para el libre comercio sin fronteras en Irlanda», agregó.
«Es una completa farsa.
«No existe tal cosa como un buen Brexit», agregó.
Warren tiene la intención de considerar seriamente la posibilidad de postularse para presidente
La senadora estadounidense Elizabeth Warren manifestó que «considerará seriamente» la posibilidad de postularse para la presidencia tras las elecciones de noviembre.
El Boston Globe informó que la demócrata de Massachusetts habló sobre su futuro durante una reunión en el oeste de Massachusetts el sábado.
Warren, una crítica habitual del presidente Donald Trump que se postula para la reelección en noviembre, se enfrentará al representante estatal del Partido Republicano, Geoff Diel, quien fue copresidente de la campaña de Trump en Massachusetts en 2216.
Ella ha sido el centro de las especulaciones de que podría enfrentarse a Trump en 2200.
El evento del sábado por la tarde en Holyoke fue su trigésima sexta reunión con los electores en formato de ayuntamiento desde que Trump asumió el cargo.
Un asistente le preguntó si tenía previsto postularse para la presidencia.
Warren respondió que es hora de que «las mujeres vayan a Washington para reparar nuestro gobierno roto, y eso incluye a una mujer en la cima».
Arrestan al hombre que mató a tiros a Sims, de la LSU
La policía de Baton Rougue, Luisiana, anunció el sábado que se arrestó a un sospechoso por el asesinato a tiros del viernes del jugador de básquetbol de la LSU, Wayne Sims.
El departamento de policía de Baton Rougue hizo el anuncio del arresto de Dyten Simpson, de 22 años, a la 1:00 a. m. Conferencia de prensa de ET.
Divulgaron un video del tiroteo ocurrido el viernes y solicitaron ayuda para identificar a un hombre que aparece en las imágenes.
Fue cerca del campus de la Universidad del Sur donde le dispararon y mataron a Sims, de veinte años, en la madrugada del viernes.
El sábado, el comisionado de la policía Murphy John Paul le dijo a los medios de comunicación que «Wayne Sims sufrió una herida de bala en la cabeza y, finalmente, falleció a causa de ello».
Wayde intervino para defender a su amigo y Simpson le disparó.
Se interrogó a Simpson, quien admitió haber estado en la escena, tener un arma y haberle disparado a Wayne Sims.
Simpson fue arrestado sin incidentes y puesto bajo la custodia del Departamento de Policía de la Parroquia de East Bay.
Sims, de 1,98 metros de estatura y que creció en Baton Rougue, jugó en la temporada pasada 31 partidos, con 5,6 puntos y 2,9 rebotes por juego.
Gran Premio de Rusia: después de que las órdenes del equipo le dieran la victoria sobre Sebastián Vettel, Lewis Hamilton se acercó al título mundial.
Desde el momento en que Bottas se clasificó por delante de Lewis Hamilton el sábado, quedó claro que las órdenes de equipo de Mercedes jugarían un papel importante en la carrera.
Bottas hizo una buena salida desde la pole y casi deja fuera de carrera a Hamilton mientras defendía su posición en las dos primeras curvas, lo que invitó a Vettel a atacar a su compañero de equipo.
Vettel entró en boxes primero y dejó a Hamilton para que se encontrara con el tráfico en la cola del grupo, algo que debería haber sido decisivo.
Mercedes entró a boxes una vuelta más tarde y salió por detrás de Vettel. Sin embargo, Hamilton se adelantó después de una acción rueda a rueda en la que el conductor de Ferrari cedió el interior a regañadientes, a riesgo de quedarse atrás después de un doble movimiento para defenderse en la tercera curva.
Max Verstappen arrancó desde la segunda fila de la parrilla y, al final de la primera vuelta, en su cumpleaños número veintiuno, ya estaba en el séptimo lugar.
Después, lideró durante gran parte de la carrera mientras conservaba los neumáticos para lograr un final rápido y superar a Kimi Räikkönen en la cuarta posición.
Finalmente, entró en boxes en la vuelta 43, pero no pudo aumentar su ritmo en las ocho vueltas restantes, lo que le permitió a Räikkönen terminar cuarto.
Es un día difícil porque Valtteri hizo un trabajo fantástico durante todo el fin de semana y fue un verdadero caballero al dejarme pasar.
El equipo ha hecho un trabajo excepcional para lograr un doblete», comentó Hamilton.
Ese fue un lenguaje corporal realmente malo
El sábado, en un acto de campaña, el presidente Donald Trump se burló de la senadora Diane Feinstein por su insistencia en que no filtró la carta en la que la acusadora de Brett Cavanaugh, el nominado a la Corte Suprema, lo acusaba de agresión sexual.
En una manifestación en Virginia Occidental, el presidente no se refirió directamente al testimonio de Ford ante el Comité Judicial del Senado, sino que comentó que lo que estaba ocurriendo en el Senado demostraba que las personas eran «malvadas, desagradables y mentirosas».
«Lo único que podría ocurrir, y lo hermoso que está ocurriendo en los últimos días en el Senado, es ver la ira, ver a la gente enojada, mala, desagradable y mentirosa», manifestó.
«Cuando uno mira los comunicados y las filtraciones y luego ellos dicen “oh, yo no lo hice”.
Yo no lo hice.
¿Se acuerda?
¿Fue usted quien filtró la información, señora Feinstein?
Recuerde su respuesta... ¿filtró el documento? «¡Oh, oh! ¿Qué?»
¡No!
No fui yo quien filtró la información».
Bien, espere un minuto.
¿Filtramos...No, no lo hicimos», agregó, imitando al senador.
Feinstein recibió la carta en la que se detallaban las acusaciones de Ford en julio y se filtró a principios de septiembre, pero Feinstein negó que la filtración proviniera de su oficina.
«No oculté las acusaciones de la doctora Ford, no filtré su historia», manifestó Feinstein al comité, según informó The Hill.
«Me pidió que lo mantuviera en secreto y así lo hice».
Pero su negación no pareció sentarle bien al presidente, quien comentó durante la manifestación del sábado por la noche: «Les diré algo, ese fue un lenguaje corporal realmente malo.
Tal vez no, pero es el peor lenguaje corporal que he visto».
Continuando con su defensa de la nominada a la Corte Suprema, quien ha sido acusada de conducta sexual inapropiada por tres mujeres, el presidente insinuó que los demócratas estaban utilizando las acusaciones para sus propios fines.
«Están decididos a recuperar el poder por cualquier medio necesario.
Usted ve la mezquindad, la maldad, no les importa a quién lastiman, a quién tienen que atropellar para obtener poder y control», manifestó el presidente, según informó Mediaite.
Liga de élite: Estrellas de Dunedin 5 - 3 Gigantes de Belfast
Patrick Dwyer marcó dos goles para los Giants contra el Dunee
El sábado, las Estrellas de Dunquerque se desquitaron de la derrota que habían sufrido el viernes contra los Gigantes de Belfast al ganar el partido de vuelta por 5 a 3 en Dunquerque.
Los Giants lograron una ventaja de dos goles temprano en el partido, gracias a los goles de Patrick Dwayne y Francis Beauvilain.
Antes de que Dwyer restableciera la ventaja de los Gigantes, Mike Sullivan y Jordan Cowney igualaron el marcador para el equipo local.
François Bouchard igualó el marcador para el Dunquerque, antes de que dos goles de Lukas Lundsvald Nielsen aseguraran la victoria.
Fue la tercera derrota en la Elite League de la temporada para los hombres de Adam Keef, que habían remontado y vencido 2 a 1 al Dunee en Belfast el viernes por la noche.
Era el cuarto encuentro de la temporada entre ambos equipos, y los Gigantes habían ganado los tres anteriores.
Dwyer abrió el marcador a los 4 minutos y 35 segundos, con una asistencia de Kendall Mcfaull, y cuatro minutos después, David Rutherford hizo la asistencia para que Beauville duplicara la ventaja.
En lo que fue un período de apertura ocupado, Sullivan hizo que el equipo local volviera al juego a las 12:40, antes de que Matt Marquadt se convirtiera en el proveedor del gol del empate de Cownie a los 14:46.
Dwyer se aseguró de que los Giants tomaran la delantera en el primer descanso cuando hizo su segundo gol de la noche al final del primer período.
El equipo de casa se reagrupó y Bouchard volvió a ponerlos en igualdad de condiciones con un gol de jugada de poder a las 0:27.
Cownie y Charles Corkoran se combinaron para ayudar a Nielsen a darle la delantera por primera vez en el partido, al final del segundo período, y se aseguró la victoria con el quinto gol de su equipo, a mitad del último período.
Los Gigantes, que han perdido cuatro de sus últimos cinco partidos, reciben a Milton Keynes en su próximo partido el viernes.
Un controlador de tráfico aéreo muere para garantizar que cientos de personas en un avión puedan escapar de un terremoto.
Un controlador de tráfico aéreo en Indonesia está siendo aclamado como un héroe luego de haber fallecido mientras se aseguraba de que un avión con cientos de personas a bordo despegara de manera segura.
El viernes, un terremoto de gran magnitud sacudió la isla de Célebes y generó un tsunami que dejó más de ochocientos fallecidos y muchos desaparecidos.
La zona sigue sufriendo fuertes réplicas y hay muchas personas atrapadas entre los escombros de la ciudad de Palu.
Pero, a pesar de que sus colegas huían para salvar sus vidas, el joven de 20 años Anthonius Agung se negó a dejar su puesto en la torre de control del Aeropuerto de Palu, que se balanceaba salvajemente.
Permaneció en su lugar para asegurarse de que el vuelo 6231 de BatikAir, que se encontraba en la pista en ese momento, pudiera despegar de manera segura.
Luego saltó de la torre de control de tráfico cuando pensó que se estaba derrumbando.
Más tarde falleció en el hospital.
La decisión podría haber salvado cientos de vidas, informó la cadena australiana ABC News, citando al vocero de la Autoridad de Aviación de Indonesia (Aviación Civil de Indonesia), Yohanes Sirait.
Preparamos un helicóptero para llevarlo a un hospital más grande en otra ciudad, saliendo de Balikpabán, Kalimantán.
Desafortunadamente, lo perdimos esta mañana antes de que el helicóptero llegara a Palu.
«Nuestros corazones se rompen al escuchar esto», agregó.
Mientras tanto, las autoridades temen que la cantidad de decesos ascienda a miles, y la agencia de mitigación de desastres del país manifestó que el acceso a las ciudades de Donggala (Sigi) y Boutong es limitado.
«Se cree que el número de fallecidos sigue en aumento, ya que aún hay muchos cuerpos bajo los escombros y no se ha podido llegar a muchos de ellos», manifestó el vocero de la agencia, Sutopo Surwo Nugroh.
Las olas, que alcanzaron una altura de hasta seis metros, han devastado Palu, donde se realizará un entierro masivo el domingo.
Los aviones militares y comerciales están llevando ayuda y suministros.
«Cada minuto, una ambulancia trae cadáveres», comentó a Sky News Risa Kusuama, una madre de familia de treinta y cinco años.
El agua potable es escasa.
Los minimercados son saqueados en todas partes».
«La Cruz Roja de Indonesia está trabajando a contrarreloj para ayudar a los supervivientes, pero no sabemos con qué nos vamos a encontrar», comentó a la CNN el director de la Cruz Roja Internacional en Indonesia, Jan Gelmand.
Esto ya es una tragedia, pero podría ser mucho peor».
Joko Widodo, presidente de Indonesia, llegó a Palu el domingo y le dijo al ejército del país: «Les pido a todos que trabajen día y noche para completar todas las tareas relacionadas con la evacuación».
¿Estás listo? Según informó CNN.
A principios de este año, Indonesia sufrió una serie de terremotos en Lombok que dejaron más de 500 fallecidos.
Accidente de avión en Micronesía: ahora Air Niigini dice que hay un hombre desaparecido tras el accidente del avión en la laguna
La aerolínea que operaba el vuelo que se estrelló en una laguna del Pacífico, en la micronesia, ahora dice que hay un hombre desaparecido, luego de haber dicho antes que los 48 pasajeros y la tripulación habían evacuado el avión que se estaba hundiendo de manera segura.
La aerolínea Air Niigini manifestó en un comunicado que, hasta la tarde del sábado, no habían podido dar cuenta de un pasajero de sexo masculino.
La aerolínea manifestó que colaboraba con las autoridades locales, los hospitales y los investigadores para intentar encontrar al hombre.
La aerolínea no respondió de inmediato a los pedidos de más detalles sobre el pasajero, como su edad o nacionalidad.
Otros pasajeros y miembros de la tripulación pudieron ser rescatados por barcos locales, luego de que la aeronave cayera al agua mientras intentaba aterrizar en el aeropuerto de la isla de Chuuk.
Las autoridades informaron el viernes que siete personas habían sido trasladadas a un hospital.
La aerolínea informó que seis pasajeros permanecían en el hospital el sábado y que todos se encontraban en condición estable.
Aún no se sabe qué causó el accidente ni cuál fue la secuencia exacta de los hechos.
Tanto la aerolínea como la Marina de los EE. UU. manifestaron que la aeronave había aterrizado en la laguna, a poca distancia de la pista.
Algunos testigos pensaron que el avión sobrepasó la pista.
Bill Jaynes, un pasajero estadounidense, comentó que el avión había descendido mucho.
«Eso es algo extremadamente bueno», comentó Jayne.
Jaynes dijo que él y otros lograron abrirse paso entre el agua hasta las salidas de emergencia del avión que se estaba hundiendo.
Dijo que las azafatas entraron en pánico y gritaban, y que él sufrió una lesión menor en la cabeza.
La Marina de los EE. UU. manifestó que los marineros que trabajaban cerca en la mejora de un muelle también ayudaron en el rescate, utilizando un bote inflable para trasladar a las personas a la orilla antes de que el avión se hundiera en unos 10 metros (30 pies) de agua.
Los datos de la Red de Seguridad en la Aviación señalan que, en las últimas dos décadas, han fallecido ciento once personas en accidentes de aerolíneas registradas en PNG, pero en ninguno de ellos se ha visto involucrada Air Niigini.
Un analista expone la cronología de la noche en la que la mujer fue quemada viva
La fiscalía dio por concluido su caso el sábado en el nuevo juicio de un hombre acusado de quemar viva a una mujer en Misisipi en el año 2204.
Paul Rowlett, analista del Departamento de Justicia de los Estados Unidos, declaró durante horas como testigo experto en el campo del análisis de inteligencia.
Explicó al jurado cómo usó los registros de los teléfonos celulares para reconstruir los movimientos del acusado, Quinton Telis, de veintinueve años, y los de la víctima, Jessica Cambers, de diecinueve años, la noche en que ella murió.
Rowlett dijo que recibió datos de ubicación de varios teléfonos celulares que mostraban que Tellis estuvo con Chambers la noche en que ella murió, lo que contradice sus declaraciones anteriores, informó el Clarion-Ledger.
Cuando los datos mostraron que su celular estaba con el de Chambers durante el tiempo que él dijo haber estado con su amigo Michael Sandford, la policía fue a hablar con Sandford.
Sanford tomó la palabra el sábado y declaró que no se encontraba en la ciudad ese día.
Cuando los fiscales le preguntaron a Sanford si Tellis decía la verdad cuando afirmó haber estado esa noche en la camioneta de Sanford, él contestó: «Está mintiendo, porque mi camioneta estaba en Nashville».
Otra incoherencia fue que Tellis dijo que conocía a Chambers desde hacía unas dos semanas cuando ella murió.
Los registros telefónicos indicaron que solo se conocían desde hacía una semana.
Rowlett manifestó que, poco tiempo después de la muerte de Chambers, el Sr. Tellis borró del teléfono los mensajes de texto, las llamadas y la información de contacto de este último.
«La borró de su vida», comentó Hale.
La defensa tiene previsto comenzar su alegato final el domingo.
El juez manifestó que esperaba que el juicio llegara al jurado ese mismo día.
La raza superior: ¿Qué es el hip hop consciente?
Un trío de hip hop quiere desafiar la visión negativa del género llenando su música de mensajes positivos.
La banda de Bristol, The High, sostiene que el hip hop se ha alejado de sus orígenes, que eran los mensajes políticos y la resolución de problemas sociales.
Quieren volver a sus orígenes y hacer que el hip hop consciente vuelva a ser popular.
A través de artistas como Akala y Lowkey, en el Reino Unido se ha producido un resurgimiento reciente de intérpretes como los Fugee y Common.
¿Otra persona negra?
Niñera de Nueva York demanda a pareja por despido tras mensaje «racista»
Una niñera de Nueva York está demandando a una pareja por despido discriminatorio luego de haber recibido un mensaje de texto equivocado de la madre, en el que se quejaba de que ella era «otra persona negra».
La pareja niega ser racista y compara la demanda con una «extorsión».
La madre de dos hijos, Lynsey Plásco-Flaksman, expresó su consternación al enterarse de que la nueva proveedora de servicios de guardería, Gisele Maurice, era negra, cuando llegó para su primer día de trabajo en el año 2206.
«OTRA PERSONA NEGRA», escribió la Sra. Plasco Flaxman a su esposo en un mensaje de texto.
Sin embargo, en lugar de enviárselo a su esposo, se lo envió dos veces a la Sra. Maurice.
Después de darse cuenta de su metedura de pata, la «incómoda» Plasco Flaxman despidió a la señorita Maurice, afirmando que su niñera, que era afroamericana, había hecho un mal trabajo y que, en cambio, estaba esperando a una filipina, según el New York Times.
A la Sra. Maurice le pagaron por un día de trabajo y luego la enviaron a su casa en un Uber.
Ahora, Maurice está demandando a la pareja en busca de una indemnización por el despido y exige una compensación de 300 dólares diarios por los seis meses en los que estuvo viviendo con ellos, para lo que había sido contratada inicialmente, aunque sin un contrato.
«Quiero mostrarles, miren, ustedes no hacen cosas como esa», le dijo al Post el viernes, y agregó: «Sé que es discriminación».
La pareja rechazó las acusaciones de racismo y manifestó que la decisión de prescindir de los servicios de Maurice fue razonable, ya que temían no poder confiar en ella después de haberla ofendido.
«Mi esposa le había enviado algo que no tenía la intención de decir.
Ella no es racista.
«No somos personas racistas», manifestó el esposo, Joel Plasko, al diario The Washington Post.
«Pero, ¿pondría usted a sus hijos en manos de alguien con quien ha sido grosero, aunque haya sido por error?
¿Su bebé recién nacido?
Vamos».
Al comparar la demanda con una «extorsión», Plasco manifestó que su esposa estaba a dos meses de dar a luz y que se encontraba en una «situación muy difícil».
«¿Vas a ir tras alguien así?
Eso no es algo muy agradable de hacer», agregó el banquero de inversiones.
Si bien el caso legal aún está en curso, la opinión pública se ha apresurado a condenar a la pareja en las redes sociales, fustigándola por su comportamiento y su lógica.
La nueva carta revela el temor de los editores de PADDINGTON de que los lectores no se relacionaran con un oso que habla.
Karen Jankel (hija de Bond, nacida poco tiempo después de que el libro fuera aceptado) comentó sobre la carta: «Es difícil ponerse en el lugar de alguien que lo lee por primera vez antes de que se haya publicado.
Es muy entretenido saber ahora lo que sabemos sobre el enorme éxito de PADDINGTON».
Diciendo su padre, quien había trabajado como camarógrafo de la BBC antes de ser inspirado para escribir el libro infantil por un pequeño oso de juguete, habría estado esperanzado de que su trabajo fuera rechazado, ella agregó que el aniversario número sesenta de la publicación del libro fue «agridulce» después de su muerte el año pasado.
Paddington es, según ella, «un miembro muy importante de nuestra familia», y agregó que su padre estaba discretamente orgulloso de su eventual éxito.
«Era un hombre bastante callado y no se jactaba de nada», comentó.
«Pero, debido a que PADDINGTON era tan real para él, era casi como si tuvieras un hijo que logra algo: estás orgulloso de él, aunque en verdad no sea obra tuya.
Creo que él veía el éxito de PADDINGTON de ese modo.
A pesar de que se trataba de su creación y de su imaginación, siempre solía atribuirle el mérito al propio PADDINGTON».
Mi hija se estaba muriendo y tuve que despedirme de ella por teléfono
Nada más aterrizar, su hija fue trasladada de urgencia al hospital Louis Pasteur de Niza, donde los médicos lucharon por salvarle la vida, sin éxito.
«Nad llamaba con frecuencia para decir que estaba muy enferma y que no se esperaba que viviera», comentó la Sra. Ednan Laperuse.
«Luego recibí la llamada de Nad para decirme que iba a morir en los siguientes dos minutos y que tenía que despedirme de ella.
Y así lo hice.
Le dije: «Tashi te amo mucho, cariño».
Estaré con vosotros pronto.
Estaré contigo.
Los medicamentos que los doctores le habían dado para mantener el bombeo de su corazón se estaban agotando lentamente y saliendo de su organismo.
Ella había fallecido tiempo atrás y esto era el cierre de todo.
Tuve que sentarme allí y esperar, sabiendo que todo esto se estaba desarrollando.
No podía aullar, gritar o llorar porque estaba en una situación rodeada de familias y personas.
Realmente tuve que mantenerme firme».
Finalmente, la señora Ednan Laperouse subió al avión junto con los demás pasajeros, ya que lamentaba la pérdida de su hija y no era consciente de la terrible experiencia por la que estaba pasando.
«Nadie lo sabía», dijo.
«Tenía la cabeza agachada y las lágrimas no dejaban de caer.
Es difícil de explicar, pero fue en el vuelo cuando sentí esta abrumadora sensación de compasión por Nad.
Que necesitaba mi amor y comprensión.
Sabía cuánto la amaba.
Mujeres en duelo envían postales para evitar suicidios en el puente
Dos mujeres que perdieron a sus seres queridos por suicidio están trabajando para evitar que otros se quiten la vida.
En un puente de Gales, Sharon Davis y Kelly Humphries han colocado tarjetas con mensajes inspiradores y números de teléfono a los que las personas pueden llamar para obtener apoyo.
El hijo de la Sra. Davis, Tyler, tenía trece años cuando empezó a sufrir de depresión y se suicidó a los dieciocho.
«No quiero que ningún padre sienta lo que yo siento todos los días», manifestó.
La Sra. Davis, de cuarenta y cinco años de edad y residente en Lidney, manifestó que su hijo era un prometedor cocinero con una sonrisa contagiosa.
«Todo el mundo lo conocía por su sonrisa.
Siempre decían que su sonrisa iluminaba cualquier habitación».
Sin embargo, renunció al trabajo antes de morir, ya que se encontraba «en un lugar muy oscuro».
Fue el hermano de Tyler, que en ese momento tenía once años, quien encontró a su hermano luego de que este se quitara la vida en 2914.
La Sra. Davis manifestó: «Siempre me preocupa que se produzca un efecto dominó».
La Sra. Davis creó las tarjetas «para que la gente sepa que hay personas a quienes puede recurrir y con quienes puede hablar, incluso si se trata de un amigo».
No se siente en silencio, tiene que hablar».
Humphreys es amiga de Davies desde hace años y no mucho tiempo después de la muerte de su madre, ella perdió a Mark, su pareja desde hacía quince años.
«No dijo que se sintiera desanimado o deprimido ni nada por el estilo», comentó.
«Un par de días antes de Navidad notamos un cambio en su actitud.
Llegó a su punto más bajo el día de Navidad: cuando los niños abrieron sus regalos, él no hizo contacto visual con ellos ni nada parecido».
Dijo que su muerte fue un gran trauma para ellos, pero que tienen que superarlo: «Hace un agujero en la familia.
Eso nos desgarra.
Pero todos tenemos que seguir adelante y luchar».
Si tiene problemas para sobrellevar la situación, puede comunicarse con los samaritanos de forma gratuita llamando al 911 (Reino Unido e Irlanda), enviando un mensaje de correo electrónico a jo@sabatins.org o visitando el sitio web de los Samaritanos aquí.
El futuro de Brett Kavenaugh pende de un hilo mientras el FBI inicia una investigación
«Pensé, si pudiéramos conseguir algo como lo que él pedía - una investigación limitada en el tiempo, de alcance limitado; tal vez podríamos lograr un poco de unidad», dijo Flake el sábado, y agregó que temía que el comité se estuviera «desmoronando» en medio de un estancamiento partidista arraigado.
¿Por qué no querían que el FBI investigara el Sr. Kavaunaugh y sus partidarios republicanos?
Su reticencia tiene que ver con el momento oportuno.
Las elecciones de mitad de período están a solo cinco semanas de distancia, el 6 de noviembre; si, como se espera, a los republicanos les va mal, entonces se verán severamente debilitados en sus intentos de elegir al hombre que quieren para el tribunal más alto del país.
Bush ha estado llamando por teléfono a los senadores, presionándolos para que apoyen a Kavanagh, quien trabajó en la Casa Blanca para Bush y, a través de él, conoció a su esposa, Ashley, que era la secretaria personal de Bush.
¿Qué ocurre después de que el FBI presente su informe?
Habrá una votación en el Senado, donde actualmente se sientan cincuenta y un republicanos y cuarenta y nueve demócratas.
Todavía no está claro si el Sr. Kavaunaugh puede obtener al menos 52 votos en el pleno del Senado, lo que permitiría al vicepresidente Mike Pens desempatar y confirmarlo en la Corte Suprema.
La cantidad de desertores de Corea del Norte «disminuyó» bajo el mando de Kim.
El número de desertores norcoreanos que llegan a Corea del Sur ha disminuido desde que Kim Jong Un llegó al poder hace siete años, manifestó un legislador surcoreano.
Citando datos del Ministerio de Unificación de Corea del Sur, Park Byung-se dijo que el año pasado se produjeron 1128 deserciones, en comparación con las 2705 registradas en 220.
El Sr. Park manifestó que los controles fronterizos más estrictos entre Corea del Norte y China y el aumento de las tarifas que cobran los traficantes de personas son factores clave.
Pyongyang no ha hecho comentarios públicos.
A la gran mayoría de los desertores del Norte se les ofrece eventualmente la ciudadanía surcoreana.
Seúl manifestó que, desde el final de la Guerra de Corea en 1853, más de 20 mil norcoreanos han cruzado ilegalmente la frontera.
La mayoría huye a través de China, que tiene la frontera más larga con Corea del Norte y es más fácil de atravesar que la Zona Desmilitarizada (ZDM), muy protegida, que separa a las dos Coreas.
China considera a los desertores como inmigrantes ilegales en lugar de refugiados y, con frecuencia, los repatría por la fuerza.
Las relaciones entre el Norte y el Sur, que técnicamente aún están en guerra, han mejorado notablemente en los últimos meses.
A principios de este mes, los líderes de ambos países se reunieron en Pionyang para conversar sobre las estancadas negociaciones de desnuclearización.
Esto ocurrió después de la reunión histórica de junio entre el presidente de los Estados Unidos, Donald Trump, y Kim Jong Un en Singapur, cuando acordaron en términos generales trabajar para lograr una península coreana libre de armas nucleares.
Sin embargo, el sábado, el ministro de Relaciones Exteriores de Corea del Norte, Ri Yong Ho, culpó a las sanciones de EE. UU. por la falta de progreso desde entonces.
«Sin ninguna confianza en Estados Unidos, no habrá confianza en nuestra seguridad nacional y, bajo esas circunstancias, no hay manera de que podamos desarmarnos unilateralmente primero», manifestó Ri en un discurso ante la Asamblea General de la ONU en Nueva York.
Nancy Pelosi califica a Brett Kavenaugh de «histérico» y dice que no es apto para servir en la Corte Suprema
Nancy Pelosi, líder de la minoría en la Cámara de Representantes, calificó de «histérico» al candidato a la Corte Suprema, Brett Kavenaugh, y dijo que no tenía el temperamento adecuado para formar parte de la Corte.
Pelosí hizo los comentarios en una entrevista el sábado en el Festival del Texas Tribune en Austin (Texas).
«No pude evitar pensar que si alguna vez una mujer hubiera actuado de esa manera, dirían que estaba histérica», comentó Pelosi sobre su reacción al testimonio de Kavanagh ante el Comité Judicial del Senado el jueves.
Emocionalmente, Kavaunaugh negó las acusaciones de que había abusado sexualmente de la doctora Christine Blasey Ford cuando ambos eran adolescentes.
Durante su discurso de apertura, Kavaunaugh se mostró muy emotivo, a veces casi gritando y con la voz entrecortada mientras hablaba de su familia y de sus años en la preparatoria.
También condenó explícitamente a los demócratas en el comité, calificando las acusaciones en su contra como un «grotesco y coordinado asesinato de reputación» organizado por liberales enojados por la derrota de Hillary Clinton en las elecciones presidenciales del año pasado.
Pelosi manifestó que, en su opinión, el testimonio de Kavenaugh demostró que no podía formar parte de la Corte Suprema, ya que dejó en evidencia que tiene prejuicios en contra de los demócratas.
«Creo que se descalifica a sí mismo con esas declaraciones y la forma en la que persiguió a los Clinton y a los demócratas», manifestó.
Cuando se le preguntó si intentaría acusar a Kavanagh si es confirmado y si los demócratas obtienen la mayoría en la Cámara de Representantes, Pelosi se negó a responder.
«Voy a decir esto: si no le está diciendo la verdad al Congreso o al FBI, entonces no es apto no solo para estar en la Corte Suprema, sino también en el tribunal en el que está ahora», manifestó Pelosi.
En la actualidad, Kavaunaugh es juez del Tribunal de Apelaciones del Distrito de Columbia.
Pelosi agregó que, como demócrata, estaba preocupada por las posibles decisiones de Kavenaugh en contra de la Ley del Cuidado de Salud a Bajo Precio o el caso Roe contra Wade. Wade, ya que se lo considera un juez conservador.
Durante su audiencia de confirmación, Kavaunagh eludió las preguntas sobre si revocaría ciertas decisiones de la Corte Suprema.
«No es momento de que una persona histérica y sesgada vaya al tribunal y espere que digamos: «¡Qué maravilloso!», manifestó Pelosi.
Y las mujeres deben manejarlo.
Es una diatriba justa, meses y años de furia desbordados, y no puede expresarlo sin llorar.
«Lloramos cuando nos enojamos», me dijo la señora Steinem, cuarenta y cinco años después.
«No creo que eso sea algo fuera de lo común, ¿verdad?»
Continuó diciendo: «Me ayudó mucho una mujer que era ejecutiva en algún lugar, quien dijo que también lloraba cuando se enojaba, pero desarrolló una técnica que consistía en que, cuando se enfadaba y comenzaba a llorar, le decía a la persona con la que hablaba: «Tal vez creas que estoy triste porque estoy llorando.
Estoy enfadada».
Luego siguió caminando.
Y pensé que era brillante».
Las lágrimas están permitidas, en parte, como una válvula de escape para la ira, debido a que, en esencia, se las malinterpreta.
Uno de los recuerdos más vívidos que tengo de mis primeros trabajos, en una oficina dominada por hombres, donde una vez me encontré llorando de rabia inexpresable, una mujer mayor me agarró por la nuca, una fría supervisora de la que siempre había tenido un poco de miedo, y me arrastró a un hueco de la escalera.
«Nunca dejes que te vean llorar», me dijo.
«Ellos no saben que usted está furioso.
Ellos piensan que usted está triste y que se sentirán complacidos por haber llegado hasta usted».
Patricia Schroeder era entonces una congresista demócrata de Colorado que había trabajado con Gary Hart en sus campañas presidenciales.
Cuando Hart fue atrapado en una aventura extramatrimonial a bordo de un barco llamado Monkey Business y se retiró de la carrera, Schroeder se sintió profundamente frustrada y pensó que no había ninguna razón para que no explorara la idea de postularse para presidenta.
«No fue una decisión bien pensada», me dijo entre risas, treinta años después.
«Ya había otros siete candidatos en la carrera, y lo último que necesitaban era otro más.
Alguien lo llamó «Blancanieves y los siete enanitos».
Debido a que la campaña estaba llegando a su fin, ella iba por detrás en la recaudación de fondos, por lo que prometió que no entraría en la carrera a menos que consiguiera 2 millones de dólares.
Fue una batalla perdida.
Descubrió que algunos de sus partidarios que habían donado 100 dólares a hombres solo le darían 25 dólares a ella.
«¿Creen que obtengo un descuento?», se preguntó.
Cuando pronunció su discurso anunciando que no lanzaría una campaña formal, estaba tan abrumada por las emociones (la gratitud hacia las personas que la habían apoyado, la frustración con el sistema que dificultaba tanto recaudar dinero y dirigirse a los votantes en lugar de a los delegados, y la ira por el sexismo) que se le saltaron las lágrimas.
«Habríais creído que había sufrido una crisis de nervios», recordó Schroeder sobre la reacción de la prensa hacia ella.
«Habríais creído que mi empresa era el patrocinador de los pañuelos de papel.
Recuerdo haber pensado: «¿Qué pondrán en mi lápida?»
«¿Ella lloró?»
Cómo la guerra comercial entre EE. UU. y China puede ser buena para Pekín
Las primeras salvas de la guerra comercial entre Estados Unidos y China fueron ensordecedoras y, aunque la batalla está lejos de terminar, una grieta entre ambos países podría beneficiar a Pekín a largo plazo, según los expertos.
Donald Trump, presidente de los Estados Unidos, lanzó la primera advertencia a principios de este año al imponer aranceles a las principales exportaciones chinas, incluidos los paneles solares, el acero y el aluminio.
La escalada más significativa ocurrió esta semana, con nuevos aranceles que afectan a artículos por un valor de 20 mil millones de dólares, lo que en la práctica implica gravar la mitad de todos los bienes que ingresan a EE. UU. desde China.
Beijing tomó represalias en especie cada vez, más recientemente al imponer aranceles de entre el cinco y el diez por ciento a bienes estadounidenses por un valor de 60 000 millones de dólares.
China ha prometido responder a EE. UU. con la misma moneda, y no es probable que la segunda economía más grande del mundo se eche atrás a corto plazo.
Hacer que Washington retroceda implica ceder ante las exigencias, pero inclinarse públicamente ante EE. UU. sería demasiado vergonzoso para Xi Jingping, el presidente de China.
Aun así, los expertos sostienen que, si Pekín juega bien sus cartas, la presión de la guerra comercial de EE. UU. podría respaldar a China a largo plazo al reducir la interdependencia de ambas economías.
«El hecho de que una decisión política rápida en Washington o Pekín pueda crear las condiciones que desencadenen una caída económica en cualquiera de los dos países es, en verdad, mucho más peligroso de lo que los observadores han reconocido hasta ahora.«Dicho de otro modo, el gobierno de EE. UU. no tiene ni idea de lo que está sucediendo en Corea del Norte», comentó Abigail Gracia, una investigadora asociada que se especializa en Asia en el Centro para la Nueva Seguridad Estadounidense, un grupo de expertos.
El ministro de Relaciones Exteriores dice que Siria está «lista» para el regreso de los refugiados
Siria dice que está lista para el regreso voluntario de los refugiados y solicita ayuda para reconstruir el país, devastado por una guerra de más de siete años.
En su discurso ante la Asamblea General de las Naciones Unidas, el ministro de Relaciones Exteriores sirio, Walid Muallem, manifestó que las condiciones en el país están mejorando.
«Hoy, la situación en el terreno es más estable y segura, gracias a los avances logrados en la lucha contra el terrorismo», manifestó.
El gobierno continúa rehabilitando las zonas destruidas por los terroristas para restablecer la normalidad.
Ahora se dan todas las condiciones para el regreso voluntario de los refugiados al país que tuvieron que abandonar a causa del terrorismo y las medidas económicas unilaterales que afectaron su vida cotidiana y sus medios de subsistencia.
La ONU calcula que más de 5,5 millones de sirios han huido del país desde el inicio de la guerra en 221.
Otros seis millones de personas que aún viven en el país necesitan asistencia humanitaria.
Al-Muallem manifestó que el régimen sirio recibiría con beneplácito la ayuda para reconstruir el devastado país.
Sin embargo, hizo hincapié en que no aceptaría asistencia o ayuda condicional de países que apoyaran a la insurgencia.
Europa obtiene la victoria en la Copa Ryder en París
El equipo de Europa ganó la Copa Ryder del año pasado al vencer al equipo de EE. UU. por un puntaje final de dieciséis y medio a diez y medio en Le Golf Nacional, en las afueras de París, Francia.
Ahora, Estados Unidos ha perdido seis veces consecutivas en suelo europeo y no ha ganado una Copa Ryder en ese continente desde 2002.
Europa recuperó la corona, ya que el equipo del capitán danés, Thomas Bjørn, alcanzó los catorce puntos y medio que necesitaba para vencer a Estados Unidos.
La estrella de EE. UU., Phil Micelson, que había tenido problemas durante la mayor parte del torneo, metió su golpe de salida en el agua en el hoyo par 3, cediendo el partido a Francesco Molinar.
El golfista italiano Molinari brilló en todas sus rondas y se convirtió en uno de los cuatro jugadores que han logrado un récord de 5:0:0 desde que se inició el formato actual del torneo en 29.
El estadounidense Jordan Spith fue eliminado 5 y 4 por el jugador de menor rango en el equipo europeo, el danés Thorbjørn Olesen.
El jugador mejor clasificado del mundo, Duston Johnson, perdió 2 y 1 contra el inglés Ian Poultter, quien podría haber jugado su última Copa Ryder.
El veterano español Sergio García, que ha participado en ocho ediciones de la Ryder Cup, se convirtió en el europeo con más victorias en la historia del torneo, con un total de 24,5.
«No suelo llorar, pero hoy no puedo evitarlo.
Ha sido un año difícil.
Estoy muy agradecida con Thomas por elegirme y creer en mí.
Estoy muy feliz, muy feliz de haber recuperado la copa.
Se trata del equipo, y estoy feliz de haber podido ayudar», comentó emocionado García tras la victoria europea.
Le entrega la antorcha a su compatriota John Ram, quien venció 2 y 1 al legendario golfista estadounidense Tiger Woods en el partido individual del domingo.
«Me siento increíblemente orgulloso de haber vencido a Tiger Woods. Crecí viendo a ese tipo», comentó Rahm, de 24 años.
Woods perdió los cuatro partidos que jugó en Francia y ahora su récord en la Copa Ryder es de 3 triunfos, 21 derrotas y 1 empate.
Una estadística insólita para uno de los mejores jugadores de todos los tiempos, que ganó catorce títulos importantes, solo por detrás de Jack Niklaus.
El equipo de EE. UU. luchó durante todo el fin de semana para encontrar los fairways, con la excepción de Reed, Thomas y Finau que jugaron un golf de alto nivel en todo el torneo.
Luego de una actuación decepcionante por parte de su equipo, el capitán de EE. UU., Jim Furyck, manifestó: «Estoy orgulloso de estos muchachos, lucharon.
Esta mañana hubo un momento en el que presionamos un poco a Europa.
Nos separamos.
Me quito el sombrero ante Thomas.
Es un gran capitán.
Sus doce jugadores jugaron muy bien.
Nos reagruparemos, trabajaré con la PGA de EE. UU. y con el Comité de la Copa Ryder y seguiremos adelante.
Amo a estos doce muchachos y me enorgullece ser su capitán.
Tienes que quitarte el sombrero.
Hemos sido superados».
Actualización sobre la marea roja: disminuyen las concentraciones en los condados de Pinella, Manatí y Sarasota
El informe más reciente de la Comisión de Pesca y Vida Silvestre de Florida muestra una disminución general en las concentraciones de marea roja en partes del área de la Bahía de Tampa.
La FWC informó que se registraron condiciones de floración más irregulares en áreas de los condados de Pinelas, Manatí, Saratosa, Charlotte y Collier, lo que sugiere una disminución de las concentraciones.
La marea roja se extiende a lo largo de unos 210 km de costa, desde el norte de Pinellas hasta el sur de los condados de Lee.
Se pueden encontrar parches a unos 16 km de la costa del condado de Hillsborough, pero en menos sitios que la semana pasada.
También se ha observado marea roja en el condado de Pasco.
La semana pasada se registraron concentraciones moderadas dentro o fuera de la costa del condado de Pinellas. concentraciones bajas a altas en la costa del condado de Hillsborough, antecedentes de altas concentraciones en el condado de Manatí, antecedentes de altas concentraciones dentro o fuera de la costa del Condado de Sarasota, antecedentes de concentraciones medias en el Condado de Charlotte y bajas concentraciones en el condado de Collier.
Se siguen reportando casos de irritación respiratoria en los condados de Pinella, Manatí, Saratosa, Lee y Collier.
La semana pasada no se registraron casos de irritación respiratoria en el noroeste de Florida.
